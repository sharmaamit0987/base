package com.android.okhttp.internal;

import com.android.okhttp.Address;
import com.android.okhttp.Call;
import com.android.okhttp.Callback;
import com.android.okhttp.ConnectionPool;
import com.android.okhttp.ConnectionSpec;
import com.android.okhttp.Headers.Builder;
import com.android.okhttp.HttpUrl;
import com.android.okhttp.OkHttpClient;
import com.android.okhttp.internal.http.StreamAllocation;
import com.android.okhttp.internal.io.RealConnection;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocket;

public class InternalProxy2 extends Internal {
    private Internal old;

    public InternalProxy2(Internal internal) {
        this.old = internal;
    }

    public void addLenient(Builder builder, String str) {
        this.old.addLenient(builder, str);
    }

    public void addLenient(Builder builder, String str, String str2) {
        this.old.addLenient(builder, str, str2);
    }

    public void setCache(OkHttpClient okHttpClient, InternalCache internalCache) {
        this.old.setCache(okHttpClient, internalCache);
    }

    public InternalCache internalCache(OkHttpClient okHttpClient) {
        return this.old.internalCache(okHttpClient);
    }

    public boolean connectionBecameIdle(ConnectionPool connectionPool, RealConnection realConnection) {
        return this.old.connectionBecameIdle(connectionPool, realConnection);
    }

    public RealConnection get(ConnectionPool connectionPool, Address address, StreamAllocation streamAllocation) {
        return this.old.get(connectionPool, address, streamAllocation);
    }

    public void put(ConnectionPool connectionPool, RealConnection realConnection) {
        this.old.put(connectionPool, realConnection);
    }

    public RouteDatabase routeDatabase(ConnectionPool connectionPool) {
        return this.old.routeDatabase(connectionPool);
    }

    public void callEnqueue(Call call, Callback callback, boolean z) {
        this.old.callEnqueue(call, callback, z);
    }

    public StreamAllocation callEngineGetStreamAllocation(Call call) {
        return this.old.callEngineGetStreamAllocation(call);
    }

    public void apply(ConnectionSpec connectionSpec, SSLSocket sSLSocket, boolean z) {
        this.old.apply(connectionSpec, sSLSocket, z);
    }

    public HttpUrl getHttpUrlChecked(String str) throws MalformedURLException, UnknownHostException {
        return this.old.getHttpUrlChecked(str);
    }
}
