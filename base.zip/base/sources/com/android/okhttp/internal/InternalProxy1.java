package com.android.okhttp.internal;

import com.android.okhttp.Call;
import com.android.okhttp.Callback;
import com.android.okhttp.Connection;
import com.android.okhttp.ConnectionPool;
import com.android.okhttp.ConnectionSpec;
import com.android.okhttp.Headers.Builder;
import com.android.okhttp.HttpUrl;
import com.android.okhttp.OkHttpClient;
import com.android.okhttp.Protocol;
import com.android.okhttp.Request;
import com.android.okhttp.internal.http.HttpEngine;
import com.android.okhttp.internal.http.RouteException;
import com.android.okhttp.internal.http.Transport;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocket;
import okio.BufferedSink;
import okio.BufferedSource;

public class InternalProxy1 extends Internal {
    private Internal old;

    public InternalProxy1(Internal internal) {
        this.old = internal;
    }

    public Transport newTransport(Connection connection, HttpEngine httpEngine) throws IOException {
        return this.old.newTransport(connection, httpEngine);
    }

    public boolean clearOwner(Connection connection) {
        return this.old.clearOwner(connection);
    }

    public void closeIfOwnedBy(Connection connection, Object obj) throws IOException {
        this.old.closeIfOwnedBy(connection, obj);
    }

    public int recycleCount(Connection connection) {
        return this.old.recycleCount(connection);
    }

    public void setProtocol(Connection connection, Protocol protocol) {
        this.old.setProtocol(connection, protocol);
    }

    public void setOwner(Connection connection, HttpEngine httpEngine) {
        this.old.setOwner(connection, httpEngine);
    }

    public boolean isReadable(Connection connection) {
        return this.old.isReadable(connection);
    }

    public void addLenient(Builder builder, String str) {
        this.old.addLenient(builder, str);
    }

    public void addLenient(Builder builder, String str, String str2) {
        this.old.addLenient(builder, str, str2);
    }

    public void setCache(OkHttpClient okHttpClient, InternalCache internalCache) {
        this.old.setCache(okHttpClient, internalCache);
    }

    public InternalCache internalCache(OkHttpClient okHttpClient) {
        return this.old.internalCache(okHttpClient);
    }

    public void recycle(ConnectionPool connectionPool, Connection connection) {
        this.old.recycle(connectionPool, connection);
    }

    public RouteDatabase routeDatabase(OkHttpClient okHttpClient) {
        return this.old.routeDatabase(okHttpClient);
    }

    public Network network(OkHttpClient okHttpClient) {
        return this.old.network(okHttpClient);
    }

    public void setNetwork(OkHttpClient okHttpClient, Network network) {
        this.old.network(okHttpClient);
    }

    public void connectAndSetOwner(OkHttpClient okHttpClient, Connection connection, HttpEngine httpEngine, Request request) throws RouteException {
        this.old.connectAndSetOwner(okHttpClient, connection, httpEngine, request);
    }

    public void callEnqueue(Call call, Callback callback, boolean z) {
        this.old.callEnqueue(call, callback, z);
    }

    public void callEngineReleaseConnection(Call call) throws IOException {
        this.old.callEngineReleaseConnection(call);
    }

    public Connection callEngineGetConnection(Call call) {
        return this.old.callEngineGetConnection(call);
    }

    public BufferedSource connectionRawSource(Connection connection) {
        return this.old.connectionRawSource(connection);
    }

    public BufferedSink connectionRawSink(Connection connection) {
        return this.old.connectionRawSink(connection);
    }

    public void connectionSetOwner(Connection connection, Object obj) {
        this.old.connectionSetOwner(connection, obj);
    }

    public void apply(ConnectionSpec connectionSpec, SSLSocket sSLSocket, boolean z) {
        this.old.apply(connectionSpec, sSLSocket, z);
    }

    public HttpUrl getHttpUrlChecked(String str) throws MalformedURLException, UnknownHostException {
        return this.old.getHttpUrlChecked(str);
    }
}
