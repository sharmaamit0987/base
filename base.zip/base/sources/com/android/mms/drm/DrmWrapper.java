package com.android.mms.drm;

import android.net.Uri;
import java.io.IOException;

public class DrmWrapper {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String LOG_TAG = "DrmWrapper";
    private final byte[] mData;
    private final Uri mDataUri;
    private byte[] mDecryptedData;

    public static boolean isDrmObject(String str) {
        return false;
    }

    public boolean consumeRights() {
        return false;
    }

    public String getContentType() {
        return null;
    }

    public byte[] getDecryptedData() throws IOException {
        return null;
    }

    public String getRightsAddress() {
        return null;
    }

    public void installRights(byte[] bArr) throws IOException {
    }

    public boolean isAllowedToForward() {
        return true;
    }

    public boolean isRightsInstalled() {
        return false;
    }

    public DrmWrapper(String str, Uri uri, byte[] bArr) throws IOException {
        if (str == null || bArr == null) {
            throw new IllegalArgumentException("Content-Type or data may not be null.");
        }
        this.mDataUri = uri;
        this.mData = bArr;
    }

    public Uri getOriginalUri() {
        return this.mDataUri;
    }

    public byte[] getOriginalData() {
        return this.mData;
    }
}
