package com.android.mms.drm;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.util.Log;
import com.google.android.mms.util.SqliteWrapper;
import java.io.IOException;
import java.io.OutputStream;

public class DrmUtils {
    private static final Uri DRM_TEMP_URI = Uri.parse("content://mms/drm");
    private static final String TAG = "DrmUtils";

    private DrmUtils() {
    }

    public static void cleanupStorage(Context context) {
        SqliteWrapper.delete(context, context.getContentResolver(), DRM_TEMP_URI, null, null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0034 A[SYNTHETIC, Splitter:B:17:0x0034] */
    public static Uri insert(Context context, DrmWrapper drmWrapper) throws IOException {
        OutputStream outputStream;
        String str = TAG;
        ContentResolver contentResolver = context.getContentResolver();
        Uri insert = SqliteWrapper.insert(context, contentResolver, DRM_TEMP_URI, new ContentValues(0));
        try {
            outputStream = contentResolver.openOutputStream(insert);
            try {
                byte[] decryptedData = drmWrapper.getDecryptedData();
                if (decryptedData != null) {
                    outputStream.write(decryptedData);
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException e) {
                        Log.e(str, e.getMessage(), e);
                    }
                }
                return insert;
            } catch (Throwable th) {
                th = th;
                if (outputStream != null) {
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            outputStream = null;
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e2) {
                    Log.e(str, e2.getMessage(), e2);
                }
            }
            throw th;
        }
    }
}
