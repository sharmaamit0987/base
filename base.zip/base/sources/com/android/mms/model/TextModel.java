package com.android.mms.model;

import android.content.Context;
import android.util.Log;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.drm.DrmWrapper;
import com.google.android.mms.pdu.CharacterSets;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.w3c.dom.events.Event;

public class TextModel extends RegionMediaModel {
    private static final String TAG = "TextModel";
    private final int mCharset;
    private CharSequence mText;

    public TextModel(Context context, String str, String str2, RegionModel regionModel) {
        this(context, str, str2, 106, new byte[0], regionModel);
    }

    public TextModel(Context context, String str, String str2, int i, byte[] bArr, RegionModel regionModel) {
        super(context, SmilHelper.ELEMENT_TAG_TEXT, str, str2, bArr != null ? bArr : new byte[0], regionModel);
        if (i == 0) {
            i = 4;
        }
        this.mCharset = i;
        this.mText = extractTextFromData(bArr);
    }

    private CharSequence extractTextFromData(byte[] bArr) {
        if (bArr == null) {
            return "";
        }
        try {
            if (this.mCharset == 0) {
                return new String(bArr);
            }
            return new String(bArr, CharacterSets.getMimeName(this.mCharset));
        } catch (UnsupportedEncodingException e) {
            StringBuilder sb = new StringBuilder("Unsupported encoding: ");
            sb.append(this.mCharset);
            Log.e(TAG, sb.toString(), e);
            return new String(bArr);
        }
    }

    public TextModel(Context context, String str, String str2, int i, DrmWrapper drmWrapper, RegionModel regionModel) throws IOException {
        super(context, SmilHelper.ELEMENT_TAG_TEXT, str, str2, drmWrapper, regionModel);
        if (i == 0) {
            i = 4;
        }
        this.mCharset = i;
    }

    public String getText() {
        if (this.mText == null) {
            try {
                this.mText = extractTextFromData(getData());
            } catch (Exception e) {
                Log.e(TAG, e.getMessage(), e);
                this.mText = e.getMessage();
            }
        }
        CharSequence charSequence = this.mText;
        if (!(charSequence instanceof String)) {
            this.mText = charSequence.toString();
        }
        return this.mText.toString();
    }

    public void setText(CharSequence charSequence) {
        this.mText = charSequence;
        notifyModelChanged(true);
    }

    public void cloneText() {
        this.mText = new String(this.mText.toString());
    }

    public int getCharset() {
        return this.mCharset;
    }

    public void handleEvent(Event event) {
        if (event.getType().equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }
}
