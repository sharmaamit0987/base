package com.android.mms.model;

import android.util.Log;
import com.android.mms.layout.LayoutManager;
import com.android.mms.layout.LayoutParameters;
import java.util.ArrayList;
import java.util.Iterator;

public class LayoutModel extends Model {
    private static final boolean DEBUG = false;
    public static final int DEFAULT_LAYOUT_TYPE = 0;
    public static final String IMAGE_REGION_ID = "Image";
    public static final int LAYOUT_BOTTOM_TEXT = 0;
    public static final int LAYOUT_TOP_TEXT = 1;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "LayoutModel";
    public static final String TEXT_REGION_ID = "Text";
    private RegionModel mImageRegion;
    private LayoutParameters mLayoutParams = LayoutManager.getInstance().getLayoutParameters();
    private int mLayoutType = 0;
    private ArrayList<RegionModel> mNonStdRegions;
    private RegionModel mRootLayout;
    private RegionModel mTextRegion;

    public LayoutModel() {
        createDefaultRootLayout();
        createDefaultImageRegion();
        createDefaultTextRegion();
    }

    public LayoutModel(ArrayList<RegionModel> arrayList) {
        this.mRootLayout = (RegionModel) arrayList.get(0);
        this.mNonStdRegions = new ArrayList<>();
        int size = arrayList.size();
        if (size > 1) {
            for (int i = 1; i < size; i++) {
                RegionModel regionModel = (RegionModel) arrayList.get(i);
                String regionId = regionModel.getRegionId();
                if (regionId.equals(IMAGE_REGION_ID)) {
                    this.mImageRegion = regionModel;
                } else if (regionId.equals(TEXT_REGION_ID)) {
                    this.mTextRegion = regionModel;
                } else {
                    this.mNonStdRegions.add(regionModel);
                }
            }
        }
        validateLayouts();
    }

    public LayoutModel(RegionModel regionModel, ArrayList<RegionModel> arrayList) {
        this.mRootLayout = regionModel;
        this.mNonStdRegions = new ArrayList<>();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            RegionModel regionModel2 = (RegionModel) it.next();
            String regionId = regionModel2.getRegionId();
            if (regionId.equals(IMAGE_REGION_ID)) {
                this.mImageRegion = regionModel2;
            } else if (regionId.equals(TEXT_REGION_ID)) {
                this.mTextRegion = regionModel2;
            } else {
                this.mNonStdRegions.add(regionModel2);
            }
        }
        validateLayouts();
    }

    private void createDefaultRootLayout() {
        RegionModel regionModel = new RegionModel(null, 0, 0, this.mLayoutParams.getWidth(), this.mLayoutParams.getHeight());
        this.mRootLayout = regionModel;
    }

    private void createDefaultImageRegion() {
        if (this.mRootLayout != null) {
            RegionModel regionModel = new RegionModel(IMAGE_REGION_ID, 0, 0, this.mRootLayout.getWidth(), this.mLayoutParams.getImageHeight());
            this.mImageRegion = regionModel;
            return;
        }
        throw new IllegalStateException("Root-Layout uninitialized.");
    }

    private void createDefaultTextRegion() {
        if (this.mRootLayout != null) {
            RegionModel regionModel = new RegionModel(TEXT_REGION_ID, 0, this.mLayoutParams.getImageHeight(), this.mRootLayout.getWidth(), this.mLayoutParams.getTextHeight());
            this.mTextRegion = regionModel;
            return;
        }
        throw new IllegalStateException("Root-Layout uninitialized.");
    }

    private void validateLayouts() {
        if (this.mRootLayout == null) {
            createDefaultRootLayout();
        }
        if (this.mImageRegion == null) {
            createDefaultImageRegion();
        }
        if (this.mTextRegion == null) {
            createDefaultTextRegion();
        }
    }

    public RegionModel getRootLayout() {
        return this.mRootLayout;
    }

    public void setRootLayout(RegionModel regionModel) {
        this.mRootLayout = regionModel;
    }

    public RegionModel getImageRegion() {
        return this.mImageRegion;
    }

    public void setImageRegion(RegionModel regionModel) {
        this.mImageRegion = regionModel;
    }

    public RegionModel getTextRegion() {
        return this.mTextRegion;
    }

    public void setTextRegion(RegionModel regionModel) {
        this.mTextRegion = regionModel;
    }

    public ArrayList<RegionModel> getRegions() {
        ArrayList<RegionModel> arrayList = new ArrayList<>();
        RegionModel regionModel = this.mImageRegion;
        if (regionModel != null) {
            arrayList.add(regionModel);
        }
        RegionModel regionModel2 = this.mTextRegion;
        if (regionModel2 != null) {
            arrayList.add(regionModel2);
        }
        return arrayList;
    }

    public RegionModel findRegionById(String str) {
        if (IMAGE_REGION_ID.equals(str)) {
            return this.mImageRegion;
        }
        if (TEXT_REGION_ID.equals(str)) {
            return this.mTextRegion;
        }
        Iterator it = this.mNonStdRegions.iterator();
        while (it.hasNext()) {
            RegionModel regionModel = (RegionModel) it.next();
            if (regionModel.getRegionId().equals(str)) {
                return regionModel;
            }
        }
        return null;
    }

    public int getLayoutWidth() {
        return this.mRootLayout.getWidth();
    }

    public int getLayoutHeight() {
        return this.mRootLayout.getHeight();
    }

    public String getBackgroundColor() {
        return this.mRootLayout.getBackgroundColor();
    }

    public void changeTo(int i) {
        if (this.mRootLayout != null) {
            if (this.mLayoutParams == null) {
                this.mLayoutParams = LayoutManager.getInstance().getLayoutParameters();
            }
            if (this.mLayoutType == i) {
                return;
            }
            if (i == 0) {
                this.mImageRegion.setTop(0);
                this.mTextRegion.setTop(this.mLayoutParams.getImageHeight());
                this.mLayoutType = i;
                notifyModelChanged(true);
            } else if (i != 1) {
                StringBuilder sb = new StringBuilder("Unknown layout type: ");
                sb.append(i);
                Log.w(TAG, sb.toString());
            } else {
                this.mImageRegion.setTop(this.mLayoutParams.getTextHeight());
                this.mTextRegion.setTop(0);
                this.mLayoutType = i;
                notifyModelChanged(true);
            }
        } else {
            throw new IllegalStateException("Root-Layout uninitialized.");
        }
    }

    public int getLayoutType() {
        return this.mLayoutType;
    }

    /* access modifiers changed from: protected */
    public void registerModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        RegionModel regionModel = this.mRootLayout;
        if (regionModel != null) {
            regionModel.registerModelChangedObserver(iModelChangedObserver);
        }
        RegionModel regionModel2 = this.mImageRegion;
        if (regionModel2 != null) {
            regionModel2.registerModelChangedObserver(iModelChangedObserver);
        }
        RegionModel regionModel3 = this.mTextRegion;
        if (regionModel3 != null) {
            regionModel3.registerModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        RegionModel regionModel = this.mRootLayout;
        if (regionModel != null) {
            regionModel.unregisterModelChangedObserver(iModelChangedObserver);
        }
        RegionModel regionModel2 = this.mImageRegion;
        if (regionModel2 != null) {
            regionModel2.unregisterModelChangedObserver(iModelChangedObserver);
        }
        RegionModel regionModel3 = this.mTextRegion;
        if (regionModel3 != null) {
            regionModel3.unregisterModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterAllModelChangedObserversInDescendants() {
        RegionModel regionModel = this.mRootLayout;
        if (regionModel != null) {
            regionModel.unregisterAllModelChangedObservers();
        }
        RegionModel regionModel2 = this.mImageRegion;
        if (regionModel2 != null) {
            regionModel2.unregisterAllModelChangedObservers();
        }
        RegionModel regionModel3 = this.mTextRegion;
        if (regionModel3 != null) {
            regionModel3.unregisterAllModelChangedObservers();
        }
    }

    public boolean hasNonStdRegions() {
        return this.mNonStdRegions.size() > 0;
    }
}
