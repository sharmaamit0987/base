package com.android.mms.model;

import android.content.Context;
import com.android.mms.UnsupportContentTypeException;
import com.android.mms.drm.DrmWrapper;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import java.io.IOException;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

public class MediaModelFactory {
    private static final String TAG = "MediaModelFactory";

    public static MediaModel getMediaModel(Context context, SMILMediaElement sMILMediaElement, LayoutModel layoutModel, PduBody pduBody) throws IOException, IllegalArgumentException, MmsException {
        String tagName = sMILMediaElement.getTagName();
        String src = sMILMediaElement.getSrc();
        PduPart findPart = findPart(pduBody, src);
        if (!(sMILMediaElement instanceof SMILRegionMediaElement)) {
            return getGenericMediaModel(context, tagName, src, sMILMediaElement, findPart, null);
        }
        return getRegionMediaModel(context, tagName, src, (SMILRegionMediaElement) sMILMediaElement, layoutModel, findPart);
    }

    private static PduPart findPart(PduBody pduBody, String str) {
        PduPart pduPart;
        if (str == null) {
            pduPart = null;
        } else if (str.startsWith("cid:")) {
            StringBuilder sb = new StringBuilder("<");
            sb.append(str.substring(4));
            sb.append(">");
            pduPart = pduBody.getPartByContentId(sb.toString());
        } else {
            PduPart partByName = pduBody.getPartByName(str);
            if (partByName == null) {
                partByName = pduBody.getPartByFileName(str);
                if (partByName == null) {
                    pduPart = pduBody.getPartByContentLocation(str);
                }
            }
            pduPart = partByName;
        }
        if (pduPart != null) {
            return pduPart;
        }
        throw new IllegalArgumentException("No part found for the model.");
    }

    private static MediaModel getRegionMediaModel(Context context, String str, String str2, SMILRegionMediaElement sMILRegionMediaElement, LayoutModel layoutModel, PduPart pduPart) throws IOException, MmsException {
        SMILRegionElement region = sMILRegionMediaElement.getRegion();
        if (region != null) {
            RegionModel findRegionById = layoutModel.findRegionById(region.getId());
            if (findRegionById != null) {
                return getGenericMediaModel(context, str, str2, sMILRegionMediaElement, pduPart, findRegionById);
            }
        } else {
            RegionModel findRegionById2 = layoutModel.findRegionById(str.equals(SmilHelper.ELEMENT_TAG_TEXT) ? LayoutModel.TEXT_REGION_ID : LayoutModel.IMAGE_REGION_ID);
            if (findRegionById2 != null) {
                return getGenericMediaModel(context, str, str2, sMILRegionMediaElement, pduPart, findRegionById2);
            }
        }
        throw new IllegalArgumentException("Region not found or bad region ID.");
    }

    /* JADX WARNING: type inference failed for: r7v1, types: [com.android.mms.model.MediaModel] */
    /* JADX WARNING: type inference failed for: r7v2, types: [com.android.mms.model.AudioModel] */
    /* JADX WARNING: type inference failed for: r0v15, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v16, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v17, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v6, types: [com.android.mms.model.AudioModel] */
    /* JADX WARNING: type inference failed for: r0v19, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v20, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v21, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v10, types: [com.android.mms.model.AudioModel] */
    /* JADX WARNING: type inference failed for: r0v25, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v26, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v27, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v14, types: [com.android.mms.model.AudioModel] */
    /* JADX WARNING: type inference failed for: r0v28, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v29, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v30, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v18 */
    /* JADX WARNING: type inference failed for: r0v31, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v32, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v33, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v19 */
    /* JADX WARNING: type inference failed for: r0v34, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v35, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v36, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v20 */
    /* JADX WARNING: type inference failed for: r0v37, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v38, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v39, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: type inference failed for: r7v21 */
    /* JADX WARNING: type inference failed for: r0v40, types: [com.android.mms.model.VideoModel] */
    /* JADX WARNING: type inference failed for: r0v41, types: [com.android.mms.model.ImageModel] */
    /* JADX WARNING: type inference failed for: r0v42, types: [com.android.mms.model.TextModel] */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r7v18
  assigns: [com.android.mms.model.VideoModel, com.android.mms.model.ImageModel, com.android.mms.model.TextModel]
  uses: [com.android.mms.model.MediaModel, com.android.mms.model.VideoModel, com.android.mms.model.ImageModel, com.android.mms.model.TextModel]
  mth insns count: 215
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 17 */
    private static MediaModel getGenericMediaModel(Context context, String str, String str2, SMILMediaElement sMILMediaElement, PduPart pduPart, RegionModel regionModel) throws IOException, MmsException {
        ? r7;
        Context context2 = context;
        String str3 = str;
        String str4 = str2;
        byte[] contentType = pduPart.getContentType();
        if (contentType != null) {
            String str5 = new String(contentType);
            boolean isDrmType = ContentType.isDrmType(str5);
            String str6 = "Unsupported Content-Type: ";
            String str7 = "Unsupported TAG: ";
            String str8 = SmilHelper.ELEMENT_TAG_REF;
            String str9 = SmilHelper.ELEMENT_TAG_AUDIO;
            String str10 = SmilHelper.ELEMENT_TAG_VIDEO;
            String str11 = SmilHelper.ELEMENT_TAG_IMAGE;
            String str12 = SmilHelper.ELEMENT_TAG_TEXT;
            if (isDrmType) {
                DrmWrapper drmWrapper = new DrmWrapper(str5, pduPart.getDataUri(), pduPart.getData());
                if (str.equals(str12)) {
                    ? textModel = new TextModel(context, str5, str2, pduPart.getCharset(), drmWrapper, regionModel);
                    r7 = textModel;
                } else if (str.equals(str11)) {
                    ? imageModel = new ImageModel(context, str5, str2, drmWrapper, regionModel);
                    r7 = imageModel;
                } else if (str.equals(str10)) {
                    ? videoModel = new VideoModel(context, str5, str2, drmWrapper, regionModel);
                    r7 = videoModel;
                } else if (str.equals(str9)) {
                    r7 = new AudioModel(context, str5, str4, drmWrapper);
                } else if (str.equals(str8)) {
                    String contentType2 = drmWrapper.getContentType();
                    if (ContentType.isTextType(contentType2)) {
                        ? textModel2 = new TextModel(context, str5, str2, pduPart.getCharset(), drmWrapper, regionModel);
                        r7 = textModel2;
                    } else if (ContentType.isImageType(contentType2)) {
                        ? imageModel2 = new ImageModel(context, str5, str2, drmWrapper, regionModel);
                        r7 = imageModel2;
                    } else if (ContentType.isVideoType(contentType2)) {
                        ? videoModel2 = new VideoModel(context, str5, str2, drmWrapper, regionModel);
                        r7 = videoModel2;
                    } else if (ContentType.isAudioType(contentType2)) {
                        r7 = new AudioModel(context, str5, str4, drmWrapper);
                    } else {
                        StringBuilder sb = new StringBuilder(str6);
                        sb.append(contentType2);
                        throw new UnsupportContentTypeException(sb.toString());
                    }
                } else {
                    StringBuilder sb2 = new StringBuilder(str7);
                    sb2.append(str);
                    throw new IllegalArgumentException(sb2.toString());
                }
            } else if (str.equals(str12)) {
                ? textModel3 = new TextModel(context, str5, str2, pduPart.getCharset(), pduPart.getData(), regionModel);
                r7 = textModel3;
            } else if (str.equals(str11)) {
                ? imageModel3 = new ImageModel(context, str5, str2, pduPart.getDataUri(), regionModel);
                r7 = imageModel3;
            } else if (str.equals(str10)) {
                ? videoModel3 = new VideoModel(context, str5, str2, pduPart.getDataUri(), regionModel);
                r7 = videoModel3;
            } else if (str.equals(str9)) {
                r7 = new AudioModel(context, str5, str4, pduPart.getDataUri());
            } else if (!str.equals(str8)) {
                StringBuilder sb3 = new StringBuilder(str7);
                sb3.append(str);
                throw new IllegalArgumentException(sb3.toString());
            } else if (ContentType.isTextType(str5)) {
                ? textModel4 = new TextModel(context, str5, str2, pduPart.getCharset(), pduPart.getData(), regionModel);
                r7 = textModel4;
            } else if (ContentType.isImageType(str5)) {
                ? imageModel4 = new ImageModel(context, str5, str2, pduPart.getDataUri(), regionModel);
                r7 = imageModel4;
            } else if (ContentType.isVideoType(str5)) {
                ? videoModel4 = new VideoModel(context, str5, str2, pduPart.getDataUri(), regionModel);
                r7 = videoModel4;
            } else if (ContentType.isAudioType(str5)) {
                r7 = new AudioModel(context, str5, str4, pduPart.getDataUri());
            } else {
                StringBuilder sb4 = new StringBuilder(str6);
                sb4.append(str5);
                throw new UnsupportContentTypeException(sb4.toString());
            }
            TimeList begin = sMILMediaElement.getBegin();
            int resolvedOffset = (begin == null || begin.getLength() <= 0) ? 0 : (int) (begin.item(0).getResolvedOffset() * 1000.0d);
            r7.setBegin(resolvedOffset);
            int dur = (int) (sMILMediaElement.getDur() * 1000.0f);
            if (dur <= 0) {
                TimeList end = sMILMediaElement.getEnd();
                if (end != null && end.getLength() > 0) {
                    Time item = end.item(0);
                    if (item.getTimeType() != 0) {
                        dur = ((int) (item.getResolvedOffset() * 1000.0d)) - resolvedOffset;
                    }
                }
            }
            r7.setDuration(dur);
            r7.setFill(sMILMediaElement.getFill());
            return r7;
        }
        throw new IllegalArgumentException("Content-Type of the part may not be null.");
    }
}
