package com.android.mms.model;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import com.android.mms.drm.DrmUtils;
import com.android.mms.drm.DrmWrapper;
import com.google.android.mms.MmsException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import org.w3c.dom.events.EventListener;

public abstract class MediaModel extends Model implements EventListener {
    private static final String TAG = "MediaModel";
    protected int mBegin;
    protected String mContentType;
    protected Context mContext;
    private byte[] mData;
    protected DrmWrapper mDrmObjectWrapper;
    protected int mDuration;
    protected short mFill;
    private final ArrayList<MediaAction> mMediaActions;
    protected int mSeekTo;
    protected int mSize;
    protected String mSrc;
    protected String mTag;
    private Uri mUri;

    public enum MediaAction {
        NO_ACTIVE_ACTION,
        START,
        STOP,
        PAUSE,
        SEEK
    }

    /* access modifiers changed from: protected */
    public boolean isPlayable() {
        return false;
    }

    public MediaModel(Context context, String str, Uri uri) throws MmsException {
        this(context, str, (String) null, (String) null, uri);
    }

    public MediaModel(Context context, String str, String str2, String str3, Uri uri) throws MmsException {
        this.mContext = context;
        this.mTag = str;
        this.mContentType = str2;
        this.mSrc = str3;
        this.mUri = uri;
        initMediaSize();
        this.mMediaActions = new ArrayList<>();
    }

    public MediaModel(Context context, String str, String str2, String str3, byte[] bArr) {
        if (bArr != null) {
            this.mContext = context;
            this.mTag = str;
            this.mContentType = str2;
            this.mSrc = str3;
            this.mData = bArr;
            this.mSize = bArr.length;
            this.mMediaActions = new ArrayList<>();
            return;
        }
        throw new IllegalArgumentException("data may not be null.");
    }

    public MediaModel(Context context, String str, String str2, String str3, DrmWrapper drmWrapper) throws IOException {
        this.mContext = context;
        this.mTag = str;
        this.mContentType = str2;
        this.mSrc = str3;
        this.mDrmObjectWrapper = drmWrapper;
        this.mUri = DrmUtils.insert(context, drmWrapper);
        this.mSize = drmWrapper.getOriginalData().length;
        this.mMediaActions = new ArrayList<>();
    }

    public int getBegin() {
        return this.mBegin;
    }

    public void setBegin(int i) {
        this.mBegin = i;
        notifyModelChanged(true);
    }

    public int getDuration() {
        return this.mDuration;
    }

    public void setDuration(int i) {
        if (!isPlayable() || i >= 0) {
            this.mDuration = i;
        } else {
            try {
                initMediaDuration();
            } catch (MmsException e) {
                Log.e(TAG, e.getMessage(), e);
                return;
            }
        }
        notifyModelChanged(true);
    }

    public String getTag() {
        return this.mTag;
    }

    public String getContentType() {
        return this.mContentType;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public Uri getUriWithDrmCheck() {
        return this.mUri;
    }

    public byte[] getData() {
        byte[] bArr = this.mData;
        if (bArr == null) {
            return null;
        }
        byte[] bArr2 = new byte[bArr.length];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        return bArr2;
    }

    /* access modifiers changed from: 0000 */
    public void setUri(Uri uri) {
        this.mUri = uri;
    }

    public String getSrc() {
        return this.mSrc;
    }

    public short getFill() {
        return this.mFill;
    }

    public void setFill(short s) {
        this.mFill = s;
        notifyModelChanged(true);
    }

    public int getMediaSize() {
        return this.mSize;
    }

    public boolean isText() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_TEXT);
    }

    public boolean isImage() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_IMAGE);
    }

    public boolean isVideo() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_VIDEO);
    }

    public boolean isAudio() {
        return this.mTag.equals(SmilHelper.ELEMENT_TAG_AUDIO);
    }

    public boolean isDrmProtected() {
        return this.mDrmObjectWrapper != null;
    }

    public boolean isAllowedToForward() {
        return this.mDrmObjectWrapper.isAllowedToForward();
    }

    /* access modifiers changed from: protected */
    public void initMediaDuration() throws MmsException {
        if (this.mUri != null) {
            MediaPlayer mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(this.mContext, this.mUri);
                mediaPlayer.prepare();
                this.mDuration = mediaPlayer.getDuration();
                mediaPlayer.release();
            } catch (IOException e) {
                Log.e(TAG, "Unexpected IOException.", e);
                throw new MmsException(e);
            } catch (Throwable th) {
                mediaPlayer.release();
                throw th;
            }
        } else {
            throw new IllegalArgumentException("Uri may not be null.");
        }
    }

    private void initMediaSize() throws MmsException {
        String str = "IOException caught while closing stream";
        String str2 = TAG;
        boolean z = null;
        try {
            z = this.mContext.getContentResolver().openInputStream(this.mUri);
            z = z instanceof FileInputStream;
            if (z) {
                this.mSize = (int) ((FileInputStream) z).getChannel().size();
            } else {
                while (-1 != z.read()) {
                    this.mSize++;
                }
            }
            if (z != null) {
                try {
                    z.close();
                } catch (IOException e) {
                    Log.e(str2, str, e);
                }
            }
        } catch (IOException e2) {
            Log.e(str2, "IOException caught while opening or reading stream", e2);
            if (e2 instanceof FileNotFoundException) {
                throw new MmsException(e2.getMessage());
            } else if (z != null) {
                z.close();
            }
        } finally {
            if (z != null) {
                try {
                    z.close();
                } catch (IOException e3) {
                    Log.e(str2, str, e3);
                }
            }
        }
    }

    public static boolean isMmsUri(Uri uri) {
        return uri.getAuthority().startsWith("mms");
    }

    public int getSeekTo() {
        return this.mSeekTo;
    }

    public void appendAction(MediaAction mediaAction) {
        this.mMediaActions.add(mediaAction);
    }

    public MediaAction getCurrentAction() {
        if (this.mMediaActions.size() == 0) {
            return MediaAction.NO_ACTIVE_ACTION;
        }
        return (MediaAction) this.mMediaActions.remove(0);
    }

    public DrmWrapper getDrmObject() {
        return this.mDrmObjectWrapper;
    }
}
