package com.android.mms.model;

import android.content.ContentResolver;
import com.android.mms.ContentRestrictionException;
import com.android.mms.ExceedMessageSizeException;
import com.android.mms.ResolutionException;
import com.android.mms.UnsupportContentTypeException;
import com.google.android.mms.ContentType;
import java.util.ArrayList;

public class CarrierContentRestriction implements ContentRestriction {
    public static final int IMAGE_HEIGHT_LIMIT = 480;
    public static final int IMAGE_WIDTH_LIMIT = 640;
    public static final int MESSAGE_SIZE_LIMIT = 307200;
    private static final ArrayList<String> sSupportedAudioTypes = ContentType.getAudioTypes();
    private static final ArrayList<String> sSupportedImageTypes = ContentType.getImageTypes();
    private static final ArrayList<String> sSupportedVideoTypes = ContentType.getVideoTypes();

    public void checkMessageSize(int i, int i2, ContentResolver contentResolver) throws ContentRestrictionException {
        if (i < 0 || i2 < 0) {
            throw new ContentRestrictionException("Negative message size or increase size");
        }
        int i3 = i + i2;
        if (i3 < 0 || i3 > 307200) {
            throw new ExceedMessageSizeException("Exceed message size limitation");
        }
    }

    public void checkResolution(int i, int i2) throws ContentRestrictionException {
        if (i > 640 || i2 > 480) {
            throw new ResolutionException("content resolution exceeds restriction.");
        }
    }

    public void checkImageContentType(String str) throws ContentRestrictionException {
        if (str == null) {
            throw new ContentRestrictionException("Null content type to be check");
        } else if (!sSupportedImageTypes.contains(str)) {
            StringBuilder sb = new StringBuilder("Unsupported image content type : ");
            sb.append(str);
            throw new UnsupportContentTypeException(sb.toString());
        }
    }

    public void checkAudioContentType(String str) throws ContentRestrictionException {
        if (str == null) {
            throw new ContentRestrictionException("Null content type to be check");
        } else if (!sSupportedAudioTypes.contains(str)) {
            StringBuilder sb = new StringBuilder("Unsupported audio content type : ");
            sb.append(str);
            throw new UnsupportContentTypeException(sb.toString());
        }
    }

    public void checkVideoContentType(String str) throws ContentRestrictionException {
        if (str == null) {
            throw new ContentRestrictionException("Null content type to be check");
        } else if (!sSupportedVideoTypes.contains(str)) {
            StringBuilder sb = new StringBuilder("Unsupported video content type : ");
            sb.append(str);
            throw new UnsupportContentTypeException(sb.toString());
        }
    }
}
