package com.android.mms.model;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import com.android.mms.ContentRestrictionException;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.drm.DrmWrapper;
import com.android.mms.model.MediaModel.MediaAction;
import com.google.android.mms.MmsException;
import com.google.android.mms.util.SqliteWrapper;
import java.io.IOException;
import org.w3c.dom.events.Event;

public class VideoModel extends RegionMediaModel {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "VideoModel";

    /* access modifiers changed from: protected */
    public boolean isPlayable() {
        return true;
    }

    public VideoModel(Context context, Uri uri, RegionModel regionModel) throws MmsException {
        this(context, (String) null, (String) null, uri, regionModel);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public VideoModel(Context context, String str, String str2, Uri uri, RegionModel regionModel) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_VIDEO, str, str2, uri, regionModel);
    }

    public VideoModel(Context context, String str, String str2, DrmWrapper drmWrapper, RegionModel regionModel) throws IOException {
        super(context, SmilHelper.ELEMENT_TAG_VIDEO, str, str2, drmWrapper, regionModel);
    }

    /* JADX INFO: finally extract failed */
    private void initModelFromUri(Uri uri) throws MmsException {
        Cursor query = SqliteWrapper.query(this.mContext, this.mContext.getContentResolver(), uri, null, null, null, null);
        if (query != null) {
            try {
                if (query.moveToFirst()) {
                    String string = query.getString(query.getColumnIndexOrThrow("_data"));
                    this.mSrc = string.substring(string.lastIndexOf(47) + 1);
                    this.mContentType = query.getString(query.getColumnIndexOrThrow("mime_type"));
                    if (!TextUtils.isEmpty(this.mContentType)) {
                        query.close();
                        initMediaDuration();
                        return;
                    }
                    throw new MmsException("Type of media is unknown.");
                }
                StringBuilder sb = new StringBuilder("Nothing found: ");
                sb.append(uri);
                throw new MmsException(sb.toString());
            } catch (Throwable th) {
                query.close();
                throw th;
            }
        } else {
            StringBuilder sb2 = new StringBuilder("Bad URI: ");
            sb2.append(uri);
            throw new MmsException(sb2.toString());
        }
    }

    public void handleEvent(Event event) {
        String type = event.getType();
        MediaAction mediaAction = MediaAction.NO_ACTIVE_ACTION;
        if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            mediaAction = MediaAction.START;
            this.mVisible = true;
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT)) {
            mediaAction = MediaAction.STOP;
            if (this.mFill != 1) {
                this.mVisible = false;
            }
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT)) {
            mediaAction = MediaAction.PAUSE;
            this.mVisible = true;
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT)) {
            mediaAction = MediaAction.SEEK;
            this.mSeekTo = event.getSeekTo();
            this.mVisible = true;
        }
        appendAction(mediaAction);
        notifyModelChanged(false);
    }

    /* access modifiers changed from: protected */
    public void checkContentRestriction() throws ContentRestrictionException {
        ContentRestrictionFactory.getContentRestriction().checkVideoContentType(this.mContentType);
    }
}
