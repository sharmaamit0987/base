package com.android.mms.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import com.android.mms.ContentRestrictionException;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.drm.DrmWrapper;
import com.android.mms.ui.UriImage;
import com.google.android.mms.MmsException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import org.w3c.dom.events.Event;

public class ImageModel extends RegionMediaModel {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "ImageModel";
    private static final int THUMBNAIL_BOUNDS_LIMIT = 480;
    private SoftReference<Bitmap> mBitmapCache = new SoftReference<>(null);
    private int mHeight;
    private int mWidth;

    public ImageModel(Context context, Uri uri, RegionModel regionModel) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_IMAGE, uri, regionModel);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public ImageModel(Context context, String str, String str2, Uri uri, RegionModel regionModel) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_IMAGE, str, str2, uri, regionModel);
        decodeImageBounds();
    }

    public ImageModel(Context context, String str, String str2, DrmWrapper drmWrapper, RegionModel regionModel) throws IOException {
        super(context, SmilHelper.ELEMENT_TAG_IMAGE, str, str2, drmWrapper, regionModel);
    }

    private void initModelFromUri(Uri uri) throws MmsException {
        UriImage uriImage = new UriImage(this.mContext, uri);
        this.mContentType = uriImage.getContentType();
        if (!TextUtils.isEmpty(this.mContentType)) {
            this.mSrc = uriImage.getSrc();
            this.mWidth = uriImage.getWidth();
            this.mHeight = uriImage.getHeight();
            return;
        }
        throw new MmsException("Type of media is unknown.");
    }

    private void decodeImageBounds() {
        UriImage uriImage = new UriImage(this.mContext, getUriWithDrmCheck());
        this.mWidth = uriImage.getWidth();
        this.mHeight = uriImage.getHeight();
    }

    public void handleEvent(Event event) {
        if (event.getType().equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }

    public int getWidth() {
        return this.mWidth;
    }

    public int getHeight() {
        return this.mHeight;
    }

    /* access modifiers changed from: protected */
    public void checkContentRestriction() throws ContentRestrictionException {
        ContentRestriction contentRestriction = ContentRestrictionFactory.getContentRestriction();
        contentRestriction.checkImageContentType(this.mContentType);
        contentRestriction.checkResolution(this.mWidth, this.mHeight);
    }

    public Bitmap getBitmap() {
        Bitmap bitmap = (Bitmap) this.mBitmapCache.get();
        if (bitmap != null) {
            return bitmap;
        }
        Bitmap createThumbnailBitmap = createThumbnailBitmap(480, getUri());
        this.mBitmapCache = new SoftReference<>(createThumbnailBitmap);
        return createThumbnailBitmap;
    }

    public Bitmap getBitmapWithDrmCheck() {
        Bitmap bitmap = (Bitmap) this.mBitmapCache.get();
        if (bitmap != null) {
            return bitmap;
        }
        Bitmap createThumbnailBitmap = createThumbnailBitmap(480, getUriWithDrmCheck());
        this.mBitmapCache = new SoftReference<>(createThumbnailBitmap);
        return createThumbnailBitmap;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0043 A[SYNTHETIC, Splitter:B:23:0x0043] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0054 A[SYNTHETIC, Splitter:B:31:0x0054] */
    private Bitmap createThumbnailBitmap(int i, Uri uri) {
        InputStream inputStream;
        String str = TAG;
        int i2 = this.mWidth;
        int i3 = this.mHeight;
        int i4 = 1;
        while (true) {
            if (i2 / i4 <= i && i3 / i4 <= i) {
                break;
            }
            i4 *= 2;
        }
        Options options = new Options();
        options.inSampleSize = i4;
        InputStream inputStream2 = null;
        try {
            inputStream = this.mContext.getContentResolver().openInputStream(uri);
            try {
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream, null, options);
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        Log.e(str, e.getMessage(), e);
                    }
                }
                return decodeStream;
            } catch (FileNotFoundException e2) {
                e = e2;
                try {
                    Log.e(str, e.getMessage(), e);
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e3) {
                            Log.e(str, e3.getMessage(), e3);
                        }
                    }
                    return null;
                } catch (Throwable th) {
                    th = th;
                    inputStream2 = inputStream;
                    if (inputStream2 != null) {
                        try {
                            inputStream2.close();
                        } catch (IOException e4) {
                            Log.e(str, e4.getMessage(), e4);
                        }
                    }
                    throw th;
                }
            }
        } catch (FileNotFoundException e5) {
            e = e5;
            inputStream = null;
            Log.e(str, e.getMessage(), e);
            if (inputStream != null) {
            }
            return null;
        } catch (Throwable th2) {
            th = th2;
            if (inputStream2 != null) {
            }
            throw th;
        }
    }
}
