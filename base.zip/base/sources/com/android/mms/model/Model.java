package com.android.mms.model;

import java.util.ArrayList;
import java.util.Iterator;

public class Model {
    protected ArrayList<IModelChangedObserver> mModelChangedObservers = new ArrayList<>();

    /* access modifiers changed from: protected */
    public void registerModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
    }

    /* access modifiers changed from: protected */
    public void unregisterAllModelChangedObserversInDescendants() {
    }

    /* access modifiers changed from: protected */
    public void unregisterModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
    }

    public void registerModelChangedObserver(IModelChangedObserver iModelChangedObserver) {
        if (!this.mModelChangedObservers.contains(iModelChangedObserver)) {
            this.mModelChangedObservers.add(iModelChangedObserver);
            registerModelChangedObserverInDescendants(iModelChangedObserver);
        }
    }

    public void unregisterModelChangedObserver(IModelChangedObserver iModelChangedObserver) {
        this.mModelChangedObservers.remove(iModelChangedObserver);
        unregisterModelChangedObserverInDescendants(iModelChangedObserver);
    }

    public void unregisterAllModelChangedObservers() {
        unregisterAllModelChangedObserversInDescendants();
        this.mModelChangedObservers.clear();
    }

    /* access modifiers changed from: protected */
    public void notifyModelChanged(boolean z) {
        Iterator it = this.mModelChangedObservers.iterator();
        while (it.hasNext()) {
            ((IModelChangedObserver) it.next()).onModelChanged(this, z);
        }
    }
}
