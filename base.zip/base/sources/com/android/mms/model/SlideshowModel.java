package com.android.mms.model;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import com.android.mms.ContentRestrictionException;
import com.android.mms.dom.smil.parser.SmilXmlSerializer;
import com.android.mms.drm.DrmWrapper;
import com.android.mms.layout.LayoutManager;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.MultimediaMessagePdu;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import com.google.android.mms.pdu.PduPersister;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILParElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRootLayoutElement;

public class SlideshowModel extends Model implements List<SlideModel>, IModelChangedObserver {
    private static final String TAG = "SlideshowModel";
    private ContentResolver mContentResolver;
    private int mCurrentMessageSize;
    private SMILDocument mDocumentCache;
    private final LayoutModel mLayout;
    private PduBody mPduBodyCache;
    private final ArrayList<SlideModel> mSlides;

    private SlideshowModel(ContentResolver contentResolver) {
        this.mLayout = new LayoutModel();
        this.mSlides = new ArrayList<>();
        this.mContentResolver = contentResolver;
    }

    private SlideshowModel(LayoutModel layoutModel, ArrayList<SlideModel> arrayList, SMILDocument sMILDocument, PduBody pduBody, ContentResolver contentResolver) {
        this.mLayout = layoutModel;
        this.mSlides = arrayList;
        this.mContentResolver = contentResolver;
        this.mDocumentCache = sMILDocument;
        this.mPduBodyCache = pduBody;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            SlideModel slideModel = (SlideModel) it.next();
            increaseMessageSize(slideModel.getSlideSize());
            slideModel.setParent(this);
        }
    }

    public static SlideshowModel createNew(Context context) {
        return new SlideshowModel(context.getContentResolver());
    }

    public static SlideshowModel createFromMessageUri(Context context, Uri uri) throws MmsException {
        return createFromPduBody(context, getPduBody(context, uri));
    }

    public static SlideshowModel createFromPduBody(Context context, PduBody pduBody) throws MmsException {
        String str = TAG;
        SMILDocument document = SmilHelper.getDocument(pduBody);
        SMILLayoutElement layout = document.getLayout();
        SMILRootLayoutElement rootLayout = layout.getRootLayout();
        int width = rootLayout.getWidth();
        int height = rootLayout.getHeight();
        if (width == 0 || height == 0) {
            width = LayoutManager.getInstance().getLayoutParameters().getWidth();
            height = LayoutManager.getInstance().getLayoutParameters().getHeight();
            rootLayout.setWidth(width);
            rootLayout.setHeight(height);
        }
        RegionModel regionModel = new RegionModel(null, 0, 0, width, height);
        ArrayList arrayList = new ArrayList();
        NodeList regions = layout.getRegions();
        int length = regions.getLength();
        int i = 0;
        while (i < length) {
            SMILRegionElement sMILRegionElement = (SMILRegionElement) regions.item(i);
            NodeList nodeList = regions;
            RegionModel regionModel2 = r8;
            RegionModel regionModel3 = new RegionModel(sMILRegionElement.getId(), sMILRegionElement.getFit(), sMILRegionElement.getLeft(), sMILRegionElement.getTop(), sMILRegionElement.getWidth(), sMILRegionElement.getHeight(), sMILRegionElement.getBackgroundColor());
            arrayList.add(regionModel2);
            i++;
            regions = nodeList;
        }
        LayoutModel layoutModel = new LayoutModel(regionModel, arrayList);
        NodeList childNodes = document.getBody().getChildNodes();
        int length2 = childNodes.getLength();
        ArrayList arrayList2 = new ArrayList(length2);
        for (int i2 = 0; i2 < length2; i2++) {
            SMILParElement sMILParElement = (SMILParElement) childNodes.item(i2);
            NodeList childNodes2 = sMILParElement.getChildNodes();
            int length3 = childNodes2.getLength();
            ArrayList arrayList3 = new ArrayList(length3);
            for (int i3 = 0; i3 < length3; i3++) {
                SMILMediaElement sMILMediaElement = (SMILMediaElement) childNodes2.item(i3);
                try {
                    MediaModel mediaModel = MediaModelFactory.getMediaModel(context, sMILMediaElement, layoutModel, pduBody);
                    SmilHelper.addMediaElementEventListeners((EventTarget) sMILMediaElement, mediaModel);
                    arrayList3.add(mediaModel);
                } catch (IOException e) {
                    Log.e(str, e.getMessage(), e);
                } catch (IllegalArgumentException e2) {
                    Log.e(str, e2.getMessage(), e2);
                }
            }
            SlideModel slideModel = new SlideModel((int) (sMILParElement.getDur() * 1000.0f), arrayList3);
            slideModel.setFill(sMILParElement.getFill());
            SmilHelper.addParElementEventListeners((EventTarget) sMILParElement, slideModel);
            arrayList2.add(slideModel);
        }
        SlideshowModel slideshowModel = new SlideshowModel(layoutModel, arrayList2, document, pduBody, context.getContentResolver());
        slideshowModel.registerModelChangedObserver(slideshowModel);
        return slideshowModel;
    }

    public PduBody toPduBody() {
        if (this.mPduBodyCache == null) {
            SMILDocument document = SmilHelper.getDocument(this);
            this.mDocumentCache = document;
            this.mPduBodyCache = makePduBody(document);
        }
        return this.mPduBodyCache;
    }

    private PduBody makePduBody(SMILDocument sMILDocument) {
        return makePduBody(null, sMILDocument, false);
    }

    private PduBody makePduBody(Context context, SMILDocument sMILDocument, boolean z) {
        PduBody pduBody = new PduBody();
        Iterator it = this.mSlides.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            Iterator it2 = ((SlideModel) it.next()).iterator();
            while (it2.hasNext()) {
                MediaModel mediaModel = (MediaModel) it2.next();
                if (!z || !mediaModel.isDrmProtected() || mediaModel.isAllowedToForward()) {
                    PduPart pduPart = new PduPart();
                    if (mediaModel.isText()) {
                        TextModel textModel = (TextModel) mediaModel;
                        if (!TextUtils.isEmpty(textModel.getText())) {
                            pduPart.setCharset(textModel.getCharset());
                        }
                    }
                    pduPart.setContentType(mediaModel.getContentType().getBytes());
                    String src = mediaModel.getSrc();
                    boolean startsWith = src.startsWith("cid:");
                    if (startsWith) {
                        src = src.substring(4);
                    }
                    pduPart.setContentLocation(src.getBytes());
                    if (startsWith) {
                        pduPart.setContentId(src.getBytes());
                    } else {
                        int lastIndexOf = src.lastIndexOf(".");
                        if (lastIndexOf != -1) {
                            src = src.substring(0, lastIndexOf);
                        }
                        pduPart.setContentId(src.getBytes());
                    }
                    if (mediaModel.isDrmProtected()) {
                        DrmWrapper drmObject = mediaModel.getDrmObject();
                        pduPart.setDataUri(drmObject.getOriginalUri());
                        pduPart.setData(drmObject.getOriginalData());
                    } else if (mediaModel.isText()) {
                        pduPart.setData(((TextModel) mediaModel).getText().getBytes());
                    } else if (mediaModel.isImage() || mediaModel.isVideo() || mediaModel.isAudio()) {
                        pduPart.setDataUri(mediaModel.getUri());
                    } else {
                        StringBuilder sb = new StringBuilder("Unsupport media: ");
                        sb.append(mediaModel);
                        Log.w(TAG, sb.toString());
                    }
                    pduBody.addPart(pduPart);
                } else {
                    z2 = true;
                }
            }
        }
        if (z2 && z && context != null) {
            Toast.makeText(context, "", 1).show();
            sMILDocument = SmilHelper.getDocument(pduBody);
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        SmilXmlSerializer.serialize(sMILDocument, byteArrayOutputStream);
        PduPart pduPart2 = new PduPart();
        pduPart2.setContentId("smil".getBytes());
        pduPart2.setContentLocation("smil.xml".getBytes());
        pduPart2.setContentType("application/smil".getBytes());
        pduPart2.setData(byteArrayOutputStream.toByteArray());
        pduBody.addPart(0, pduPart2);
        return pduBody;
    }

    public PduBody makeCopy(Context context) {
        return makePduBody(context, SmilHelper.getDocument(this), true);
    }

    public SMILDocument toSmilDocument() {
        if (this.mDocumentCache == null) {
            this.mDocumentCache = SmilHelper.getDocument(this);
        }
        return this.mDocumentCache;
    }

    public static PduBody getPduBody(Context context, Uri uri) throws MmsException {
        MultimediaMessagePdu load = PduPersister.getPduPersister(context).load(uri);
        int messageType = load.getMessageType();
        if (messageType == 128 || messageType == 132) {
            return load.getBody();
        }
        throw new MmsException();
    }

    public void setCurrentMessageSize(int i) {
        this.mCurrentMessageSize = i;
    }

    public int getCurrentMessageSize() {
        return this.mCurrentMessageSize;
    }

    public void increaseMessageSize(int i) {
        if (i > 0) {
            this.mCurrentMessageSize += i;
        }
    }

    public void decreaseMessageSize(int i) {
        if (i > 0) {
            this.mCurrentMessageSize -= i;
        }
    }

    public LayoutModel getLayout() {
        return this.mLayout;
    }

    public boolean add(SlideModel slideModel) {
        int slideSize = slideModel.getSlideSize();
        checkMessageSize(slideSize);
        if (slideModel == null || !this.mSlides.add(slideModel)) {
            return false;
        }
        increaseMessageSize(slideSize);
        slideModel.registerModelChangedObserver(this);
        Iterator it = this.mModelChangedObservers.iterator();
        while (it.hasNext()) {
            slideModel.registerModelChangedObserver((IModelChangedObserver) it.next());
        }
        notifyModelChanged(true);
        return true;
    }

    public boolean addAll(Collection<? extends SlideModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public void clear() {
        if (this.mSlides.size() > 0) {
            Iterator it = this.mSlides.iterator();
            while (it.hasNext()) {
                SlideModel slideModel = (SlideModel) it.next();
                slideModel.unregisterModelChangedObserver(this);
                Iterator it2 = this.mModelChangedObservers.iterator();
                while (it2.hasNext()) {
                    slideModel.unregisterModelChangedObserver((IModelChangedObserver) it2.next());
                }
            }
            this.mCurrentMessageSize = 0;
            this.mSlides.clear();
            notifyModelChanged(true);
        }
    }

    public boolean contains(Object obj) {
        return this.mSlides.contains(obj);
    }

    public boolean containsAll(Collection<?> collection) {
        return this.mSlides.containsAll(collection);
    }

    public boolean isEmpty() {
        return this.mSlides.isEmpty();
    }

    public Iterator<SlideModel> iterator() {
        return this.mSlides.iterator();
    }

    public boolean remove(Object obj) {
        if (obj == null || !this.mSlides.remove(obj)) {
            return false;
        }
        SlideModel slideModel = (SlideModel) obj;
        decreaseMessageSize(slideModel.getSlideSize());
        slideModel.unregisterAllModelChangedObservers();
        notifyModelChanged(true);
        return true;
    }

    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public int size() {
        return this.mSlides.size();
    }

    public Object[] toArray() {
        return this.mSlides.toArray();
    }

    public <T> T[] toArray(T[] tArr) {
        return this.mSlides.toArray(tArr);
    }

    public void add(int i, SlideModel slideModel) {
        if (slideModel != null) {
            int slideSize = slideModel.getSlideSize();
            checkMessageSize(slideSize);
            this.mSlides.add(i, slideModel);
            increaseMessageSize(slideSize);
            slideModel.registerModelChangedObserver(this);
            Iterator it = this.mModelChangedObservers.iterator();
            while (it.hasNext()) {
                slideModel.registerModelChangedObserver((IModelChangedObserver) it.next());
            }
            notifyModelChanged(true);
        }
    }

    public boolean addAll(int i, Collection<? extends SlideModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public SlideModel get(int i) {
        return (SlideModel) this.mSlides.get(i);
    }

    public int indexOf(Object obj) {
        return this.mSlides.indexOf(obj);
    }

    public int lastIndexOf(Object obj) {
        return this.mSlides.lastIndexOf(obj);
    }

    public ListIterator<SlideModel> listIterator() {
        return this.mSlides.listIterator();
    }

    public ListIterator<SlideModel> listIterator(int i) {
        return this.mSlides.listIterator(i);
    }

    public SlideModel remove(int i) {
        SlideModel slideModel = (SlideModel) this.mSlides.remove(i);
        if (slideModel != null) {
            decreaseMessageSize(slideModel.getSlideSize());
            slideModel.unregisterAllModelChangedObservers();
            notifyModelChanged(true);
        }
        return slideModel;
    }

    public SlideModel set(int i, SlideModel slideModel) {
        SlideModel slideModel2 = (SlideModel) this.mSlides.get(i);
        if (slideModel != null) {
            int i2 = 0;
            int slideSize = slideModel.getSlideSize();
            if (slideModel2 != null) {
                i2 = slideModel2.getSlideSize();
            }
            if (slideSize > i2) {
                int i3 = slideSize - i2;
                checkMessageSize(i3);
                increaseMessageSize(i3);
            } else {
                decreaseMessageSize(i2 - slideSize);
            }
        }
        SlideModel slideModel3 = (SlideModel) this.mSlides.set(i, slideModel);
        if (slideModel3 != null) {
            slideModel3.unregisterAllModelChangedObservers();
        }
        if (slideModel != null) {
            slideModel.registerModelChangedObserver(this);
            Iterator it = this.mModelChangedObservers.iterator();
            while (it.hasNext()) {
                slideModel.registerModelChangedObserver((IModelChangedObserver) it.next());
            }
        }
        notifyModelChanged(true);
        return slideModel3;
    }

    public List<SlideModel> subList(int i, int i2) {
        return this.mSlides.subList(i, i2);
    }

    /* access modifiers changed from: protected */
    public void registerModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        this.mLayout.registerModelChangedObserver(iModelChangedObserver);
        Iterator it = this.mSlides.iterator();
        while (it.hasNext()) {
            ((SlideModel) it.next()).registerModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        this.mLayout.unregisterModelChangedObserver(iModelChangedObserver);
        Iterator it = this.mSlides.iterator();
        while (it.hasNext()) {
            ((SlideModel) it.next()).unregisterModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterAllModelChangedObserversInDescendants() {
        this.mLayout.unregisterAllModelChangedObservers();
        Iterator it = this.mSlides.iterator();
        while (it.hasNext()) {
            ((SlideModel) it.next()).unregisterAllModelChangedObservers();
        }
    }

    public void onModelChanged(Model model, boolean z) {
        if (z) {
            this.mDocumentCache = null;
            this.mPduBodyCache = null;
        }
    }

    public void sync(PduBody pduBody) {
        Iterator it = this.mSlides.iterator();
        while (it.hasNext()) {
            Iterator it2 = ((SlideModel) it.next()).iterator();
            while (it2.hasNext()) {
                MediaModel mediaModel = (MediaModel) it2.next();
                PduPart partByContentLocation = pduBody.getPartByContentLocation(mediaModel.getSrc());
                if (partByContentLocation != null) {
                    mediaModel.setUri(partByContentLocation.getDataUri());
                }
            }
        }
    }

    public void checkMessageSize(int i) throws ContentRestrictionException {
        ContentRestrictionFactory.getContentRestriction().checkMessageSize(this.mCurrentMessageSize, i, this.mContentResolver);
    }

    public boolean isSimple() {
        if (size() != 1) {
            return false;
        }
        SlideModel slideModel = get(0);
        return (slideModel.hasImage() ^ slideModel.hasVideo()) && !slideModel.hasAudio();
    }

    public void prepareForSend() {
        if (size() == 1) {
            TextModel text = get(0).getText();
            if (text != null) {
                text.cloneText();
            }
        }
    }
}
