package com.android.mms.model;

import com.android.mms.dom.smil.SmilParElementImpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;

public class SlideModel extends Model implements List<MediaModel>, EventListener {
    private static final boolean DEBUG = false;
    private static final int DEFAULT_SLIDE_DURATION = 5000;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "SlideModel";
    private MediaModel mAudio;
    private boolean mCanAddAudio;
    private boolean mCanAddImage;
    private boolean mCanAddVideo;
    private int mDuration;
    private short mFill;
    private MediaModel mImage;
    private final ArrayList<MediaModel> mMedia;
    private SlideshowModel mParent;
    private int mSlideSize;
    private MediaModel mText;
    private MediaModel mVideo;
    private boolean mVisible;

    public SlideModel(SlideshowModel slideshowModel) {
        this(5000, slideshowModel);
    }

    public SlideModel(int i, SlideshowModel slideshowModel) {
        this.mMedia = new ArrayList<>();
        this.mCanAddImage = true;
        this.mCanAddAudio = true;
        this.mCanAddVideo = true;
        this.mVisible = true;
        this.mDuration = i;
        this.mParent = slideshowModel;
    }

    public SlideModel(int i, ArrayList<MediaModel> arrayList) {
        this.mMedia = new ArrayList<>();
        this.mCanAddImage = true;
        this.mCanAddAudio = true;
        this.mCanAddVideo = true;
        this.mVisible = true;
        this.mDuration = i;
        Iterator it = arrayList.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            MediaModel mediaModel = (MediaModel) it.next();
            internalAdd(mediaModel);
            int duration = mediaModel.getDuration();
            if (duration > i2) {
                i2 = duration;
            }
        }
        updateDuration(i2);
    }

    private void internalAdd(MediaModel mediaModel) throws IllegalStateException {
        if (mediaModel != null) {
            if (mediaModel.isText()) {
                internalAddOrReplace(this.mText, mediaModel);
                this.mText = mediaModel;
            } else if (mediaModel.isImage()) {
                if (this.mCanAddImage) {
                    internalAddOrReplace(this.mImage, mediaModel);
                    this.mImage = mediaModel;
                    this.mCanAddVideo = false;
                } else {
                    throw new IllegalStateException();
                }
            } else if (mediaModel.isAudio()) {
                if (this.mCanAddAudio) {
                    internalAddOrReplace(this.mAudio, mediaModel);
                    this.mAudio = mediaModel;
                    this.mCanAddVideo = false;
                } else {
                    throw new IllegalStateException();
                }
            } else if (mediaModel.isVideo()) {
                if (this.mCanAddVideo) {
                    internalAddOrReplace(this.mVideo, mediaModel);
                    this.mVideo = mediaModel;
                    this.mCanAddImage = false;
                    this.mCanAddAudio = false;
                } else {
                    throw new IllegalStateException();
                }
            }
        }
    }

    private void internalAddOrReplace(MediaModel mediaModel, MediaModel mediaModel2) {
        int mediaSize = mediaModel2.getMediaSize();
        if (mediaModel == null) {
            SlideshowModel slideshowModel = this.mParent;
            if (slideshowModel != null) {
                slideshowModel.checkMessageSize(mediaSize);
            }
            this.mMedia.add(mediaModel2);
            increaseSlideSize(mediaSize);
            increaseMessageSize(mediaSize);
        } else {
            int mediaSize2 = mediaModel.getMediaSize();
            if (mediaSize > mediaSize2) {
                SlideshowModel slideshowModel2 = this.mParent;
                if (slideshowModel2 != null) {
                    slideshowModel2.checkMessageSize(mediaSize - mediaSize2);
                }
                int i = mediaSize - mediaSize2;
                increaseSlideSize(i);
                increaseMessageSize(i);
            } else {
                int i2 = mediaSize2 - mediaSize;
                decreaseSlideSize(i2);
                decreaseMessageSize(i2);
            }
            ArrayList<MediaModel> arrayList = this.mMedia;
            arrayList.set(arrayList.indexOf(mediaModel), mediaModel2);
            mediaModel.unregisterAllModelChangedObservers();
        }
        Iterator it = this.mModelChangedObservers.iterator();
        while (it.hasNext()) {
            mediaModel2.registerModelChangedObserver((IModelChangedObserver) it.next());
        }
    }

    private boolean internalRemove(Object obj) {
        if (!this.mMedia.remove(obj)) {
            return false;
        }
        if (obj instanceof TextModel) {
            this.mText = null;
        } else if (obj instanceof ImageModel) {
            this.mImage = null;
            this.mCanAddVideo = true;
        } else if (obj instanceof AudioModel) {
            this.mAudio = null;
            this.mCanAddVideo = true;
        } else if (obj instanceof VideoModel) {
            this.mVideo = null;
            this.mCanAddImage = true;
            this.mCanAddAudio = true;
        }
        int mediaSize = ((MediaModel) obj).getMediaSize();
        decreaseSlideSize(mediaSize);
        decreaseMessageSize(mediaSize);
        ((Model) obj).unregisterAllModelChangedObservers();
        return true;
    }

    public int getDuration() {
        return this.mDuration;
    }

    public void setDuration(int i) {
        this.mDuration = i;
        notifyModelChanged(true);
    }

    public int getSlideSize() {
        return this.mSlideSize;
    }

    public void increaseSlideSize(int i) {
        if (i > 0) {
            this.mSlideSize += i;
        }
    }

    public void decreaseSlideSize(int i) {
        if (i > 0) {
            this.mSlideSize -= i;
        }
    }

    public void setParent(SlideshowModel slideshowModel) {
        this.mParent = slideshowModel;
    }

    public void increaseMessageSize(int i) {
        if (i > 0) {
            SlideshowModel slideshowModel = this.mParent;
            if (slideshowModel != null) {
                this.mParent.setCurrentMessageSize(slideshowModel.getCurrentMessageSize() + i);
            }
        }
    }

    public void decreaseMessageSize(int i) {
        if (i > 0) {
            SlideshowModel slideshowModel = this.mParent;
            if (slideshowModel != null) {
                this.mParent.setCurrentMessageSize(slideshowModel.getCurrentMessageSize() - i);
            }
        }
    }

    public boolean add(MediaModel mediaModel) {
        internalAdd(mediaModel);
        notifyModelChanged(true);
        return true;
    }

    public boolean addAll(Collection<? extends MediaModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public void clear() {
        if (this.mMedia.size() > 0) {
            Iterator it = this.mMedia.iterator();
            while (it.hasNext()) {
                MediaModel mediaModel = (MediaModel) it.next();
                mediaModel.unregisterAllModelChangedObservers();
                int mediaSize = mediaModel.getMediaSize();
                decreaseSlideSize(mediaSize);
                decreaseMessageSize(mediaSize);
            }
            this.mMedia.clear();
            this.mText = null;
            this.mImage = null;
            this.mAudio = null;
            this.mVideo = null;
            this.mCanAddImage = true;
            this.mCanAddAudio = true;
            this.mCanAddVideo = true;
            notifyModelChanged(true);
        }
    }

    public boolean contains(Object obj) {
        return this.mMedia.contains(obj);
    }

    public boolean containsAll(Collection<?> collection) {
        return this.mMedia.containsAll(collection);
    }

    public boolean isEmpty() {
        return this.mMedia.isEmpty();
    }

    public Iterator<MediaModel> iterator() {
        return this.mMedia.iterator();
    }

    public boolean remove(Object obj) {
        if (obj == null || !(obj instanceof MediaModel) || !internalRemove(obj)) {
            return false;
        }
        notifyModelChanged(true);
        return true;
    }

    public boolean removeAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public boolean retainAll(Collection<?> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public int size() {
        return this.mMedia.size();
    }

    public Object[] toArray() {
        return this.mMedia.toArray();
    }

    public <T> T[] toArray(T[] tArr) {
        return this.mMedia.toArray(tArr);
    }

    public void add(int i, MediaModel mediaModel) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public boolean addAll(int i, Collection<? extends MediaModel> collection) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public MediaModel get(int i) {
        return (MediaModel) this.mMedia.get(i);
    }

    public int indexOf(Object obj) {
        return this.mMedia.indexOf(obj);
    }

    public int lastIndexOf(Object obj) {
        return this.mMedia.lastIndexOf(obj);
    }

    public ListIterator<MediaModel> listIterator() {
        return this.mMedia.listIterator();
    }

    public ListIterator<MediaModel> listIterator(int i) {
        return this.mMedia.listIterator(i);
    }

    public MediaModel remove(int i) {
        MediaModel mediaModel = (MediaModel) this.mMedia.get(i);
        if (mediaModel != null && internalRemove(mediaModel)) {
            notifyModelChanged(true);
        }
        return mediaModel;
    }

    public MediaModel set(int i, MediaModel mediaModel) {
        throw new UnsupportedOperationException("Operation not supported.");
    }

    public List<MediaModel> subList(int i, int i2) {
        return this.mMedia.subList(i, i2);
    }

    public boolean isVisible() {
        return this.mVisible;
    }

    public void setVisible(boolean z) {
        this.mVisible = z;
        notifyModelChanged(true);
    }

    public short getFill() {
        return this.mFill;
    }

    public void setFill(short s) {
        this.mFill = s;
        notifyModelChanged(true);
    }

    /* access modifiers changed from: protected */
    public void registerModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        Iterator it = this.mMedia.iterator();
        while (it.hasNext()) {
            ((MediaModel) it.next()).registerModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterModelChangedObserverInDescendants(IModelChangedObserver iModelChangedObserver) {
        Iterator it = this.mMedia.iterator();
        while (it.hasNext()) {
            ((MediaModel) it.next()).unregisterModelChangedObserver(iModelChangedObserver);
        }
    }

    /* access modifiers changed from: protected */
    public void unregisterAllModelChangedObserversInDescendants() {
        Iterator it = this.mMedia.iterator();
        while (it.hasNext()) {
            ((MediaModel) it.next()).unregisterAllModelChangedObservers();
        }
    }

    public void handleEvent(Event event) {
        if (event.getType().equals(SmilParElementImpl.SMIL_SLIDE_START_EVENT)) {
            this.mVisible = true;
        } else if (this.mFill != 1) {
            this.mVisible = false;
        }
        notifyModelChanged(false);
    }

    public boolean hasText() {
        return this.mText != null;
    }

    public boolean hasImage() {
        return this.mImage != null;
    }

    public boolean hasAudio() {
        return this.mAudio != null;
    }

    public boolean hasVideo() {
        return this.mVideo != null;
    }

    public boolean removeText() {
        return remove((Object) this.mText);
    }

    public boolean removeImage() {
        return remove((Object) this.mImage);
    }

    public boolean removeAudio() {
        return remove((Object) this.mAudio);
    }

    public boolean removeVideo() {
        return remove((Object) this.mVideo);
    }

    public TextModel getText() {
        return (TextModel) this.mText;
    }

    public ImageModel getImage() {
        return (ImageModel) this.mImage;
    }

    public AudioModel getAudio() {
        return (AudioModel) this.mAudio;
    }

    public VideoModel getVideo() {
        return (VideoModel) this.mVideo;
    }

    public void updateDuration(int i) {
        if (i > 0) {
            int i2 = this.mDuration;
            if (i > i2 || i2 == 5000) {
                this.mDuration = i;
            }
        }
    }
}
