package com.android.mms.model;

import android.text.TextUtils;
import android.util.Log;
import com.android.mms.dom.smil.SmilDocumentImpl;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.dom.smil.SmilParElementImpl;
import com.android.mms.dom.smil.parser.SmilXmlParser;
import com.android.mms.drm.DrmWrapper;
import com.google.android.mms.ContentType;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.PduBody;
import com.google.android.mms.pdu.PduPart;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import org.nanohttpd.protocols.http.NanoHTTPD;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILMediaElement;
import org.w3c.dom.smil.SMILParElement;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;
import org.w3c.dom.smil.SMILRootLayoutElement;
import org.xml.sax.SAXException;

public class SmilHelper {
    private static final boolean DEBUG = false;
    public static final String ELEMENT_TAG_AUDIO = "audio";
    public static final String ELEMENT_TAG_IMAGE = "img";
    public static final String ELEMENT_TAG_REF = "ref";
    public static final String ELEMENT_TAG_TEXT = "text";
    public static final String ELEMENT_TAG_VIDEO = "video";
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "SmilHelper";

    private static SMILDocument validate(SMILDocument sMILDocument) {
        return sMILDocument;
    }

    private SmilHelper() {
    }

    public static SMILDocument getDocument(PduBody pduBody) {
        PduPart findSmilPart = findSmilPart(pduBody);
        SMILDocument smilDocument = findSmilPart != null ? getSmilDocument(findSmilPart) : null;
        return smilDocument == null ? createSmilDocument(pduBody) : smilDocument;
    }

    public static SMILDocument getDocument(SlideshowModel slideshowModel) {
        return createSmilDocument(slideshowModel);
    }

    private static PduPart findSmilPart(PduBody pduBody) {
        int partsNum = pduBody.getPartsNum();
        for (int i = 0; i < partsNum; i++) {
            PduPart part = pduBody.getPart(i);
            if (Arrays.equals(part.getContentType(), "application/smil".getBytes())) {
                return part;
            }
        }
        return null;
    }

    private static SMILDocument getSmilDocument(PduPart pduPart) {
        String str = "Failed to parse SMIL document.";
        String str2 = TAG;
        try {
            byte[] data = pduPart.getData();
            if (data != null) {
                return validate(new SmilXmlParser().parse(new ByteArrayInputStream(data)));
            }
        } catch (IOException e) {
            Log.e(str2, str, e);
        } catch (SAXException e2) {
            Log.e(str2, str, e2);
        } catch (MmsException e3) {
            Log.e(str2, str, e3);
        }
        return null;
    }

    public static SMILParElement addPar(SMILDocument sMILDocument) {
        SMILParElement sMILParElement = (SMILParElement) sMILDocument.createElement("par");
        sMILParElement.setDur(8.0f);
        sMILDocument.getBody().appendChild(sMILParElement);
        return sMILParElement;
    }

    public static SMILMediaElement createMediaElement(String str, SMILDocument sMILDocument, String str2) {
        SMILMediaElement sMILMediaElement = (SMILMediaElement) sMILDocument.createElement(str);
        sMILMediaElement.setSrc(str2);
        return sMILMediaElement;
    }

    private static SMILDocument createSmilDocument(PduBody pduBody) {
        SmilDocumentImpl smilDocumentImpl = new SmilDocumentImpl();
        SMILElement sMILElement = (SMILElement) smilDocumentImpl.createElement("smil");
        sMILElement.setAttribute("xmlns", "http://www.w3.org/2001/SMIL20/Language");
        smilDocumentImpl.appendChild(sMILElement);
        SMILElement sMILElement2 = (SMILElement) smilDocumentImpl.createElement("head");
        sMILElement.appendChild(sMILElement2);
        sMILElement2.appendChild((SMILLayoutElement) smilDocumentImpl.createElement("layout"));
        sMILElement.appendChild((SMILElement) smilDocumentImpl.createElement("body"));
        SMILParElement addPar = addPar(smilDocumentImpl);
        int partsNum = pduBody.getPartsNum();
        if (partsNum == 0) {
            return smilDocumentImpl;
        }
        boolean z = false;
        boolean z2 = false;
        for (int i = 0; i < partsNum; i++) {
            if (addPar == null || (z && z2)) {
                addPar = addPar(smilDocumentImpl);
                z = false;
                z2 = false;
            }
            PduPart part = pduBody.getPart(i);
            String str = new String(part.getContentType());
            boolean isDrmType = ContentType.isDrmType(str);
            String str2 = TAG;
            if (isDrmType) {
                try {
                    str = new DrmWrapper(str, part.getDataUri(), part.getData()).getContentType();
                } catch (IOException e) {
                    Log.e(str2, e.getMessage(), e);
                }
            }
            if (str.equals(NanoHTTPD.MIME_PLAINTEXT) || str.equalsIgnoreCase("application/vnd.wap.xhtml+xml")) {
                addPar.appendChild(createMediaElement(ELEMENT_TAG_TEXT, smilDocumentImpl, part.generateLocation()));
                z2 = true;
            } else {
                if (ContentType.isImageType(str)) {
                    addPar.appendChild(createMediaElement(ELEMENT_TAG_IMAGE, smilDocumentImpl, part.generateLocation()));
                } else if (ContentType.isVideoType(str)) {
                    addPar.appendChild(createMediaElement(ELEMENT_TAG_VIDEO, smilDocumentImpl, part.generateLocation()));
                } else if (ContentType.isAudioType(str)) {
                    addPar.appendChild(createMediaElement(ELEMENT_TAG_AUDIO, smilDocumentImpl, part.generateLocation()));
                } else {
                    Log.w(str2, "unsupport media type");
                }
                z = true;
            }
        }
        return smilDocumentImpl;
    }

    private static SMILDocument createSmilDocument(SlideshowModel slideshowModel) {
        SMILMediaElement sMILMediaElement;
        SmilDocumentImpl smilDocumentImpl = new SmilDocumentImpl();
        SMILElement sMILElement = (SMILElement) smilDocumentImpl.createElement("smil");
        smilDocumentImpl.appendChild(sMILElement);
        SMILElement sMILElement2 = (SMILElement) smilDocumentImpl.createElement("head");
        sMILElement.appendChild(sMILElement2);
        SMILLayoutElement sMILLayoutElement = (SMILLayoutElement) smilDocumentImpl.createElement("layout");
        sMILElement2.appendChild(sMILLayoutElement);
        SMILRootLayoutElement sMILRootLayoutElement = (SMILRootLayoutElement) smilDocumentImpl.createElement("root-layout");
        LayoutModel layout = slideshowModel.getLayout();
        sMILRootLayoutElement.setWidth(layout.getLayoutWidth());
        sMILRootLayoutElement.setHeight(layout.getLayoutHeight());
        String backgroundColor = layout.getBackgroundColor();
        if (!TextUtils.isEmpty(backgroundColor)) {
            sMILRootLayoutElement.setBackgroundColor(backgroundColor);
        }
        sMILLayoutElement.appendChild(sMILRootLayoutElement);
        ArrayList regions = layout.getRegions();
        ArrayList arrayList = new ArrayList();
        Iterator it = regions.iterator();
        while (it.hasNext()) {
            RegionModel regionModel = (RegionModel) it.next();
            SMILRegionElement sMILRegionElement = (SMILRegionElement) smilDocumentImpl.createElement("region");
            sMILRegionElement.setId(regionModel.getRegionId());
            sMILRegionElement.setLeft(regionModel.getLeft());
            sMILRegionElement.setTop(regionModel.getTop());
            sMILRegionElement.setWidth(regionModel.getWidth());
            sMILRegionElement.setHeight(regionModel.getHeight());
            sMILRegionElement.setFit(regionModel.getFit());
            arrayList.add(sMILRegionElement);
        }
        sMILElement.appendChild((SMILElement) smilDocumentImpl.createElement("body"));
        Iterator it2 = slideshowModel.iterator();
        boolean z = false;
        boolean z2 = false;
        while (it2.hasNext()) {
            SlideModel slideModel = (SlideModel) it2.next();
            SMILParElement addPar = addPar(smilDocumentImpl);
            addPar.setDur(((float) slideModel.getDuration()) / 1000.0f);
            addParElementEventListeners((EventTarget) addPar, slideModel);
            Iterator it3 = slideModel.iterator();
            while (it3.hasNext()) {
                MediaModel mediaModel = (MediaModel) it3.next();
                String src = mediaModel.getSrc();
                if (!(mediaModel instanceof TextModel)) {
                    boolean z3 = mediaModel instanceof ImageModel;
                    String str = LayoutModel.IMAGE_REGION_ID;
                    if (z3) {
                        sMILMediaElement = createMediaElement(ELEMENT_TAG_IMAGE, smilDocumentImpl, src);
                        z2 = setRegion((SMILRegionMediaElement) sMILMediaElement, arrayList, sMILLayoutElement, str, z2);
                    } else if (mediaModel instanceof VideoModel) {
                        sMILMediaElement = createMediaElement(ELEMENT_TAG_VIDEO, smilDocumentImpl, src);
                        z2 = setRegion((SMILRegionMediaElement) sMILMediaElement, arrayList, sMILLayoutElement, str, z2);
                    } else if (mediaModel instanceof AudioModel) {
                        sMILMediaElement = createMediaElement(ELEMENT_TAG_AUDIO, smilDocumentImpl, src);
                    } else {
                        StringBuilder sb = new StringBuilder("Unsupport media: ");
                        sb.append(mediaModel);
                        Log.w(TAG, sb.toString());
                    }
                } else if (!TextUtils.isEmpty(((TextModel) mediaModel).getText())) {
                    sMILMediaElement = createMediaElement(ELEMENT_TAG_TEXT, smilDocumentImpl, src);
                    z = setRegion((SMILRegionMediaElement) sMILMediaElement, arrayList, sMILLayoutElement, LayoutModel.TEXT_REGION_ID, z);
                }
                int begin = mediaModel.getBegin();
                if (begin != 0) {
                    sMILMediaElement.setAttribute("begin", String.valueOf(begin / 1000));
                }
                int duration = mediaModel.getDuration();
                if (duration != 0) {
                    sMILMediaElement.setDur(((float) duration) / 1000.0f);
                }
                addPar.appendChild(sMILMediaElement);
                addMediaElementEventListeners((EventTarget) sMILMediaElement, mediaModel);
            }
        }
        return smilDocumentImpl;
    }

    private static SMILRegionElement findRegionElementById(ArrayList<SMILRegionElement> arrayList, String str) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            SMILRegionElement sMILRegionElement = (SMILRegionElement) it.next();
            if (sMILRegionElement.getId().equals(str)) {
                return sMILRegionElement;
            }
        }
        return null;
    }

    private static boolean setRegion(SMILRegionMediaElement sMILRegionMediaElement, ArrayList<SMILRegionElement> arrayList, SMILLayoutElement sMILLayoutElement, String str, boolean z) {
        SMILRegionElement findRegionElementById = findRegionElementById(arrayList, str);
        if (z || findRegionElementById == null) {
            return false;
        }
        sMILRegionMediaElement.setRegion(findRegionElementById);
        sMILLayoutElement.appendChild(findRegionElementById);
        return true;
    }

    static void addMediaElementEventListeners(EventTarget eventTarget, MediaModel mediaModel) {
        eventTarget.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT, mediaModel, false);
        eventTarget.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT, mediaModel, false);
        eventTarget.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT, mediaModel, false);
        eventTarget.addEventListener(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT, mediaModel, false);
    }

    static void addParElementEventListeners(EventTarget eventTarget, SlideModel slideModel) {
        eventTarget.addEventListener(SmilParElementImpl.SMIL_SLIDE_START_EVENT, slideModel, false);
        eventTarget.addEventListener(SmilParElementImpl.SMIL_SLIDE_END_EVENT, slideModel, false);
    }
}
