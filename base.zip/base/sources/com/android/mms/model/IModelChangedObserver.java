package com.android.mms.model;

public interface IModelChangedObserver {
    void onModelChanged(Model model, boolean z);
}
