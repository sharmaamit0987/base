package com.android.mms.model;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import com.android.mms.ContentRestrictionException;
import com.android.mms.dom.smil.SmilMediaElementImpl;
import com.android.mms.drm.DrmWrapper;
import com.android.mms.model.MediaModel.MediaAction;
import com.google.android.mms.MmsException;
import com.google.android.mms.util.SqliteWrapper;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.events.Event;

public class AudioModel extends MediaModel {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    private static final String TAG = "AudioModel";
    private final HashMap<String, String> mExtras;

    /* access modifiers changed from: protected */
    public boolean isPlayable() {
        return true;
    }

    public AudioModel(Context context, Uri uri) throws MmsException {
        this(context, (String) null, (String) null, uri);
        initModelFromUri(uri);
        checkContentRestriction();
    }

    public AudioModel(Context context, String str, String str2, Uri uri) throws MmsException {
        super(context, SmilHelper.ELEMENT_TAG_AUDIO, str, str2, uri);
        this.mExtras = new HashMap<>();
    }

    public AudioModel(Context context, String str, String str2, DrmWrapper drmWrapper) throws IOException {
        super(context, SmilHelper.ELEMENT_TAG_AUDIO, str, str2, drmWrapper);
        this.mExtras = new HashMap<>();
    }

    /* JADX INFO: finally extract failed */
    private void initModelFromUri(Uri uri) throws MmsException {
        String str;
        String str2 = "artist";
        String str3 = "album";
        Cursor query = SqliteWrapper.query(this.mContext, this.mContext.getContentResolver(), uri, null, null, null, null);
        if (query != null) {
            try {
                if (query.moveToFirst()) {
                    String str4 = "_data";
                    if (isMmsUri(uri)) {
                        str = query.getString(query.getColumnIndexOrThrow(str4));
                        this.mContentType = query.getString(query.getColumnIndexOrThrow("ct"));
                    } else {
                        str = query.getString(query.getColumnIndexOrThrow(str4));
                        this.mContentType = query.getString(query.getColumnIndexOrThrow("mime_type"));
                        String string = query.getString(query.getColumnIndexOrThrow(str3));
                        if (!TextUtils.isEmpty(string)) {
                            this.mExtras.put(str3, string);
                        }
                        String string2 = query.getString(query.getColumnIndexOrThrow(str2));
                        if (!TextUtils.isEmpty(string2)) {
                            this.mExtras.put(str2, string2);
                        }
                    }
                    this.mSrc = str.substring(str.lastIndexOf(47) + 1);
                    if (!TextUtils.isEmpty(this.mContentType)) {
                        query.close();
                        initMediaDuration();
                        return;
                    }
                    throw new MmsException("Type of media is unknown.");
                }
                StringBuilder sb = new StringBuilder("Nothing found: ");
                sb.append(uri);
                throw new MmsException(sb.toString());
            } catch (Throwable th) {
                query.close();
                throw th;
            }
        } else {
            StringBuilder sb2 = new StringBuilder("Bad URI: ");
            sb2.append(uri);
            throw new MmsException(sb2.toString());
        }
    }

    public void stop() {
        appendAction(MediaAction.STOP);
        notifyModelChanged(false);
    }

    public void handleEvent(Event event) {
        String type = event.getType();
        MediaAction mediaAction = MediaAction.NO_ACTIVE_ACTION;
        if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_START_EVENT)) {
            mediaAction = MediaAction.START;
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_END_EVENT)) {
            mediaAction = MediaAction.STOP;
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_PAUSE_EVENT)) {
            mediaAction = MediaAction.PAUSE;
        } else if (type.equals(SmilMediaElementImpl.SMIL_MEDIA_SEEK_EVENT)) {
            mediaAction = MediaAction.SEEK;
            this.mSeekTo = event.getSeekTo();
        }
        appendAction(mediaAction);
        notifyModelChanged(false);
    }

    public Map<String, ?> getExtras() {
        return this.mExtras;
    }

    /* access modifiers changed from: protected */
    public void checkContentRestriction() throws ContentRestrictionException {
        ContentRestrictionFactory.getContentRestriction().checkAudioContentType(this.mContentType);
    }
}
