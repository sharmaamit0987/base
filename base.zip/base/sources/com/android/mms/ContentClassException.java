package com.android.mms;

import com.google.android.mms.MmsException;

public final class ContentClassException extends MmsException {
    private final boolean mIsRestricted;

    public ContentClassException(boolean z) {
        this.mIsRestricted = z;
    }

    public ContentClassException(String str, boolean z) {
        super(str);
        this.mIsRestricted = z;
    }

    public ContentClassException(Exception exc, boolean z) {
        super(exc);
        this.mIsRestricted = z;
    }

    public boolean isRestricted() {
        return this.mIsRestricted;
    }
}
