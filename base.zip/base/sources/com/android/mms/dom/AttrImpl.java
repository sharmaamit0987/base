package com.android.mms.dom;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.UserDataHandler;

public class AttrImpl extends NodeImpl implements Attr {
    private String mName;
    private String mValue;

    public short compareDocumentPosition(Node node) throws DOMException {
        return 0;
    }

    public String getBaseURI() {
        return null;
    }

    public Object getFeature(String str, String str2) {
        return null;
    }

    public Node getNextSibling() {
        return null;
    }

    public short getNodeType() {
        return 2;
    }

    public Element getOwnerElement() {
        return null;
    }

    public Node getParentNode() {
        return null;
    }

    public Node getPreviousSibling() {
        return null;
    }

    public TypeInfo getSchemaTypeInfo() {
        return null;
    }

    public String getTextContent() throws DOMException {
        return null;
    }

    public Object getUserData(String str) {
        return null;
    }

    public boolean isDefaultNamespace(String str) {
        return false;
    }

    public boolean isEqualNode(Node node) {
        return false;
    }

    public boolean isId() {
        return false;
    }

    public boolean isSameNode(Node node) {
        return false;
    }

    public String lookupNamespaceURI(String str) {
        return null;
    }

    public String lookupPrefix(String str) {
        return null;
    }

    public void setTextContent(String str) throws DOMException {
    }

    public Object setUserData(String str, Object obj, UserDataHandler userDataHandler) {
        return null;
    }

    protected AttrImpl(DocumentImpl documentImpl, String str) {
        super(documentImpl);
        this.mName = str;
    }

    public String getName() {
        return this.mName;
    }

    public boolean getSpecified() {
        return this.mValue != null;
    }

    public String getValue() {
        return this.mValue;
    }

    public void setValue(String str) throws DOMException {
        this.mValue = str;
    }

    public String getNodeName() {
        return this.mName;
    }

    public void setNodeValue(String str) throws DOMException {
        setValue(str);
    }
}
