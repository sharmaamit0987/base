package com.android.mms.dom;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.UserDataHandler;

public class ElementImpl extends NodeImpl implements Element {
    private NamedNodeMap mAttributes = new NamedNodeMapImpl();
    private String mTagName;

    public short compareDocumentPosition(Node node) throws DOMException {
        return 0;
    }

    public String getAttributeNS(String str, String str2) {
        return null;
    }

    public Attr getAttributeNodeNS(String str, String str2) {
        return null;
    }

    public String getBaseURI() {
        return null;
    }

    public NodeList getElementsByTagNameNS(String str, String str2) {
        return null;
    }

    public Object getFeature(String str, String str2) {
        return null;
    }

    public short getNodeType() {
        return 1;
    }

    public TypeInfo getSchemaTypeInfo() {
        return null;
    }

    public String getTextContent() throws DOMException {
        return null;
    }

    public Object getUserData(String str) {
        return null;
    }

    public boolean hasAttributeNS(String str, String str2) {
        return false;
    }

    public boolean isDefaultNamespace(String str) {
        return false;
    }

    public boolean isEqualNode(Node node) {
        return false;
    }

    public boolean isSameNode(Node node) {
        return false;
    }

    public String lookupNamespaceURI(String str) {
        return null;
    }

    public String lookupPrefix(String str) {
        return null;
    }

    public void removeAttribute(String str) throws DOMException {
    }

    public void removeAttributeNS(String str, String str2) throws DOMException {
    }

    public Attr removeAttributeNode(Attr attr) throws DOMException {
        return null;
    }

    public void setAttributeNS(String str, String str2, String str3) throws DOMException {
    }

    public Attr setAttributeNode(Attr attr) throws DOMException {
        return null;
    }

    public Attr setAttributeNodeNS(Attr attr) throws DOMException {
        return null;
    }

    public void setIdAttribute(String str, boolean z) throws DOMException {
    }

    public void setIdAttributeNS(String str, String str2, boolean z) throws DOMException {
    }

    public void setIdAttributeNode(Attr attr, boolean z) throws DOMException {
    }

    public void setTextContent(String str) throws DOMException {
    }

    public Object setUserData(String str, Object obj, UserDataHandler userDataHandler) {
        return null;
    }

    protected ElementImpl(DocumentImpl documentImpl, String str) {
        super(documentImpl);
        this.mTagName = str;
    }

    public String getAttribute(String str) {
        Attr attributeNode = getAttributeNode(str);
        return attributeNode != null ? attributeNode.getValue() : "";
    }

    public Attr getAttributeNode(String str) {
        return (Attr) this.mAttributes.getNamedItem(str);
    }

    public NodeList getElementsByTagName(String str) {
        return new NodeListImpl(this, str, true);
    }

    public String getTagName() {
        return this.mTagName;
    }

    public boolean hasAttribute(String str) {
        return getAttributeNode(str) != null;
    }

    public void setAttribute(String str, String str2) throws DOMException {
        Attr attributeNode = getAttributeNode(str);
        if (attributeNode == null) {
            attributeNode = this.mOwnerDocument.createAttribute(str);
        }
        attributeNode.setNodeValue(str2);
        this.mAttributes.setNamedItem(attributeNode);
    }

    public String getNodeName() {
        return this.mTagName;
    }

    public NamedNodeMap getAttributes() {
        return this.mAttributes;
    }

    public boolean hasAttributes() {
        return this.mAttributes.getLength() > 0;
    }
}
