package com.android.mms.dom;

import com.android.mms.dom.events.EventTargetImpl;
import java.util.NoSuchElementException;
import java.util.Vector;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventException;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;

public abstract class NodeImpl implements Node, EventTarget {
    private final Vector<Node> mChildNodes = new Vector<>();
    private final EventTarget mEventTarget = new EventTargetImpl(this);
    DocumentImpl mOwnerDocument;
    private Node mParentNode;

    public Node cloneNode(boolean z) {
        return null;
    }

    public NamedNodeMap getAttributes() {
        return null;
    }

    public String getLocalName() {
        return null;
    }

    public String getNamespaceURI() {
        return null;
    }

    public abstract String getNodeName();

    public abstract short getNodeType();

    public String getNodeValue() throws DOMException {
        return null;
    }

    public String getPrefix() {
        return null;
    }

    public boolean hasAttributes() {
        return false;
    }

    public Node insertBefore(Node node, Node node2) throws DOMException {
        return null;
    }

    public boolean isSupported(String str, String str2) {
        return false;
    }

    public void normalize() {
    }

    public void setNodeValue(String str) throws DOMException {
    }

    public void setPrefix(String str) throws DOMException {
    }

    protected NodeImpl(DocumentImpl documentImpl) {
        this.mOwnerDocument = documentImpl;
    }

    public Node appendChild(Node node) throws DOMException {
        ((NodeImpl) node).setParentNode(this);
        this.mChildNodes.remove(node);
        this.mChildNodes.add(node);
        return node;
    }

    public NodeList getChildNodes() {
        return new NodeListImpl(this, null, false);
    }

    public Node getFirstChild() {
        try {
            return (Node) this.mChildNodes.firstElement();
        } catch (NoSuchElementException unused) {
            return null;
        }
    }

    public Node getLastChild() {
        try {
            return (Node) this.mChildNodes.lastElement();
        } catch (NoSuchElementException unused) {
            return null;
        }
    }

    public Node getNextSibling() {
        Node node = this.mParentNode;
        if (node == null || this == node.getLastChild()) {
            return null;
        }
        Vector<Node> vector = ((NodeImpl) this.mParentNode).mChildNodes;
        return (Node) vector.elementAt(vector.indexOf(this) + 1);
    }

    public Document getOwnerDocument() {
        return this.mOwnerDocument;
    }

    public Node getParentNode() {
        return this.mParentNode;
    }

    public Node getPreviousSibling() {
        Node node = this.mParentNode;
        if (node == null || this == node.getFirstChild()) {
            return null;
        }
        Vector<Node> vector = ((NodeImpl) this.mParentNode).mChildNodes;
        return (Node) vector.elementAt(vector.indexOf(this) - 1);
    }

    public boolean hasChildNodes() {
        return !this.mChildNodes.isEmpty();
    }

    public Node removeChild(Node node) throws DOMException {
        if (this.mChildNodes.contains(node)) {
            this.mChildNodes.remove(node);
            ((NodeImpl) node).setParentNode(null);
            return null;
        }
        throw new DOMException(8, "Child does not exist");
    }

    public Node replaceChild(Node node, Node node2) throws DOMException {
        if (this.mChildNodes.contains(node2)) {
            try {
                this.mChildNodes.remove(node);
            } catch (DOMException unused) {
            }
            Vector<Node> vector = this.mChildNodes;
            vector.setElementAt(node, vector.indexOf(node2));
            ((NodeImpl) node).setParentNode(this);
            ((NodeImpl) node2).setParentNode(null);
            return node2;
        }
        throw new DOMException(8, "Old child does not exist");
    }

    private void setParentNode(Node node) {
        this.mParentNode = node;
    }

    public void addEventListener(String str, EventListener eventListener, boolean z) {
        this.mEventTarget.addEventListener(str, eventListener, z);
    }

    public void removeEventListener(String str, EventListener eventListener, boolean z) {
        this.mEventTarget.removeEventListener(str, eventListener, z);
    }

    public boolean dispatchEvent(Event event) throws EventException {
        return this.mEventTarget.dispatchEvent(event);
    }
}
