package com.android.mms.dom.smil;

import org.w3c.dom.NodeList;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILRegionElement;
import org.w3c.dom.smil.SMILRegionMediaElement;

public class SmilRegionMediaElementImpl extends SmilMediaElementImpl implements SMILRegionMediaElement {
    private SMILRegionElement mRegion;

    SmilRegionMediaElementImpl(SmilDocumentImpl smilDocumentImpl, String str) {
        super(smilDocumentImpl, str);
    }

    public SMILRegionElement getRegion() {
        if (this.mRegion == null) {
            String str = "region";
            NodeList elementsByTagName = ((SMILDocument) getOwnerDocument()).getLayout().getElementsByTagName(str);
            for (int i = 0; i < elementsByTagName.getLength(); i++) {
                SMILRegionElement sMILRegionElement = (SMILRegionElement) elementsByTagName.item(i);
                if (sMILRegionElement.getId().equals(getAttribute(str))) {
                    this.mRegion = sMILRegionElement;
                }
            }
        }
        return this.mRegion;
    }

    public void setRegion(SMILRegionElement sMILRegionElement) {
        setAttribute("region", sMILRegionElement.getId());
        this.mRegion = sMILRegionElement;
    }
}
