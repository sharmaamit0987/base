package com.android.mms.dom.smil;

import android.util.Log;
import java.util.ArrayList;
import org.w3c.dom.DOMException;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.TimeList;

public abstract class ElementTimeImpl implements ElementTime {
    private static final String FILLDEFAULT_ATTRIBUTE_NAME = "fillDefault";
    private static final String FILL_ATTRIBUTE_NAME = "fill";
    private static final String FILL_AUTO_ATTRIBUTE = "auto";
    private static final String FILL_FREEZE_ATTRIBUTE = "freeze";
    private static final String FILL_HOLD_ATTRIBUTE = "hold";
    private static final String FILL_REMOVE_ATTRIBUTE = "remove";
    private static final String FILL_TRANSITION_ATTRIBUTE = "transition";
    private static final String TAG = "ElementTimeImpl";
    final SMILElement mSmilElement;

    /* access modifiers changed from: 0000 */
    public int getBeginConstraints() {
        return 255;
    }

    /* access modifiers changed from: 0000 */
    public int getEndConstraints() {
        return 255;
    }

    /* access modifiers changed from: 0000 */
    public abstract ElementTime getParentElementTime();

    ElementTimeImpl(SMILElement sMILElement) {
        this.mSmilElement = sMILElement;
    }

    public TimeList getBegin() {
        String[] split = this.mSmilElement.getAttribute("begin").split(";");
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < split.length; i++) {
            try {
                arrayList.add(new TimeImpl(split[i], getBeginConstraints()));
            } catch (IllegalArgumentException unused) {
            }
        }
        if (arrayList.size() == 0) {
            arrayList.add(new TimeImpl("0", 255));
        }
        return new TimeListImpl(arrayList);
    }

    public float getDur() {
        try {
            String attribute = this.mSmilElement.getAttribute("dur");
            if (attribute != null) {
                return TimeImpl.parseClockValue(attribute) / 1000.0f;
            }
        } catch (IllegalArgumentException unused) {
        }
        return 0.0f;
    }

    public TimeList getEnd() {
        ArrayList arrayList = new ArrayList();
        String[] split = this.mSmilElement.getAttribute("end").split(";");
        int length = split.length;
        if (!(length == 1 && split[0].length() == 0)) {
            for (int i = 0; i < length; i++) {
                try {
                    arrayList.add(new TimeImpl(split[i], getEndConstraints()));
                } catch (IllegalArgumentException e) {
                    Log.e(TAG, "Malformed time value.", e);
                }
            }
        }
        if (arrayList.size() == 0) {
            float dur = getDur();
            if (dur < 0.0f) {
                arrayList.add(new TimeImpl("indefinite", getEndConstraints()));
            } else {
                TimeList begin = getBegin();
                for (int i2 = 0; i2 < begin.getLength(); i2++) {
                    StringBuilder sb = new StringBuilder(String.valueOf(begin.item(i2).getResolvedOffset() + ((double) dur)));
                    sb.append("s");
                    arrayList.add(new TimeImpl(sb.toString(), getEndConstraints()));
                }
            }
        }
        return new TimeListImpl(arrayList);
    }

    public short getFill() {
        String attribute = this.mSmilElement.getAttribute(FILL_ATTRIBUTE_NAME);
        if (attribute.equalsIgnoreCase(FILL_FREEZE_ATTRIBUTE)) {
            return 1;
        }
        if (attribute.equalsIgnoreCase(FILL_REMOVE_ATTRIBUTE)) {
            return 0;
        }
        if (attribute.equalsIgnoreCase(FILL_HOLD_ATTRIBUTE) || attribute.equalsIgnoreCase(FILL_TRANSITION_ATTRIBUTE)) {
            return 1;
        }
        if (!attribute.equalsIgnoreCase(FILL_AUTO_ATTRIBUTE)) {
            short fillDefault = getFillDefault();
            if (fillDefault != 2) {
                return fillDefault;
            }
        }
        if (this.mSmilElement.getAttribute("dur").length() == 0 && this.mSmilElement.getAttribute("end").length() == 0 && this.mSmilElement.getAttribute("repeatCount").length() == 0 && this.mSmilElement.getAttribute("repeatDur").length() == 0) {
            return 1;
        }
        return 0;
    }

    public short getFillDefault() {
        String attribute = this.mSmilElement.getAttribute(FILLDEFAULT_ATTRIBUTE_NAME);
        if (attribute.equalsIgnoreCase(FILL_REMOVE_ATTRIBUTE)) {
            return 0;
        }
        if (attribute.equalsIgnoreCase(FILL_FREEZE_ATTRIBUTE)) {
            return 1;
        }
        if (attribute.equalsIgnoreCase(FILL_AUTO_ATTRIBUTE)) {
            return 2;
        }
        if (attribute.equalsIgnoreCase(FILL_HOLD_ATTRIBUTE) || attribute.equalsIgnoreCase(FILL_TRANSITION_ATTRIBUTE)) {
            return 1;
        }
        ElementTime parentElementTime = getParentElementTime();
        if (parentElementTime == null) {
            return 2;
        }
        return ((ElementTimeImpl) parentElementTime).getFillDefault();
    }

    public float getRepeatCount() {
        try {
            float parseFloat = Float.parseFloat(this.mSmilElement.getAttribute("repeatCount"));
            if (parseFloat > 0.0f) {
                return parseFloat;
            }
            return 0.0f;
        } catch (NumberFormatException unused) {
        }
    }

    public float getRepeatDur() {
        try {
            float parseClockValue = TimeImpl.parseClockValue(this.mSmilElement.getAttribute("repeatDur"));
            if (parseClockValue > 0.0f) {
                return parseClockValue;
            }
            return 0.0f;
        } catch (IllegalArgumentException unused) {
        }
    }

    public short getRestart() {
        String attribute = this.mSmilElement.getAttribute("restart");
        if (attribute.equalsIgnoreCase("never")) {
            return 1;
        }
        return attribute.equalsIgnoreCase("whenNotActive") ? (short) 2 : 0;
    }

    public void setBegin(TimeList timeList) throws DOMException {
        this.mSmilElement.setAttribute("begin", "indefinite");
    }

    public void setDur(float f) throws DOMException {
        SMILElement sMILElement = this.mSmilElement;
        StringBuilder sb = new StringBuilder(String.valueOf(Integer.toString((int) (f * 1000.0f))));
        sb.append("ms");
        sMILElement.setAttribute("dur", sb.toString());
    }

    public void setEnd(TimeList timeList) throws DOMException {
        this.mSmilElement.setAttribute("end", "indefinite");
    }

    public void setFill(short s) throws DOMException {
        String str = FILL_ATTRIBUTE_NAME;
        if (s == 1) {
            this.mSmilElement.setAttribute(str, FILL_FREEZE_ATTRIBUTE);
        } else {
            this.mSmilElement.setAttribute(str, FILL_REMOVE_ATTRIBUTE);
        }
    }

    public void setFillDefault(short s) throws DOMException {
        String str = FILLDEFAULT_ATTRIBUTE_NAME;
        if (s == 1) {
            this.mSmilElement.setAttribute(str, FILL_FREEZE_ATTRIBUTE);
        } else {
            this.mSmilElement.setAttribute(str, FILL_REMOVE_ATTRIBUTE);
        }
    }

    public void setRepeatCount(float f) throws DOMException {
        this.mSmilElement.setAttribute("repeatCount", f > 0.0f ? Float.toString(f) : "indefinite");
    }

    public void setRepeatDur(float f) throws DOMException {
        String str;
        if (f > 0.0f) {
            StringBuilder sb = new StringBuilder(String.valueOf(Float.toString(f)));
            sb.append("ms");
            str = sb.toString();
        } else {
            str = "indefinite";
        }
        this.mSmilElement.setAttribute("repeatDur", str);
    }

    public void setRestart(short s) throws DOMException {
        String str = "restart";
        if (s == 1) {
            this.mSmilElement.setAttribute(str, "never");
        } else if (s == 2) {
            this.mSmilElement.setAttribute(str, "whenNotActive");
        } else {
            this.mSmilElement.setAttribute(str, "always");
        }
    }
}
