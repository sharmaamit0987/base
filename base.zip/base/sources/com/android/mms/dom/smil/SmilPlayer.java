package com.android.mms.dom.smil;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.w3c.dom.NodeList;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.smil.ElementParallelTimeContainer;
import org.w3c.dom.smil.ElementSequentialTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

public class SmilPlayer implements Runnable {
    private static final boolean DEBUG = false;
    private static final boolean LOCAL_LOGV = false;
    public static final String MEDIA_TIME_UPDATED_EVENT = "mediaTimeUpdated";
    private static final String TAG = "SmilPlayer";
    private static final int TIMESLICE = 200;
    private static SmilPlayer sPlayer;
    private static final Comparator<TimelineEntry> sTimelineEntryComparator = new Comparator<TimelineEntry>() {
        public int compare(TimelineEntry timelineEntry, TimelineEntry timelineEntry2) {
            return Double.compare(timelineEntry.getOffsetTime(), timelineEntry2.getOffsetTime());
        }
    };
    private SmilPlayerAction mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    private ArrayList<ElementTime> mActiveElements;
    private ArrayList<TimelineEntry> mAllEntries;
    private int mCurrentElement;
    private int mCurrentSlide;
    private long mCurrentTime;
    private Event mMediaTimeUpdatedEvent;
    private Thread mPlayerThread;
    private ElementTime mRoot;
    private SmilPlayerState mState = SmilPlayerState.INITIALIZED;

    private enum SmilPlayerAction {
        NO_ACTIVE_ACTION,
        RELOAD,
        STOP,
        PAUSE,
        START
    }

    private enum SmilPlayerState {
        INITIALIZED,
        PLAYING,
        PLAYED,
        PAUSED,
        STOPPED
    }

    private static final class TimelineEntry {
        static final int ACTION_BEGIN = 0;
        static final int ACTION_END = 1;
        private final int mAction;
        private final ElementTime mElement;
        /* access modifiers changed from: private */
        public final double mOffsetTime;

        public TimelineEntry(double d, ElementTime elementTime, int i) {
            this.mOffsetTime = d;
            this.mElement = elementTime;
            this.mAction = i;
        }

        public double getOffsetTime() {
            return this.mOffsetTime;
        }

        public ElementTime getElement() {
            return this.mElement;
        }

        public int getAction() {
            return this.mAction;
        }
    }

    private static ArrayList<TimelineEntry> getParTimeline(ElementParallelTimeContainer elementParallelTimeContainer, double d, double d2) {
        ArrayList<TimelineEntry> arrayList = new ArrayList<>();
        double resolvedOffset = elementParallelTimeContainer.getBegin().item(0).getResolvedOffset() + d;
        if (resolvedOffset > d2) {
            return arrayList;
        }
        arrayList.add(new TimelineEntry(resolvedOffset, elementParallelTimeContainer, 0));
        double resolvedOffset2 = elementParallelTimeContainer.getEnd().item(0).getResolvedOffset() + d;
        if (resolvedOffset2 <= d2) {
            d2 = resolvedOffset2;
        }
        TimelineEntry timelineEntry = new TimelineEntry(d2, elementParallelTimeContainer, 1);
        NodeList timeChildren = elementParallelTimeContainer.getTimeChildren();
        for (int i = 0; i < timeChildren.getLength(); i++) {
            arrayList.addAll(getTimeline((ElementTime) timeChildren.item(i), d, d2));
        }
        Collections.sort(arrayList, sTimelineEntryComparator);
        NodeList activeChildrenAt = elementParallelTimeContainer.getActiveChildrenAt(((float) (d2 - d)) * 1000.0f);
        for (int i2 = 0; i2 < activeChildrenAt.getLength(); i2++) {
            arrayList.add(new TimelineEntry(d2, (ElementTime) activeChildrenAt.item(i2), 1));
        }
        arrayList.add(timelineEntry);
        return arrayList;
    }

    private static ArrayList<TimelineEntry> getSeqTimeline(ElementSequentialTimeContainer elementSequentialTimeContainer, double d, double d2) {
        ArrayList<TimelineEntry> arrayList = new ArrayList<>();
        double resolvedOffset = elementSequentialTimeContainer.getBegin().item(0).getResolvedOffset() + d;
        if (resolvedOffset > d2) {
            return arrayList;
        }
        arrayList.add(new TimelineEntry(resolvedOffset, elementSequentialTimeContainer, 0));
        double resolvedOffset2 = elementSequentialTimeContainer.getEnd().item(0).getResolvedOffset() + d;
        if (resolvedOffset2 <= d2) {
            d2 = resolvedOffset2;
        }
        TimelineEntry timelineEntry = new TimelineEntry(d2, elementSequentialTimeContainer, 1);
        NodeList timeChildren = elementSequentialTimeContainer.getTimeChildren();
        double d3 = d;
        for (int i = 0; i < timeChildren.getLength(); i++) {
            ArrayList timeline = getTimeline((ElementTime) timeChildren.item(i), d3, d2);
            arrayList.addAll(timeline);
            d3 = ((TimelineEntry) timeline.get(timeline.size() - 1)).getOffsetTime();
        }
        NodeList activeChildrenAt = elementSequentialTimeContainer.getActiveChildrenAt((float) (d2 - d));
        for (int i2 = 0; i2 < activeChildrenAt.getLength(); i2++) {
            arrayList.add(new TimelineEntry(d2, (ElementTime) activeChildrenAt.item(i2), 1));
        }
        arrayList.add(timelineEntry);
        return arrayList;
    }

    private static ArrayList<TimelineEntry> getTimeline(ElementTime elementTime, double d, double d2) {
        if (elementTime instanceof ElementParallelTimeContainer) {
            return getParTimeline((ElementParallelTimeContainer) elementTime, d, d2);
        }
        if (elementTime instanceof ElementSequentialTimeContainer) {
            return getSeqTimeline((ElementSequentialTimeContainer) elementTime, d, d2);
        }
        ArrayList<TimelineEntry> arrayList = new ArrayList<>();
        TimeList begin = elementTime.getBegin();
        for (int i = 0; i < begin.getLength(); i++) {
            Time item = begin.item(i);
            if (item.getResolved()) {
                double resolvedOffset = item.getResolvedOffset() + d;
                if (resolvedOffset <= d2) {
                    arrayList.add(new TimelineEntry(resolvedOffset, elementTime, 0));
                }
            }
        }
        TimeList end = elementTime.getEnd();
        for (int i2 = 0; i2 < end.getLength(); i2++) {
            Time item2 = end.item(i2);
            if (item2.getResolved()) {
                double resolvedOffset2 = item2.getResolvedOffset() + d;
                if (resolvedOffset2 <= d2) {
                    arrayList.add(new TimelineEntry(resolvedOffset2, elementTime, 1));
                }
            }
        }
        Collections.sort(arrayList, sTimelineEntryComparator);
        return arrayList;
    }

    private SmilPlayer() {
    }

    public static SmilPlayer getPlayer() {
        if (sPlayer == null) {
            sPlayer = new SmilPlayer();
        }
        return sPlayer;
    }

    public synchronized boolean isPlayingState() {
        return this.mState == SmilPlayerState.PLAYING;
    }

    public synchronized boolean isPlayedState() {
        return this.mState == SmilPlayerState.PLAYED;
    }

    public synchronized boolean isPausedState() {
        return this.mState == SmilPlayerState.PAUSED;
    }

    public synchronized boolean isStoppedState() {
        return this.mState == SmilPlayerState.STOPPED;
    }

    private synchronized boolean isPauseAction() {
        return this.mAction == SmilPlayerAction.PAUSE;
    }

    private synchronized boolean isStartAction() {
        return this.mAction == SmilPlayerAction.START;
    }

    private synchronized boolean isStopAction() {
        return this.mAction == SmilPlayerAction.STOP;
    }

    private synchronized boolean isReloadAction() {
        return this.mAction == SmilPlayerAction.RELOAD;
    }

    public synchronized void init(ElementTime elementTime) {
        this.mRoot = elementTime;
        this.mAllEntries = getTimeline(elementTime, 0.0d, 9.223372036854776E18d);
        Event createEvent = ((DocumentEvent) this.mRoot).createEvent("Event");
        this.mMediaTimeUpdatedEvent = createEvent;
        createEvent.initEvent(MEDIA_TIME_UPDATED_EVENT, false, false);
        this.mActiveElements = new ArrayList<>();
    }

    public synchronized void play() {
        if (!isPlayingState()) {
            this.mCurrentTime = 0;
            this.mCurrentElement = 0;
            this.mCurrentSlide = 0;
            this.mPlayerThread = new Thread(this);
            this.mState = SmilPlayerState.PLAYING;
            this.mPlayerThread.start();
        } else {
            Log.w(TAG, "Error State: Playback is playing!");
        }
    }

    public synchronized void pause() {
        if (isPlayingState()) {
            this.mAction = SmilPlayerAction.PAUSE;
            notifyAll();
        } else {
            Log.w(TAG, "Error State: Playback is not playing!");
        }
    }

    public synchronized void start() {
        if (isPausedState()) {
            resumeActiveElements();
            this.mAction = SmilPlayerAction.START;
            notifyAll();
        } else if (isPlayedState()) {
            play();
        } else {
            Log.w(TAG, "Error State: Playback can not be started!");
        }
    }

    public synchronized void stop() {
        if (!isPlayingState()) {
            if (!isPausedState()) {
                if (isPlayedState()) {
                    actionStop();
                }
            }
        }
        this.mAction = SmilPlayerAction.STOP;
        notifyAll();
    }

    public synchronized void stopWhenReload() {
        endActiveElements();
    }

    public synchronized void reload() {
        if (!isPlayingState()) {
            if (!isPausedState()) {
                if (isPlayedState()) {
                    actionReload();
                }
            }
        }
        this.mAction = SmilPlayerAction.RELOAD;
        notifyAll();
    }

    private synchronized boolean isBeginOfSlide(TimelineEntry timelineEntry) {
        return timelineEntry.getAction() == 0 && (timelineEntry.getElement() instanceof SmilParElementImpl);
    }

    private synchronized void reloadActiveSlide() {
        this.mActiveElements.clear();
        beginSmilDocument();
        for (int i = this.mCurrentSlide; i < this.mCurrentElement; i++) {
            actionEntry((TimelineEntry) this.mAllEntries.get(i));
        }
        seekActiveMedia();
    }

    private synchronized void beginSmilDocument() {
        actionEntry((TimelineEntry) this.mAllEntries.get(0));
    }

    private synchronized double getOffsetTime(ElementTime elementTime) {
        for (int i = this.mCurrentSlide; i < this.mCurrentElement; i++) {
            TimelineEntry timelineEntry = (TimelineEntry) this.mAllEntries.get(i);
            if (elementTime.equals(timelineEntry.getElement())) {
                return timelineEntry.getOffsetTime() * 1000.0d;
            }
        }
        return -1.0d;
    }

    private synchronized void seekActiveMedia() {
        int size = this.mActiveElements.size() - 1;
        while (size >= 0) {
            ElementTime elementTime = (ElementTime) this.mActiveElements.get(size);
            if (!(elementTime instanceof SmilParElementImpl)) {
                double offsetTime = getOffsetTime(elementTime);
                if (offsetTime >= 0.0d && offsetTime <= ((double) this.mCurrentTime)) {
                    elementTime.seekElement((float) (((double) this.mCurrentTime) - offsetTime));
                }
                size--;
            } else {
                return;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x004e, code lost:
        return;
     */
    private synchronized void waitForEntry(long j) throws InterruptedException {
        long j2 = 0;
        while (j > 0) {
            long currentTimeMillis = System.currentTimeMillis();
            long min = Math.min(j, 200);
            if (j2 < min) {
                wait(min - j2);
                this.mCurrentTime += min;
            } else {
                this.mCurrentTime += j2;
                min = 0;
            }
            if (!isStopAction() && !isReloadAction()) {
                if (!isPauseAction()) {
                    ((EventTarget) this.mRoot).dispatchEvent(this.mMediaTimeUpdatedEvent);
                    j -= 200;
                    j2 = (System.currentTimeMillis() - currentTimeMillis) - min;
                }
            }
        }
    }

    public synchronized int getDuration() {
        if (this.mAllEntries == null || this.mAllEntries.isEmpty()) {
            return 0;
        }
        return ((int) ((TimelineEntry) this.mAllEntries.get(this.mAllEntries.size() - 1)).mOffsetTime) * 1000;
    }

    public synchronized int getCurrentPosition() {
        return (int) this.mCurrentTime;
    }

    private synchronized void endActiveElements() {
        for (int size = this.mActiveElements.size() - 1; size >= 0; size--) {
            ((ElementTime) this.mActiveElements.get(size)).endElement();
        }
    }

    private synchronized void pauseActiveElements() {
        for (int size = this.mActiveElements.size() - 1; size >= 0; size--) {
            ((ElementTime) this.mActiveElements.get(size)).pauseElement();
        }
    }

    private synchronized void resumeActiveElements() {
        int size = this.mActiveElements.size();
        for (int i = 0; i < size; i++) {
            ((ElementTime) this.mActiveElements.get(i)).resumeElement();
        }
    }

    private synchronized void waitForWakeUp() {
        while (true) {
            try {
                if (isStartAction() || isStopAction()) {
                    break;
                } else if (isReloadAction()) {
                    break;
                } else {
                    wait(200);
                }
            } catch (InterruptedException e) {
                Log.e(TAG, "Unexpected InterruptedException.", e);
            }
        }
        if (isStartAction()) {
            this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
            this.mState = SmilPlayerState.PLAYING;
        }
        return;
    }

    private synchronized void actionEntry(TimelineEntry timelineEntry) {
        int action = timelineEntry.getAction();
        if (action == 0) {
            timelineEntry.getElement().beginElement();
            this.mActiveElements.add(timelineEntry.getElement());
        } else if (action == 1) {
            timelineEntry.getElement().endElement();
            this.mActiveElements.remove(timelineEntry.getElement());
        }
    }

    private synchronized TimelineEntry reloadCurrentEntry() {
        return (TimelineEntry) this.mAllEntries.get(this.mCurrentElement);
    }

    private synchronized void actionPause() {
        pauseActiveElements();
        this.mState = SmilPlayerState.PAUSED;
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    private synchronized void actionStop() {
        endActiveElements();
        this.mCurrentTime = 0;
        this.mCurrentElement = 0;
        this.mCurrentSlide = 0;
        this.mState = SmilPlayerState.STOPPED;
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    private synchronized void actionReload() {
        reloadActiveSlide();
        this.mAction = SmilPlayerAction.NO_ACTIVE_ACTION;
    }

    public void run() {
        TimelineEntry timelineEntry;
        long offsetTime;
        if (!isStoppedState()) {
            int size = this.mAllEntries.size();
            int i = 0;
            while (true) {
                this.mCurrentElement = i;
                int i2 = this.mCurrentElement;
                if (i2 >= size) {
                    this.mState = SmilPlayerState.PLAYED;
                    return;
                }
                timelineEntry = (TimelineEntry) this.mAllEntries.get(i2);
                if (isBeginOfSlide(timelineEntry)) {
                    this.mCurrentSlide = this.mCurrentElement;
                }
                offsetTime = (long) (timelineEntry.getOffsetTime() * 1000.0d);
                while (true) {
                    long j = this.mCurrentTime;
                    if (offsetTime <= j) {
                        break;
                    }
                    try {
                        waitForEntry(offsetTime - j);
                    } catch (InterruptedException e) {
                        Log.e(TAG, "Unexpected InterruptedException.", e);
                    }
                    while (true) {
                        if (isPauseAction() || isStopAction() || isReloadAction()) {
                            if (isPauseAction()) {
                                actionPause();
                                waitForWakeUp();
                            }
                            if (isStopAction()) {
                                actionStop();
                                return;
                            } else if (isReloadAction()) {
                                actionReload();
                                timelineEntry = reloadCurrentEntry();
                                if (isPausedState()) {
                                    this.mAction = SmilPlayerAction.PAUSE;
                                }
                            }
                        }
                    }
                }
                this.mCurrentTime = offsetTime;
                actionEntry(timelineEntry);
                i = this.mCurrentElement + 1;
            }
        }
    }
}
