package com.android.mms.dom.smil;

import com.android.mms.dom.DocumentImpl;
import com.android.mms.dom.events.EventImpl;
import com.android.mms.model.SmilHelper;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;
import org.w3c.dom.events.DocumentEvent;
import org.w3c.dom.events.Event;
import org.w3c.dom.smil.ElementSequentialTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.TimeList;

public class SmilDocumentImpl extends DocumentImpl implements SMILDocument, DocumentEvent {
    public static final String SMIL_DOCUMENT_END_EVENT = "SimlDocumentEnd";
    public static final String SMIL_DOCUMENT_START_EVENT = "SmilDocumentStart";
    ElementSequentialTimeContainer mSeqTimeContainer;

    public Node adoptNode(Node node) throws DOMException {
        return null;
    }

    public short compareDocumentPosition(Node node) throws DOMException {
        return 0;
    }

    public String getBaseURI() {
        return null;
    }

    public String getDocumentURI() {
        return null;
    }

    public DOMConfiguration getDomConfig() {
        return null;
    }

    public Object getFeature(String str, String str2) {
        return null;
    }

    public String getInputEncoding() {
        return null;
    }

    public boolean getStrictErrorChecking() {
        return false;
    }

    public String getTextContent() throws DOMException {
        return null;
    }

    public Object getUserData(String str) {
        return null;
    }

    public String getXmlEncoding() {
        return null;
    }

    public boolean getXmlStandalone() {
        return false;
    }

    public String getXmlVersion() {
        return null;
    }

    public boolean isDefaultNamespace(String str) {
        return false;
    }

    public boolean isEqualNode(Node node) {
        return false;
    }

    public boolean isSameNode(Node node) {
        return false;
    }

    public String lookupNamespaceURI(String str) {
        return null;
    }

    public String lookupPrefix(String str) {
        return null;
    }

    public void normalizeDocument() {
    }

    public Node renameNode(Node node, String str, String str2) throws DOMException {
        return null;
    }

    public void setDocumentURI(String str) {
    }

    public void setStrictErrorChecking(boolean z) {
    }

    public void setTextContent(String str) throws DOMException {
    }

    public Object setUserData(String str, Object obj, UserDataHandler userDataHandler) {
        return null;
    }

    public void setXmlStandalone(boolean z) throws DOMException {
    }

    public void setXmlVersion(String str) throws DOMException {
    }

    public NodeList getActiveChildrenAt(float f) {
        return this.mSeqTimeContainer.getActiveChildrenAt(f);
    }

    public NodeList getTimeChildren() {
        return this.mSeqTimeContainer.getTimeChildren();
    }

    public boolean beginElement() {
        return this.mSeqTimeContainer.beginElement();
    }

    public boolean endElement() {
        return this.mSeqTimeContainer.endElement();
    }

    public TimeList getBegin() {
        return this.mSeqTimeContainer.getBegin();
    }

    public float getDur() {
        return this.mSeqTimeContainer.getDur();
    }

    public TimeList getEnd() {
        return this.mSeqTimeContainer.getEnd();
    }

    public short getFill() {
        return this.mSeqTimeContainer.getFill();
    }

    public short getFillDefault() {
        return this.mSeqTimeContainer.getFillDefault();
    }

    public float getRepeatCount() {
        return this.mSeqTimeContainer.getRepeatCount();
    }

    public float getRepeatDur() {
        return this.mSeqTimeContainer.getRepeatDur();
    }

    public short getRestart() {
        return this.mSeqTimeContainer.getRestart();
    }

    public void pauseElement() {
        this.mSeqTimeContainer.pauseElement();
    }

    public void resumeElement() {
        this.mSeqTimeContainer.resumeElement();
    }

    public void seekElement(float f) {
        this.mSeqTimeContainer.seekElement(f);
    }

    public void setBegin(TimeList timeList) throws DOMException {
        this.mSeqTimeContainer.setBegin(timeList);
    }

    public void setDur(float f) throws DOMException {
        this.mSeqTimeContainer.setDur(f);
    }

    public void setEnd(TimeList timeList) throws DOMException {
        this.mSeqTimeContainer.setEnd(timeList);
    }

    public void setFill(short s) throws DOMException {
        this.mSeqTimeContainer.setFill(s);
    }

    public void setFillDefault(short s) throws DOMException {
        this.mSeqTimeContainer.setFillDefault(s);
    }

    public void setRepeatCount(float f) throws DOMException {
        this.mSeqTimeContainer.setRepeatCount(f);
    }

    public void setRepeatDur(float f) throws DOMException {
        this.mSeqTimeContainer.setRepeatDur(f);
    }

    public void setRestart(short s) throws DOMException {
        this.mSeqTimeContainer.setRestart(s);
    }

    public Element createElement(String str) throws DOMException {
        String lowerCase = str.toLowerCase();
        if (lowerCase.equals(SmilHelper.ELEMENT_TAG_TEXT) || lowerCase.equals(SmilHelper.ELEMENT_TAG_IMAGE) || lowerCase.equals(SmilHelper.ELEMENT_TAG_VIDEO)) {
            return new SmilRegionMediaElementImpl(this, lowerCase);
        }
        if (lowerCase.equals(SmilHelper.ELEMENT_TAG_AUDIO)) {
            return new SmilMediaElementImpl(this, lowerCase);
        }
        if (lowerCase.equals("layout")) {
            return new SmilLayoutElementImpl(this, lowerCase);
        }
        if (lowerCase.equals("root-layout")) {
            return new SmilRootLayoutElementImpl(this, lowerCase);
        }
        if (lowerCase.equals("region")) {
            return new SmilRegionElementImpl(this, lowerCase);
        }
        if (lowerCase.equals(SmilHelper.ELEMENT_TAG_REF)) {
            return new SmilRefElementImpl(this, lowerCase);
        }
        if (lowerCase.equals("par")) {
            return new SmilParElementImpl(this, lowerCase);
        }
        return new SmilElementImpl(this, lowerCase);
    }

    public SMILElement getDocumentElement() {
        Node firstChild = getFirstChild();
        if (firstChild == null || !(firstChild instanceof SMILElement)) {
            firstChild = createElement("smil");
            appendChild(firstChild);
        }
        return (SMILElement) firstChild;
    }

    public SMILElement getHead() {
        SMILElement documentElement = getDocumentElement();
        Node firstChild = documentElement.getFirstChild();
        if (firstChild == null || !(firstChild instanceof SMILElement)) {
            firstChild = createElement("head");
            documentElement.appendChild(firstChild);
        }
        return (SMILElement) firstChild;
    }

    public SMILElement getBody() {
        SMILElement documentElement = getDocumentElement();
        Node nextSibling = getHead().getNextSibling();
        if (nextSibling == null || !(nextSibling instanceof SMILElement)) {
            nextSibling = createElement("body");
            documentElement.appendChild(nextSibling);
        }
        SMILElement sMILElement = (SMILElement) nextSibling;
        this.mSeqTimeContainer = new ElementSequentialTimeContainerImpl(sMILElement) {
            /* access modifiers changed from: 0000 */
            public ElementTime getParentElementTime() {
                return null;
            }

            public void pauseElement() {
            }

            public void resumeElement() {
            }

            public void seekElement(float f) {
            }

            public NodeList getTimeChildren() {
                return SmilDocumentImpl.this.getBody().getElementsByTagName("par");
            }

            public boolean beginElement() {
                Event createEvent = SmilDocumentImpl.this.createEvent("Event");
                createEvent.initEvent(SmilDocumentImpl.SMIL_DOCUMENT_START_EVENT, false, false);
                SmilDocumentImpl.this.dispatchEvent(createEvent);
                return true;
            }

            public boolean endElement() {
                Event createEvent = SmilDocumentImpl.this.createEvent("Event");
                createEvent.initEvent(SmilDocumentImpl.SMIL_DOCUMENT_END_EVENT, false, false);
                SmilDocumentImpl.this.dispatchEvent(createEvent);
                return true;
            }
        };
        return sMILElement;
    }

    public SMILLayoutElement getLayout() {
        SMILElement head = getHead();
        Node firstChild = head.getFirstChild();
        while (firstChild != null && !(firstChild instanceof SMILLayoutElement)) {
            firstChild = firstChild.getNextSibling();
        }
        if (firstChild == null) {
            firstChild = new SmilLayoutElementImpl(this, "layout");
            head.appendChild(firstChild);
        }
        return (SMILLayoutElement) firstChild;
    }

    public Event createEvent(String str) throws DOMException {
        if ("Event".equals(str)) {
            return new EventImpl();
        }
        throw new DOMException(9, "Not supported interface");
    }
}
