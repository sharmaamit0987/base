package com.android.mms.dom.smil;

import com.android.mms.layout.LayoutManager;
import org.w3c.dom.NodeList;
import org.w3c.dom.smil.SMILLayoutElement;
import org.w3c.dom.smil.SMILRootLayoutElement;

public class SmilLayoutElementImpl extends SmilElementImpl implements SMILLayoutElement {
    public boolean getResolved() {
        return false;
    }

    SmilLayoutElementImpl(SmilDocumentImpl smilDocumentImpl, String str) {
        super(smilDocumentImpl, str);
    }

    public String getType() {
        return getAttribute("type");
    }

    public NodeList getRegions() {
        return getElementsByTagName("region");
    }

    public SMILRootLayoutElement getRootLayout() {
        String str;
        NodeList childNodes = getChildNodes();
        int length = childNodes.getLength();
        SMILRootLayoutElement sMILRootLayoutElement = null;
        int i = 0;
        while (true) {
            str = "root-layout";
            if (i >= length) {
                break;
            }
            if (childNodes.item(i).getNodeName().equals(str)) {
                sMILRootLayoutElement = (SMILRootLayoutElement) childNodes.item(i);
            }
            i++;
        }
        if (sMILRootLayoutElement != null) {
            return sMILRootLayoutElement;
        }
        SMILRootLayoutElement sMILRootLayoutElement2 = (SMILRootLayoutElement) getOwnerDocument().createElement(str);
        sMILRootLayoutElement2.setWidth(LayoutManager.getInstance().getLayoutParameters().getWidth());
        sMILRootLayoutElement2.setHeight(LayoutManager.getInstance().getLayoutParameters().getHeight());
        appendChild(sMILRootLayoutElement2);
        return sMILRootLayoutElement2;
    }
}
