package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.smil.SMILDocument;
import org.w3c.dom.smil.SMILRegionElement;

public class SmilRegionElementImpl extends SmilElementImpl implements SMILRegionElement {
    private static final String BACKGROUND_COLOR_ATTRIBUTE_NAME = "backgroundColor";
    private static final String BOTTOM_ATTRIBUTE_NAME = "bottom";
    private static final boolean DEBUG = false;
    private static final String FILL_ATTRIBUTE = "fill";
    private static final String FIT_ATTRIBUTE_NAME = "fit";
    private static final String HEIGHT_ATTRIBUTE_NAME = "height";
    private static final String HIDDEN_ATTRIBUTE = "hidden";
    private static final String ID_ATTRIBUTE_NAME = "id";
    private static final String LEFT_ATTRIBUTE_NAME = "left";
    private static final boolean LOCAL_LOGV = false;
    private static final String MEET_ATTRIBUTE = "meet";
    private static final String RIGHT_ATTRIBUTE_NAME = "right";
    private static final String SCROLL_ATTRIBUTE = "scroll";
    private static final String SLICE_ATTRIBUTE = "slice";
    private static final String TAG = "SmilRegionElementImpl";
    private static final String TITLE_ATTRIBUTE_NAME = "title";
    private static final String TOP_ATTRIBUTE_NAME = "top";
    private static final String WIDTH_ATTRIBUTE_NAME = "width";
    private static final String Z_INDEX_ATTRIBUTE_NAME = "z-index";

    SmilRegionElementImpl(SmilDocumentImpl smilDocumentImpl, String str) {
        super(smilDocumentImpl, str);
    }

    public String getFit() {
        String attribute = getAttribute(FIT_ATTRIBUTE_NAME);
        String str = FILL_ATTRIBUTE;
        if (str.equalsIgnoreCase(attribute)) {
            return str;
        }
        String str2 = MEET_ATTRIBUTE;
        if (str2.equalsIgnoreCase(attribute)) {
            return str2;
        }
        String str3 = SCROLL_ATTRIBUTE;
        if (str3.equalsIgnoreCase(attribute)) {
            return str3;
        }
        String str4 = SLICE_ATTRIBUTE;
        return str4.equalsIgnoreCase(attribute) ? str4 : HIDDEN_ATTRIBUTE;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(4:4|5|6|7) */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0036, code lost:
        return 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0034, code lost:
        return (((org.w3c.dom.smil.SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth() - parseRegionLength(getAttribute(RIGHT_ATTRIBUTE_NAME), true)) - parseRegionLength(getAttribute(WIDTH_ATTRIBUTE_NAME), true);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:4:0x000c */
    public int getLeft() {
        return parseRegionLength(getAttribute(LEFT_ATTRIBUTE_NAME), true);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(4:4|5|6|7) */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0034, code lost:
        return (((org.w3c.dom.smil.SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight() - parseRegionLength(getAttribute(BOTTOM_ATTRIBUTE_NAME), false)) - parseRegionLength(getAttribute(HEIGHT_ATTRIBUTE_NAME), false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0035, code lost:
        return 0;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:4:0x000c */
    public int getTop() {
        return parseRegionLength(getAttribute(TOP_ATTRIBUTE_NAME), false);
    }

    public int getZIndex() {
        try {
            return Integer.parseInt(getAttribute(Z_INDEX_ATTRIBUTE_NAME));
        } catch (NumberFormatException unused) {
            return 0;
        }
    }

    public void setFit(String str) throws DOMException {
        boolean equalsIgnoreCase = str.equalsIgnoreCase(FILL_ATTRIBUTE);
        String str2 = FIT_ATTRIBUTE_NAME;
        if (equalsIgnoreCase || str.equalsIgnoreCase(MEET_ATTRIBUTE) || str.equalsIgnoreCase(SCROLL_ATTRIBUTE) || str.equalsIgnoreCase(SLICE_ATTRIBUTE)) {
            setAttribute(str2, str.toLowerCase());
        } else {
            setAttribute(str2, HIDDEN_ATTRIBUTE);
        }
    }

    public void setLeft(int i) throws DOMException {
        setAttribute(LEFT_ATTRIBUTE_NAME, String.valueOf(i));
    }

    public void setTop(int i) throws DOMException {
        setAttribute(TOP_ATTRIBUTE_NAME, String.valueOf(i));
    }

    public void setZIndex(int i) throws DOMException {
        String str = Z_INDEX_ATTRIBUTE_NAME;
        if (i > 0) {
            setAttribute(str, Integer.toString(i));
        } else {
            setAttribute(str, Integer.toString(0));
        }
    }

    public String getBackgroundColor() {
        return getAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME);
    }

    public int getHeight() {
        try {
            return parseRegionLength(getAttribute(HEIGHT_ATTRIBUTE_NAME), false);
        } catch (NumberFormatException unused) {
            int height = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight();
            try {
                height -= parseRegionLength(getAttribute(TOP_ATTRIBUTE_NAME), false);
            } catch (NumberFormatException unused2) {
            }
            try {
                height -= parseRegionLength(getAttribute(BOTTOM_ATTRIBUTE_NAME), false);
            } catch (NumberFormatException unused3) {
            }
            return height;
        }
    }

    public String getTitle() {
        return getAttribute(TITLE_ATTRIBUTE_NAME);
    }

    public int getWidth() {
        try {
            return parseRegionLength(getAttribute(WIDTH_ATTRIBUTE_NAME), true);
        } catch (NumberFormatException unused) {
            int width = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth();
            try {
                width -= parseRegionLength(getAttribute(LEFT_ATTRIBUTE_NAME), true);
            } catch (NumberFormatException unused2) {
            }
            try {
                width -= parseRegionLength(getAttribute(RIGHT_ATTRIBUTE_NAME), true);
            } catch (NumberFormatException unused3) {
            }
            return width;
        }
    }

    public void setBackgroundColor(String str) throws DOMException {
        setAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME, str);
    }

    public void setHeight(int i) throws DOMException {
        StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(i)));
        sb.append("px");
        setAttribute(HEIGHT_ATTRIBUTE_NAME, sb.toString());
    }

    public void setTitle(String str) throws DOMException {
        setAttribute(TITLE_ATTRIBUTE_NAME, str);
    }

    public void setWidth(int i) throws DOMException {
        StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(i)));
        sb.append("px");
        setAttribute(WIDTH_ATTRIBUTE_NAME, sb.toString());
    }

    public String getId() {
        return getAttribute(ID_ATTRIBUTE_NAME);
    }

    public void setId(String str) throws DOMException {
        setAttribute(ID_ATTRIBUTE_NAME, str);
    }

    private int parseRegionLength(String str, boolean z) {
        int i;
        String str2 = "px";
        if (str.endsWith(str2)) {
            return Integer.parseInt(str.substring(0, str.indexOf(str2)));
        }
        if (!str.endsWith("%")) {
            return Integer.parseInt(str);
        }
        double parseInt = ((double) Integer.parseInt(str.substring(0, str.length() - 1))) * 0.01d;
        if (z) {
            i = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getWidth();
        } else {
            i = ((SMILDocument) getOwnerDocument()).getLayout().getRootLayout().getHeight();
        }
        return (int) Math.round(parseInt * ((double) i));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(String.valueOf(super.toString()));
        sb.append(": id=");
        sb.append(getId());
        sb.append(", width=");
        sb.append(getWidth());
        sb.append(", height=");
        sb.append(getHeight());
        sb.append(", left=");
        sb.append(getLeft());
        sb.append(", top=");
        sb.append(getTop());
        return sb.toString();
    }
}
