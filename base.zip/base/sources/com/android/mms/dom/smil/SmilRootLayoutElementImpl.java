package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.smil.SMILRootLayoutElement;

public class SmilRootLayoutElementImpl extends SmilElementImpl implements SMILRootLayoutElement {
    private static final String BACKGROUND_COLOR_ATTRIBUTE_NAME = "backgroundColor";
    private static final String HEIGHT_ATTRIBUTE_NAME = "height";
    private static final String TITLE_ATTRIBUTE_NAME = "title";
    private static final String WIDTH_ATTRIBUTE_NAME = "width";

    SmilRootLayoutElementImpl(SmilDocumentImpl smilDocumentImpl, String str) {
        super(smilDocumentImpl, str);
    }

    public String getBackgroundColor() {
        return getAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME);
    }

    public int getHeight() {
        return parseAbsoluteLength(getAttribute(HEIGHT_ATTRIBUTE_NAME));
    }

    public String getTitle() {
        return getAttribute(TITLE_ATTRIBUTE_NAME);
    }

    public int getWidth() {
        return parseAbsoluteLength(getAttribute(WIDTH_ATTRIBUTE_NAME));
    }

    public void setBackgroundColor(String str) throws DOMException {
        setAttribute(BACKGROUND_COLOR_ATTRIBUTE_NAME, str);
    }

    public void setHeight(int i) throws DOMException {
        StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(i)));
        sb.append("px");
        setAttribute(HEIGHT_ATTRIBUTE_NAME, sb.toString());
    }

    public void setTitle(String str) throws DOMException {
        setAttribute(TITLE_ATTRIBUTE_NAME, str);
    }

    public void setWidth(int i) throws DOMException {
        StringBuilder sb = new StringBuilder(String.valueOf(String.valueOf(i)));
        sb.append("px");
        setAttribute(WIDTH_ATTRIBUTE_NAME, sb.toString());
    }

    private int parseAbsoluteLength(String str) {
        String str2 = "px";
        if (str.endsWith(str2)) {
            str = str.substring(0, str.indexOf(str2));
        }
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException unused) {
            return 0;
        }
    }
}
