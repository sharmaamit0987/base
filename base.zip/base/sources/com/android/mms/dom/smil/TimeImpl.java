package com.android.mms.dom.smil;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.smil.Time;

public class TimeImpl implements Time {
    static final int ALLOW_ALL = 255;
    static final int ALLOW_EVENT_VALUE = 16;
    static final int ALLOW_INDEFINITE_VALUE = 1;
    static final int ALLOW_MARKER_VALUE = 32;
    static final int ALLOW_NEGATIVE_VALUE = 128;
    static final int ALLOW_OFFSET_VALUE = 2;
    static final int ALLOW_SYNCBASE_VALUE = 4;
    static final int ALLOW_SYNCTOPREV_VALUE = 8;
    static final int ALLOW_WALLCLOCK_VALUE = 64;
    boolean mResolved;
    double mResolvedOffset;
    short mTimeType;

    public boolean getBaseBegin() {
        return false;
    }

    public Element getBaseElement() {
        return null;
    }

    public String getEvent() {
        return null;
    }

    public String getMarker() {
        return null;
    }

    public double getOffset() {
        return 0.0d;
    }

    public void setBaseBegin(boolean z) throws DOMException {
    }

    public void setBaseElement(Element element) throws DOMException {
    }

    public void setEvent(String str) throws DOMException {
    }

    public void setMarker(String str) throws DOMException {
    }

    public void setOffset(double d) throws DOMException {
    }

    TimeImpl(String str, int i) {
        int i2;
        if (str.equals("indefinite") && (i & 1) != 0) {
            this.mTimeType = 0;
        } else if ((i & 2) != 0) {
            if (str.startsWith("+")) {
                str = str.substring(1);
            } else if (str.startsWith("-")) {
                str = str.substring(1);
                i2 = -1;
                this.mResolvedOffset = ((double) (((float) i2) * parseClockValue(str))) / 1000.0d;
                this.mResolved = true;
                this.mTimeType = 1;
            }
            i2 = 1;
            this.mResolvedOffset = ((double) (((float) i2) * parseClockValue(str))) / 1000.0d;
            this.mResolved = true;
            this.mTimeType = 1;
        } else {
            throw new IllegalArgumentException("Unsupported time value");
        }
    }

    public static float parseClockValue(String str) {
        String trim;
        float f;
        int i;
        float f2;
        try {
            trim = str.trim();
            if (trim.endsWith("ms")) {
                f = parseFloat(trim, 2, true);
            } else if (trim.endsWith("s")) {
                f = parseFloat(trim, 1, true) * 1000.0f;
            } else if (trim.endsWith("min")) {
                f = parseFloat(trim, 3, true) * 60000.0f;
            } else if (!trim.endsWith("h")) {
                return parseFloat(trim, 0, true) * 1000.0f;
            } else {
                f = parseFloat(trim, 1, true) * 3600000.0f;
            }
        } catch (NumberFormatException unused) {
            String[] split = trim.split(":");
            if (split.length == 2) {
                f2 = 0.0f;
                i = 0;
            } else if (split.length == 3) {
                f2 = (float) (((int) parseFloat(split[0], 0, false)) * 3600000);
                i = 1;
            } else {
                throw new IllegalArgumentException();
            }
            int parseFloat = (int) parseFloat(split[i], 0, false);
            if (parseFloat < 0 || parseFloat > 59) {
                throw new IllegalArgumentException();
            }
            float f3 = f2 + ((float) (parseFloat * 60000));
            float parseFloat2 = parseFloat(split[i + 1], 0, true);
            if (parseFloat2 < 0.0f || parseFloat2 >= 60.0f) {
                throw new IllegalArgumentException();
            }
            f = (parseFloat2 * 60000.0f) + f3;
        } catch (NumberFormatException unused2) {
            throw new IllegalArgumentException();
        }
        return f;
    }

    private static float parseFloat(String str, int i, boolean z) {
        String substring = str.substring(0, str.length() - i);
        int indexOf = substring.indexOf(46);
        if (indexOf == -1) {
            return (float) Integer.parseInt(substring);
        }
        if (z) {
            StringBuilder sb = new StringBuilder(String.valueOf(substring));
            sb.append("000");
            String sb2 = sb.toString();
            return Float.parseFloat(sb2.substring(0, indexOf)) + (Float.parseFloat(sb2.substring(indexOf + 1, indexOf + 4)) / 1000.0f);
        }
        throw new IllegalArgumentException("int value contains decimal");
    }

    public boolean getResolved() {
        return this.mResolved;
    }

    public double getResolvedOffset() {
        return this.mResolvedOffset;
    }

    public short getTimeType() {
        return this.mTimeType;
    }
}
