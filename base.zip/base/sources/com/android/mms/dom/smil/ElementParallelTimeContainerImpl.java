package com.android.mms.dom.smil;

import com.android.mms.dom.NodeListImpl;
import java.util.ArrayList;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.smil.ElementParallelTimeContainer;
import org.w3c.dom.smil.ElementTime;
import org.w3c.dom.smil.SMILElement;
import org.w3c.dom.smil.Time;
import org.w3c.dom.smil.TimeList;

public abstract class ElementParallelTimeContainerImpl extends ElementTimeContainerImpl implements ElementParallelTimeContainer {
    private static final String ENDSYNC_ALL = "all";
    private static final String ENDSYNC_ATTRIBUTE_NAME = "endsync";
    private static final String ENDSYNC_FIRST = "first";
    private static final String ENDSYNC_LAST = "last";
    private static final String ENDSYNC_MEDIA = "media";

    ElementParallelTimeContainerImpl(SMILElement sMILElement) {
        super(sMILElement);
    }

    public String getEndSync() {
        String attribute = this.mSmilElement.getAttribute(ENDSYNC_ATTRIBUTE_NAME);
        String str = ENDSYNC_LAST;
        if (attribute == null || attribute.length() == 0) {
            setEndSync(str);
            return str;
        } else if (ENDSYNC_FIRST.equals(attribute) || str.equals(attribute) || ENDSYNC_ALL.equals(attribute) || ENDSYNC_MEDIA.equals(attribute)) {
            return attribute;
        } else {
            setEndSync(str);
            return str;
        }
    }

    public void setEndSync(String str) throws DOMException {
        if (ENDSYNC_FIRST.equals(str) || ENDSYNC_LAST.equals(str) || ENDSYNC_ALL.equals(str) || ENDSYNC_MEDIA.equals(str)) {
            this.mSmilElement.setAttribute(ENDSYNC_ATTRIBUTE_NAME, str);
            return;
        }
        StringBuilder sb = new StringBuilder("Unsupported endsync value");
        sb.append(str);
        throw new DOMException(9, sb.toString());
    }

    public float getDur() {
        float dur = super.getDur();
        return dur == 0.0f ? getImplicitDuration() : dur;
    }

    public float getImplicitDuration() {
        float f = -1.0f;
        if (ENDSYNC_LAST.equals(getEndSync())) {
            NodeList timeChildren = getTimeChildren();
            float f2 = -1.0f;
            for (int i = 0; i < timeChildren.getLength(); i++) {
                TimeList end = ((ElementTime) timeChildren.item(i)).getEnd();
                for (int i2 = 0; i2 < end.getLength(); i2++) {
                    Time item = end.item(i2);
                    if (item.getTimeType() == 0) {
                        return -1.0f;
                    }
                    if (item.getResolved()) {
                        float resolvedOffset = (float) item.getResolvedOffset();
                        if (resolvedOffset > f2) {
                            f2 = resolvedOffset;
                        }
                    }
                }
            }
            f = f2;
        }
        return f;
    }

    public NodeList getActiveChildrenAt(float f) {
        int i;
        float f2 = f;
        ArrayList arrayList = new ArrayList();
        NodeList timeChildren = getTimeChildren();
        int length = timeChildren.getLength();
        int i2 = 0;
        while (i2 < length) {
            double d = 0.0d;
            ElementTime elementTime = (ElementTime) timeChildren.item(i2);
            TimeList begin = elementTime.getBegin();
            int length2 = begin.getLength();
            int i3 = 0;
            boolean z = false;
            while (i3 < length2) {
                int i4 = i2;
                Time item = begin.item(i3);
                if (item.getResolved()) {
                    double resolvedOffset = item.getResolvedOffset() * 1000.0d;
                    if (resolvedOffset <= ((double) f2) && resolvedOffset >= d) {
                        z = true;
                        d = resolvedOffset;
                    }
                }
                i3++;
                i2 = i4;
            }
            TimeList end = elementTime.getEnd();
            int length3 = end.getLength();
            int i5 = 0;
            while (i5 < length3) {
                Time item2 = end.item(i5);
                if (item2.getResolved()) {
                    double resolvedOffset2 = item2.getResolvedOffset() * 1000.0d;
                    i = i2;
                    if (resolvedOffset2 <= ((double) f2) && resolvedOffset2 >= d) {
                        d = resolvedOffset2;
                        z = false;
                    }
                } else {
                    i = i2;
                }
                i5++;
                i2 = i;
            }
            if (z) {
                arrayList.add((Node) elementTime);
            }
            i2++;
        }
        return new NodeListImpl(arrayList);
    }
}
