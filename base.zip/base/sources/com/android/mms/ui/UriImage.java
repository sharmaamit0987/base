package com.android.mms.ui;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;
import com.android.mms.model.ImageModel;
import com.google.android.mms.pdu.PduPart;
import com.google.android.mms.util.SqliteWrapper;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class UriImage {
    private static final boolean DEBUG = true;
    private static final boolean LOCAL_LOGV = true;
    private static final String TAG = "UriImage";
    private String mContentType;
    private final Context mContext;
    private int mHeight;
    private String mPath;
    private String mSrc;
    private final Uri mUri;
    private int mWidth;

    public UriImage(Context context, Uri uri) {
        if (context == null || uri == null) {
            throw new IllegalArgumentException();
        }
        if (uri.getScheme().equals("content")) {
            initFromContentUri(context, uri);
        } else if (uri.getScheme().equals("file")) {
            initFromFile(context, uri);
        }
        String str = this.mPath;
        String substring = str.substring(str.lastIndexOf(47) + 1);
        this.mSrc = substring;
        this.mSrc = substring.replace(' ', '_');
        this.mContext = context;
        this.mUri = uri;
        decodeBoundsInfo();
    }

    private void initFromFile(Context context, Uri uri) {
        String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(uri.toString()));
        this.mContentType = mimeTypeFromExtension;
        if (mimeTypeFromExtension != null) {
            this.mPath = uri.getPath();
            return;
        }
        StringBuilder sb = new StringBuilder("Unable to determine extension for ");
        sb.append(uri.toString());
        throw new IllegalArgumentException(sb.toString());
    }

    private void initFromContentUri(Context context, Uri uri) {
        String str;
        Cursor query = SqliteWrapper.query(context, context.getContentResolver(), uri, null, null, null, null);
        String str2 = "Query on ";
        if (query != null) {
            try {
                if (query.getCount() != 1 || !query.moveToFirst()) {
                    StringBuilder sb = new StringBuilder(str2);
                    sb.append(uri);
                    sb.append(" returns 0 or multiple rows.");
                    throw new IllegalArgumentException(sb.toString());
                }
                String str3 = "_data";
                if (ImageModel.isMmsUri(uri)) {
                    str = query.getString(query.getColumnIndexOrThrow("fn"));
                    if (TextUtils.isEmpty(str)) {
                        str = query.getString(query.getColumnIndexOrThrow(str3));
                    }
                    this.mContentType = query.getString(query.getColumnIndexOrThrow("ct"));
                } else {
                    str = query.getString(query.getColumnIndexOrThrow(str3));
                    this.mContentType = query.getString(query.getColumnIndexOrThrow("mime_type"));
                }
                this.mPath = str;
            } finally {
                query.close();
            }
        } else {
            StringBuilder sb2 = new StringBuilder(str2);
            sb2.append(uri);
            sb2.append(" returns null result.");
            throw new IllegalArgumentException(sb2.toString());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x003c A[SYNTHETIC, Splitter:B:17:0x003c] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0048 A[SYNTHETIC, Splitter:B:23:0x0048] */
    /* JADX WARNING: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    private void decodeBoundsInfo() {
        InputStream inputStream;
        Throwable e;
        String str = "IOException caught while closing stream";
        String str2 = TAG;
        try {
            inputStream = this.mContext.getContentResolver().openInputStream(this.mUri);
            try {
                Options options = new Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(inputStream, null, options);
                this.mWidth = options.outWidth;
                this.mHeight = options.outHeight;
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e2) {
                        Log.e(str2, str, e2);
                    }
                }
            } catch (FileNotFoundException e3) {
                e = e3;
                try {
                    Log.e(str2, "IOException caught while opening stream", e);
                    if (inputStream == null) {
                        inputStream.close();
                    }
                } catch (Throwable th) {
                    th = th;
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e4) {
                            Log.e(str2, str, e4);
                        }
                    }
                    throw th;
                }
            }
        } catch (FileNotFoundException e5) {
            Throwable th2 = e5;
            inputStream = null;
            e = th2;
            Log.e(str2, "IOException caught while opening stream", e);
            if (inputStream == null) {
            }
        } catch (Throwable th3) {
            Throwable th4 = th3;
            inputStream = null;
            th = th4;
            if (inputStream != null) {
            }
            throw th;
        }
    }

    public String getContentType() {
        return this.mContentType;
    }

    public String getSrc() {
        return this.mSrc;
    }

    public int getWidth() {
        return this.mWidth;
    }

    public int getHeight() {
        return this.mHeight;
    }

    public PduPart getResizedImageAsPart(int i, int i2) {
        PduPart pduPart = new PduPart();
        byte[] resizedImageData = getResizedImageData(i, i2);
        if (resizedImageData == null) {
            Log.v(TAG, "Resize image failed.");
            return null;
        }
        pduPart.setData(resizedImageData);
        pduPart.setContentType(getContentType().getBytes());
        String src = getSrc();
        byte[] bytes = src.getBytes();
        pduPart.setContentLocation(bytes);
        pduPart.setFilename(bytes);
        pduPart.setContentId(src.substring(0, src.lastIndexOf(".")).getBytes());
        return pduPart;
    }

    /* JADX WARNING: Removed duplicated region for block: B:32:0x007f A[SYNTHETIC, Splitter:B:32:0x007f] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0090 A[SYNTHETIC, Splitter:B:40:0x0090] */
    private byte[] getResizedImageData(int i, int i2) {
        int i3;
        int i4;
        InputStream inputStream;
        int i5 = this.mWidth;
        int i6 = this.mHeight;
        int i7 = 1;
        while (true) {
            i3 = i5 / i7;
            if (i3 <= i) {
                i4 = i6 / i7;
                if (i4 <= i2) {
                    break;
                }
            }
            i7 *= 2;
        }
        StringBuilder sb = new StringBuilder("outWidth=");
        sb.append(i3);
        sb.append(" outHeight=");
        sb.append(i4);
        String sb2 = sb.toString();
        String str = TAG;
        Log.v(str, sb2);
        Options options = new Options();
        options.inSampleSize = i7;
        InputStream inputStream2 = null;
        try {
            inputStream = this.mContext.getContentResolver().openInputStream(this.mUri);
            try {
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream, null, options);
                if (decodeStream == null) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            Log.e(str, e.getMessage(), e);
                        }
                    }
                    return null;
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                decodeStream.compress(CompressFormat.JPEG, 100, byteArrayOutputStream);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e2) {
                        Log.e(str, e2.getMessage(), e2);
                    }
                }
                return byteArray;
            } catch (FileNotFoundException e3) {
                e = e3;
                try {
                    Log.e(str, e.getMessage(), e);
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e4) {
                            Log.e(str, e4.getMessage(), e4);
                        }
                    }
                    return null;
                } catch (Throwable th) {
                    th = th;
                    inputStream2 = inputStream;
                    if (inputStream2 != null) {
                    }
                    throw th;
                }
            }
        } catch (FileNotFoundException e5) {
            e = e5;
            inputStream = null;
            Log.e(str, e.getMessage(), e);
            if (inputStream != null) {
            }
            return null;
        } catch (Throwable th2) {
            th = th2;
            if (inputStream2 != null) {
                try {
                    inputStream2.close();
                } catch (IOException e6) {
                    Log.e(str, e6.getMessage(), e6);
                }
            }
            throw th;
        }
    }
}
