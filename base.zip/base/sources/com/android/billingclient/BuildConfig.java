package com.android.billingclient;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.android.billingclient";
    public static final String VERSION_NAME = "3.0.0";
}
