package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzq implements Runnable {
    private final /* synthetic */ int zza;
    private final /* synthetic */ String zzb;
    private final /* synthetic */ zzo zzc;

    zzq(zzo zzo, int i, String str) {
        this.zzc = zzo;
        this.zza = i;
        this.zzb = str;
    }

    public final void run() {
        this.zzc.zza.onAcknowledgePurchaseResponse(BillingResult.newBuilder().setResponseCode(this.zza).setDebugMessage(this.zzb).build());
    }
}
