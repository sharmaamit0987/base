package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzm implements Runnable {
    private final /* synthetic */ zzb zza;
    private final /* synthetic */ zzn zzb;

    zzm(zzn zzn, zzb zzb2) {
        this.zzb = zzn;
        this.zza = zzb2;
    }

    public final void run() {
        this.zzb.zza.onPurchaseHistoryResponse(this.zza.zza(), this.zza.zzb());
    }
}
