package com.android.billingclient.api;

import android.os.Bundle;
import com.google.android.gms.internal.play_billing.zzb;
import java.util.ArrayList;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzam {
    static BillingResult zza(Bundle bundle, String str, String str2) {
        BillingResult billingResult = zzak.zzl;
        if (bundle == null) {
            zzb.zzb(str, String.format("%s got null owned items list", new Object[]{str2}));
            return billingResult;
        }
        int zza = zzb.zza(bundle, str);
        BillingResult build = BillingResult.newBuilder().setResponseCode(zza).setDebugMessage(zzb.zzb(bundle, str)).build();
        if (zza != 0) {
            zzb.zzb(str, String.format("%s failed. Response code: %s", new Object[]{str2, Integer.valueOf(zza)}));
            return build;
        }
        String str3 = "INAPP_PURCHASE_ITEM_LIST";
        if (bundle.containsKey(str3)) {
            String str4 = "INAPP_PURCHASE_DATA_LIST";
            if (bundle.containsKey(str4)) {
                String str5 = "INAPP_DATA_SIGNATURE_LIST";
                if (bundle.containsKey(str5)) {
                    ArrayList stringArrayList = bundle.getStringArrayList(str3);
                    ArrayList stringArrayList2 = bundle.getStringArrayList(str4);
                    ArrayList stringArrayList3 = bundle.getStringArrayList(str5);
                    if (stringArrayList == null) {
                        zzb.zzb(str, String.format("Bundle returned from %s contains null SKUs list.", new Object[]{str2}));
                        return billingResult;
                    } else if (stringArrayList2 == null) {
                        zzb.zzb(str, String.format("Bundle returned from %s contains null purchases list.", new Object[]{str2}));
                        return billingResult;
                    } else if (stringArrayList3 != null) {
                        return zzak.zzn;
                    } else {
                        zzb.zzb(str, String.format("Bundle returned from %s contains null signatures list.", new Object[]{str2}));
                        return billingResult;
                    }
                }
            }
        }
        zzb.zzb(str, String.format("Bundle returned from %s doesn't contain required fields.", new Object[]{str2}));
        return billingResult;
    }
}
