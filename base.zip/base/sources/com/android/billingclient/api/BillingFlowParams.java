package com.android.billingclient.api;

import android.text.TextUtils;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public class BillingFlowParams {
    public static final String EXTRA_PARAM_KEY_ACCOUNT_ID = "accountId";
    public static final String EXTRA_PARAM_KEY_OLD_SKUS = "skusToReplace";
    public static final String EXTRA_PARAM_KEY_OLD_SKU_PURCHASE_TOKEN = "oldSkuPurchaseToken";
    public static final String EXTRA_PARAM_KEY_REPLACE_SKUS_PRORATION_MODE = "prorationMode";
    public static final String EXTRA_PARAM_KEY_VR = "vr";
    /* access modifiers changed from: private */
    public String zza;
    /* access modifiers changed from: private */
    public String zzb;
    /* access modifiers changed from: private */
    public String zzc;
    /* access modifiers changed from: private */
    public String zzd;
    /* access modifiers changed from: private */
    public String zze;
    /* access modifiers changed from: private */
    public int zzf;
    /* access modifiers changed from: private */
    public ArrayList<SkuDetails> zzg;
    /* access modifiers changed from: private */
    public boolean zzh;

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    public static class Builder {
        private String zza;
        private String zzb;
        private String zzc;
        private String zzd;
        private int zze;
        private ArrayList<SkuDetails> zzf;
        private boolean zzg;

        private Builder() {
            this.zze = 0;
        }

        public Builder setSkuDetails(SkuDetails skuDetails) {
            ArrayList<SkuDetails> arrayList = new ArrayList<>();
            arrayList.add(skuDetails);
            this.zzf = arrayList;
            return this;
        }

        public Builder setOldSku(String str, String str2) {
            this.zzb = str;
            this.zzc = str2;
            return this;
        }

        public Builder setReplaceSkusProrationMode(int i) {
            this.zze = i;
            return this;
        }

        public Builder setObfuscatedAccountId(String str) {
            this.zza = str;
            return this;
        }

        public Builder setVrPurchaseFlow(boolean z) {
            this.zzg = z;
            return this;
        }

        public Builder setObfuscatedProfileId(String str) {
            this.zzd = str;
            return this;
        }

        public BillingFlowParams build() {
            ArrayList<SkuDetails> arrayList = this.zzf;
            if (arrayList == null || arrayList.isEmpty()) {
                throw new IllegalArgumentException("SkuDetails must be provided.");
            }
            ArrayList arrayList2 = this.zzf;
            int size = arrayList2.size();
            int i = 0;
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList2.get(i2);
                i2++;
                if (((SkuDetails) obj) == null) {
                    throw new IllegalArgumentException("SKU cannot be null.");
                }
            }
            if (this.zzf.size() > 1) {
                SkuDetails skuDetails = (SkuDetails) this.zzf.get(0);
                String type = skuDetails.getType();
                ArrayList arrayList3 = this.zzf;
                int size2 = arrayList3.size();
                int i3 = 0;
                while (i3 < size2) {
                    Object obj2 = arrayList3.get(i3);
                    i3++;
                    if (!type.equals(((SkuDetails) obj2).getType())) {
                        throw new IllegalArgumentException("SKUs should have the same type.");
                    }
                }
                String zza2 = skuDetails.zza();
                String str = "All SKUs must have the same package name.";
                if (TextUtils.isEmpty(zza2)) {
                    ArrayList arrayList4 = this.zzf;
                    int size3 = arrayList4.size();
                    while (i < size3) {
                        Object obj3 = arrayList4.get(i);
                        i++;
                        if (!TextUtils.isEmpty(((SkuDetails) obj3).zza())) {
                            throw new IllegalArgumentException(str);
                        }
                    }
                } else {
                    ArrayList arrayList5 = this.zzf;
                    int size4 = arrayList5.size();
                    while (i < size4) {
                        Object obj4 = arrayList5.get(i);
                        i++;
                        if (!zza2.equals(((SkuDetails) obj4).zza())) {
                            throw new IllegalArgumentException(str);
                        }
                    }
                }
            }
            BillingFlowParams billingFlowParams = new BillingFlowParams();
            billingFlowParams.zza = null;
            billingFlowParams.zzb = this.zza;
            billingFlowParams.zze = this.zzd;
            billingFlowParams.zzc = this.zzb;
            billingFlowParams.zzd = this.zzc;
            billingFlowParams.zzf = this.zze;
            billingFlowParams.zzg = this.zzf;
            billingFlowParams.zzh = this.zzg;
            return billingFlowParams;
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    public @interface ProrationMode {
        public static final int DEFERRED = 4;
        public static final int IMMEDIATE_AND_CHARGE_PRORATED_PRICE = 2;
        public static final int IMMEDIATE_WITHOUT_PRORATION = 3;
        public static final int IMMEDIATE_WITH_TIME_PRORATION = 1;
        public static final int UNKNOWN_SUBSCRIPTION_UPGRADE_DOWNGRADE_POLICY = 0;
    }

    private BillingFlowParams() {
        this.zzf = 0;
    }

    public String getSku() {
        return ((SkuDetails) this.zzg.get(0)).getSku();
    }

    public String getSkuType() {
        return ((SkuDetails) this.zzg.get(0)).getType();
    }

    public SkuDetails getSkuDetails() {
        return (SkuDetails) this.zzg.get(0);
    }

    public final ArrayList<SkuDetails> zza() {
        ArrayList<SkuDetails> arrayList = new ArrayList<>();
        arrayList.addAll(this.zzg);
        return arrayList;
    }

    public String getOldSku() {
        return this.zzc;
    }

    public String getOldSkuPurchaseToken() {
        return this.zzd;
    }

    public final String zzb() {
        return this.zzb;
    }

    public boolean getVrPurchaseFlow() {
        return this.zzh;
    }

    public int getReplaceSkusProrationMode() {
        return this.zzf;
    }

    /* access modifiers changed from: 0000 */
    public final boolean zzc() {
        boolean z;
        ArrayList arrayList = this.zzg;
        int size = arrayList.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                z = true;
                break;
            }
            Object obj = arrayList.get(i);
            i++;
            if (((SkuDetails) obj).zza().isEmpty()) {
                z = false;
                break;
            }
        }
        return (!this.zzh && this.zzb == null && this.zza == null && this.zze == null && this.zzf == 0 && !z) ? false : true;
    }

    public final String zzd() {
        return this.zze;
    }

    /* access modifiers changed from: 0000 */
    public final String zze() {
        return this.zza;
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
