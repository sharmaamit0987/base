package com.android.billingclient.api;

import android.os.Bundle;
import com.android.billingclient.api.BillingClient.SkuType;
import java.util.Arrays;
import java.util.concurrent.Callable;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzaa implements Callable<Bundle> {
    private final /* synthetic */ BillingFlowParams zza;
    private final /* synthetic */ SkuDetails zzb;
    private final /* synthetic */ BillingClientImpl zzc;

    zzaa(BillingClientImpl billingClientImpl, BillingFlowParams billingFlowParams, SkuDetails skuDetails) {
        this.zzc = billingClientImpl;
        this.zza = billingFlowParams;
        this.zzb = skuDetails;
    }

    public final /* synthetic */ Object call() throws Exception {
        return this.zzc.zzg.zza(5, this.zzc.zzf.getPackageName(), Arrays.asList(new String[]{this.zza.getOldSku()}), this.zzb.getSku(), SkuType.SUBS, (String) null);
    }
}
