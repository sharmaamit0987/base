package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzaf implements Runnable {
    private final /* synthetic */ zza zza;

    zzaf(zza zza2) {
        this.zza = zza2;
    }

    public final void run() {
        BillingClientImpl.this.zza = 0;
        BillingClientImpl.this.zzg = null;
        this.zza.zza(zzak.zzp);
    }
}
