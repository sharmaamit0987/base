package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzj implements Runnable {
    private final /* synthetic */ zza zza;
    private final /* synthetic */ zzg zzb;

    zzj(zzg zzg, zza zza2) {
        this.zzb = zzg;
        this.zza = zza2;
    }

    public final void run() {
        this.zzb.zza.onSkuDetailsResponse(BillingResult.newBuilder().setResponseCode(this.zza.zzb()).setDebugMessage(this.zza.zzc()).build(), this.zza.zza());
    }
}
