package com.android.billingclient.api;

import android.os.Bundle;
import com.google.android.gms.internal.play_billing.zzb;
import java.util.concurrent.Callable;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzo implements Callable<Void> {
    final /* synthetic */ AcknowledgePurchaseResponseListener zza;
    private final /* synthetic */ AcknowledgePurchaseParams zzb;
    private final /* synthetic */ BillingClientImpl zzc;

    zzo(BillingClientImpl billingClientImpl, AcknowledgePurchaseParams acknowledgePurchaseParams, AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener) {
        this.zzc = billingClientImpl;
        this.zzb = acknowledgePurchaseParams;
        this.zza = acknowledgePurchaseResponseListener;
    }

    /* access modifiers changed from: private */
    /* renamed from: zza */
    public final Void call() {
        try {
            Bundle zzd = this.zzc.zzg.zzd(9, this.zzc.zzf.getPackageName(), this.zzb.getPurchaseToken(), zzb.zza(this.zzb, this.zzc.zzb));
            String str = "BillingClient";
            this.zzc.zza((Runnable) new zzq(this, zzb.zza(zzd, str), zzb.zzb(zzd, str)));
            return null;
        } catch (Exception e) {
            this.zzc.zza((Runnable) new zzr(this, e));
            return null;
        }
    }
}
