package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzt implements Runnable {
    private final /* synthetic */ AcknowledgePurchaseResponseListener zza;

    zzt(BillingClientImpl billingClientImpl, AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener) {
        this.zza = acknowledgePurchaseResponseListener;
    }

    public final void run() {
        this.zza.onAcknowledgePurchaseResponse(zzak.zzp);
    }
}
