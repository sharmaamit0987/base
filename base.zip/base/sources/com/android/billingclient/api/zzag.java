package com.android.billingclient.api;

import java.util.concurrent.Callable;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzag implements Callable<Void> {
    private final /* synthetic */ zza zza;

    zzag(zza zza2) {
        this.zza = zza2;
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:10:?, code lost:
        r3 = com.android.billingclient.api.BillingClientImpl.this.zzf.getPackageName();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0021, code lost:
        r5 = 13;
        r6 = 3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0026, code lost:
        if (r5 < 3) goto L_0x003c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:?, code lost:
        r6 = com.android.billingclient.api.BillingClientImpl.this.zzg.zza(r5, r3, com.android.billingclient.api.BillingClient.SkuType.SUBS);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0036, code lost:
        if (r6 != 0) goto L_0x0039;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0039, code lost:
        r5 = r5 - 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x003c, code lost:
        r5 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x003d, code lost:
        r7 = com.android.billingclient.api.BillingClientImpl.this;
        r9 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0043, code lost:
        if (r5 < 5) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0045, code lost:
        r8 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0047, code lost:
        r8 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0048, code lost:
        r7.zzj = r8;
        r7 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004f, code lost:
        if (r5 < 3) goto L_0x0053;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0051, code lost:
        r8 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0053, code lost:
        r8 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0054, code lost:
        r7.zzi = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0057, code lost:
        if (r5 >= 3) goto L_0x0060;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0059, code lost:
        com.google.android.gms.internal.play_billing.zzb.zza("BillingClient", "In-app billing API does not support subscription on this device.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0060, code lost:
        r5 = 13;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0062, code lost:
        if (r5 < 3) goto L_0x0078;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0064, code lost:
        r6 = com.android.billingclient.api.BillingClientImpl.this.zzg.zza(r5, r3, com.android.billingclient.api.BillingClient.SkuType.INAPP);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0072, code lost:
        if (r6 != 0) goto L_0x0075;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0075, code lost:
        r5 = r5 - 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0078, code lost:
        r5 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0079, code lost:
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x007d, code lost:
        if (r5 < 13) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x007f, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0081, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0082, code lost:
        r3.zzp = r4;
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x008b, code lost:
        if (r5 < 12) goto L_0x008f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x008d, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x008f, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0090, code lost:
        r3.zzo = r4;
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0099, code lost:
        if (r5 < 10) goto L_0x009d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x009b, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x009d, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x009e, code lost:
        r3.zzn = r4;
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00a7, code lost:
        if (r5 < 9) goto L_0x00ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00a9, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00ab, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00ac, code lost:
        r3.zzm = r4;
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00b5, code lost:
        if (r5 < 8) goto L_0x00b9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00b7, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00b9, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00ba, code lost:
        r3.zzl = r4;
        r3 = com.android.billingclient.api.BillingClientImpl.this;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x00c2, code lost:
        if (r5 < 6) goto L_0x00c5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00c5, code lost:
        r9 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x00c6, code lost:
        r3.zzk = r9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x00c9, code lost:
        if (r5 >= 3) goto L_0x00d2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x00cb, code lost:
        com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "In-app billing API version 3 is not supported on this device.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00d2, code lost:
        if (r6 != 0) goto L_0x00dd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x00d4, code lost:
        com.android.billingclient.api.BillingClientImpl.this.zza = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00dd, code lost:
        com.android.billingclient.api.BillingClientImpl.this.zza = 0;
        com.android.billingclient.api.BillingClientImpl.this.zzg = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00ec, code lost:
        r0 = r6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x00ed, code lost:
        com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "Exception while checking if billing is supported; try to reconnect");
        com.android.billingclient.api.BillingClientImpl.this.zza = 0;
        com.android.billingclient.api.BillingClientImpl.this.zzg = null;
        r6 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0103, code lost:
        if (r6 != 0) goto L_0x010d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0105, code lost:
        r10.zza.zza(com.android.billingclient.api.zzak.zzn);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x010d, code lost:
        r10.zza.zza(com.android.billingclient.api.zzak.zza);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0114, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0013, code lost:
        r0 = 3;
     */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x010d  */
    /* renamed from: zza */
    public final Void call() {
        synchronized (this.zza.zzb) {
            if (this.zza.zzc) {
                return null;
            }
        }
    }
}
