package com.android.billingclient.api;

import java.util.concurrent.Callable;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzl implements Callable<Void> {
    private final /* synthetic */ ConsumeParams zza;
    private final /* synthetic */ ConsumeResponseListener zzb;
    private final /* synthetic */ BillingClientImpl zzc;

    zzl(BillingClientImpl billingClientImpl, ConsumeParams consumeParams, ConsumeResponseListener consumeResponseListener) {
        this.zzc = billingClientImpl;
        this.zza = consumeParams;
        this.zzb = consumeResponseListener;
    }

    public final /* synthetic */ Object call() throws Exception {
        this.zzc.zza(this.zza, this.zzb);
        return null;
    }
}
