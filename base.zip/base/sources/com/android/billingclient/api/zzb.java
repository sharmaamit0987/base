package com.android.billingclient.api;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public final class zzb {

    @Documented
    @Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.CONSTRUCTOR})
    @Retention(RetentionPolicy.CLASS)
    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    public @interface zza {
    }
}
