package com.android.billingclient.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.text.TextUtils;
import com.android.billingclient.BuildConfig;
import com.android.billingclient.api.BillingClient.FeatureType;
import com.android.billingclient.api.BillingClient.SkuType;
import com.android.billingclient.api.Purchase.PurchasesResult;
import com.google.android.gms.internal.play_billing.zzd;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
class BillingClientImpl extends BillingClient {
    /* access modifiers changed from: private */
    public int zza;
    /* access modifiers changed from: private */
    public final String zzb;
    private final Handler zzc;
    /* access modifiers changed from: private */
    public zzd zzd;
    private Context zze;
    /* access modifiers changed from: private */
    public Context zzf;
    /* access modifiers changed from: private */
    public com.google.android.gms.internal.play_billing.zza zzg;
    private zza zzh;
    /* access modifiers changed from: private */
    public boolean zzi;
    /* access modifiers changed from: private */
    public boolean zzj;
    /* access modifiers changed from: private */
    public boolean zzk;
    /* access modifiers changed from: private */
    public boolean zzl;
    /* access modifiers changed from: private */
    public boolean zzm;
    /* access modifiers changed from: private */
    public boolean zzn;
    /* access modifiers changed from: private */
    public boolean zzo;
    /* access modifiers changed from: private */
    public boolean zzp;
    private boolean zzq;
    private ExecutorService zzr;
    private String zzs;
    private final ResultReceiver zzt;

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    private final class zza implements ServiceConnection {
        /* access modifiers changed from: private */
        public final Object zzb;
        /* access modifiers changed from: private */
        public boolean zzc;
        /* access modifiers changed from: private */
        public BillingClientStateListener zzd;

        private zza(BillingClientStateListener billingClientStateListener) {
            this.zzb = new Object();
            this.zzc = false;
            this.zzd = billingClientStateListener;
        }

        public final void onServiceDisconnected(ComponentName componentName) {
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "Billing service disconnected.");
            BillingClientImpl.this.zzg = null;
            BillingClientImpl.this.zza = 0;
            synchronized (this.zzb) {
                if (this.zzd != null) {
                    this.zzd.onBillingServiceDisconnected();
                }
            }
        }

        /* access modifiers changed from: 0000 */
        public final void zza() {
            synchronized (this.zzb) {
                this.zzd = null;
                this.zzc = true;
            }
        }

        /* access modifiers changed from: private */
        public final void zza(BillingResult billingResult) {
            BillingClientImpl.this.zza((Runnable) new zzae(this, billingResult));
        }

        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            com.google.android.gms.internal.play_billing.zzb.zza("BillingClient", "Billing service connected.");
            BillingClientImpl.this.zzg = zzd.zza(iBinder);
            if (BillingClientImpl.this.zza((Callable<T>) new zzag<T>(this), 30000, (Runnable) new zzaf(this)) == null) {
                zza(BillingClientImpl.this.zzc());
            }
        }

        /* synthetic */ zza(BillingClientImpl billingClientImpl, BillingClientStateListener billingClientStateListener, zzh zzh) {
            this(billingClientStateListener);
        }
    }

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    private static class zzb {
        private final List<PurchaseHistoryRecord> zza;
        private final BillingResult zzb;

        zzb(BillingResult billingResult, List<PurchaseHistoryRecord> list) {
            this.zza = list;
            this.zzb = billingResult;
        }

        /* access modifiers changed from: 0000 */
        public final BillingResult zza() {
            return this.zzb;
        }

        /* access modifiers changed from: 0000 */
        public final List<PurchaseHistoryRecord> zzb() {
            return this.zza;
        }
    }

    BillingClientImpl(String str, boolean z, Context context, PurchasesUpdatedListener purchasesUpdatedListener) {
        this(context, z, purchasesUpdatedListener, zza(), null);
    }

    private BillingClientImpl(Activity activity, boolean z, String str) {
        this(activity.getApplicationContext(), z, new zzah(), str, null);
    }

    private BillingClientImpl(Context context, boolean z, PurchasesUpdatedListener purchasesUpdatedListener, String str, String str2) {
        this.zza = 0;
        this.zzc = new Handler(Looper.getMainLooper());
        this.zzt = new zzh(this, this.zzc);
        this.zzs = str2;
        this.zzb = str;
        initialize(context, purchasesUpdatedListener, z);
    }

    private BillingClientImpl(String str) {
        this.zza = 0;
        this.zzc = new Handler(Looper.getMainLooper());
        this.zzt = new zzh(this, this.zzc);
        this.zzb = str;
    }

    private static String zza() {
        try {
            return (String) Class.forName("com.android.billingclient.ktx.BuildConfig").getField("VERSION_NAME").get(null);
        } catch (Exception unused) {
            return BuildConfig.VERSION_NAME;
        }
    }

    private void initialize(Context context, PurchasesUpdatedListener purchasesUpdatedListener, boolean z) {
        this.zzf = context.getApplicationContext();
        this.zzd = new zzd(this.zzf, purchasesUpdatedListener);
        this.zze = context;
        this.zzq = z;
    }

    public BillingResult isFeatureSupported(String str) {
        if (!isReady()) {
            return zzak.zzo;
        }
        char c = 65535;
        switch (str.hashCode()) {
            case -422092961:
                if (str.equals(FeatureType.SUBSCRIPTIONS_UPDATE)) {
                    c = 1;
                    break;
                }
                break;
            case 207616302:
                if (str.equals(FeatureType.PRICE_CHANGE_CONFIRMATION)) {
                    c = 4;
                    break;
                }
                break;
            case 292218239:
                if (str.equals(FeatureType.IN_APP_ITEMS_ON_VR)) {
                    c = 2;
                    break;
                }
                break;
            case 1219490065:
                if (str.equals(FeatureType.SUBSCRIPTIONS_ON_VR)) {
                    c = 3;
                    break;
                }
                break;
            case 1987365622:
                if (str.equals(FeatureType.SUBSCRIPTIONS)) {
                    c = 0;
                    break;
                }
                break;
        }
        if (c == 0) {
            return this.zzi ? zzak.zzn : zzak.zzi;
        }
        if (c != 1) {
            if (c == 2) {
                return zzb(SkuType.INAPP);
            }
            if (c == 3) {
                return zzb(SkuType.SUBS);
            }
            if (c == 4) {
                return this.zzl ? zzak.zzn : zzak.zzi;
            }
            String str2 = "Unsupported feature: ";
            String valueOf = String.valueOf(str);
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            return zzak.zzs;
        } else if (this.zzj) {
            return zzak.zzn;
        } else {
            return zzak.zzi;
        }
    }

    public boolean isReady() {
        return (this.zza != 2 || this.zzg == null || this.zzh == null) ? false : true;
    }

    public void startConnection(BillingClientStateListener billingClientStateListener) {
        String str = "BillingClient";
        if (isReady()) {
            com.google.android.gms.internal.play_billing.zzb.zza(str, "Service connection is valid. No need to re-initialize.");
            billingClientStateListener.onBillingSetupFinished(zzak.zzn);
            return;
        }
        int i = this.zza;
        if (i == 1) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str, "Client is already in the process of connecting to billing service.");
            billingClientStateListener.onBillingSetupFinished(zzak.zzd);
        } else if (i == 3) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str, "Client was already closed and can't be reused. Please create another instance.");
            billingClientStateListener.onBillingSetupFinished(zzak.zzo);
        } else {
            this.zza = 1;
            this.zzd.zza();
            com.google.android.gms.internal.play_billing.zzb.zza(str, "Starting in-app billing setup.");
            this.zzh = new zza(this, billingClientStateListener, null);
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            String str2 = "com.android.vending";
            intent.setPackage(str2);
            List queryIntentServices = this.zzf.getPackageManager().queryIntentServices(intent, 0);
            if (queryIntentServices != null && !queryIntentServices.isEmpty()) {
                ResolveInfo resolveInfo = (ResolveInfo) queryIntentServices.get(0);
                if (resolveInfo.serviceInfo != null) {
                    String str3 = resolveInfo.serviceInfo.packageName;
                    String str4 = resolveInfo.serviceInfo.name;
                    if (!str2.equals(str3) || str4 == null) {
                        com.google.android.gms.internal.play_billing.zzb.zzb(str, "The device doesn't have valid Play Store.");
                    } else {
                        ComponentName componentName = new ComponentName(str3, str4);
                        Intent intent2 = new Intent(intent);
                        intent2.setComponent(componentName);
                        intent2.putExtra("playBillingLibraryVersion", this.zzb);
                        if (this.zzf.bindService(intent2, this.zzh, 1)) {
                            com.google.android.gms.internal.play_billing.zzb.zza(str, "Service was bonded successfully.");
                            return;
                        }
                        com.google.android.gms.internal.play_billing.zzb.zzb(str, "Connection to Billing service is blocked.");
                    }
                }
            }
            this.zza = 0;
            com.google.android.gms.internal.play_billing.zzb.zza(str, "Billing service unavailable on device.");
            billingClientStateListener.onBillingSetupFinished(zzak.zzc);
        }
    }

    private void startConnection(long j) {
        startConnection(new zzah(j));
    }

    public void endConnection() {
        String str = "BillingClient";
        try {
            this.zzd.zzc();
            if (this.zzh != null) {
                this.zzh.zza();
            }
            if (!(this.zzh == null || this.zzg == null)) {
                com.google.android.gms.internal.play_billing.zzb.zza(str, "Unbinding from service.");
                this.zzf.unbindService(this.zzh);
                this.zzh = null;
            }
            this.zzg = null;
            if (this.zzr != null) {
                this.zzr.shutdownNow();
                this.zzr = null;
            }
        } catch (Exception e) {
            String valueOf = String.valueOf(e);
            StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 48);
            sb.append("There was an exception while ending connection: ");
            sb.append(valueOf);
            com.google.android.gms.internal.play_billing.zzb.zzb(str, sb.toString());
        } finally {
            this.zza = 3;
        }
    }

    private void launchPriceChangeConfirmationFlow(Activity activity, PriceChangeFlowParams priceChangeFlowParams, long j) {
        launchPriceChangeConfirmationFlow(activity, priceChangeFlowParams, new zzah(j));
    }

    public void launchPriceChangeConfirmationFlow(Activity activity, PriceChangeFlowParams priceChangeFlowParams, PriceChangeConfirmationListener priceChangeConfirmationListener) {
        String str = "SUBS_MANAGEMENT_INTENT";
        String str2 = "; try to reconnect";
        if (!isReady()) {
            priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzo);
            return;
        }
        String str3 = "Please fix the input params. priceChangeFlowParams must contain valid sku.";
        String str4 = "BillingClient";
        if (priceChangeFlowParams == null || priceChangeFlowParams.getSkuDetails() == null) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str4, str3);
            priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzm);
            return;
        }
        String sku = priceChangeFlowParams.getSkuDetails().getSku();
        if (sku == null) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str4, str3);
            priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzm);
        } else if (!this.zzl) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str4, "Current client doesn't support price change confirmation flow.");
            priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzi);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("playBillingLibraryVersion", this.zzb);
            bundle.putBoolean("subs_price_change", true);
            try {
                Bundle bundle2 = (Bundle) zza((Callable<T>) new zzv<T>(this, sku, bundle), 5000, (Runnable) null).get(5000, TimeUnit.MILLISECONDS);
                int zza2 = com.google.android.gms.internal.play_billing.zzb.zza(bundle2, str4);
                BillingResult build = BillingResult.newBuilder().setResponseCode(zza2).setDebugMessage(com.google.android.gms.internal.play_billing.zzb.zzb(bundle2, str4)).build();
                if (zza2 != 0) {
                    StringBuilder sb = new StringBuilder(68);
                    sb.append("Unable to launch price change flow, error response code: ");
                    sb.append(zza2);
                    com.google.android.gms.internal.play_billing.zzb.zzb(str4, sb.toString());
                    priceChangeConfirmationListener.onPriceChangeConfirmationResult(build);
                    return;
                }
                zzy zzy = new zzy(this, this.zzc, priceChangeConfirmationListener);
                Intent intent = new Intent(activity, ProxyBillingActivity.class);
                intent.putExtra(str, (PendingIntent) bundle2.getParcelable(str));
                intent.putExtra("result_receiver", zzy);
                activity.startActivity(intent);
            } catch (CancellationException | TimeoutException unused) {
                StringBuilder sb2 = new StringBuilder(String.valueOf(sku).length() + 70);
                sb2.append("Time out while launching Price Change Flow for sku: ");
                sb2.append(sku);
                sb2.append(str2);
                com.google.android.gms.internal.play_billing.zzb.zzb(str4, sb2.toString());
                priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzp);
            } catch (Exception unused2) {
                StringBuilder sb3 = new StringBuilder(String.valueOf(sku).length() + 78);
                sb3.append("Exception caught while launching Price Change Flow for sku: ");
                sb3.append(sku);
                sb3.append(str2);
                com.google.android.gms.internal.play_billing.zzb.zzb(str4, sb3.toString());
                priceChangeConfirmationListener.onPriceChangeConfirmationResult(zzak.zzo);
            }
        }
    }

    public BillingResult launchBillingFlow(Activity activity, BillingFlowParams billingFlowParams) {
        long j;
        Future future;
        Activity activity2 = activity;
        BillingFlowParams billingFlowParams2 = billingFlowParams;
        String str = "BUY_INTENT";
        String str2 = "; try to reconnect";
        if (!isReady()) {
            return zza(zzak.zzo);
        }
        ArrayList zza2 = billingFlowParams.zza();
        SkuDetails skuDetails = (SkuDetails) zza2.get(0);
        String type = skuDetails.getType();
        String str3 = "BillingClient";
        if (!type.equals(SkuType.SUBS) || this.zzi) {
            boolean z = billingFlowParams.getOldSku() != null;
            if (z && !this.zzj) {
                com.google.android.gms.internal.play_billing.zzb.zzb(str3, "Current client doesn't support subscriptions update.");
                return zza(zzak.zzr);
            } else if (!billingFlowParams.zzc() || this.zzk) {
                String str4 = "";
                for (int i = 0; i < zza2.size(); i++) {
                    String valueOf = String.valueOf(str4);
                    String valueOf2 = String.valueOf(zza2.get(i));
                    StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + String.valueOf(valueOf2).length());
                    sb.append(valueOf);
                    sb.append(valueOf2);
                    str4 = sb.toString();
                    if (i < zza2.size() - 1) {
                        str4 = String.valueOf(str4).concat(", ");
                    }
                }
                StringBuilder sb2 = new StringBuilder(String.valueOf(str4).length() + 41 + String.valueOf(type).length());
                sb2.append("Constructing buy intent for ");
                sb2.append(str4);
                sb2.append(", item type: ");
                sb2.append(type);
                com.google.android.gms.internal.play_billing.zzb.zza(str3, sb2.toString());
                if (this.zzk) {
                    Bundle zza3 = com.google.android.gms.internal.play_billing.zzb.zza(billingFlowParams2, this.zzm, this.zzq, this.zzb);
                    if (!skuDetails.zzb().isEmpty()) {
                        zza3.putString("skuDetailsToken", skuDetails.zzb());
                    }
                    if (!TextUtils.isEmpty(skuDetails.zza())) {
                        zza3.putString("skuPackageName", skuDetails.zza());
                    }
                    if (!TextUtils.isEmpty(this.zzs)) {
                        zza3.putString("accountName", this.zzs);
                    }
                    if (zza2.size() > 1) {
                        ArrayList arrayList = new ArrayList(zza2.size() - 1);
                        for (int i2 = 1; i2 < zza2.size(); i2++) {
                            arrayList.add(((SkuDetails) zza2.get(i2)).getSku());
                        }
                        zza3.putStringArrayList("additionalSkus", arrayList);
                    }
                    int i3 = this.zzm ? 9 : billingFlowParams.getVrPurchaseFlow() ? 7 : 6;
                    zzab zzab = r0;
                    zzab zzab2 = new zzab(this, i3, skuDetails, type, billingFlowParams, zza3);
                    future = zza((Callable<T>) zzab, 5000, (Runnable) null);
                    j = 5000;
                } else {
                    j = 5000;
                    if (z) {
                        future = zza((Callable<T>) new zzaa<T>(this, billingFlowParams2, skuDetails), 5000, (Runnable) null);
                    } else {
                        future = zza((Callable<T>) new zzad<T>(this, skuDetails, type), 5000, (Runnable) null);
                    }
                }
                try {
                    Bundle bundle = (Bundle) future.get(j, TimeUnit.MILLISECONDS);
                    int zza4 = com.google.android.gms.internal.play_billing.zzb.zza(bundle, str3);
                    String zzb2 = com.google.android.gms.internal.play_billing.zzb.zzb(bundle, str3);
                    if (zza4 != 0) {
                        StringBuilder sb3 = new StringBuilder(52);
                        sb3.append("Unable to buy item, Error response code: ");
                        sb3.append(zza4);
                        com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb3.toString());
                        return zza(BillingResult.newBuilder().setResponseCode(zza4).setDebugMessage(zzb2).build());
                    }
                    Intent intent = new Intent(activity2, ProxyBillingActivity.class);
                    intent.putExtra("result_receiver", this.zzt);
                    intent.putExtra(str, (PendingIntent) bundle.getParcelable(str));
                    activity2.startActivity(intent);
                    return zzak.zzn;
                } catch (CancellationException | TimeoutException unused) {
                    StringBuilder sb4 = new StringBuilder(String.valueOf(str4).length() + 68);
                    sb4.append("Time out while launching billing flow: ; for sku: ");
                    sb4.append(str4);
                    sb4.append(str2);
                    com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb4.toString());
                    return zza(zzak.zzp);
                } catch (Exception unused2) {
                    StringBuilder sb5 = new StringBuilder(String.valueOf(str4).length() + 69);
                    sb5.append("Exception while launching billing flow: ; for sku: ");
                    sb5.append(str4);
                    sb5.append(str2);
                    com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb5.toString());
                    return zza(zzak.zzo);
                }
            } else {
                com.google.android.gms.internal.play_billing.zzb.zzb(str3, "Current client doesn't support extra params for buy intent.");
                return zza(zzak.zzh);
            }
        } else {
            com.google.android.gms.internal.play_billing.zzb.zzb(str3, "Current client doesn't support subscriptions.");
            return zza(zzak.zzq);
        }
    }

    private final BillingResult zza(BillingResult billingResult) {
        this.zzd.zzb().onPurchasesUpdated(billingResult, null);
        return billingResult;
    }

    private int launchBillingFlowCpp(Activity activity, BillingFlowParams billingFlowParams) {
        return launchBillingFlow(activity, billingFlowParams).getResponseCode();
    }

    public PurchasesResult queryPurchases(String str) {
        if (!isReady()) {
            return new PurchasesResult(zzak.zzo, null);
        }
        if (TextUtils.isEmpty(str)) {
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "Please provide a valid SKU type.");
            return new PurchasesResult(zzak.zzg, null);
        }
        try {
            return (PurchasesResult) zza((Callable<T>) new zzac<T>(this, str), 5000, (Runnable) null).get(5000, TimeUnit.MILLISECONDS);
        } catch (CancellationException | TimeoutException unused) {
            return new PurchasesResult(zzak.zzp, null);
        } catch (Exception unused2) {
            return new PurchasesResult(zzak.zzl, null);
        }
    }

    public void querySkuDetailsAsync(SkuDetailsParams skuDetailsParams, SkuDetailsResponseListener skuDetailsResponseListener) {
        if (!isReady()) {
            skuDetailsResponseListener.onSkuDetailsResponse(zzak.zzo, null);
            return;
        }
        String skuType = skuDetailsParams.getSkuType();
        List skusList = skuDetailsParams.getSkusList();
        String zza2 = skuDetailsParams.zza();
        String str = "BillingClient";
        if (TextUtils.isEmpty(skuType)) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str, "Please fix the input params. SKU type can't be empty.");
            skuDetailsResponseListener.onSkuDetailsResponse(zzak.zzg, null);
        } else if (skusList == null) {
            com.google.android.gms.internal.play_billing.zzb.zzb(str, "Please fix the input params. The list of SKUs can't be empty.");
            skuDetailsResponseListener.onSkuDetailsResponse(zzak.zzf, null);
        } else if (this.zzp || zza2 == null) {
            zzg zzg2 = new zzg(this, skuType, skusList, zza2, skuDetailsResponseListener);
            if (zza((Callable<T>) zzg2, 30000, (Runnable) new zzi(this, skuDetailsResponseListener)) == null) {
                skuDetailsResponseListener.onSkuDetailsResponse(zzc(), null);
            }
        } else {
            com.google.android.gms.internal.play_billing.zzb.zzb(str, "The user's client is too old to handle skuPackageName from SkuDetails.");
            skuDetailsResponseListener.onSkuDetailsResponse(zzak.zze, null);
        }
    }

    public void consumeAsync(ConsumeParams consumeParams, ConsumeResponseListener consumeResponseListener) {
        if (!isReady()) {
            consumeResponseListener.onConsumeResponse(zzak.zzo, consumeParams.getPurchaseToken());
            return;
        }
        if (zza((Callable<T>) new zzl<T>(this, consumeParams, consumeResponseListener), 30000, (Runnable) new zzk(this, consumeResponseListener, consumeParams)) == null) {
            consumeResponseListener.onConsumeResponse(zzc(), consumeParams.getPurchaseToken());
        }
    }

    public void queryPurchaseHistoryAsync(String str, PurchaseHistoryResponseListener purchaseHistoryResponseListener) {
        if (!isReady()) {
            purchaseHistoryResponseListener.onPurchaseHistoryResponse(zzak.zzo, null);
            return;
        }
        if (zza((Callable<T>) new zzn<T>(this, str, purchaseHistoryResponseListener), 30000, (Runnable) new zzp(this, purchaseHistoryResponseListener)) == null) {
            purchaseHistoryResponseListener.onPurchaseHistoryResponse(zzc(), null);
        }
    }

    /* access modifiers changed from: private */
    public final zzb zza(String str) {
        String valueOf = String.valueOf(str);
        String str2 = "Querying purchase history, item type: ";
        String str3 = "BillingClient";
        com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        ArrayList arrayList = new ArrayList();
        Bundle zza2 = com.google.android.gms.internal.play_billing.zzb.zza(this.zzm, this.zzq, this.zzb);
        String str4 = null;
        while (this.zzk) {
            try {
                Bundle zza3 = this.zzg.zza(6, this.zzf.getPackageName(), str, str4, zza2);
                BillingResult zza4 = zzam.zza(zza3, str3, "getPurchaseHistory()");
                if (zza4 != zzak.zzn) {
                    return new zzb(zza4, null);
                }
                ArrayList stringArrayList = zza3.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                ArrayList stringArrayList2 = zza3.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                ArrayList stringArrayList3 = zza3.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
                int i = 0;
                while (i < stringArrayList2.size()) {
                    String str5 = (String) stringArrayList2.get(i);
                    String str6 = (String) stringArrayList3.get(i);
                    String str7 = "Purchase record found for sku : ";
                    String valueOf2 = String.valueOf((String) stringArrayList.get(i));
                    com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf2.length() != 0 ? str7.concat(valueOf2) : new String(str7));
                    try {
                        PurchaseHistoryRecord purchaseHistoryRecord = new PurchaseHistoryRecord(str5, str6);
                        if (TextUtils.isEmpty(purchaseHistoryRecord.getPurchaseToken())) {
                            com.google.android.gms.internal.play_billing.zzb.zzb(str3, "BUG: empty/null token!");
                        }
                        arrayList.add(purchaseHistoryRecord);
                        i++;
                    } catch (JSONException e) {
                        String valueOf3 = String.valueOf(e);
                        StringBuilder sb = new StringBuilder(String.valueOf(valueOf3).length() + 48);
                        sb.append("Got an exception trying to decode the purchase: ");
                        sb.append(valueOf3);
                        com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb.toString());
                        return new zzb(zzak.zzl, null);
                    }
                }
                str4 = zza3.getString("INAPP_CONTINUATION_TOKEN");
                String str8 = "Continuation token: ";
                String valueOf4 = String.valueOf(str4);
                com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf4.length() != 0 ? str8.concat(valueOf4) : new String(str8));
                if (TextUtils.isEmpty(str4)) {
                    return new zzb(zzak.zzn, arrayList);
                }
            } catch (RemoteException e2) {
                String valueOf5 = String.valueOf(e2);
                StringBuilder sb2 = new StringBuilder(String.valueOf(valueOf5).length() + 64);
                sb2.append("Got exception trying to get purchase history: ");
                sb2.append(valueOf5);
                sb2.append("; try to reconnect");
                com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb2.toString());
                return new zzb(zzak.zzo, null);
            }
        }
        com.google.android.gms.internal.play_billing.zzb.zzb(str3, "getPurchaseHistory is not supported on current device");
        return new zzb(zzak.zzj, null);
    }

    public void acknowledgePurchase(AcknowledgePurchaseParams acknowledgePurchaseParams, AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener) {
        if (!isReady()) {
            acknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzak.zzo);
        } else if (TextUtils.isEmpty(acknowledgePurchaseParams.getPurchaseToken())) {
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "Please provide a valid purchase token.");
            acknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzak.zzk);
        } else if (!this.zzm) {
            acknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzak.zzb);
        } else {
            if (zza((Callable<T>) new zzo<T>(this, acknowledgePurchaseParams, acknowledgePurchaseResponseListener), 30000, (Runnable) new zzt(this, acknowledgePurchaseResponseListener)) == null) {
                acknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzc());
            }
        }
    }

    /* access modifiers changed from: private */
    public final <T> Future<T> zza(Callable<T> callable, long j, Runnable runnable) {
        long j2 = (long) (((double) j) * 0.95d);
        if (this.zzr == null) {
            this.zzr = Executors.newFixedThreadPool(com.google.android.gms.internal.play_billing.zzb.zza);
        }
        try {
            Future<T> submit = this.zzr.submit(callable);
            this.zzc.postDelayed(new zzs(this, submit, runnable), j2);
            return submit;
        } catch (Exception e) {
            String valueOf = String.valueOf(e);
            StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 28);
            sb.append("Async task throws exception ");
            sb.append(valueOf);
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", sb.toString());
            return null;
        }
    }

    private final BillingResult zzb(String str) {
        try {
            if (((Integer) zza((Callable<T>) new zzu<T>(this, str), 5000, (Runnable) null).get(5000, TimeUnit.MILLISECONDS)).intValue() == 0) {
                return zzak.zzn;
            }
            return zzak.zzi;
        } catch (Exception unused) {
            com.google.android.gms.internal.play_billing.zzb.zzb("BillingClient", "Exception while checking if billing is supported; try to reconnect");
            return zzak.zzo;
        }
    }

    /* access modifiers changed from: private */
    public static Bundle zzb() {
        Bundle bundle = new Bundle();
        bundle.putBoolean(BillingFlowParams.EXTRA_PARAM_KEY_VR, true);
        return bundle;
    }

    /* access modifiers changed from: 0000 */
    public final zza zza(String str, List<String> list, String str2) {
        Bundle bundle;
        String str3 = "BillingClient";
        ArrayList arrayList = new ArrayList();
        int size = list.size();
        int i = 0;
        while (i < size) {
            int i2 = i + 20;
            ArrayList arrayList2 = new ArrayList(list.subList(i, i2 > size ? size : i2));
            Bundle bundle2 = new Bundle();
            bundle2.putStringArrayList("ITEM_ID_LIST", arrayList2);
            bundle2.putString("playBillingLibraryVersion", this.zzb);
            try {
                if (this.zzn) {
                    bundle = this.zzg.zza(10, this.zzf.getPackageName(), str, bundle2, com.google.android.gms.internal.play_billing.zzb.zza(this.zzm, this.zzp, this.zzq, this.zzb, str2));
                    String str4 = str;
                } else {
                    String str5 = str2;
                    bundle = this.zzg.zza(3, this.zzf.getPackageName(), str, bundle2);
                }
                if (bundle == null) {
                    com.google.android.gms.internal.play_billing.zzb.zzb(str3, "querySkuDetailsAsync got null sku details list");
                    return new zza(4, "Null sku details list", null);
                }
                String str6 = "DETAILS_LIST";
                if (!bundle.containsKey(str6)) {
                    int zza2 = com.google.android.gms.internal.play_billing.zzb.zza(bundle, str3);
                    String zzb2 = com.google.android.gms.internal.play_billing.zzb.zzb(bundle, str3);
                    if (zza2 != 0) {
                        StringBuilder sb = new StringBuilder(50);
                        sb.append("getSkuDetails() failed. Response code: ");
                        sb.append(zza2);
                        com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb.toString());
                        return new zza(zza2, zzb2, arrayList);
                    }
                    com.google.android.gms.internal.play_billing.zzb.zzb(str3, "getSkuDetails() returned a bundle with neither an error nor a detail list.");
                    return new zza(6, zzb2, arrayList);
                }
                ArrayList stringArrayList = bundle.getStringArrayList(str6);
                if (stringArrayList == null) {
                    String str7 = "querySkuDetailsAsync got null response list";
                    com.google.android.gms.internal.play_billing.zzb.zzb(str3, str7);
                    return new zza(4, str7, null);
                }
                int i3 = 0;
                while (i3 < stringArrayList.size()) {
                    try {
                        SkuDetails skuDetails = new SkuDetails((String) stringArrayList.get(i3));
                        String valueOf = String.valueOf(skuDetails);
                        StringBuilder sb2 = new StringBuilder(String.valueOf(valueOf).length() + 17);
                        sb2.append("Got sku details: ");
                        sb2.append(valueOf);
                        com.google.android.gms.internal.play_billing.zzb.zza(str3, sb2.toString());
                        arrayList.add(skuDetails);
                        i3++;
                    } catch (JSONException unused) {
                        com.google.android.gms.internal.play_billing.zzb.zzb(str3, "Got a JSON exception trying to decode SkuDetails.");
                        return new zza(6, "Error trying to decode SkuDetails.", null);
                    }
                }
                i = i2;
            } catch (Exception e) {
                String str8 = "querySkuDetailsAsync got a remote exception (try to reconnect).";
                String valueOf2 = String.valueOf(e);
                StringBuilder sb3 = new StringBuilder(str8.length() + String.valueOf(valueOf2).length());
                sb3.append(str8);
                sb3.append(valueOf2);
                com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb3.toString());
                return new zza(-1, "Service connection is disconnected.", null);
            }
        }
        return new zza(0, "", arrayList);
    }

    /* access modifiers changed from: private */
    public final PurchasesResult zzc(String str) {
        Bundle bundle;
        String valueOf = String.valueOf(str);
        String str2 = "Querying owned items, item type: ";
        String str3 = "BillingClient";
        com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        ArrayList arrayList = new ArrayList();
        Bundle zza2 = com.google.android.gms.internal.play_billing.zzb.zza(this.zzm, this.zzq, this.zzb);
        String str4 = null;
        do {
            try {
                if (this.zzm) {
                    bundle = this.zzg.zzc(9, this.zzf.getPackageName(), str, str4, zza2);
                } else {
                    bundle = this.zzg.zza(3, this.zzf.getPackageName(), str, str4);
                }
                BillingResult zza3 = zzam.zza(bundle, str3, "getPurchase()");
                if (zza3 != zzak.zzn) {
                    return new PurchasesResult(zza3, null);
                }
                ArrayList stringArrayList = bundle.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                ArrayList stringArrayList2 = bundle.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                ArrayList stringArrayList3 = bundle.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
                int i = 0;
                while (i < stringArrayList2.size()) {
                    String str5 = (String) stringArrayList2.get(i);
                    String str6 = (String) stringArrayList3.get(i);
                    String str7 = "Sku is owned: ";
                    String valueOf2 = String.valueOf((String) stringArrayList.get(i));
                    com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf2.length() != 0 ? str7.concat(valueOf2) : new String(str7));
                    try {
                        Purchase purchase = new Purchase(str5, str6);
                        if (TextUtils.isEmpty(purchase.getPurchaseToken())) {
                            com.google.android.gms.internal.play_billing.zzb.zzb(str3, "BUG: empty/null token!");
                        }
                        arrayList.add(purchase);
                        i++;
                    } catch (JSONException e) {
                        String valueOf3 = String.valueOf(e);
                        StringBuilder sb = new StringBuilder(String.valueOf(valueOf3).length() + 48);
                        sb.append("Got an exception trying to decode the purchase: ");
                        sb.append(valueOf3);
                        com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb.toString());
                        return new PurchasesResult(zzak.zzl, null);
                    }
                }
                str4 = bundle.getString("INAPP_CONTINUATION_TOKEN");
                String str8 = "Continuation token: ";
                String valueOf4 = String.valueOf(str4);
                com.google.android.gms.internal.play_billing.zzb.zza(str3, valueOf4.length() != 0 ? str8.concat(valueOf4) : new String(str8));
            } catch (Exception e2) {
                String valueOf5 = String.valueOf(e2);
                StringBuilder sb2 = new StringBuilder(String.valueOf(valueOf5).length() + 57);
                sb2.append("Got exception trying to get purchases: ");
                sb2.append(valueOf5);
                sb2.append("; try to reconnect");
                com.google.android.gms.internal.play_billing.zzb.zzb(str3, sb2.toString());
                return new PurchasesResult(zzak.zzo, null);
            }
        } while (!TextUtils.isEmpty(str4));
        return new PurchasesResult(zzak.zzn, arrayList);
    }

    /* access modifiers changed from: private */
    public final void zza(Runnable runnable) {
        if (!Thread.interrupted()) {
            this.zzc.post(runnable);
        }
    }

    /* access modifiers changed from: private */
    public final void zza(ConsumeParams consumeParams, ConsumeResponseListener consumeResponseListener) {
        String str;
        int i;
        String str2 = "BillingClient";
        String purchaseToken = consumeParams.getPurchaseToken();
        String str3 = "Consuming purchase with token: ";
        try {
            String valueOf = String.valueOf(purchaseToken);
            com.google.android.gms.internal.play_billing.zzb.zza(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            if (this.zzm) {
                Bundle zzc2 = this.zzg.zzc(9, this.zzf.getPackageName(), purchaseToken, com.google.android.gms.internal.play_billing.zzb.zza(consumeParams, this.zzm, this.zzb));
                int i2 = zzc2.getInt("RESPONSE_CODE");
                str = com.google.android.gms.internal.play_billing.zzb.zzb(zzc2, str2);
                i = i2;
            } else {
                i = this.zzg.zzb(3, this.zzf.getPackageName(), purchaseToken);
                str = "";
            }
            BillingResult build = BillingResult.newBuilder().setResponseCode(i).setDebugMessage(str).build();
            if (i == 0) {
                zza((Runnable) new zzx(this, consumeResponseListener, build, purchaseToken));
                return;
            }
            zzw zzw = new zzw(this, i, consumeResponseListener, build, purchaseToken);
            zza((Runnable) zzw);
        } catch (Exception e) {
            zza((Runnable) new zzz(this, e, consumeResponseListener, purchaseToken));
        }
    }

    /* access modifiers changed from: private */
    public final BillingResult zzc() {
        int i = this.zza;
        if (i == 0 || i == 3) {
            return zzak.zzo;
        }
        return zzak.zzl;
    }
}
