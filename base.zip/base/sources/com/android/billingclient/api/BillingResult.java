package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public final class BillingResult {
    /* access modifiers changed from: private */
    public int zza;
    /* access modifiers changed from: private */
    public String zzb;

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    public static class Builder {
        private int zza;
        private String zzb;

        private Builder() {
            this.zzb = "";
        }

        public Builder setResponseCode(int i) {
            this.zza = i;
            return this;
        }

        public Builder setDebugMessage(String str) {
            this.zzb = str;
            return this;
        }

        public BillingResult build() {
            BillingResult billingResult = new BillingResult();
            billingResult.zza = this.zza;
            billingResult.zzb = this.zzb;
            return billingResult;
        }
    }

    public final int getResponseCode() {
        return this.zza;
    }

    public final String getDebugMessage() {
        return this.zzb;
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
