package com.android.billingclient.api;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzh extends ResultReceiver {
    private final /* synthetic */ BillingClientImpl zza;

    zzh(BillingClientImpl billingClientImpl, Handler handler) {
        this.zza = billingClientImpl;
        super(handler);
    }

    public final void onReceiveResult(int i, Bundle bundle) {
        PurchasesUpdatedListener zzb = this.zza.zzd.zzb();
        String str = "BillingClient";
        if (zzb == null) {
            zzb.zzb(str, "PurchasesUpdatedListener is null - no way to return the response.");
            return;
        }
        zzb.onPurchasesUpdated(BillingResult.newBuilder().setResponseCode(i).setDebugMessage(zzb.zzb(bundle, str)).build(), zzb.zza(bundle));
    }
}
