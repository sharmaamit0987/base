package com.android.billingclient.api;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzy extends ResultReceiver {
    private final /* synthetic */ PriceChangeConfirmationListener zza;

    zzy(BillingClientImpl billingClientImpl, Handler handler, PriceChangeConfirmationListener priceChangeConfirmationListener) {
        this.zza = priceChangeConfirmationListener;
        super(handler);
    }

    public final void onReceiveResult(int i, Bundle bundle) {
        this.zza.onPriceChangeConfirmationResult(BillingResult.newBuilder().setResponseCode(i).setDebugMessage(zzb.zzb(bundle, "BillingClient")).build());
    }
}
