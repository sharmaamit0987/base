package com.android.billingclient.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public class ProxyBillingActivity extends Activity {
    private ResultReceiver zza;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        PendingIntent pendingIntent;
        super.onCreate(bundle);
        String str = "result_receiver";
        String str2 = "ProxyBillingActivity";
        if (bundle == null) {
            zzb.zza(str2, "Launching Play Store billing flow");
            this.zza = (ResultReceiver) getIntent().getParcelableExtra(str);
            String str3 = "BUY_INTENT";
            if (getIntent().hasExtra(str3)) {
                pendingIntent = (PendingIntent) getIntent().getParcelableExtra(str3);
            } else {
                String str4 = "SUBS_MANAGEMENT_INTENT";
                pendingIntent = getIntent().hasExtra(str4) ? (PendingIntent) getIntent().getParcelableExtra(str4) : null;
            }
            try {
                startIntentSenderForResult(pendingIntent.getIntentSender(), 100, new Intent(), 0, 0, 0);
            } catch (SendIntentException e) {
                String valueOf = String.valueOf(e);
                StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 53);
                sb.append("Got exception while trying to start a purchase flow: ");
                sb.append(valueOf);
                zzb.zzb(str2, sb.toString());
                this.zza.send(6, null);
                finish();
            }
        } else {
            zzb.zza(str2, "Launching Play Store billing flow from savedInstanceState");
            this.zza = (ResultReceiver) bundle.getParcelable(str);
        }
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putParcelable("result_receiver", this.zza);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        String str = "ProxyBillingActivity";
        if (i == 100) {
            int zza2 = zzb.zza(intent, str);
            if (!(i2 == -1 && zza2 == 0)) {
                StringBuilder sb = new StringBuilder(85);
                sb.append("Activity finished with resultCode ");
                sb.append(i2);
                sb.append(" and billing's responseCode: ");
                sb.append(zza2);
                zzb.zzb(str, sb.toString());
            }
            this.zza.send(zza2, intent == null ? null : intent.getExtras());
        } else {
            StringBuilder sb2 = new StringBuilder(69);
            sb2.append("Got onActivityResult with wrong requestCode: ");
            sb2.append(i);
            sb2.append("; skipping...");
            zzb.zzb(str, sb2.toString());
        }
        finish();
    }
}
