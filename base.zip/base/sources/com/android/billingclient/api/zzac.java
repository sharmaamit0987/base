package com.android.billingclient.api;

import com.android.billingclient.api.Purchase.PurchasesResult;
import java.util.concurrent.Callable;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzac implements Callable<PurchasesResult> {
    private final /* synthetic */ String zza;
    private final /* synthetic */ BillingClientImpl zzb;

    zzac(BillingClientImpl billingClientImpl, String str) {
        this.zzb = billingClientImpl;
        this.zza = str;
    }

    public final /* synthetic */ Object call() throws Exception {
        return this.zzb.zzc(this.zza);
    }
}
