package com.android.billingclient.api;

import java.util.ArrayList;
import java.util.List;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public class SkuDetailsParams {
    /* access modifiers changed from: private */
    public String zza;
    /* access modifiers changed from: private */
    public String zzb;
    /* access modifiers changed from: private */
    public List<String> zzc;

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    public static class Builder {
        private String zza;
        private List<String> zzb;

        private Builder() {
        }

        public Builder setSkusList(List<String> list) {
            this.zzb = new ArrayList(list);
            return this;
        }

        public Builder setType(String str) {
            this.zza = str;
            return this;
        }

        public SkuDetailsParams build() {
            if (this.zza == null) {
                throw new IllegalArgumentException("SKU type must be set");
            } else if (this.zzb != null) {
                SkuDetailsParams skuDetailsParams = new SkuDetailsParams();
                skuDetailsParams.zza = this.zza;
                skuDetailsParams.zzc = this.zzb;
                skuDetailsParams.zzb = null;
                return skuDetailsParams;
            } else {
                throw new IllegalArgumentException("SKUs list must be set");
            }
        }
    }

    public String getSkuType() {
        return this.zza;
    }

    public final String zza() {
        return this.zzb;
    }

    public List<String> getSkusList() {
        return this.zzc;
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
