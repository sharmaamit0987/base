package com.android.billingclient.api;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
final class zzi implements Runnable {
    private final /* synthetic */ SkuDetailsResponseListener zza;

    zzi(BillingClientImpl billingClientImpl, SkuDetailsResponseListener skuDetailsResponseListener) {
        this.zza = skuDetailsResponseListener;
    }

    public final void run() {
        this.zza.onSkuDetailsResponse(zzak.zzp, null);
    }
}
