package com.android.billingclient.api;

import android.text.TextUtils;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: com.android.billingclient:billing@@3.0.0 */
public class SkuDetails {
    private final String zza;
    private final JSONObject zzb = new JSONObject(this.zza);

    /* compiled from: com.android.billingclient:billing@@3.0.0 */
    static class zza {
        private final List<SkuDetails> zza;
        private final int zzb;
        private final String zzc;

        public zza(int i, String str, List<SkuDetails> list) {
            this.zzb = i;
            this.zzc = str;
            this.zza = list;
        }

        public final List<SkuDetails> zza() {
            return this.zza;
        }

        public final int zzb() {
            return this.zzb;
        }

        public final String zzc() {
            return this.zzc;
        }
    }

    public SkuDetails(String str) throws JSONException {
        this.zza = str;
        if (TextUtils.isEmpty(getSku())) {
            throw new IllegalArgumentException("SKU cannot be empty.");
        } else if (TextUtils.isEmpty(getType())) {
            throw new IllegalArgumentException("SkuType cannot be empty.");
        }
    }

    public String getOriginalJson() {
        return this.zza;
    }

    public String getSku() {
        return this.zzb.optString("productId");
    }

    public final String zza() {
        return this.zzb.optString("packageName");
    }

    public String getType() {
        return this.zzb.optString("type");
    }

    public String getPrice() {
        return this.zzb.optString("price");
    }

    public long getPriceAmountMicros() {
        return this.zzb.optLong("price_amount_micros");
    }

    public String getPriceCurrencyCode() {
        return this.zzb.optString("price_currency_code");
    }

    public String getOriginalPrice() {
        String str = "original_price";
        if (this.zzb.has(str)) {
            return this.zzb.optString(str);
        }
        return getPrice();
    }

    public long getOriginalPriceAmountMicros() {
        String str = "original_price_micros";
        if (this.zzb.has(str)) {
            return this.zzb.optLong(str);
        }
        return getPriceAmountMicros();
    }

    public String getTitle() {
        return this.zzb.optString("title");
    }

    public String getDescription() {
        return this.zzb.optString("description");
    }

    public String getSubscriptionPeriod() {
        return this.zzb.optString("subscriptionPeriod");
    }

    public String getFreeTrialPeriod() {
        return this.zzb.optString("freeTrialPeriod");
    }

    public String getIntroductoryPrice() {
        return this.zzb.optString("introductoryPrice");
    }

    public long getIntroductoryPriceAmountMicros() {
        return this.zzb.optLong("introductoryPriceAmountMicros");
    }

    public String getIntroductoryPricePeriod() {
        return this.zzb.optString("introductoryPricePeriod");
    }

    public int getIntroductoryPriceCycles() {
        return this.zzb.optInt("introductoryPriceCycles");
    }

    public String getIconUrl() {
        return this.zzb.optString("iconUrl");
    }

    /* access modifiers changed from: 0000 */
    public final String zzb() {
        return this.zzb.optString("skuDetailsToken");
    }

    public String toString() {
        String valueOf = String.valueOf(this.zza);
        String str = "SkuDetails: ";
        return valueOf.length() != 0 ? str.concat(valueOf) : new String(str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SkuDetails)) {
            return false;
        }
        return TextUtils.equals(this.zza, ((SkuDetails) obj).zza);
    }

    public int hashCode() {
        return this.zza.hashCode();
    }
}
