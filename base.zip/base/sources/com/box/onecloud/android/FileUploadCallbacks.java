package com.box.onecloud.android;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface FileUploadCallbacks extends IInterface {

    public static class Default implements FileUploadCallbacks {
        public IBinder asBinder() {
            return null;
        }

        public void onComplete() throws RemoteException {
        }

        public void onError() throws RemoteException {
        }

        public void onProgress(long j, long j2) throws RemoteException {
        }
    }

    public static abstract class Stub extends Binder implements FileUploadCallbacks {
        private static final String DESCRIPTOR = "com.box.onecloud.android.FileUploadCallbacks";
        static final int TRANSACTION_onComplete = 2;
        static final int TRANSACTION_onError = 3;
        static final int TRANSACTION_onProgress = 1;

        private static class Proxy implements FileUploadCallbacks {
            public static FileUploadCallbacks sDefaultImpl;
            private IBinder mRemote;

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public void onProgress(long j, long j2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeLong(j);
                    obtain.writeLong(j2);
                    if (this.mRemote.transact(1, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().onProgress(j, j2);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void onComplete() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(2, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().onComplete();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void onError() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(3, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().onError();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static FileUploadCallbacks asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof FileUploadCallbacks)) {
                return new Proxy(iBinder);
            }
            return (FileUploadCallbacks) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String str = DESCRIPTOR;
            if (i == 1) {
                parcel.enforceInterface(str);
                onProgress(parcel.readLong(), parcel.readLong());
                parcel2.writeNoException();
                return true;
            } else if (i == 2) {
                parcel.enforceInterface(str);
                onComplete();
                parcel2.writeNoException();
                return true;
            } else if (i == 3) {
                parcel.enforceInterface(str);
                onError();
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString(str);
                return true;
            }
        }

        public static boolean setDefaultImpl(FileUploadCallbacks fileUploadCallbacks) {
            if (Proxy.sDefaultImpl != null || fileUploadCallbacks == null) {
                return false;
            }
            Proxy.sDefaultImpl = fileUploadCallbacks;
            return true;
        }

        public static FileUploadCallbacks getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }

    void onComplete() throws RemoteException;

    void onError() throws RemoteException;

    void onProgress(long j, long j2) throws RemoteException;
}
