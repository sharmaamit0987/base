package com.box.onecloud.android;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.box.onecloud.android.OneCloudHandshakeInterface.Stub;

public class OneCloudHandshake implements Parcelable {
    public static final Creator<OneCloudHandshake> CREATOR = new Creator<OneCloudHandshake>() {
        public OneCloudHandshake createFromParcel(Parcel parcel) {
            return new OneCloudHandshake(parcel);
        }

        public OneCloudHandshake[] newArray(int i) {
            return new OneCloudHandshake[i];
        }
    };
    private OneCloudHandshakeInterface mBinder;

    public int describeContents() {
        return 0;
    }

    public OneCloudHandshake(Parcel parcel) {
        readFromParcel(parcel);
    }

    public OneCloudHandshake(OneCloudHandshakeInterface oneCloudHandshakeInterface) {
        this.mBinder = oneCloudHandshakeInterface;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.mBinder.asBinder());
    }

    private void readFromParcel(Parcel parcel) {
        this.mBinder = Stub.asInterface(parcel.readStrongBinder());
    }

    public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
        this.mBinder.sendHandshake(handshakeCallback);
    }

    public void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException {
        this.mBinder.sendOneCloudData(oneCloudInterface);
    }
}
