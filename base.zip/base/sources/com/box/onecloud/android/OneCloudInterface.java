package com.box.onecloud.android;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface OneCloudInterface extends IInterface {

    public static class Default implements OneCloudInterface {
        public IBinder asBinder() {
            return null;
        }

        public long getFileId() throws RemoteException {
            return 0;
        }

        public String getFileName() throws RemoteException {
            return null;
        }

        public long getFileSize() throws RemoteException {
            return 0;
        }

        public long getFolderId() throws RemoteException {
            return 0;
        }

        public String getFolderPath() throws RemoteException {
            return null;
        }

        public String getMimeType() throws RemoteException {
            return null;
        }

        public long getToken() throws RemoteException {
            return 0;
        }

        public String getUsername() throws RemoteException {
            return null;
        }

        public int iAvailable() throws RemoteException {
            return 0;
        }

        public void iClose() throws RemoteException {
        }

        public void iMark(int i) throws RemoteException {
        }

        public boolean iMarkSupported() throws RemoteException {
            return false;
        }

        public int iRead(byte[] bArr, int i, int i2) throws RemoteException {
            return 0;
        }

        public int iReadAll(byte[] bArr) throws RemoteException {
            return 0;
        }

        public int iReadOne() throws RemoteException {
            return 0;
        }

        public void iReset() throws RemoteException {
        }

        public long iSkip(long j) throws RemoteException {
            return 0;
        }

        public void launch() throws RemoteException {
        }

        public void notifyDataChanged() throws RemoteException {
        }

        public void oClose() throws RemoteException {
        }

        public void oFlush() throws RemoteException {
        }

        public void oWrite(byte[] bArr, int i, int i2) throws RemoteException {
        }

        public void oWriteAll(byte[] bArr) throws RemoteException {
        }

        public void oWriteOne(int i) throws RemoteException {
        }

        public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
        }

        public void uploadNewFile(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
        }

        public void uploadNewVersion(FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
        }

        public void uploadNewVersionWithNewName(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
        }
    }

    public static abstract class Stub extends Binder implements OneCloudInterface {
        private static final String DESCRIPTOR = "com.box.onecloud.android.OneCloudInterface";
        static final int TRANSACTION_getFileId = 24;
        static final int TRANSACTION_getFileName = 20;
        static final int TRANSACTION_getFileSize = 22;
        static final int TRANSACTION_getFolderId = 25;
        static final int TRANSACTION_getFolderPath = 26;
        static final int TRANSACTION_getMimeType = 21;
        static final int TRANSACTION_getToken = 23;
        static final int TRANSACTION_getUsername = 27;
        static final int TRANSACTION_iAvailable = 1;
        static final int TRANSACTION_iClose = 2;
        static final int TRANSACTION_iMark = 3;
        static final int TRANSACTION_iMarkSupported = 4;
        static final int TRANSACTION_iRead = 7;
        static final int TRANSACTION_iReadAll = 5;
        static final int TRANSACTION_iReadOne = 6;
        static final int TRANSACTION_iReset = 8;
        static final int TRANSACTION_iSkip = 9;
        static final int TRANSACTION_launch = 19;
        static final int TRANSACTION_notifyDataChanged = 28;
        static final int TRANSACTION_oClose = 10;
        static final int TRANSACTION_oFlush = 11;
        static final int TRANSACTION_oWrite = 12;
        static final int TRANSACTION_oWriteAll = 13;
        static final int TRANSACTION_oWriteOne = 14;
        static final int TRANSACTION_sendHandshake = 15;
        static final int TRANSACTION_uploadNewFile = 18;
        static final int TRANSACTION_uploadNewVersion = 16;
        static final int TRANSACTION_uploadNewVersionWithNewName = 17;

        private static class Proxy implements OneCloudInterface {
            public static OneCloudInterface sDefaultImpl;
            private IBinder mRemote;

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public int iAvailable() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(1, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iAvailable();
                    }
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    obtain2.recycle();
                    obtain.recycle();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void iClose() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(2, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().iClose();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void iMark(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeInt(i);
                    if (this.mRemote.transact(3, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().iMark(i);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public boolean iMarkSupported() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    boolean z = false;
                    if (!this.mRemote.transact(4, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iMarkSupported();
                    }
                    obtain2.readException();
                    if (obtain2.readInt() != 0) {
                        z = true;
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return z;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int iReadAll(byte[] bArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bArr == null) {
                        obtain.writeInt(-1);
                    } else {
                        obtain.writeInt(bArr.length);
                    }
                    if (!this.mRemote.transact(5, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iReadAll(bArr);
                    }
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    obtain2.readByteArray(bArr);
                    obtain2.recycle();
                    obtain.recycle();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int iReadOne() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(6, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iReadOne();
                    }
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    obtain2.recycle();
                    obtain.recycle();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int iRead(byte[] bArr, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (bArr == null) {
                        obtain.writeInt(-1);
                    } else {
                        obtain.writeInt(bArr.length);
                    }
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    if (!this.mRemote.transact(7, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iRead(bArr, i, i2);
                    }
                    obtain2.readException();
                    int readInt = obtain2.readInt();
                    obtain2.readByteArray(bArr);
                    obtain2.recycle();
                    obtain.recycle();
                    return readInt;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void iReset() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(8, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().iReset();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public long iSkip(long j) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeLong(j);
                    if (!this.mRemote.transact(9, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().iSkip(j);
                    }
                    obtain2.readException();
                    long readLong = obtain2.readLong();
                    obtain2.recycle();
                    obtain.recycle();
                    return readLong;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void oClose() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(10, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().oClose();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void oFlush() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(11, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().oFlush();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void oWrite(byte[] bArr, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeByteArray(bArr);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    if (this.mRemote.transact(12, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().oWrite(bArr, i, i2);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void oWriteAll(byte[] bArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeByteArray(bArr);
                    if (this.mRemote.transact(13, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().oWriteAll(bArr);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void oWriteOne(int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeInt(i);
                    if (this.mRemote.transact(14, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().oWriteOne(i);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeStrongBinder(handshakeCallback != null ? handshakeCallback.asBinder() : null);
                    if (this.mRemote.transact(15, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().sendHandshake(handshakeCallback);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void uploadNewVersion(FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeStrongBinder(fileUploadCallbacks != null ? fileUploadCallbacks.asBinder() : null);
                    if (this.mRemote.transact(16, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().uploadNewVersion(fileUploadCallbacks);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void uploadNewVersionWithNewName(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeString(str);
                    obtain.writeStrongBinder(fileUploadCallbacks != null ? fileUploadCallbacks.asBinder() : null);
                    if (this.mRemote.transact(17, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().uploadNewVersionWithNewName(str, fileUploadCallbacks);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void uploadNewFile(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeString(str);
                    obtain.writeStrongBinder(fileUploadCallbacks != null ? fileUploadCallbacks.asBinder() : null);
                    if (this.mRemote.transact(18, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().uploadNewFile(str, fileUploadCallbacks);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void launch() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(19, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().launch();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public String getFileName() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(20, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getFileName();
                    }
                    obtain2.readException();
                    String readString = obtain2.readString();
                    obtain2.recycle();
                    obtain.recycle();
                    return readString;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public String getMimeType() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(21, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getMimeType();
                    }
                    obtain2.readException();
                    String readString = obtain2.readString();
                    obtain2.recycle();
                    obtain.recycle();
                    return readString;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public long getFileSize() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(22, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getFileSize();
                    }
                    obtain2.readException();
                    long readLong = obtain2.readLong();
                    obtain2.recycle();
                    obtain.recycle();
                    return readLong;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public long getToken() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(23, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getToken();
                    }
                    obtain2.readException();
                    long readLong = obtain2.readLong();
                    obtain2.recycle();
                    obtain.recycle();
                    return readLong;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public long getFileId() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(24, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getFileId();
                    }
                    obtain2.readException();
                    long readLong = obtain2.readLong();
                    obtain2.recycle();
                    obtain.recycle();
                    return readLong;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public long getFolderId() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(25, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getFolderId();
                    }
                    obtain2.readException();
                    long readLong = obtain2.readLong();
                    obtain2.recycle();
                    obtain.recycle();
                    return readLong;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public String getFolderPath() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(26, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getFolderPath();
                    }
                    obtain2.readException();
                    String readString = obtain2.readString();
                    obtain2.recycle();
                    obtain.recycle();
                    return readString;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public String getUsername() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (!this.mRemote.transact(27, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        return Stub.getDefaultImpl().getUsername();
                    }
                    obtain2.readException();
                    String readString = obtain2.readString();
                    obtain2.recycle();
                    obtain.recycle();
                    return readString;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void notifyDataChanged() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(28, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().notifyDataChanged();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static OneCloudInterface asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof OneCloudInterface)) {
                return new Proxy(iBinder);
            }
            return (OneCloudInterface) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String str = DESCRIPTOR;
            if (i != 1598968902) {
                byte[] bArr = null;
                switch (i) {
                    case 1:
                        parcel.enforceInterface(str);
                        int iAvailable = iAvailable();
                        parcel2.writeNoException();
                        parcel2.writeInt(iAvailable);
                        return true;
                    case 2:
                        parcel.enforceInterface(str);
                        iClose();
                        parcel2.writeNoException();
                        return true;
                    case 3:
                        parcel.enforceInterface(str);
                        iMark(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 4:
                        parcel.enforceInterface(str);
                        boolean iMarkSupported = iMarkSupported();
                        parcel2.writeNoException();
                        parcel2.writeInt(iMarkSupported ? 1 : 0);
                        return true;
                    case 5:
                        parcel.enforceInterface(str);
                        int readInt = parcel.readInt();
                        if (readInt >= 0) {
                            bArr = new byte[readInt];
                        }
                        int iReadAll = iReadAll(bArr);
                        parcel2.writeNoException();
                        parcel2.writeInt(iReadAll);
                        parcel2.writeByteArray(bArr);
                        return true;
                    case 6:
                        parcel.enforceInterface(str);
                        int iReadOne = iReadOne();
                        parcel2.writeNoException();
                        parcel2.writeInt(iReadOne);
                        return true;
                    case 7:
                        parcel.enforceInterface(str);
                        int readInt2 = parcel.readInt();
                        if (readInt2 >= 0) {
                            bArr = new byte[readInt2];
                        }
                        int iRead = iRead(bArr, parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        parcel2.writeInt(iRead);
                        parcel2.writeByteArray(bArr);
                        return true;
                    case 8:
                        parcel.enforceInterface(str);
                        iReset();
                        parcel2.writeNoException();
                        return true;
                    case 9:
                        parcel.enforceInterface(str);
                        long iSkip = iSkip(parcel.readLong());
                        parcel2.writeNoException();
                        parcel2.writeLong(iSkip);
                        return true;
                    case 10:
                        parcel.enforceInterface(str);
                        oClose();
                        parcel2.writeNoException();
                        return true;
                    case 11:
                        parcel.enforceInterface(str);
                        oFlush();
                        parcel2.writeNoException();
                        return true;
                    case 12:
                        parcel.enforceInterface(str);
                        oWrite(parcel.createByteArray(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 13:
                        parcel.enforceInterface(str);
                        oWriteAll(parcel.createByteArray());
                        parcel2.writeNoException();
                        return true;
                    case 14:
                        parcel.enforceInterface(str);
                        oWriteOne(parcel.readInt());
                        parcel2.writeNoException();
                        return true;
                    case 15:
                        parcel.enforceInterface(str);
                        sendHandshake(com.box.onecloud.android.HandshakeCallback.Stub.asInterface(parcel.readStrongBinder()));
                        parcel2.writeNoException();
                        return true;
                    case 16:
                        parcel.enforceInterface(str);
                        uploadNewVersion(com.box.onecloud.android.FileUploadCallbacks.Stub.asInterface(parcel.readStrongBinder()));
                        parcel2.writeNoException();
                        return true;
                    case 17:
                        parcel.enforceInterface(str);
                        uploadNewVersionWithNewName(parcel.readString(), com.box.onecloud.android.FileUploadCallbacks.Stub.asInterface(parcel.readStrongBinder()));
                        parcel2.writeNoException();
                        return true;
                    case 18:
                        parcel.enforceInterface(str);
                        uploadNewFile(parcel.readString(), com.box.onecloud.android.FileUploadCallbacks.Stub.asInterface(parcel.readStrongBinder()));
                        parcel2.writeNoException();
                        return true;
                    case 19:
                        parcel.enforceInterface(str);
                        launch();
                        parcel2.writeNoException();
                        return true;
                    case 20:
                        parcel.enforceInterface(str);
                        String fileName = getFileName();
                        parcel2.writeNoException();
                        parcel2.writeString(fileName);
                        return true;
                    case 21:
                        parcel.enforceInterface(str);
                        String mimeType = getMimeType();
                        parcel2.writeNoException();
                        parcel2.writeString(mimeType);
                        return true;
                    case 22:
                        parcel.enforceInterface(str);
                        long fileSize = getFileSize();
                        parcel2.writeNoException();
                        parcel2.writeLong(fileSize);
                        return true;
                    case 23:
                        parcel.enforceInterface(str);
                        long token = getToken();
                        parcel2.writeNoException();
                        parcel2.writeLong(token);
                        return true;
                    case 24:
                        parcel.enforceInterface(str);
                        long fileId = getFileId();
                        parcel2.writeNoException();
                        parcel2.writeLong(fileId);
                        return true;
                    case 25:
                        parcel.enforceInterface(str);
                        long folderId = getFolderId();
                        parcel2.writeNoException();
                        parcel2.writeLong(folderId);
                        return true;
                    case 26:
                        parcel.enforceInterface(str);
                        String folderPath = getFolderPath();
                        parcel2.writeNoException();
                        parcel2.writeString(folderPath);
                        return true;
                    case 27:
                        parcel.enforceInterface(str);
                        String username = getUsername();
                        parcel2.writeNoException();
                        parcel2.writeString(username);
                        return true;
                    case 28:
                        parcel.enforceInterface(str);
                        notifyDataChanged();
                        parcel2.writeNoException();
                        return true;
                    default:
                        return super.onTransact(i, parcel, parcel2, i2);
                }
            } else {
                parcel2.writeString(str);
                return true;
            }
        }

        public static boolean setDefaultImpl(OneCloudInterface oneCloudInterface) {
            if (Proxy.sDefaultImpl != null || oneCloudInterface == null) {
                return false;
            }
            Proxy.sDefaultImpl = oneCloudInterface;
            return true;
        }

        public static OneCloudInterface getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }

    long getFileId() throws RemoteException;

    String getFileName() throws RemoteException;

    long getFileSize() throws RemoteException;

    long getFolderId() throws RemoteException;

    String getFolderPath() throws RemoteException;

    String getMimeType() throws RemoteException;

    long getToken() throws RemoteException;

    String getUsername() throws RemoteException;

    int iAvailable() throws RemoteException;

    void iClose() throws RemoteException;

    void iMark(int i) throws RemoteException;

    boolean iMarkSupported() throws RemoteException;

    int iRead(byte[] bArr, int i, int i2) throws RemoteException;

    int iReadAll(byte[] bArr) throws RemoteException;

    int iReadOne() throws RemoteException;

    void iReset() throws RemoteException;

    long iSkip(long j) throws RemoteException;

    void launch() throws RemoteException;

    void notifyDataChanged() throws RemoteException;

    void oClose() throws RemoteException;

    void oFlush() throws RemoteException;

    void oWrite(byte[] bArr, int i, int i2) throws RemoteException;

    void oWriteAll(byte[] bArr) throws RemoteException;

    void oWriteOne(int i) throws RemoteException;

    void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException;

    void uploadNewFile(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException;

    void uploadNewVersion(FileUploadCallbacks fileUploadCallbacks) throws RemoteException;

    void uploadNewVersionWithNewName(String str, FileUploadCallbacks fileUploadCallbacks) throws RemoteException;
}
