package com.box.onecloud.android;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface OneCloudHandshakeInterface extends IInterface {

    public static class Default implements OneCloudHandshakeInterface {
        public IBinder asBinder() {
            return null;
        }

        public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
        }

        public void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException {
        }
    }

    public static abstract class Stub extends Binder implements OneCloudHandshakeInterface {
        private static final String DESCRIPTOR = "com.box.onecloud.android.OneCloudHandshakeInterface";
        static final int TRANSACTION_sendHandshake = 1;
        static final int TRANSACTION_sendOneCloudData = 2;

        private static class Proxy implements OneCloudHandshakeInterface {
            public static OneCloudHandshakeInterface sDefaultImpl;
            private IBinder mRemote;

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeStrongBinder(handshakeCallback != null ? handshakeCallback.asBinder() : null);
                    if (this.mRemote.transact(1, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().sendHandshake(handshakeCallback);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    obtain.writeStrongBinder(oneCloudInterface != null ? oneCloudInterface.asBinder() : null);
                    if (this.mRemote.transact(2, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().sendOneCloudData(oneCloudInterface);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static OneCloudHandshakeInterface asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof OneCloudHandshakeInterface)) {
                return new Proxy(iBinder);
            }
            return (OneCloudHandshakeInterface) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String str = DESCRIPTOR;
            if (i == 1) {
                parcel.enforceInterface(str);
                sendHandshake(com.box.onecloud.android.HandshakeCallback.Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            } else if (i == 2) {
                parcel.enforceInterface(str);
                sendOneCloudData(com.box.onecloud.android.OneCloudInterface.Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString(str);
                return true;
            }
        }

        public static boolean setDefaultImpl(OneCloudHandshakeInterface oneCloudHandshakeInterface) {
            if (Proxy.sDefaultImpl != null || oneCloudHandshakeInterface == null) {
                return false;
            }
            Proxy.sDefaultImpl = oneCloudHandshakeInterface;
            return true;
        }

        public static OneCloudHandshakeInterface getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }

    void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException;

    void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException;
}
