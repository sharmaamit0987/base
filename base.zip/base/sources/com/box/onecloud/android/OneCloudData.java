package com.box.onecloud.android;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Binder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.box.onecloud.android.FileUploadCallbacks.Stub;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class OneCloudData implements Parcelable {
    public static final Creator<OneCloudData> CREATOR = new Creator<OneCloudData>() {
        public OneCloudData createFromParcel(Parcel parcel) {
            return new OneCloudData(parcel);
        }

        public OneCloudData[] newArray(int i) {
            return new OneCloudData[i];
        }
    };
    /* access modifiers changed from: private */
    public OneCloudInterface mBinder;
    private int mBoxAppVersionCode = 0;
    /* access modifiers changed from: private */
    public boolean mHandshaken = false;

    private static class CustomCountDownLatch extends CountDownLatch {
        private OneCloudData mOcd;

        public CustomCountDownLatch(int i) {
            super(i);
        }

        public void attachOneCloudData(OneCloudData oneCloudData) {
            this.mOcd = oneCloudData;
        }

        public OneCloudData getOneCloudData() {
            return this.mOcd;
        }
    }

    public interface UploadListener {
        void onComplete();

        void onError();

        void onProgress(long j, long j2);
    }

    public int describeContents() {
        return 0;
    }

    public OneCloudData(OneCloudInterface oneCloudInterface) {
        this.mBinder = oneCloudInterface;
    }

    public OneCloudData(Parcel parcel) {
        readFromParcel(parcel);
    }

    public long getToken() throws NoSuchMethodException {
        if (this.mBoxAppVersionCode < 19000) {
            StringBuilder sb = new StringBuilder();
            sb.append("Requires Box app version 1.9.0 or later. Installed Box app is at ");
            sb.append(this.mBoxAppVersionCode);
            throw new NoSuchMethodException(sb.toString());
        } else if (!isBinderValid()) {
            return -1;
        } else {
            try {
                return this.mBinder.getToken();
            } catch (RemoteException unused) {
                return -1;
            }
        }
    }

    public String getFileName() {
        if (!isBinderValid()) {
            return null;
        }
        try {
            return this.mBinder.getFileName();
        } catch (RemoteException unused) {
            return null;
        }
    }

    public long getFileSize() {
        if (!isBinderValid()) {
            return 0;
        }
        try {
            return this.mBinder.getFileSize();
        } catch (RemoteException unused) {
            return 0;
        }
    }

    public String getMimeType() {
        if (!isBinderValid()) {
            return null;
        }
        try {
            return this.mBinder.getMimeType();
        } catch (RemoteException unused) {
            return null;
        }
    }

    public long getFileId() throws NoSuchMethodException {
        if (this.mBoxAppVersionCode < 19000) {
            throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
        } else if (!isBinderValid()) {
            return -1;
        } else {
            try {
                return this.mBinder.getFileId();
            } catch (RemoteException unused) {
                return -1;
            }
        }
    }

    public long getFolderId() throws NoSuchMethodException {
        if (this.mBoxAppVersionCode < 19000) {
            throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
        } else if (!isBinderValid()) {
            return -1;
        } else {
            try {
                return this.mBinder.getFolderId();
            } catch (RemoteException unused) {
                return -1;
            }
        }
    }

    public String getFolderPath() throws NoSuchMethodException {
        if (this.mBoxAppVersionCode < 19000) {
            throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
        } else if (!isBinderValid()) {
            return null;
        } else {
            try {
                return this.mBinder.getFolderPath();
            } catch (RemoteException unused) {
                return null;
            }
        }
    }

    public String getUsername() throws NoSuchMethodException {
        if (this.mBoxAppVersionCode < 19000) {
            throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
        } else if (!isBinderValid()) {
            return null;
        } else {
            try {
                return this.mBinder.getUsername();
            } catch (RemoteException unused) {
                return null;
            }
        }
    }

    public InputStream getInputStream() {
        if (!isBinderValid()) {
            return null;
        }
        return new InputStream() {
            public int available() {
                try {
                    return OneCloudData.this.mBinder.iAvailable();
                } catch (RemoteException unused) {
                    return 0;
                }
            }

            public void close() {
                try {
                    OneCloudData.this.mBinder.iClose();
                } catch (RemoteException unused) {
                }
            }

            public void mark(int i) {
                try {
                    OneCloudData.this.mBinder.iMark(i);
                } catch (RemoteException unused) {
                }
            }

            public boolean markSupported() {
                try {
                    return OneCloudData.this.mBinder.iMarkSupported();
                } catch (RemoteException unused) {
                    return false;
                }
            }

            public int read(byte[] bArr) throws IOException {
                try {
                    return OneCloudData.this.mBinder.iReadAll(bArr);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public int read() throws IOException {
                try {
                    return OneCloudData.this.mBinder.iReadOne();
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public int read(byte[] bArr, int i, int i2) throws IOException {
                try {
                    return OneCloudData.this.mBinder.iRead(bArr, i, i2);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public synchronized void reset() {
                try {
                    OneCloudData.this.mBinder.iReset();
                } catch (RemoteException unused) {
                }
            }

            public long skip(long j) throws IOException {
                try {
                    return OneCloudData.this.mBinder.iSkip(j);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }
        };
    }

    public OutputStream getOutputStream() {
        if (!isBinderValid()) {
            return null;
        }
        return new OutputStream() {
            public void close() throws IOException {
                try {
                    OneCloudData.this.mBinder.oClose();
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public void flush() throws IOException {
                try {
                    OneCloudData.this.mBinder.oFlush();
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public void write(byte[] bArr, int i, int i2) throws IOException {
                try {
                    OneCloudData.this.mBinder.oWrite(bArr, i, i2);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public void write(byte[] bArr) throws IOException {
                try {
                    OneCloudData.this.mBinder.oWriteAll(bArr);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }

            public void write(int i) throws IOException {
                try {
                    OneCloudData.this.mBinder.oWriteOne(i);
                } catch (RemoteException unused) {
                    throw new IOException();
                }
            }
        };
    }

    public void uploadNewVersion(final UploadListener uploadListener) throws RemoteException {
        if (isBinderValid()) {
            this.mBinder.uploadNewVersion(new Stub() {
                public void onProgress(long j, long j2) throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onProgress(j, j2);
                    }
                }

                public void onComplete() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onComplete();
                    }
                }

                public void onError() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onError();
                    }
                }
            });
        }
    }

    public void uploadNewVersion(String str, final UploadListener uploadListener) throws RemoteException {
        if (isBinderValid()) {
            this.mBinder.uploadNewVersionWithNewName(str, new Stub() {
                public void onProgress(long j, long j2) throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onProgress(j, j2);
                    }
                }

                public void onComplete() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onComplete();
                    }
                }

                public void onError() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onError();
                    }
                }
            });
        }
    }

    public void uploadNewFile(String str, final UploadListener uploadListener) throws RemoteException {
        if (isBinderValid()) {
            this.mBinder.uploadNewFile(str, new Stub() {
                public void onProgress(long j, long j2) throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onProgress(j, j2);
                    }
                }

                public void onComplete() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onComplete();
                    }
                }

                public void onError() throws RemoteException {
                    UploadListener uploadListener = uploadListener;
                    if (uploadListener != null) {
                        uploadListener.onError();
                    }
                }
            });
        }
    }

    public void launch() throws RemoteException {
        if (isBinderValid()) {
            this.mBinder.launch();
        }
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.mBinder.asBinder());
        parcel.writeByte(this.mHandshaken ? (byte) 1 : 0);
        parcel.writeInt(this.mBoxAppVersionCode);
    }

    private void readFromParcel(Parcel parcel) {
        this.mBinder = OneCloudInterface.Stub.asInterface(parcel.readStrongBinder());
        boolean z = true;
        if (parcel.readByte() != 1) {
            z = false;
        }
        this.mHandshaken = z;
        this.mBoxAppVersionCode = parcel.readInt();
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    public void sendHandshake(final Context context) {
        try {
            this.mBoxAppVersionCode = context.getPackageManager().getPackageInfo(BoxOneCloudReceiver.BOX_PACKAGE_NAME, 0).versionCode;
            this.mBinder.sendHandshake(new HandshakeCallback.Stub() {
                public void onShake() throws RemoteException {
                    String[] packagesForUid = context.getPackageManager().getPackagesForUid(Binder.getCallingUid());
                    if (packagesForUid.length == 1 && packagesForUid[0].equals(BoxOneCloudReceiver.BOX_PACKAGE_NAME)) {
                        OneCloudData.this.mHandshaken = true;
                    }
                }
            });
        } catch (NameNotFoundException unused) {
        }
    }

    public void notifyDataChanged() throws RemoteException {
        if (isBinderValid()) {
            this.mBinder.notifyDataChanged();
        }
    }

    public OneCloudData createNewSibling(final Context context) throws NoSuchMethodException {
        String str = BoxOneCloudReceiver.BOX_PACKAGE_NAME;
        try {
            if (context.getPackageManager().getPackageInfo(str, 0).versionCode >= 19000) {
                Intent intent = new Intent(BoxOneCloudReceiver.ACTION_BOX_CREATE_SIBLING_ONE_CLOUD_DATA);
                intent.setComponent(new ComponentName(str, BoxOneCloudReceiver.BOX_RECEIVER_CLASS_NAME));
                intent.putExtra(BoxOneCloudReceiver.EXTRA_ONE_CLOUD_TOKEN, getToken());
                final CustomCountDownLatch customCountDownLatch = new CustomCountDownLatch(1);
                intent.putExtra(BoxOneCloudReceiver.EXTRA_ONE_CLOUD_HANDSHAKE, new OneCloudHandshake(OneCloudHandshakeInterface.Stub.asInterface(new OneCloudHandshakeInterface.Stub() {
                    public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
                        String[] packagesForUid = context.getPackageManager().getPackagesForUid(Binder.getCallingUid());
                        if (packagesForUid.length == 1 && packagesForUid[0].equals(BoxOneCloudReceiver.BOX_PACKAGE_NAME)) {
                            handshakeCallback.onShake();
                        }
                    }

                    public void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException {
                        OneCloudData oneCloudData = new OneCloudData(oneCloudInterface);
                        oneCloudData.sendHandshake(context);
                        customCountDownLatch.attachOneCloudData(oneCloudData);
                        customCountDownLatch.countDown();
                    }
                }.asBinder())));
                context.sendBroadcast(intent);
                try {
                    customCountDownLatch.await(3, TimeUnit.SECONDS);
                    return customCountDownLatch.getOneCloudData();
                } catch (InterruptedException unused) {
                    return null;
                }
            } else {
                throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
            }
        } catch (NameNotFoundException unused2) {
            return null;
        }
    }

    private boolean isBinderValid() {
        if (this.mHandshaken) {
            OneCloudInterface oneCloudInterface = this.mBinder;
            if (oneCloudInterface != null && oneCloudInterface.asBinder().isBinderAlive()) {
                return true;
            }
        }
        return false;
    }

    public static OneCloudData restoreFromToken(final Context context, long j) throws NoSuchMethodException {
        String str = BoxOneCloudReceiver.BOX_PACKAGE_NAME;
        try {
            if (context.getPackageManager().getPackageInfo(str, 0).versionCode >= 19000) {
                Intent intent = new Intent(BoxOneCloudReceiver.ACTION_BOX_RESTORE_ONE_CLOUD_DATA);
                intent.setComponent(new ComponentName(str, BoxOneCloudReceiver.BOX_RECEIVER_CLASS_NAME));
                intent.putExtra(BoxOneCloudReceiver.EXTRA_ONE_CLOUD_TOKEN, j);
                final CustomCountDownLatch customCountDownLatch = new CustomCountDownLatch(1);
                intent.putExtra(BoxOneCloudReceiver.EXTRA_ONE_CLOUD_HANDSHAKE, new OneCloudHandshake(OneCloudHandshakeInterface.Stub.asInterface(new OneCloudHandshakeInterface.Stub() {
                    public void sendHandshake(HandshakeCallback handshakeCallback) throws RemoteException {
                        String[] packagesForUid = context.getPackageManager().getPackagesForUid(Binder.getCallingUid());
                        if (packagesForUid.length == 1 && packagesForUid[0].equals(BoxOneCloudReceiver.BOX_PACKAGE_NAME)) {
                            handshakeCallback.onShake();
                        }
                    }

                    public void sendOneCloudData(OneCloudInterface oneCloudInterface) throws RemoteException {
                        OneCloudData oneCloudData = new OneCloudData(oneCloudInterface);
                        oneCloudData.sendHandshake(context);
                        customCountDownLatch.attachOneCloudData(oneCloudData);
                        customCountDownLatch.countDown();
                    }
                }.asBinder())));
                context.sendBroadcast(intent);
                try {
                    customCountDownLatch.await(3, TimeUnit.SECONDS);
                    return customCountDownLatch.getOneCloudData();
                } catch (InterruptedException unused) {
                    return null;
                }
            } else {
                throw new NoSuchMethodException("Requires Box app version 1.9.0 or later.");
            }
        } catch (NameNotFoundException unused2) {
            return null;
        }
    }
}
