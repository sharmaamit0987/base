package com.box.onecloud.android;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface HandshakeCallback extends IInterface {

    public static class Default implements HandshakeCallback {
        public IBinder asBinder() {
            return null;
        }

        public void onShake() throws RemoteException {
        }
    }

    public static abstract class Stub extends Binder implements HandshakeCallback {
        private static final String DESCRIPTOR = "com.box.onecloud.android.HandshakeCallback";
        static final int TRANSACTION_onShake = 1;

        private static class Proxy implements HandshakeCallback {
            public static HandshakeCallback sDefaultImpl;
            private IBinder mRemote;

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public void onShake() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (this.mRemote.transact(1, obtain, obtain2, 0) || Stub.getDefaultImpl() == null) {
                        obtain2.readException();
                        obtain2.recycle();
                        obtain.recycle();
                        return;
                    }
                    Stub.getDefaultImpl().onShake();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static HandshakeCallback asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(DESCRIPTOR);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof HandshakeCallback)) {
                return new Proxy(iBinder);
            }
            return (HandshakeCallback) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            String str = DESCRIPTOR;
            if (i == 1) {
                parcel.enforceInterface(str);
                onShake();
                parcel2.writeNoException();
                return true;
            } else if (i != 1598968902) {
                return super.onTransact(i, parcel, parcel2, i2);
            } else {
                parcel2.writeString(str);
                return true;
            }
        }

        public static boolean setDefaultImpl(HandshakeCallback handshakeCallback) {
            if (Proxy.sDefaultImpl != null || handshakeCallback == null) {
                return false;
            }
            Proxy.sDefaultImpl = handshakeCallback;
            return true;
        }

        public static HandshakeCallback getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
    }

    void onShake() throws RemoteException;
}
