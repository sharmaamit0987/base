package com.box.onecloud.android;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public abstract class BoxOneCloudReceiver extends BroadcastReceiver {
    public static final String ACTION_BOX_CREATE_FILE = "com.box.android.CREATE_FILE";
    public static final String ACTION_BOX_CREATE_SIBLING_ONE_CLOUD_DATA = "com.box.android.CREATE_SIBLING_ONE_CLOUD_DATA";
    public static final String ACTION_BOX_EDIT_FILE = "com.box.android.EDIT_FILE";
    public static final String ACTION_BOX_INSTALL_REFERRED = "com.box.android.INSTALL_REFERRER";
    public static final String ACTION_BOX_LAUNCH = "com.box.android.LAUNCH";
    public static final String ACTION_BOX_RESTORE_ONE_CLOUD_DATA = "com.box.android.RESTORE_ONE_CLOUD_DATA";
    public static final String ACTION_BOX_VIEW_FILE = "com.box.android.VIEW_FILE";
    public static final String BOX_PACKAGE_NAME = "com.box.android";
    public static final String BOX_RECEIVER_CLASS_NAME = "com.box.android.onecloud.OneCloudReceiver";
    public static final String EXTRA_ONE_CLOUD = "com.box.android.ONE_CLOUD";
    public static final String EXTRA_ONE_CLOUD_HANDSHAKE = "com.box.android.ONE_CLOUD_HANDSHAKE";
    public static final String EXTRA_ONE_CLOUD_TOKEN = "com.box.android.ONE_CLOUD_TOKEN";
    public static final String EXTRA_PACKAGE_NAME = "com.box.android.PACKAGE_NAME";
    public static final String EXTRA_REFERRER = "com.box.android.REFERRER";

    public abstract void onCreateFileRequested(Context context, OneCloudData oneCloudData);

    public abstract void onEditFileRequested(Context context, OneCloudData oneCloudData);

    public abstract void onLaunchRequested(Context context, OneCloudData oneCloudData);

    public abstract void onViewFileRequested(Context context, OneCloudData oneCloudData);

    public void onReceive(Context context, Intent intent) {
        OneCloudData oneCloudData;
        String str = EXTRA_ONE_CLOUD;
        if (intent.getParcelableExtra(str) != null) {
            oneCloudData = (OneCloudData) intent.getParcelableExtra(str);
            oneCloudData.sendHandshake(context);
        } else {
            oneCloudData = null;
        }
        if (intent.getAction().equals(ACTION_BOX_EDIT_FILE)) {
            onEditFileRequested(context, oneCloudData);
        } else if (intent.getAction().equals(ACTION_BOX_CREATE_FILE)) {
            onCreateFileRequested(context, oneCloudData);
        } else if (intent.getAction().equals(ACTION_BOX_VIEW_FILE)) {
            onViewFileRequested(context, oneCloudData);
        } else if (intent.getAction().equals(ACTION_BOX_LAUNCH)) {
            onLaunchRequested(context, oneCloudData);
        } else if (intent.getAction().equals("com.android.vending.INSTALL_REFERRER")) {
            String stringExtra = intent.getStringExtra("referrer");
            if (stringExtra != null && stringExtra.toLowerCase().contains("box")) {
                Intent intent2 = new Intent(ACTION_BOX_INSTALL_REFERRED);
                intent2.setComponent(new ComponentName(BOX_PACKAGE_NAME, BOX_RECEIVER_CLASS_NAME));
                intent2.putExtra(EXTRA_REFERRER, stringExtra);
                intent2.putExtra(EXTRA_PACKAGE_NAME, context.getPackageName());
                context.sendBroadcast(intent2);
            }
        }
    }
}
