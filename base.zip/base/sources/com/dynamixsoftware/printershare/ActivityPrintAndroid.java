package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.print.PrintJobInfo;
import java.io.File;

public class ActivityPrintAndroid extends ActivityPrintPDF {
    private PrintJobInfo job_info;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            String stringExtra = getIntent().getStringExtra("temp_file");
            if (stringExtra != null && !new File(stringExtra).exists()) {
                Intent intent = new Intent();
                intent.setClass(this, ActivityMain.class);
                startActivity(intent);
                finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }

    /* access modifiers changed from: protected */
    public void initPrinterParams() {
        try {
            Intent intent = getIntent();
            if (intent != null) {
                Bundle extras = intent.getExtras();
                if (extras != null) {
                    PrintJobInfo printJobInfo = (PrintJobInfo) extras.getParcelable("job_info");
                    this.job_info = printJobInfo;
                    if (printJobInfo != null) {
                        Editor edit = this.prefs.edit();
                        StringBuilder sb = new StringBuilder();
                        sb.append(getActivityClassName());
                        sb.append("#paper");
                        edit.putString(sb.toString(), this.job_info.getAttributes().getMediaSize().getId());
                        edit.commit();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        super.initPrinterParams();
    }
}
