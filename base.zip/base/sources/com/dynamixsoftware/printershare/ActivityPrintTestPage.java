package com.dynamixsoftware.printershare;

import android.view.ContextMenu;
import android.view.View;
import java.util.Vector;

public class ActivityPrintTestPage extends ActivityPrint {
    public void onCreateOptionsMenu(ContextMenu contextMenu) {
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        this.pages = new Vector();
        this.pages.add(prepareTestPage());
    }

    /* access modifiers changed from: protected */
    public void update() {
        super.update();
        View findViewById = findViewById(R.id.upgrade_banner);
        if (findViewById != null) {
            findViewById.setVisibility(8);
        }
    }
}
