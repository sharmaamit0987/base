package com.dynamixsoftware.printershare;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Picture;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.FileUtils;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy.Builder;
import android.os.SystemProperties;
import android.provider.CallLog.Calls;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import android.text.format.Time;
import com.android.okhttp.Dns;
import com.android.okhttp.HttpUrl;
import com.android.okhttp.OkHttpClient;
import com.android.okhttp.internal.Internal;
import com.android.okhttp.internal.InternalCache;
import com.android.okhttp.internal.InternalProxy1;
import com.android.okhttp.internal.InternalProxy2;
import com.dynamixsoftware.UEH;
import com.dynamixsoftware.printershare.bt.BTAdapter;
import com.dynamixsoftware.printershare.data.SoapService;
import com.flurry.android.Constants;
import com.flurry.android.FlurryAgent;
import com.flurry.android.FlurryConfig;
import com.flurry.android.FlurryConfigListener;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.channels.IllegalBlockingModeException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class App extends Application {
    public static final String[] DOWNLOAD_PATH_PREFIXES = {"http://download.printershare.com/files/android/libpacks/", "http://www.dynamixsoftware.com/android/libpacks/"};
    public static Vector<InetAddress> bal_cache_dat;
    public static long bal_cache_ts;
    public static String ext_storage_root;
    public static boolean has_feature_bluetooth;
    public static boolean has_feature_call_log;
    public static boolean has_feature_gls;
    public static boolean has_feature_messages;
    public static boolean has_feature_usb;
    public static boolean is_dev;
    private static final String[] mfg_map = {"Hewlett Packard", "HP", "Hewlett-Packard", "HP", "Lexmark International", "Lexmark", "OKI DATA CORP", "OKI", "Xerox Corporation", "XEROX", "FUJI XEROX", "XEROX", "TOSHIBA TEC", "TOSHIBA", "Samsung Electronics Co., Ltd.", "Samsung", "SAMSUNG ELECTRONICS CO., LTD", "Samsung", "Samsun\u0000xfffd", "Samsung", "Eastman Kodak Company", "KODAK", "Canon Inc", "Canon", "Canon Inc.", "Canon", "Canon,Inc.", "Canon", "Canon .", "Canon", "Zebra Technologies", "Zebra", "Prolific Technology Inc.", "Prolific", "SEIKO EPSON", "EPSON", "KONICA MINOLTA BUSINESS TECHNOLOGIES,INC.", "KONICA MINOLTA", "KONICAMINOLTA", "KONICA MINOLTA"};
    public static SoapService psService;
    private static WeakReference<Context> s24HourLastContext;
    private static boolean sCached24HourMode;
    protected static App self;

    static class MyHostnameVerifier implements HostnameVerifier {
        MyHostnameVerifier() {
        }

        public boolean verify(String str, SSLSession sSLSession) {
            if (str != null) {
                if ("".equals(App.fixEncoding("test"))) {
                    return false;
                }
            }
            return true;
        }
    }

    static final class MyTrustManager implements X509TrustManager {
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }

        MyTrustManager() {
        }

        public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
            if (x509CertificateArr != null) {
                if ("".equals(App.fixEncoding("test"))) {
                    throw new CertificateException("Not Trusted");
                }
            }
        }

        public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
            if (x509CertificateArr != null) {
                if ("".equals(App.fixEncoding("test"))) {
                    throw new CertificateException("Not Trusted");
                }
            }
        }
    }

    public static final class NetworkInterfaceData {
        public final NetworkInterface iface;
        public final Vector<InetAddress> ipv4_addresses;
        public final Vector<InetAddress> ipv4_broadcasts;
        public final InetAddress ipv6_linklocal_address;
        public final boolean is_multicast;

        private NetworkInterfaceData(NetworkInterface networkInterface, boolean z, Vector<InetAddress> vector, Vector<InetAddress> vector2, InetAddress inetAddress) {
            this.iface = networkInterface;
            this.is_multicast = z;
            if (vector == null || vector.size() <= 0) {
                vector = null;
            }
            this.ipv4_addresses = vector;
            if (vector2 == null || vector2.size() <= 0) {
                vector2 = null;
            }
            this.ipv4_broadcasts = vector2;
            this.ipv6_linklocal_address = inetAddress;
        }

        private NetworkInterfaceData(NetworkInterface networkInterface, boolean z, InetAddress inetAddress, InetAddress inetAddress2) {
            this.iface = networkInterface;
            this.is_multicast = z;
            Vector<InetAddress> vector = new Vector<>();
            this.ipv4_addresses = vector;
            vector.add(inetAddress);
            if (inetAddress2 != null) {
                Vector<InetAddress> vector2 = new Vector<>();
                this.ipv4_broadcasts = vector2;
                vector2.add(inetAddress2);
            } else {
                this.ipv4_broadcasts = null;
            }
            this.ipv6_linklocal_address = null;
        }

        private NetworkInterfaceData(String str, String str2, boolean z, InetAddress inetAddress, InetAddress inetAddress2) {
            NetworkInterface networkInterface;
            InetAddress inetAddress3 = inetAddress;
            InetAddress inetAddress4 = inetAddress2;
            if (str2 != null) {
                try {
                    int parseInt = Integer.parseInt(str2);
                    Constructor[] declaredConstructors = NetworkInterface.class.getDeclaredConstructors();
                    int i = 0;
                    while (true) {
                        if (i >= declaredConstructors.length) {
                            break;
                        }
                        Class[] parameterTypes = declaredConstructors[i].getParameterTypes();
                        if (parameterTypes.length != 4 || !Integer.TYPE.equals(parameterTypes[1])) {
                            if (parameterTypes.length == 4 && Integer.TYPE.equals(parameterTypes[3])) {
                                declaredConstructors[i].setAccessible(true);
                                networkInterface = (NetworkInterface) declaredConstructors[i].newInstance(new Object[]{str, str, new InetAddress[]{inetAddress3}, Integer.valueOf(parseInt)});
                                break;
                            }
                            i++;
                        } else {
                            declaredConstructors[i].setAccessible(true);
                            ArrayList arrayList = new ArrayList();
                            arrayList.add(inetAddress3);
                            networkInterface = (NetworkInterface) declaredConstructors[i].newInstance(new Object[]{str, Integer.valueOf(parseInt), arrayList, null});
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            networkInterface = null;
            this.iface = networkInterface;
            this.is_multicast = z;
            Vector<InetAddress> vector = new Vector<>();
            this.ipv4_addresses = vector;
            vector.add(inetAddress3);
            if (inetAddress4 != null) {
                Vector<InetAddress> vector2 = new Vector<>();
                this.ipv4_broadcasts = vector2;
                vector2.add(inetAddress4);
            } else {
                this.ipv4_broadcasts = null;
            }
            this.ipv6_linklocal_address = null;
        }

        static final NetworkInterfaceData getIfActive(String str, String str2) {
            return getIfActiveFromIfconfig(str, str2, null);
        }

        /* JADX WARNING: Removed duplicated region for block: B:11:0x001f A[SYNTHETIC, Splitter:B:11:0x001f] */
        static final NetworkInterfaceData getIfActive(final NetworkInterface networkInterface) {
            boolean z;
            try {
                if (VERSION.class.getField("SDK_INT").getInt(null) >= 9) {
                    z = true;
                    if (z) {
                        try {
                            final NetworkInterfaceData[] networkInterfaceDataArr = new NetworkInterfaceData[1];
                            new Object() {
                                /* JADX WARNING: Removed duplicated region for block: B:59:0x011f  */
                                /* JADX WARNING: Removed duplicated region for block: B:68:0x0120 A[SYNTHETIC] */
                                {
                                    boolean z;
                                    List interfaceAddresses = networkInterface.getInterfaceAddresses();
                                    if (interfaceAddresses != null && interfaceAddresses.size() > 0 && networkInterface.isUp() && !networkInterface.isLoopback()) {
                                        Vector vector = new Vector();
                                        Vector vector2 = new Vector();
                                        InetAddress inetAddress = null;
                                        InetAddress inetAddress2 = null;
                                        int i = 0;
                                        while (i < interfaceAddresses.size()) {
                                            InterfaceAddress interfaceAddress = (InterfaceAddress) interfaceAddresses.get(i);
                                            InetAddress address = interfaceAddress != null ? interfaceAddress.getAddress() : inetAddress;
                                            if (address != null) {
                                                if (address.getAddress().length == 4) {
                                                    vector.add(address);
                                                    InetAddress broadcast = interfaceAddress.getBroadcast();
                                                    if (broadcast != null && !address.equals(broadcast)) {
                                                        vector2.add(broadcast);
                                                    }
                                                } else if (address.isLinkLocalAddress()) {
                                                    try {
                                                        if (VERSION.class.getField("SDK_INT").getInt(inetAddress) < 28) {
                                                            String name = networkInterface.getName();
                                                            byte[] address2 = address.getAddress();
                                                            String str = "";
                                                            int i2 = 0;
                                                            while (true) {
                                                                z = true;
                                                                if (i2 >= address2.length) {
                                                                    break;
                                                                }
                                                                StringBuilder sb = new StringBuilder();
                                                                sb.append(str);
                                                                sb.append(Integer.toHexString((address2[i2] & Constants.UNKNOWN) + 256).substring(1));
                                                                str = sb.toString();
                                                                i2++;
                                                            }
                                                            File file = new File("/proc/net/if_inet6");
                                                            if (file.exists() && file.canRead()) {
                                                                DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                                                                while (true) {
                                                                    String readLine = dataInputStream.readLine();
                                                                    if (readLine == null) {
                                                                        z = false;
                                                                        break;
                                                                    }
                                                                    String trim = readLine.trim();
                                                                    if (trim.startsWith(str) && trim.endsWith(name)) {
                                                                        String[] split = trim.substring(0, trim.lastIndexOf(name)).trim().split(" ");
                                                                        if (split.length != 5 || (Integer.parseInt(split[4], 16) & 64) == 0) {
                                                                        }
                                                                    }
                                                                }
                                                                try {
                                                                    dataInputStream.close();
                                                                } catch (Exception e) {
                                                                    e = e;
                                                                }
                                                                if (!z) {
                                                                    inetAddress2 = address;
                                                                }
                                                            }
                                                        }
                                                        z = false;
                                                    } catch (Exception e2) {
                                                        e = e2;
                                                        z = false;
                                                        e.printStackTrace();
                                                        App.reportThrowable(e);
                                                        if (!z) {
                                                        }
                                                        i++;
                                                        inetAddress = null;
                                                    }
                                                    if (!z) {
                                                    }
                                                }
                                            }
                                            i++;
                                            inetAddress = null;
                                        }
                                        NetworkInterfaceData[] networkInterfaceDataArr = networkInterfaceDataArr;
                                        NetworkInterface networkInterface = networkInterface;
                                        NetworkInterfaceData networkInterfaceData = new NetworkInterfaceData(networkInterface, networkInterface.supportsMulticast(), vector, vector2, inetAddress2);
                                        networkInterfaceDataArr[0] = networkInterfaceData;
                                    }
                                }
                            };
                            return networkInterfaceDataArr[0];
                        } catch (Throwable th) {
                            th.printStackTrace();
                            App.reportThrowable(th);
                        }
                    }
                    return getIfActiveFromIfconfig(networkInterface.getName(), null, networkInterface);
                }
            } catch (NoSuchFieldException unused) {
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            z = false;
            if (z) {
            }
            return getIfActiveFromIfconfig(networkInterface.getName(), null, networkInterface);
        }

        private static final NetworkInterfaceData getIfActiveFromIfconfig(String str, String str2, NetworkInterface networkInterface) {
            InetAddress inetAddress;
            InetAddress inetAddress2;
            String str3 = "/system/bin/ifconfig";
            if (new File(str3).exists()) {
                try {
                    boolean z = false;
                    Process exec = Runtime.getRuntime().exec(new String[]{str3, str});
                    String str4 = "";
                    DataInputStream dataInputStream = new DataInputStream(exec.getInputStream());
                    while (true) {
                        String readLine = dataInputStream.readLine();
                        if (readLine == null) {
                            break;
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append(str4);
                        sb.append(readLine);
                        sb.append("\n");
                        str4 = sb.toString();
                    }
                    dataInputStream.close();
                    if (exec.waitFor() != 0) {
                        return null;
                    }
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(str);
                    sb2.append(":");
                    if (str4.startsWith(sb2.toString())) {
                        String lowerCase = str4.toLowerCase();
                        int indexOf = lowerCase.indexOf(" ip ", lowerCase.indexOf(": ") + 1);
                        int i = indexOf + 1;
                        int indexOf2 = lowerCase.indexOf(" mask ", i);
                        int indexOf3 = lowerCase.indexOf(" flags [", i);
                        int indexOf4 = lowerCase.indexOf("]", indexOf3 + 1);
                        InetAddress byName = InetAddress.getByName(lowerCase.substring(indexOf + 4, indexOf2 < 0 ? indexOf3 : indexOf2).trim());
                        if (indexOf2 < 0) {
                            inetAddress = null;
                        } else {
                            inetAddress = InetAddress.getByName(lowerCase.substring(indexOf2 + 6, indexOf3).trim());
                        }
                        String substring = lowerCase.substring(indexOf3 + 8, indexOf4);
                        if (substring.indexOf("up") < 0 || substring.indexOf("running") < 0 || substring.indexOf("loopback") >= 0) {
                            return null;
                        }
                        if (substring.indexOf("broadcast") >= 0) {
                            byte[] address = byName.getAddress();
                            byte[] address2 = inetAddress.getAddress();
                            inetAddress2 = InetAddress.getByAddress(new byte[]{(byte) ((~address2[0]) | address[0]), (byte) ((~address2[1]) | address[1]), (byte) ((~address2[2]) | address[2]), (byte) ((~address2[3]) | address[3])});
                        } else {
                            inetAddress2 = null;
                        }
                        String str5 = "multicast";
                        if (networkInterface != null) {
                            if (substring.indexOf(str5) >= 0) {
                                z = true;
                            }
                            return new NetworkInterfaceData(networkInterface, z, byName, inetAddress2);
                        }
                        NetworkInterfaceData networkInterfaceData = new NetworkInterfaceData(str, str2, substring.indexOf(str5) >= 0, byName, inetAddress2);
                        return networkInterfaceData;
                    }
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Unexpected ifconfig output:\n");
                    sb3.append(str4);
                    throw new Exception(sb3.toString());
                } catch (Throwable th) {
                    th.printStackTrace();
                    App.reportThrowable(th);
                }
            }
            return null;
        }
    }

    public static class PCanvas extends Canvas {
        boolean aa;

        public PCanvas(Bitmap bitmap) {
            this(bitmap, false);
        }

        public PCanvas(Bitmap bitmap, boolean z) {
            super(bitmap);
            this.aa = z;
        }

        public void drawPicture(Picture picture) {
            if (picture instanceof XPicture) {
                ((XPicture) picture).draw(this, this.aa);
            } else {
                picture.draw(this);
            }
        }
    }

    public static abstract class XPicture extends Picture {
        public abstract void draw(Canvas canvas, boolean z);

        public void draw(Canvas canvas) {
            draw(canvas, true);
        }
    }

    /* access modifiers changed from: protected */
    public void onPrinterChanged() {
    }

    public void onCreate() {
        Class cls;
        String str = "SDK_INT";
        super.onCreate();
        self = this;
        is_dev = getVersion().endsWith(" dev");
        initUEH();
        initFlurry();
        try {
            cls = Class.forName("dalvik.system.VMRuntime");
        } catch (ClassNotFoundException unused) {
            cls = null;
        }
        if (cls != null) {
            try {
                Object invoke = cls.getMethod("getRuntime", new Class[0]).invoke(null, new Object[0]);
                cls.getMethod("setMinimumHeapSize", new Class[]{Long.TYPE}).invoke(invoke, new Object[]{Integer.valueOf(4194304)});
            } catch (Exception e) {
                e.printStackTrace();
                reportThrowable(e);
            }
        }
        try {
            if (VERSION.class.getField(str).getInt(null) > 24) {
                new Object() {
                    {
                        StrictMode.setVmPolicy(new Builder().build());
                    }
                };
            }
        } catch (NoSuchFieldException unused2) {
        } catch (Exception e2) {
            e2.printStackTrace();
            UEH.reportThrowable(e2);
        }
        try {
            int i = VERSION.class.getField(str).getInt(null);
            if (i == 24 || i == 25) {
                new Object() {
                    {
                        boolean z = false;
                        try {
                            Method[] declaredMethods = Internal.class.getDeclaredMethods();
                            for (int i = 0; i < declaredMethods.length; i++) {
                                if (declaredMethods[i].toString().startsWith("public abstract")) {
                                    InternalProxy1.class.getDeclaredMethod(declaredMethods[i].getName(), declaredMethods[i].getParameterTypes());
                                }
                            }
                            z = true;
                        } catch (Throwable th) {
                            th.printStackTrace();
                            UEH.reportThrowable(th);
                        }
                        if (z) {
                            Class.forName("com.android.okhttp.OkHttpClient");
                            Internal.instance = new InternalProxy1(Internal.instance) {
                                public HttpUrl getHttpUrlChecked(String str) throws MalformedURLException, UnknownHostException {
                                    String str2;
                                    int indexOf = str.indexOf("://[");
                                    int indexOf2 = str.indexOf("]", indexOf + 1);
                                    if (indexOf <= 0 || indexOf2 <= indexOf) {
                                        str2 = null;
                                    } else {
                                        int i = indexOf + 4;
                                        str2 = str.substring(i, indexOf2);
                                        int indexOf3 = str.indexOf("%", i);
                                        if (indexOf3 > 0) {
                                            StringBuilder sb = new StringBuilder();
                                            sb.append(str.substring(0, indexOf3));
                                            sb.append(str.substring(indexOf2));
                                            str = sb.toString();
                                        }
                                    }
                                    HttpUrl parse = HttpUrl.parse(str);
                                    if (parse == null) {
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append("Invalid URL: ");
                                        sb2.append(str);
                                        new MalformedURLException(sb2.toString());
                                    }
                                    if (str2 == null) {
                                        return parse;
                                    }
                                    try {
                                        HttpUrl.Builder newBuilder = parse.newBuilder();
                                        Field declaredField = newBuilder.getClass().getDeclaredField("host");
                                        declaredField.setAccessible(true);
                                        declaredField.set(newBuilder, str2);
                                        return newBuilder.build();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                        return parse;
                                    }
                                }
                            };
                        }
                    }
                };
            }
            if (i == 26 || i == 27) {
                new Object() {
                    {
                        boolean z = false;
                        try {
                            Method[] declaredMethods = Internal.class.getDeclaredMethods();
                            for (int i = 0; i < declaredMethods.length; i++) {
                                if (declaredMethods[i].toString().startsWith("public abstract")) {
                                    InternalProxy2.class.getDeclaredMethod(declaredMethods[i].getName(), declaredMethods[i].getParameterTypes());
                                }
                            }
                            z = true;
                        } catch (Throwable th) {
                            th.printStackTrace();
                            UEH.reportThrowable(th);
                        }
                        if (z) {
                            Class.forName("com.android.okhttp.OkHttpClient");
                            Internal.instance = new InternalProxy2(Internal.instance) {
                                /* access modifiers changed from: private */
                                public final Hashtable<String, String> ipv6_map = new Hashtable<>();

                                public HttpUrl getHttpUrlChecked(String str) throws MalformedURLException, UnknownHostException {
                                    String str2;
                                    int indexOf = str.indexOf("://[");
                                    int indexOf2 = str.indexOf("]", indexOf + 1);
                                    String str3 = "%";
                                    if (indexOf <= 0 || indexOf2 <= indexOf) {
                                        str2 = null;
                                    } else {
                                        int i = indexOf + 4;
                                        str2 = str.substring(i, indexOf2);
                                        int indexOf3 = str.indexOf(str3, i);
                                        if (indexOf3 > 0) {
                                            StringBuilder sb = new StringBuilder();
                                            sb.append(str.substring(0, indexOf3));
                                            sb.append(str.substring(indexOf2));
                                            str = sb.toString();
                                        }
                                    }
                                    if (str2 != null) {
                                        int indexOf4 = str2.indexOf(str3);
                                        if (indexOf4 > 0) {
                                            this.ipv6_map.put(str2.substring(0, indexOf4), str2);
                                        }
                                    }
                                    return super.getHttpUrlChecked(str);
                                }

                                public InternalCache internalCache(OkHttpClient okHttpClient) {
                                    try {
                                        Method declaredMethod = okHttpClient.getClass().getDeclaredMethod("getSocketFactory", new Class[0]);
                                        declaredMethod.setAccessible(true);
                                        final SocketFactory socketFactory = (SocketFactory) declaredMethod.invoke(okHttpClient, new Object[0]);
                                        if (socketFactory.getClass().getPackage().getName().indexOf(BuildConfig.FLAVOR_base) < 0) {
                                            AnonymousClass1 r3 = new SocketFactory() {
                                                /* access modifiers changed from: private */
                                                public SocketAddress fixAddress(SocketAddress socketAddress) throws UnknownHostException {
                                                    InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddress;
                                                    if (inetSocketAddress.getAddress().getAddress().length <= 4) {
                                                        return socketAddress;
                                                    }
                                                    String str = (String) AnonymousClass1.this.ipv6_map.get(inetSocketAddress.getAddress().getHostAddress());
                                                    return new InetSocketAddress(str != null ? InetAddress.getByName(str) : inetSocketAddress.getAddress(), inetSocketAddress.getPort());
                                                }

                                                public Socket createSocket() throws IOException {
                                                    return new Socket() {
                                                        public void connect(SocketAddress socketAddress) throws IOException, IllegalBlockingModeException, IllegalArgumentException {
                                                            super.connect(AnonymousClass1.this.fixAddress(socketAddress));
                                                        }

                                                        public void connect(SocketAddress socketAddress, int i) throws IOException, SocketTimeoutException, IllegalBlockingModeException, IllegalArgumentException {
                                                            super.connect(AnonymousClass1.this.fixAddress(socketAddress), i);
                                                        }
                                                    };
                                                }

                                                public Socket createSocket(String str, int i) throws IOException, UnknownHostException {
                                                    return socketFactory.createSocket(str, i);
                                                }

                                                public Socket createSocket(String str, int i, InetAddress inetAddress, int i2) throws IOException, UnknownHostException {
                                                    return socketFactory.createSocket(str, i, inetAddress, i2);
                                                }

                                                public Socket createSocket(InetAddress inetAddress, int i) throws IOException {
                                                    return socketFactory.createSocket(inetAddress, i);
                                                }

                                                public Socket createSocket(InetAddress inetAddress, int i, InetAddress inetAddress2, int i2) throws IOException {
                                                    return socketFactory.createSocket(inetAddress, i, inetAddress2, i2);
                                                }
                                            };
                                            Method declaredMethod2 = okHttpClient.getClass().getDeclaredMethod("setSocketFactory", new Class[]{SocketFactory.class});
                                            declaredMethod2.setAccessible(true);
                                            declaredMethod2.invoke(okHttpClient, new Object[]{r3});
                                        }
                                    } catch (NoSuchMethodException unused) {
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                    return super.internalCache(okHttpClient);
                                }
                            };
                        }
                    }
                };
            }
            if (i == 28 || i == 29) {
                new Object() {
                    {
                        boolean z = false;
                        try {
                            Method[] declaredMethods = Internal.class.getDeclaredMethods();
                            for (int i = 0; i < declaredMethods.length; i++) {
                                if (declaredMethods[i].toString().startsWith("public abstract")) {
                                    InternalProxy2.class.getDeclaredMethod(declaredMethods[i].getName(), declaredMethods[i].getParameterTypes());
                                }
                            }
                            z = true;
                        } catch (Throwable th) {
                            th.printStackTrace();
                            App.reportThrowable(th);
                        }
                        if (z) {
                            Class.forName("com.android.okhttp.OkHttpClient");
                            Internal.instance = new InternalProxy2(Internal.instance) {
                                /* access modifiers changed from: private */
                                public final Hashtable<String, String> ipv6_map = new Hashtable<>();

                                public HttpUrl getHttpUrlChecked(String str) throws MalformedURLException, UnknownHostException {
                                    String str2;
                                    int indexOf = str.indexOf("://[");
                                    int indexOf2 = str.indexOf("]", indexOf + 1);
                                    String str3 = "%";
                                    if (indexOf <= 0 || indexOf2 <= indexOf) {
                                        str2 = null;
                                    } else {
                                        int i = indexOf + 4;
                                        str2 = str.substring(i, indexOf2);
                                        int indexOf3 = str.indexOf(str3, i);
                                        if (indexOf3 > 0) {
                                            StringBuilder sb = new StringBuilder();
                                            sb.append(str.substring(0, indexOf3));
                                            sb.append(str.substring(indexOf2));
                                            str = sb.toString();
                                        }
                                    }
                                    if (str2 != null) {
                                        int indexOf4 = str2.indexOf(str3);
                                        if (indexOf4 > 0) {
                                            this.ipv6_map.put(str2.substring(0, indexOf4), str2);
                                        }
                                    }
                                    return super.getHttpUrlChecked(str);
                                }

                                public InternalCache internalCache(OkHttpClient okHttpClient) {
                                    try {
                                        Field declaredField = okHttpClient.getClass().getDeclaredField("dns");
                                        declaredField.setAccessible(true);
                                        if (((Dns) declaredField.get(okHttpClient)).getClass().getPackage().getName().indexOf(BuildConfig.FLAVOR_base) < 0) {
                                            declaredField.set(okHttpClient, new Dns() {
                                                public List<InetAddress> lookup(String str) throws UnknownHostException {
                                                    if (str != null) {
                                                        String str2 = (String) AnonymousClass1.this.ipv6_map.get(str);
                                                        if (str2 != null) {
                                                            str = str2;
                                                        }
                                                        return Arrays.asList(InetAddress.getAllByName(str));
                                                    }
                                                    throw new UnknownHostException("hostname == null");
                                                }
                                            });
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                    return super.internalCache(okHttpClient);
                                }
                            };
                        }
                    }
                };
            }
        } catch (NoSuchFieldException unused3) {
        } catch (Exception e3) {
            e3.printStackTrace();
            UEH.reportThrowable(e3);
        }
        psService = new SoapService("http://server.printershare.com/paService.asmx", getUserAgent());
        File externalStorageDirectory = Environment.getExternalStorageDirectory();
        if (!externalStorageDirectory.exists() || !externalStorageDirectory.isDirectory() || !externalStorageDirectory.canRead() || !externalStorageDirectory.canWrite()) {
            ext_storage_root = "/sdcard";
        } else {
            ext_storage_root = externalStorageDirectory.getAbsolutePath();
        }
        try {
            SSLContext instance = SSLContext.getInstance("TLS");
            instance.init(null, new TrustManager[]{new MyTrustManager()}, null);
            HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(new MyHostnameVerifier());
        } catch (Exception e4) {
            e4.printStackTrace();
            reportThrowable(e4);
        }
        try {
            Field declaredField = URI.class.getDeclaredField("AUTHORITY_ENCODER");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(null);
            Field declaredField2 = obj.getClass().getDeclaredField("extraLegalCharacters");
            declaredField2.setAccessible(true);
            declaredField2.set(obj, "@[]%");
        } catch (NoSuchFieldException unused4) {
        } catch (Exception e5) {
            e5.printStackTrace();
            reportThrowable(e5);
        }
        Resources resources = getResources();
        Configuration configuration = resources.getConfiguration();
        if ("ca".equals(configuration.locale.getLanguage())) {
            configuration.locale = new Locale("es");
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
        Context applicationContext = getApplicationContext();
        has_feature_call_log = true;
        try {
            if (applicationContext.getContentResolver().getType(Calls.CONTENT_URI) == null) {
                has_feature_call_log = false;
            }
            TelephonyManager telephonyManager = (TelephonyManager) applicationContext.getSystemService("phone");
            if (telephonyManager != null && telephonyManager.getPhoneType() == 0) {
                has_feature_call_log = false;
            }
        } catch (Exception e6) {
            e6.printStackTrace();
            reportThrowable(e6);
        }
        has_feature_messages = true;
        try {
            if (applicationContext.getContentResolver().getType(Uri.parse("content://mms-sms/")) == null) {
                has_feature_messages = false;
            }
            ConnectivityManager connectivityManager = (ConnectivityManager) applicationContext.getSystemService("connectivity");
            if (connectivityManager != null && connectivityManager.getNetworkInfo(0) == null) {
                has_feature_messages = false;
            }
            if ("wifi-only".equals(SystemProperties.get("ro.carrier"))) {
                has_feature_messages = false;
            }
        } catch (Exception e7) {
            e7.printStackTrace();
            reportThrowable(e7);
        }
        has_feature_bluetooth = false;
        try {
            if (BTAdapter.getDefault(applicationContext) != null) {
                has_feature_bluetooth = true;
            }
        } catch (Throwable th) {
            th.printStackTrace();
            reportThrowable(th);
        }
        has_feature_usb = false;
        try {
            if (!(applicationContext.getSystemService("usb") == null || Class.forName("android.hardware.usb.UsbManager").getMethod("getDeviceList", new Class[0]) == null)) {
                has_feature_usb = true;
            }
        } catch (ClassNotFoundException | NoSuchMethodException unused5) {
        } catch (Exception e8) {
            e8.printStackTrace();
            reportThrowable(e8);
        }
        has_feature_gls = false;
        try {
            if (applicationContext.getSystemService("account") != null) {
                has_feature_gls = true;
            }
            if ("amazon".equalsIgnoreCase(Build.BRAND) && (Build.MODEL.startsWith("SD") || Build.MODEL.startsWith("KF") || "Kindle Fire".equalsIgnoreCase(Build.MODEL))) {
                has_feature_gls = false;
            }
        } catch (Exception e9) {
            e9.printStackTrace();
            reportThrowable(e9);
        }
        try {
            Class.forName("android.webkit.WebView").getMethod("enableSlowWholeDocumentDraw", new Class[0]).invoke(null, new Object[0]);
        } catch (ClassNotFoundException | NoSuchMethodException unused6) {
        } catch (Exception e10) {
            e10.printStackTrace();
            reportThrowable(e10);
        }
        if ("qnx".equals(System.getProperty("os.name"))) {
            has_feature_call_log = false;
            has_feature_messages = false;
            has_feature_gls = false;
        }
    }

    public static final String getDeviceID() {
        String str;
        String str2 = null;
        try {
            str = Secure.getString(self.getContentResolver(), "android_id");
        } catch (Exception e) {
            e.printStackTrace();
            UEH.reportThrowable(e);
            str = null;
        }
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 9) {
                str2 = (String) Build.class.getField("SERIAL").get(null);
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e2) {
            e2.printStackTrace();
            UEH.reportThrowable(e2);
        }
        if (str2 != null) {
            if (str != null) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append("|");
                sb.append(str2);
                str = sb.toString();
            } else {
                str = str2;
            }
        }
        return str != null ? str : "unknown";
    }

    public static final String getVersion() {
        try {
            return self.getPackageManager().getPackageInfo(self.getPackageName(), 0).versionName;
        } catch (Exception e) {
            e.printStackTrace();
            reportThrowable(e);
            return "";
        }
    }

    public static final String getFullModelName(String str, String str2) {
        String str3 = ")";
        String str4 = "(";
        if (str != null && str.startsWith(str4) && str.endsWith(str3)) {
            str = str.substring(1, str.length() - 1).trim();
        }
        if (str2 != null && str2.startsWith(str4) && str2.endsWith(str3)) {
            str2 = str2.substring(1, str2.length() - 1).trim();
        }
        if (str2 != null) {
            if (str != null) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append(" ");
                sb.append(str2);
                str = sb.toString();
            } else {
                str = str2;
            }
        }
        return clearPrinterModelName(str);
    }

    public static final String clearPrinterModelName(String str) {
        String str2;
        if (str != null) {
            if (str.startsWith("(") && str.endsWith(")")) {
                str = str.substring(1, str.length() - 1).trim();
            }
            String lowerCase = str.toLowerCase();
            int i = 0;
            while (true) {
                String[] strArr = mfg_map;
                str2 = " ";
                if (i >= strArr.length) {
                    break;
                }
                String lowerCase2 = strArr[i].toLowerCase();
                while (true) {
                    int indexOf = lowerCase.indexOf(lowerCase2);
                    if (indexOf < 0) {
                        break;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(str.substring(0, indexOf));
                    sb.append(mfg_map[i + 1]);
                    sb.append(str2);
                    sb.append(str.substring(indexOf + lowerCase2.length()).trim());
                    str = sb.toString();
                    lowerCase = str.toLowerCase();
                }
                i += 2;
            }
            while (true) {
                int indexOf2 = str.indexOf(str2);
                if (indexOf2 <= 0) {
                    break;
                }
                int i2 = indexOf2 + 1;
                if (str.toLowerCase().indexOf(str.substring(0, i2).toLowerCase(), i2) != i2) {
                    break;
                }
                str = str.substring(i2);
            }
        }
        if ("".equals(str)) {
            return null;
        }
        return str;
    }

    public static final String getUserAgent() {
        StringBuilder sb = new StringBuilder();
        sb.append("PS4Android ");
        sb.append(getVersion());
        return sb.toString();
    }

    public static final synchronized Vector<NetworkInterfaceData> getActiveNetworkInterfaces() {
        Enumeration enumeration;
        NetworkInterface networkInterface;
        NetworkInterfaceData networkInterfaceData;
        synchronized (App.class) {
            if ("qnx".equals(System.getProperty("os.name"))) {
                return null;
            }
            try {
                enumeration = NetworkInterface.getNetworkInterfaces();
            } catch (Throwable th) {
                if (!(th.getCause() instanceof NumberFormatException)) {
                    th.printStackTrace();
                    reportThrowable(th);
                }
                enumeration = null;
            }
            if (enumeration != null) {
                try {
                    Vector<NetworkInterfaceData> vector = new Vector<>();
                    while (enumeration.hasMoreElements()) {
                        NetworkInterfaceData ifActive = NetworkInterfaceData.getIfActive((NetworkInterface) enumeration.nextElement());
                        if (ifActive != null) {
                            vector.add(ifActive);
                        }
                    }
                    return vector;
                } catch (Throwable th2) {
                    th2.printStackTrace();
                    reportThrowable(th2);
                }
            }
            if (new File("/sys/class/net").exists()) {
                try {
                    String[] list = new File("/sys/class/net").list();
                    if (list != null) {
                        Vector<NetworkInterfaceData> vector2 = new Vector<>();
                        for (int i = 0; i < list.length; i++) {
                            networkInterface = NetworkInterface.getByName(list[i]);
                            if (networkInterface == null) {
                                StringBuilder sb = new StringBuilder();
                                sb.append("/sys/class/net/");
                                sb.append(list[i]);
                                sb.append("/ifindex");
                                DataInputStream dataInputStream = new DataInputStream(new FileInputStream(sb.toString()));
                                String readLine = dataInputStream.readLine();
                                dataInputStream.close();
                                networkInterfaceData = NetworkInterfaceData.getIfActive(list[i], readLine);
                            } else {
                                networkInterfaceData = NetworkInterfaceData.getIfActive(networkInterface);
                            }
                            if (networkInterfaceData != null) {
                                vector2.add(networkInterfaceData);
                            }
                        }
                        return vector2;
                    }
                } catch (Throwable th3) {
                    th3.printStackTrace();
                    reportThrowable(th3);
                }
            }
        }
        return null;
    }

    public static final synchronized Vector<InetAddress> getBroadcastAdrresses() {
        synchronized (App.class) {
            if (bal_cache_dat == null || System.currentTimeMillis() - bal_cache_ts >= 5000) {
                Vector<InetAddress> vector = new Vector<>();
                Vector activeNetworkInterfaces = getActiveNetworkInterfaces();
                if (activeNetworkInterfaces != null) {
                    for (int i = 0; i < activeNetworkInterfaces.size(); i++) {
                        NetworkInterfaceData networkInterfaceData = (NetworkInterfaceData) activeNetworkInterfaces.get(i);
                        if (networkInterfaceData.ipv4_broadcasts != null) {
                            for (int i2 = 0; i2 < networkInterfaceData.ipv4_broadcasts.size(); i2++) {
                                vector.add(networkInterfaceData.ipv4_broadcasts.get(i2));
                            }
                        }
                    }
                } else {
                    try {
                        vector.add(InetAddress.getByName("255.255.255.255"));
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        reportThrowable(e);
                    }
                }
                bal_cache_dat = vector;
                bal_cache_ts = System.currentTimeMillis();
                return vector;
            }
            Vector<InetAddress> vector2 = (Vector) bal_cache_dat.clone();
            return vector2;
        }
    }

    public static final void reportThrowable(Throwable th) {
        reportThrowable(th, null);
    }

    public static final void reportThrowable(Throwable th, String str) {
        UEH.reportThrowable(th, str);
    }

    public static final File getFilesDirInt() {
        return getFilesDirInt(null);
    }

    public static final File getFilesDirInt(String str) {
        File filesDir = self.getFilesDir();
        if (str != null) {
            filesDir = new File(filesDir, str);
        }
        if (!filesDir.exists()) {
            filesDir.mkdirs();
        }
        return filesDir;
    }

    public static final File getFilesDirExt() {
        return getFilesDirExt(null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x001f  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0063  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x006f  */
    public static final File getFilesDirExt(String str) {
        boolean z;
        File file = null;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) > 8) {
                z = true;
                if (z) {
                    try {
                        file = (File) Context.class.getMethod("getExternalFilesDir", new Class[]{String.class}).invoke(self, new Object[]{null});
                    } catch (NoSuchMethodException unused) {
                    } catch (Exception e) {
                        e.printStackTrace();
                        reportThrowable(e);
                    }
                }
                if (file == null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(ext_storage_root);
                    sb.append("/PrinterShare/files");
                    file = new File(sb.toString());
                }
                if (str != null) {
                    file = new File(file, str);
                }
                if (!file.exists()) {
                    file.mkdirs();
                }
                return file;
            }
        } catch (NoSuchFieldException unused2) {
        } catch (Exception e2) {
            e2.printStackTrace();
            reportThrowable(e2);
        }
        z = false;
        if (z) {
        }
        if (file == null) {
        }
        if (str != null) {
        }
        if (!file.exists()) {
        }
        return file;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x001e  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x003f  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x005d  */
    public static final File getTempDir() {
        boolean z;
        File file = null;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) > 8) {
                z = true;
                if (z) {
                    try {
                        file = (File) Context.class.getMethod("getExternalCacheDir", new Class[0]).invoke(self, new Object[0]);
                    } catch (NoSuchMethodException unused) {
                    } catch (Exception e) {
                        e.printStackTrace();
                        reportThrowable(e);
                    }
                }
                if (file == null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(ext_storage_root);
                    sb.append("/PrinterShare/cache");
                    file = new File(sb.toString());
                }
                if (!file.exists()) {
                    file.mkdirs();
                }
                return file;
            }
        } catch (NoSuchFieldException unused2) {
        } catch (Exception e2) {
            e2.printStackTrace();
            reportThrowable(e2);
        }
        z = false;
        if (z) {
        }
        if (file == null) {
        }
        if (!file.exists()) {
        }
        return file;
    }

    public void onLowMemory() {
        super.onLowMemory();
        freeMem();
    }

    public static final void clearExternalBytesAllocated() {
        Class cls;
        try {
            cls = Class.forName("dalvik.system.VMRuntime");
        } catch (ClassNotFoundException unused) {
            cls = null;
        }
        if (cls != null) {
            try {
                Object invoke = cls.getMethod("getRuntime", new Class[0]).invoke(null, new Object[0]);
                Object invoke2 = cls.getMethod("getExternalBytesAllocated", new Class[0]).invoke(invoke, new Object[0]);
                cls.getMethod("trackExternalFree", new Class[]{Long.TYPE}).invoke(invoke, new Object[]{invoke2});
            } catch (Exception e) {
                e.printStackTrace();
                reportThrowable(e);
            }
        }
    }

    public static final void freeMem() {
        Runtime.getRuntime().gc();
        Runtime.getRuntime().runFinalization();
        try {
            Thread.sleep(100);
        } catch (Throwable th) {
            th.printStackTrace();
        }
        System.gc();
        try {
            Thread.sleep(100);
        } catch (Throwable th2) {
            th2.printStackTrace();
        }
        System.gc();
    }

    private static synchronized boolean get24HourMode(Context context) {
        synchronized (App.class) {
            if (s24HourLastContext == null || s24HourLastContext.get() != context) {
                s24HourLastContext = new WeakReference<>(context);
                boolean is24HourFormat = DateFormat.is24HourFormat(context);
                sCached24HourMode = is24HourFormat;
                return is24HourFormat;
            }
            boolean z = sCached24HourMode;
            return z;
        }
    }

    public static final String getRawCPUABI() {
        try {
            String str = (String) Build.class.getField("CPU_ABI").get(null);
            if (str != null) {
                return str;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            reportThrowable(e);
        }
        return "arm";
    }

    public static final String getCPUABI(Context context, boolean z, boolean z2) {
        String str = Build.MODEL;
        String rawCPUABI = getRawCPUABI();
        String str2 = "arm";
        String str3 = "mips";
        if (rawCPUABI.toLowerCase().indexOf(str2) >= 0) {
            str3 = str2;
        } else if (rawCPUABI.toLowerCase().indexOf(str3) < 0) {
            str3 = "x86";
        }
        if (z && rawCPUABI.indexOf("64") > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(str3);
            sb.append("_64");
            str3 = sb.toString();
        }
        if (!"VAP430".equals(str) && !"NSZ-GS7/GX70".equals(str) && !"NX008HI".equals(str) && !"NX008HD8".equals(str) && !"NX008HD8G".equals(str) && !"PMP5580C".equals(str) && !"PMP5770D".equals(str)) {
            str2 = str3;
        }
        if (z2) {
            try {
                if (VERSION.class.getField("SDK_INT").getInt(null) >= 21) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(str2);
                    sb2.append("_pie");
                    str2 = sb2.toString();
                }
            } catch (NoSuchFieldException unused) {
            } catch (Exception e) {
                e.printStackTrace();
                UEH.reportThrowable(e);
            }
        }
        try {
            if ("qnx".equals(System.getProperty("os.name"))) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("bb_");
                sb3.append(str2);
                str2 = sb3.toString();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            reportThrowable(e2);
        }
        try {
            if (!((Boolean) PackageManager.class.getMethod("hasSystemFeature", new Class[]{String.class}).invoke(context.getPackageManager(), new Object[]{"com.google.android.tv"})).booleanValue()) {
                return str2;
            }
            StringBuilder sb4 = new StringBuilder();
            sb4.append("gtv_");
            sb4.append(str2);
            return sb4.toString();
        } catch (NoSuchMethodException unused2) {
            return str2;
        } catch (Exception e3) {
            e3.printStackTrace();
            reportThrowable(e3);
            return str2;
        }
    }

    public static final void setExecutable(File file) {
        boolean z = false;
        try {
            z = ((Boolean) file.getClass().getMethod("setExecutable", new Class[]{Boolean.TYPE}).invoke(file, new Object[]{Boolean.valueOf(true)})).booleanValue();
        } catch (NoSuchMethodException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            reportThrowable(e);
        }
        if (!z) {
            FileUtils.setPermissions(file.getAbsolutePath(), 33279, -1, -1);
        }
    }

    public static final String formatTimeStampString(Context context, long j, boolean z) {
        Time time = new Time();
        time.set(j);
        Time time2 = new Time();
        time2.setToNow();
        int i = get24HourMode(context) ? 527232 : 527168;
        int i2 = time.year != time2.year ? i | 20 : time.yearDay != time2.yearDay ? i | 16 : i | 1;
        if (z) {
            i2 |= 21;
        }
        return DateUtils.formatDateTime(context, j, i2);
    }

    public static final Paint newPaint() {
        Paint paint = new Paint();
        paint.setAntiAlias(false);
        paint.setLinearText(true);
        paint.setSubpixelText(true);
        paint.setFilterBitmap(true);
        paint.setDither(false);
        return paint;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x001d, code lost:
        if (r3.getInt(null) >= 11) goto L_0x002d;
     */
    public static final int getMaxMemory() {
        boolean z;
        boolean z2 = true;
        final int[] iArr = new int[1];
        try {
            Field field = VERSION.class.getField("SDK_INT");
            z = field.getInt(null) >= 5;
            try {
            } catch (NoSuchFieldException unused) {
            } catch (Exception e) {
                e = e;
                e.printStackTrace();
                reportThrowable(e);
            }
        } catch (NoSuchFieldException unused2) {
            z = false;
        } catch (Exception e2) {
            e = e2;
            z = false;
            e.printStackTrace();
            reportThrowable(e);
        }
        z2 = false;
        if (z2) {
            new Object() {
                {
                    ActivityManager activityManager = (ActivityManager) App.self.getSystemService("activity");
                    if (activityManager != null) {
                        iArr[0] = activityManager.getLargeMemoryClass() * 1024;
                    }
                }
            };
        } else if (z) {
            new Object() {
                {
                    ActivityManager activityManager = (ActivityManager) App.self.getSystemService("activity");
                    if (activityManager != null) {
                        iArr[0] = activityManager.getMemoryClass() * 1024;
                    }
                }
            };
        }
        return iArr[0] > 0 ? iArr[0] : SmbConstants.FLAGS2_STATUS32;
    }

    public static final int getTotalMemory() {
        int i;
        String readLine;
        ActivityManager activityManager = (ActivityManager) self.getSystemService("activity");
        int i2 = 0;
        if (activityManager != null) {
            MemoryInfo memoryInfo = new MemoryInfo();
            activityManager.getMemoryInfo(memoryInfo);
            i = (int) (memoryInfo.availMem / 1024);
        } else {
            i = 0;
        }
        File file = new File("/proc/meminfo");
        if (file.exists()) {
            try {
                DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                while (true) {
                    readLine = dataInputStream.readLine();
                    if (readLine == null || readLine.startsWith("MemTotal:")) {
                        dataInputStream.close();
                    }
                }
                dataInputStream.close();
                if (readLine != null) {
                    int indexOf = readLine.indexOf(":");
                    int indexOf2 = readLine.indexOf("kB");
                    if (indexOf > 0 && indexOf2 > indexOf) {
                        i2 = Integer.parseInt(readLine.substring(indexOf + 1, indexOf2).trim());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                reportThrowable(e);
            }
            if (i2 != -1) {
                int i3 = i2 - 65536;
                if (i3 > i) {
                    i = i3;
                }
            }
        }
        return i < 16384 ? SmbConstants.FLAGS2_STATUS32 : i;
    }

    public static final String getMimeTypeByName(String str) {
        String lowerCase = str != null ? str.toLowerCase() : "";
        String str2 = lowerCase.endsWith(".jpg") ? "image/jpeg" : "application/octet-stream";
        if (lowerCase.endsWith(".png")) {
            str2 = "image/png";
        }
        if (lowerCase.endsWith(".txt")) {
            str2 = NanoHTTPD.MIME_PLAINTEXT;
        }
        if (lowerCase.endsWith(".htm") || lowerCase.endsWith(".html")) {
            str2 = NanoHTTPD.MIME_HTML;
        }
        if (lowerCase.endsWith(".pdf")) {
            str2 = "application/pdf";
        }
        if (lowerCase.endsWith(".doc")) {
            str2 = "application/msword";
        }
        if (lowerCase.endsWith(".docx")) {
            str2 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        }
        if (lowerCase.endsWith(".xls")) {
            str2 = "application/vnd.ms-excel";
        }
        if (lowerCase.endsWith(".xlsx")) {
            str2 = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        if (lowerCase.endsWith(".ppt")) {
            str2 = "application/vnd.ms-powerpoint";
        }
        if (lowerCase.endsWith(".pptx")) {
            str2 = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        }
        return lowerCase.endsWith(".hwp") ? "application/haansofthwp" : str2;
    }

    public static final String getExtByMimeType(String str) {
        String str2 = "";
        String lowerCase = str != null ? str.toLowerCase() : str2;
        if ("image/jpeg".equals(lowerCase)) {
            str2 = ".jpg";
        }
        if ("image/png".equals(lowerCase)) {
            str2 = ".png";
        }
        if (NanoHTTPD.MIME_PLAINTEXT.equals(lowerCase)) {
            str2 = ".txt";
        }
        if (NanoHTTPD.MIME_HTML.equals(lowerCase)) {
            str2 = ".htm";
        }
        if ("application/pdf".equals(lowerCase)) {
            str2 = ".pdf";
        }
        if ("application/msword".equals(lowerCase)) {
            str2 = ".doc";
        }
        if ("application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(lowerCase)) {
            str2 = ".docx";
        }
        if ("application/vnd.ms-excel".equals(lowerCase)) {
            str2 = ".xls";
        }
        if ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equals(lowerCase)) {
            str2 = ".xlsx";
        }
        if ("application/vnd.ms-powerpoint".equals(lowerCase)) {
            str2 = ".ppt";
        }
        if ("application/vnd.openxmlformats-officedocument.presentationml.presentation".equals(lowerCase)) {
            str2 = ".pptx";
        }
        return "application/haansofthwp".equals(lowerCase) ? ".hwp" : str2;
    }

    public static final String fixEncoding(String str) {
        if (str != null) {
            try {
                int length = str.length();
                char[] cArr = new char[length];
                str.getChars(0, str.length(), cArr, 0);
                byte[] bArr = new byte[length];
                for (int i = 0; i < length; i++) {
                    bArr[i] = (byte) (cArr[i] & 255);
                }
                return new String(bArr, "UTF-8");
            } catch (UnsupportedEncodingException unused) {
            }
        }
        return str;
    }

    public static final String getUserCountry() {
        String str = null;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) self.getSystemService("phone");
            if (telephonyManager != null) {
                str = telephonyManager.getSimCountryIso();
                if (str == null || str.length() != 2) {
                    str = telephonyManager.getNetworkCountryIso();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            reportThrowable(e);
        }
        if (str == null || str.length() != 2) {
            str = Locale.getDefault().getCountry();
        }
        return str.trim().toUpperCase();
    }

    public static final void firePrinterChanged() {
        App app = self;
        if (app != null) {
            app.onPrinterChanged();
        }
    }

    /* access modifiers changed from: protected */
    public void initUEH() {
        UEH.init(this, 8);
    }

    /* access modifiers changed from: protected */
    public void initFlurry() {
        new FlurryAgent.Builder().withCaptureUncaughtExceptions(false).withContinueSessionMillis(300000).build(this, is_dev ? "W1BPTME454DTS4IJJLAU" : "YGTGYZJ4ALDB1KEDBEDP");
        FlurryAgent.setReportLocation(false);
        try {
            FlurryConfig instance = FlurryConfig.getInstance();
            instance.registerListener(new FlurryConfigListener() {
                public void onActivateComplete(boolean z) {
                }

                public void onFetchError(boolean z) {
                }

                public void onFetchNoChange() {
                }

                public void onFetchSuccess() {
                    FlurryConfig.getInstance().activateConfig();
                }
            });
            instance.fetchConfig();
        } catch (Exception e) {
            e.printStackTrace();
            reportThrowable(e);
        }
    }
}
