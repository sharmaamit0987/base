package com.dynamixsoftware.printershare;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.mms.pdu.CharacterSets;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class ActivityMessages extends ActivityRoot {
    static final StyleSpan STYLE_BOLD = new StyleSpan(1);
    private static final Map<String, String> sRecipientAddress = new ConcurrentHashMap(20);
    /* access modifiers changed from: private */
    public ContactInfoCache cache;
    /* access modifiers changed from: private */
    public ListView mList;

    private final class CachingNameStore {
        private final ConcurrentHashMap<String, String> mCachedNames = new ConcurrentHashMap<>();

        public CachingNameStore(Context context) {
        }

        public String getContactNames(String str) {
            String str2;
            String str3 = (String) this.mCachedNames.get(str);
            if (str3 != null) {
                return str3;
            }
            String[] split = str.split(";");
            if (split.length < 2) {
                str2 = ActivityMessages.this.cache.getContactName(str).replace(';', ',');
            } else {
                int i = 0;
                for (int i2 = 0; i2 < split.length; i2++) {
                    split[i2] = getContactNames(split[i2]);
                    i += split[i2].length() + 2;
                }
                StringBuilder sb = new StringBuilder(i);
                sb.append(split[0]);
                for (int i3 = 1; i3 < split.length; i3++) {
                    sb.append(", ");
                    sb.append(split[i3]);
                }
                str2 = sb.toString();
            }
            this.mCachedNames.put(str, str2);
            return str2;
        }
    }

    class MessageAdapter extends BaseAdapter {
        private Vector<MessageHeader> mDat;

        public long getItemId(int i) {
            return (long) i;
        }

        public MessageAdapter(Context context, Vector<MessageHeader> vector) {
            this.mDat = vector;
        }

        public int getCount() {
            return this.mDat.size();
        }

        public Object getItem(int i) {
            return this.mDat.get(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            int i2 = 0;
            if (view == null) {
                view = ActivityMessages.this.getLayoutInflater().inflate(R.layout.list_item_messages, viewGroup, false);
            }
            TextView textView = (TextView) view.findViewById(R.id.from);
            TextView textView2 = (TextView) view.findViewById(R.id.subject);
            TextView textView3 = (TextView) view.findViewById(R.id.date);
            View findViewById = view.findViewById(R.id.unread_indicator);
            MessageHeader messageHeader = (MessageHeader) getItem(i);
            textView.setText(formatMessage(messageHeader));
            findViewById.setVisibility(messageHeader.read ? 4 : 0);
            textView2.setText(messageHeader.subject);
            textView3.setText(messageHeader.date);
            View findViewById2 = view.findViewById(R.id.selected);
            if (!ActivityMessages.this.mList.isItemChecked(i)) {
                i2 = 8;
            }
            findViewById2.setVisibility(i2);
            return view;
        }

        private CharSequence formatMessage(MessageHeader messageHeader) {
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(messageHeader.from);
            if (messageHeader.message_count > 1) {
                StringBuilder sb = new StringBuilder();
                sb.append(" (");
                sb.append(messageHeader.message_count);
                sb.append(") ");
                spannableStringBuilder.append(sb.toString());
            }
            if (!messageHeader.read) {
                spannableStringBuilder.setSpan(ActivityMessages.STYLE_BOLD, 0, spannableStringBuilder.length(), 17);
            }
            return spannableStringBuilder;
        }
    }

    class MessageHeader {
        public String date;
        public boolean error;
        public String from;
        public int message_count;
        public boolean read;
        public String subject;
        public long thread_id;

        MessageHeader() {
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_messages);
        ((TextView) findViewById(R.id.empty)).setText(R.string.label_no_messages);
        ListView listView = (ListView) findViewById(R.id.list);
        this.mList = listView;
        listView.setChoiceMode(2);
        this.mList.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                View findViewById = view != null ? view.findViewById(R.id.selected) : null;
                if (findViewById != null) {
                    findViewById.setVisibility(ActivityMessages.this.mList.isItemChecked(i) ? 0 : 8);
                }
            }
        });
        Button button = (Button) findViewById(R.id.button_print);
        boolean z = false;
        button.setEnabled(false);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SparseBooleanArray checkedItemPositions = ActivityMessages.this.mList.getCheckedItemPositions();
                String str = "";
                String str2 = str;
                for (int i = 0; i < checkedItemPositions.size(); i++) {
                    if (checkedItemPositions.valueAt(i)) {
                        MessageHeader messageHeader = (MessageHeader) ActivityMessages.this.mList.getAdapter().getItem(checkedItemPositions.keyAt(i));
                        StringBuilder sb = new StringBuilder();
                        sb.append(str2);
                        sb.append(str2.length() > 0 ? "\n" : str);
                        sb.append(messageHeader.thread_id);
                        sb.append(" ");
                        sb.append(messageHeader.from);
                        str2 = sb.toString();
                    }
                }
                if (str2.length() > 0) {
                    Intent intent = new Intent();
                    intent.setClass(ActivityMessages.this, ActivityPrintMessages.class);
                    intent.putExtra("data", str2);
                    ActivityMessages.this.startActivity(intent);
                    return;
                }
                Toast.makeText(ActivityMessages.this, R.string.toast_nothing_selected, 1).show();
            }
        });
        this.cache = new ContactInfoCache(this);
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                z = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        if (z) {
            new Object() {
                {
                    String[] strArr = {"android.permission.READ_SMS", "android.permission.READ_CONTACTS"};
                    if (ActivityMessages.this.checkSelfPermission(strArr[0]) == 0 && ActivityMessages.this.checkSelfPermission(strArr[1]) == 0) {
                        ActivityMessages.this.init();
                    } else {
                        ActivityMessages.this.requestPermissions(strArr, 444555);
                    }
                }
            };
        } else {
            init();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 444555 && iArr != null && iArr.length > 1 && iArr[0] == 0 && iArr[1] == 0) {
            init();
            return;
        }
        setResult(0);
        finish();
    }

    /* access modifiers changed from: private */
    public void init() {
        Builder buildUpon = Uri.parse("content://mms-sms/conversations").buildUpon();
        buildUpon.appendQueryParameter("simple", "true");
        Cursor query = getContentResolver().query(buildUpon.build(), new String[]{"_id", "message_count", "recipient_ids", "date", "read", "snippet", "snippet_cs", "error"}, null, null, "date DESC");
        Vector vector = new Vector();
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        CachingNameStore cachingNameStore = new CachingNameStore(this);
        if (query != null) {
            while (query.moveToNext()) {
                MessageHeader messageHeader = new MessageHeader();
                messageHeader.thread_id = query.getLong(0);
                String string = query.getString(2);
                String recipientsByIds = getRecipientsByIds(this, string, true);
                String str = (String) concurrentHashMap.get(string);
                if (str == null) {
                    String contactNames = cachingNameStore.getContactNames(recipientsByIds);
                    if (contactNames == null) {
                        contactNames = "";
                    }
                    str = contactNames;
                    concurrentHashMap.put(string, str);
                }
                messageHeader.from = str;
                messageHeader.subject = extractEncStrFromCursor(query.getString(5), query.getInt(6));
                messageHeader.date = App.formatTimeStampString(this, query.getLong(3), false);
                messageHeader.read = query.getInt(4) != 0;
                messageHeader.error = query.getInt(7) != 0;
                messageHeader.message_count = query.getInt(1);
                vector.add(messageHeader);
            }
            query.close();
        }
        Button button = (Button) findViewById(R.id.button_print);
        if (vector.size() > 0) {
            this.mList.setAdapter(new MessageAdapter(this, vector));
            this.mList.setVisibility(0);
            button.setEnabled(true);
            return;
        }
        this.mList.setVisibility(8);
        findViewById(R.id.empty).setVisibility(0);
        button.setEnabled(false);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, R.string.menu_select_all);
        menu.add(0, 2, 0, R.string.menu_unselect_all);
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        ListAdapter adapter = this.mList.getAdapter();
        if (adapter != null) {
            int itemId = menuItem.getItemId();
            if (itemId == 1) {
                for (int i2 = 0; i2 < adapter.getCount(); i2++) {
                    this.mList.setItemChecked(i2, true);
                }
                return true;
            } else if (itemId == 2) {
                for (int i3 = 0; i3 < adapter.getCount(); i3++) {
                    this.mList.setItemChecked(i3, false);
                }
                return true;
            }
        }
        return false;
    }

    private static String extractEncStrFromCursor(String str, int i) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        if (i == 0) {
            return str;
        }
        try {
            return new String(str.getBytes("iso-8859-1"), CharacterSets.getMimeName(i));
        } catch (UnsupportedEncodingException unused) {
            return str;
        }
    }

    private static String getRecipientsByIds(Context context, String str, boolean z) {
        String str2 = (String) sRecipientAddress.get(str);
        if (str2 != null) {
            return str2;
        }
        String str3 = "";
        if (!TextUtils.isEmpty(str)) {
            StringBuilder extractIdsToAddresses = extractIdsToAddresses(context, str, z);
            if (extractIdsToAddresses == null) {
                return str3;
            }
            str3 = extractIdsToAddresses.toString();
        }
        sRecipientAddress.put(str, str3);
        return str3;
    }

    /* JADX WARNING: type inference failed for: r7v1, types: [android.database.Cursor] */
    /* JADX WARNING: type inference failed for: r7v2, types: [android.database.Cursor] */
    /* JADX WARNING: type inference failed for: r7v3 */
    /* JADX WARNING: type inference failed for: r7v4 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 2 */
    private static StringBuilder extractIdsToAddresses(Context context, String str, boolean z) {
        ? r7;
        StringBuilder sb = new StringBuilder();
        String[] split = str.split(" ");
        int length = split.length;
        boolean z2 = true;
        int i = 0;
        while (true) {
            StringBuilder sb2 = 0;
            if (i < length) {
                String str2 = split[i];
                String str3 = (String) sRecipientAddress.get(str2);
                if (str3 == null) {
                    if (!z) {
                        return sb2;
                    }
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("content://mms-sms/canonical-address/");
                    sb3.append(str2);
                    try {
                        r7 = context.getContentResolver().query(Uri.parse(sb3.toString()), null, null, null, null);
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                        r7 = sb2;
                    }
                    if (r7 != 0) {
                        try {
                            if (r7.moveToFirst()) {
                                String string = r7.getString(0);
                                sRecipientAddress.put(str2, string);
                                str3 = string;
                            }
                        } finally {
                            r7.close();
                        }
                    }
                }
                if (str3 != null) {
                    if (z2) {
                        z2 = false;
                    } else {
                        sb.append(";");
                    }
                    sb.append(str3);
                }
                i++;
            } else {
                if (sb.length() == 0) {
                    sb = sb2;
                }
                return sb;
            }
        }
    }
}
