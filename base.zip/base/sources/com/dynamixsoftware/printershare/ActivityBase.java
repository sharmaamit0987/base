package com.dynamixsoftware.printershare;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.data.Printer;

public abstract class ActivityBase extends ActivityCore {
    protected boolean local_only = false;
    protected AlertDialog printers_menu;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.printers_menu = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.menu_select_printer).setAdapter(new BaseAdapter() {
            public Object getItem(int i) {
                return null;
            }

            public long getItemId(int i) {
                return 0;
            }

            public int getCount() {
                return ActivityBase.this.local_only ? 3 : 5;
            }

            public boolean isEnabled(int i) {
                boolean z = true;
                if (i == 1 && !App.has_feature_bluetooth) {
                    z = false;
                }
                if (i == 2 && !App.has_feature_usb) {
                    z = false;
                }
                if (i != 3 || App.has_feature_gls) {
                    return z;
                }
                return false;
            }

            public View getView(int i, View view, ViewGroup viewGroup) {
                int i2;
                int i3;
                if (view == null) {
                    view = ActivityBase.this.getLayoutInflater().inflate(17367043, viewGroup, false);
                }
                TextView textView = (TextView) view.findViewById(16908308);
                if (i == 0) {
                    i3 = R.string.menu_nearby_wifi;
                    i2 = R.drawable.dlg_ic_wifi;
                } else if (i == 1) {
                    i3 = R.string.menu_nearby_bt;
                    i2 = R.drawable.dlg_ic_bluetooth;
                } else if (i == 2) {
                    i3 = R.string.menu_nearby_usb;
                    i2 = R.drawable.dlg_ic_usb;
                } else if (i == 3) {
                    i3 = R.string.menu_google_cloud_printer;
                    i2 = R.drawable.dlg_ic_cloud;
                } else if (i != 4) {
                    i3 = 0;
                    i2 = 0;
                } else {
                    i3 = R.string.menu_remote_printer;
                    i2 = R.drawable.dlg_ic_network;
                }
                textView.setText(i3);
                textView.setCompoundDrawablesWithIntrinsicBounds(i2, 0, 0, 0);
                textView.setEnabled(isEnabled(i));
                textView.getCompoundDrawables()[0].setAlpha(isEnabled(i) ? 255 : 128);
                return view;
            }
        }, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                String str = "activity_name";
                if (i == 0) {
                    Intent intent = new Intent("WIFI");
                    intent.setClass(ActivityBase.this, ActivityLocalPrinters.class);
                    intent.putExtra(str, ActivityBase.this.getClass().getSimpleName());
                    ActivityBase.this.startActivityForResult(intent, 2);
                } else if (i == 1) {
                    Intent intent2 = new Intent("BT");
                    intent2.setClass(ActivityBase.this, ActivityLocalPrinters.class);
                    intent2.putExtra(str, ActivityBase.this.getClass().getSimpleName());
                    ActivityBase.this.startActivityForResult(intent2, 2);
                } else if (i == 2) {
                    ActivityBase.this.startLocalPrintersUSB();
                } else if (i == 3) {
                    Intent intent3 = new Intent();
                    intent3.setClass(ActivityBase.this, ActivityCloudPrinters.class);
                    intent3.putExtra(str, ActivityBase.this.getClass().getSimpleName());
                    ActivityBase.this.startActivityForResult(intent3, 2);
                } else if (i == 4) {
                    Intent intent4 = new Intent();
                    intent4.setClass(ActivityBase.this, ActivityPrinters.class);
                    intent4.putExtra(str, ActivityBase.this.getClass().getSimpleName());
                    ActivityBase.this.startActivityForResult(intent4, 2);
                }
                ActivityBase.this.printers_menu.dismiss();
            }
        }).create();
    }

    /* access modifiers changed from: protected */
    public void startLocalPrintersUSB() {
        Intent intent = new Intent("USB");
        intent.setClass(this, ActivityLocalPrinters.class);
        intent.putExtra("activity_name", getClass().getSimpleName());
        startActivityForResult(intent, 2);
    }

    /* access modifiers changed from: protected */
    public void update() {
        Printer printer = printer;
        ImageView imageView = (ImageView) findViewById(R.id.printer_status);
        int i = (printer == null || printer.online == null) ? R.drawable.printer : printer.online.booleanValue() ? R.drawable.printer_on : R.drawable.printer_off;
        imageView.setBackgroundResource(i);
        TextView textView = (TextView) findViewById(R.id.printer_name);
        if (printer != null) {
            textView.setText(printer.getInfoTitle());
        } else {
            textView.setText(getResources().getString(R.string.label_printer));
        }
        TextView textView2 = (TextView) findViewById(R.id.printer_owner);
        if (printer != null) {
            textView2.setText(printer.getInfoOwner());
        } else {
            textView2.setText(getResources().getString(R.string.label_not_selected));
        }
        TextView textView3 = (TextView) findViewById(R.id.printer_location);
        if (printer != null) {
            textView3.setText(printer.getInfoLocation());
        } else {
            textView3.setText("");
        }
        if (npc_pid != null) {
            String str = npc_pid;
            npc_pid = null;
            if (printer == null || printer.id.indexOf("_usb.local.") <= 0 || !printer.id.startsWith(str)) {
                startLocalPrintersUSB();
            }
        }
    }
}
