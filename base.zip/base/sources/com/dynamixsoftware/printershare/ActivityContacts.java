package com.dynamixsoftware.printershare;

import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.CharArrayBuffer;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.provider.Contacts.People;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AlphabetIndexer;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ResourceCursorAdapter;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ActivityContacts extends ActivityRoot {
    private static final String FOCUS_KEY = "focused";
    private static final String LIST_STATE_KEY = "liststate";
    private static final int QUERY_TOKEN = 42;
    /* access modifiers changed from: private */
    public static ExecutorService sImageFetchThreadPool;
    /* access modifiers changed from: private */
    public Impl impl = Impl.getImpl();
    /* access modifiers changed from: private */
    public ContactItemListAdapter mAdapter;
    private boolean mJustCreated;
    /* access modifiers changed from: private */
    public boolean mListHasFocus;
    /* access modifiers changed from: private */
    public Parcelable mListState = null;
    /* access modifiers changed from: private */
    public ListView mListView;
    private QueryHandler mQueryHandler;
    /* access modifiers changed from: private */
    public int mScrollState;

    private final class ContactItemListAdapter extends ResourceCursorAdapter implements SectionIndexer, OnScrollListener {
        private static final int FETCH_IMAGE_MSG = 1;
        private String mAlphabet;
        /* access modifiers changed from: private */
        public HashMap<Long, SoftReference<Bitmap>> mBitmapCache = null;
        /* access modifiers changed from: private */
        public ImageFetchHandler mHandler = new ImageFetchHandler();
        private ImageDbFetcher mImageFetcher;
        private SectionIndexer mIndexer;
        /* access modifiers changed from: private */
        public HashSet<ImageView> mItemsMissingImages = null;
        private boolean mLoading = true;
        private int[] mSectionPositions;
        private CharSequence mUnknownNameText;

        private class ImageDbFetcher implements Runnable {
            private ImageView mImageView;
            long mPhotoId;

            public ImageDbFetcher(long j, ImageView imageView) {
                this.mPhotoId = j;
                this.mImageView = imageView;
            }

            public void run() {
                if (!ActivityContacts.this.isFinishing() && !Thread.interrupted()) {
                    Bitmap bitmap = null;
                    try {
                        bitmap = ActivityContacts.this.impl.loadContactPhoto(ActivityContacts.this, this.mPhotoId, null);
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                    if (bitmap != null) {
                        ContactItemListAdapter.this.mBitmapCache.put(Long.valueOf(this.mPhotoId), new SoftReference(bitmap));
                        if (!Thread.interrupted()) {
                            Message message = new Message();
                            message.what = 1;
                            message.obj = this.mImageView;
                            ContactItemListAdapter.this.mHandler.sendMessage(message);
                        }
                    }
                }
            }
        }

        private class ImageFetchHandler extends Handler {
            private ImageFetchHandler() {
            }

            public void handleMessage(Message message) {
                if (!ActivityContacts.this.isFinishing() && message.what == 1) {
                    ImageView imageView = (ImageView) message.obj;
                    if (imageView != null) {
                        PhotoInfo photoInfo = (PhotoInfo) imageView.getTag();
                        if (photoInfo != null) {
                            long j = photoInfo.photoId;
                            if (j != 0) {
                                SoftReference softReference = (SoftReference) ContactItemListAdapter.this.mBitmapCache.get(Long.valueOf(j));
                                if (softReference != null) {
                                    Bitmap bitmap = (Bitmap) softReference.get();
                                    if (bitmap == null) {
                                        ContactItemListAdapter.this.mBitmapCache.remove(Long.valueOf(j));
                                    } else {
                                        synchronized (imageView) {
                                            if (((PhotoInfo) imageView.getTag()).photoId == j) {
                                                imageView.setImageBitmap(bitmap);
                                                ContactItemListAdapter.this.mItemsMissingImages.remove(imageView);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            public void clearImageFecthing() {
                removeMessages(1);
            }
        }

        public boolean areAllItemsEnabled() {
            return false;
        }

        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        public ContactItemListAdapter(Context context) {
            super(context, R.layout.list_item_contacts, null, false);
            this.mAlphabet = context.getString(R.string.fast_scroll_alphabet);
            this.mUnknownNameText = context.getText(17039374);
            setViewResource(R.layout.list_item_contacts);
            this.mBitmapCache = new HashMap<>();
            this.mItemsMissingImages = new HashSet<>();
        }

        private SectionIndexer getNewIndexer(Cursor cursor) {
            return new AlphabetIndexer(cursor, 1, this.mAlphabet);
        }

        /* access modifiers changed from: protected */
        public void onContentChanged() {
            CharSequence textFilter = ActivityContacts.this.mListView.getTextFilter();
            if (!TextUtils.isEmpty(textFilter)) {
                getFilter().filter(textFilter);
            } else {
                ActivityContacts.this.startQuery();
            }
        }

        public void setLoading(boolean z) {
            this.mLoading = z;
        }

        public boolean isEmpty() {
            if (this.mLoading) {
                return false;
            }
            return super.isEmpty();
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            Cursor cursor = getCursor();
            if (cursor.moveToPosition(i)) {
                if (view == null) {
                    view = newView(ActivityContacts.this, cursor, viewGroup);
                }
                bindView(view, ActivityContacts.this, cursor);
                bindSectionHeader(view, i);
                return view;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("couldn't move cursor to position ");
            sb.append(i);
            throw new IllegalStateException(sb.toString());
        }

        public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
            View newView = super.newView(context, cursor, viewGroup);
            ContactListItemCache contactListItemCache = new ContactListItemCache();
            contactListItemCache.header = newView.findViewById(R.id.header);
            contactListItemCache.headerText = (TextView) newView.findViewById(R.id.header_text);
            contactListItemCache.nameView = (TextView) newView.findViewById(R.id.name);
            contactListItemCache.nonQuickContactPhotoView = (ImageView) newView.findViewById(R.id.noQuickContactPhoto);
            contactListItemCache.selectedView = (ImageView) newView.findViewById(R.id.selected);
            newView.setTag(contactListItemCache);
            return newView;
        }

        public void bindView(View view, Context context, Cursor cursor) {
            ContactListItemCache contactListItemCache = (ContactListItemCache) view.getTag();
            cursor.copyStringToBuffer(1, contactListItemCache.nameBuffer);
            int i = contactListItemCache.nameBuffer.sizeCopied;
            if (i != 0) {
                contactListItemCache.nameView.setText(contactListItemCache.nameBuffer.data, 0, i);
            } else {
                contactListItemCache.nameView.setText(this.mUnknownNameText);
            }
            contactListItemCache.selectedView.setVisibility(ActivityContacts.this.mListView.isItemChecked(cursor.getPosition()) ? 0 : 8);
            ImageView imageView = contactListItemCache.nonQuickContactPhotoView;
            contactListItemCache.nonQuickContactPhotoView.setVisibility(0);
            int position = cursor.getPosition();
            long j = !cursor.isNull(2) ? cursor.getLong(2) : 0;
            imageView.setTag(new PhotoInfo(position, j));
            if (j == 0) {
                imageView.setImageResource(R.drawable.contact);
                return;
            }
            Bitmap bitmap = null;
            SoftReference softReference = (SoftReference) this.mBitmapCache.get(Long.valueOf(j));
            if (softReference != null) {
                bitmap = (Bitmap) softReference.get();
                if (bitmap == null) {
                    this.mBitmapCache.remove(Long.valueOf(j));
                }
            }
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                return;
            }
            imageView.setImageResource(R.drawable.contact);
            this.mItemsMissingImages.add(imageView);
            if (ActivityContacts.this.mScrollState != 2) {
                sendFetchImageMessage(imageView);
            }
        }

        private void bindSectionHeader(View view, int i) {
            ContactListItemCache contactListItemCache = (ContactListItemCache) view.getTag();
            int sectionForPosition = getSectionForPosition(i);
            if (getPositionForSection(sectionForPosition) == i) {
                String trim = this.mIndexer.getSections()[sectionForPosition].toString().trim();
                if (!TextUtils.isEmpty(trim)) {
                    contactListItemCache.headerText.setText(trim);
                    contactListItemCache.header.setVisibility(0);
                    return;
                }
                contactListItemCache.header.setVisibility(8);
                return;
            }
            contactListItemCache.header.setVisibility(8);
        }

        public void changeCursor(Cursor cursor) {
            super.changeCursor(cursor);
            updateIndexer(cursor);
        }

        private void updateIndexer(Cursor cursor) {
            SectionIndexer sectionIndexer = this.mIndexer;
            if (sectionIndexer == null) {
                this.mIndexer = getNewIndexer(cursor);
            } else if (sectionIndexer instanceof AlphabetIndexer) {
                ((AlphabetIndexer) sectionIndexer).setCursor(cursor);
            } else {
                this.mIndexer = getNewIndexer(cursor);
            }
            int length = this.mIndexer.getSections().length;
            int[] iArr = this.mSectionPositions;
            if (iArr == null || iArr.length != length) {
                this.mSectionPositions = new int[length];
            }
            for (int i = 0; i < length; i++) {
                this.mSectionPositions[i] = -1;
            }
        }

        public Cursor runQueryOnBackgroundThread(CharSequence charSequence) {
            return ActivityContacts.this.doFilter(charSequence.toString());
        }

        public Object[] getSections() {
            return this.mIndexer.getSections();
        }

        public int getPositionForSection(int i) {
            if (i < 0 || i >= this.mSectionPositions.length) {
                return -1;
            }
            if (this.mIndexer == null) {
                Cursor cursor = ActivityContacts.this.mAdapter.getCursor();
                if (cursor == null) {
                    return 0;
                }
                this.mIndexer = getNewIndexer(cursor);
            }
            int[] iArr = this.mSectionPositions;
            int i2 = iArr[i];
            if (i2 == -1) {
                i2 = this.mIndexer.getPositionForSection(i);
                iArr[i] = i2;
            }
            return i2;
        }

        public int getSectionForPosition(int i) {
            int length = this.mSectionPositions.length;
            int i2 = 0;
            while (i2 != length) {
                int i3 = ((length - i2) / 4) + i2;
                if (getPositionForSection(i3) <= i) {
                    i2 = i3 + 1;
                } else {
                    length = i3;
                }
            }
            return i2 - 1;
        }

        public void onScrollStateChanged(AbsListView absListView, int i) {
            ActivityContacts.this.mScrollState = i;
            if (i == 2) {
                clearImageFetching();
            } else {
                processMissingImageItems(absListView);
            }
        }

        private void processMissingImageItems(AbsListView absListView) {
            Iterator it = this.mItemsMissingImages.iterator();
            while (it.hasNext()) {
                sendFetchImageMessage((ImageView) it.next());
            }
        }

        private void sendFetchImageMessage(ImageView imageView) {
            PhotoInfo photoInfo = (PhotoInfo) imageView.getTag();
            if (photoInfo != null) {
                long j = photoInfo.photoId;
                if (j != 0) {
                    this.mImageFetcher = new ImageDbFetcher(j, imageView);
                    synchronized (ActivityContacts.this) {
                        if (ActivityContacts.sImageFetchThreadPool == null) {
                            ActivityContacts.sImageFetchThreadPool = Executors.newFixedThreadPool(3);
                        }
                        ActivityContacts.sImageFetchThreadPool.execute(this.mImageFetcher);
                    }
                }
            }
        }

        public void clearImageFetching() {
            synchronized (ActivityContacts.this) {
                if (ActivityContacts.sImageFetchThreadPool != null) {
                    ActivityContacts.sImageFetchThreadPool.shutdownNow();
                    ActivityContacts.sImageFetchThreadPool = null;
                }
            }
            this.mHandler.clearImageFecthing();
        }
    }

    static final class ContactListItemCache {
        public View header;
        public TextView headerText;
        public CharArrayBuffer nameBuffer = new CharArrayBuffer(128);
        public TextView nameView;
        public ImageView nonQuickContactPhotoView;
        public ImageView selectedView;

        ContactListItemCache() {
        }
    }

    static abstract class Impl {
        static Uri CONTACTS_CONTENT_FILTER_URI = null;
        static Uri CONTACTS_CONTENT_URI = null;
        static String[] CONTACTS_PROJECTION = null;
        static String CONTACTS_SELECTION = null;
        static String NAME_COLUMN = null;
        static final int SUMMARY_ID_COLUMN_INDEX = 0;
        static final int SUMMARY_NAME_COLUMN_INDEX = 1;
        static final int SUMMARY_PHOTO_ID_COLUMN_INDEX = 2;

        /* access modifiers changed from: 0000 */
        public abstract Bitmap loadContactPhoto(Context context, long j, Options options);

        Impl() {
        }

        static Impl getImpl() {
            if (Integer.parseInt(VERSION.SDK) < 5) {
                return new ImplOld();
            }
            return new ImplNew();
        }
    }

    private static class ImplNew extends Impl {
        private ImplNew() {
        }

        static {
            String str = "display_name";
            NAME_COLUMN = str;
            CONTACTS_CONTENT_URI = Contacts.CONTENT_URI;
            CONTACTS_CONTENT_FILTER_URI = Contacts.CONTENT_FILTER_URI;
            CONTACTS_PROJECTION = new String[]{"_id", str, "photo_id"};
            if (!"amazon".equalsIgnoreCase(Build.BRAND) || !Build.MODEL.startsWith("KF")) {
                CONTACTS_SELECTION = "in_visible_group=1";
            } else {
                CONTACTS_SELECTION = null;
            }
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [android.database.Cursor] */
        /* JADX WARNING: type inference failed for: r0v2 */
        /* JADX WARNING: type inference failed for: r0v6 */
        /* access modifiers changed from: 0000 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x003a  */
        /* JADX WARNING: Unknown variable types count: 1 */
        public Bitmap loadContactPhoto(Context context, long j, Options options) {
            ? r0;
            Bitmap bitmap = 0;
            try {
                Cursor query = context.getContentResolver().query(ContentUris.withAppendedId(Data.CONTENT_URI, j), new String[]{"data15"}, null, null, null);
                try {
                    if (query.moveToFirst() && !query.isNull(0)) {
                        byte[] blob = query.getBlob(0);
                        bitmap = BitmapFactory.decodeByteArray(blob, 0, blob.length, options);
                    }
                    if (query != 0) {
                        query.close();
                    }
                    return bitmap;
                } catch (Throwable th) {
                    th = th;
                    r0 = query;
                    if (r0 != 0) {
                        r0.close();
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                r0 = bitmap;
                if (r0 != 0) {
                }
                throw th;
            }
        }
    }

    private static class ImplOld extends Impl {
        private ImplOld() {
        }

        static {
            String str = "display_name";
            NAME_COLUMN = str;
            CONTACTS_CONTENT_URI = People.CONTENT_URI;
            CONTACTS_CONTENT_FILTER_URI = People.CONTENT_FILTER_URI;
            String str2 = "_id";
            CONTACTS_PROJECTION = new String[]{str2, str, str2};
            CONTACTS_SELECTION = null;
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [android.database.Cursor] */
        /* JADX WARNING: type inference failed for: r0v2 */
        /* JADX WARNING: type inference failed for: r0v6 */
        /* access modifiers changed from: 0000 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x0044  */
        /* JADX WARNING: Unknown variable types count: 1 */
        public Bitmap loadContactPhoto(Context context, long j, Options options) {
            ? r0;
            Bitmap bitmap = 0;
            try {
                Cursor query = context.getContentResolver().query(Uri.withAppendedPath(Uri.withAppendedPath(People.CONTENT_URI, String.valueOf(j)), "photo"), new String[]{"data"}, null, null, null);
                try {
                    if (query.moveToFirst() && !query.isNull(0)) {
                        byte[] blob = query.getBlob(0);
                        bitmap = BitmapFactory.decodeByteArray(blob, 0, blob.length, options);
                    }
                    if (query != 0) {
                        query.close();
                    }
                    return bitmap;
                } catch (Throwable th) {
                    th = th;
                    r0 = query;
                    if (r0 != 0) {
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                r0 = bitmap;
                if (r0 != 0) {
                    r0.close();
                }
                throw th;
            }
        }
    }

    static final class PhotoInfo {
        public long photoId;
        public int position;

        public PhotoInfo(int i, long j) {
            this.position = i;
            this.photoId = j;
        }
    }

    private static class QueryHandler extends AsyncQueryHandler {
        protected final WeakReference<ActivityContacts> mActivity;

        public QueryHandler(Context context) {
            super(context.getContentResolver());
            this.mActivity = new WeakReference<>((ActivityContacts) context);
        }

        /* access modifiers changed from: protected */
        public void onQueryComplete(int i, Object obj, Cursor cursor) {
            ActivityContacts activityContacts = (ActivityContacts) this.mActivity.get();
            if (activityContacts == null || activityContacts.isFinishing()) {
                cursor.close();
            } else {
                activityContacts.mAdapter.setLoading(false);
                activityContacts.mListView.clearTextFilter();
                activityContacts.mAdapter.changeCursor(cursor);
                if (activityContacts.mListState != null) {
                    activityContacts.mListView.onRestoreInstanceState(activityContacts.mListState);
                    if (activityContacts.mListHasFocus) {
                        activityContacts.mListView.requestFocus();
                    }
                    activityContacts.mListHasFocus = false;
                    activityContacts.mListState = null;
                }
            }
            if (activityContacts.mAdapter.isEmpty()) {
                activityContacts.mListView.setVisibility(8);
                activityContacts.findViewById(R.id.empty).setVisibility(0);
                activityContacts.findViewById(R.id.button_print).setEnabled(false);
                return;
            }
            activityContacts.mListView.setVisibility(0);
            activityContacts.findViewById(R.id.empty).setVisibility(8);
            activityContacts.findViewById(R.id.button_print).setEnabled(true);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_contacts);
        ((TextView) findViewById(R.id.empty)).setText(R.string.label_no_contacts);
        Button button = (Button) findViewById(R.id.button_print);
        button.setEnabled(false);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SparseBooleanArray checkedItemPositions = ActivityContacts.this.mListView.getCheckedItemPositions();
                String str = "";
                String str2 = str;
                for (int i = 0; i < checkedItemPositions.size(); i++) {
                    if (checkedItemPositions.valueAt(i)) {
                        Cursor cursor = ActivityContacts.this.mAdapter.getCursor();
                        cursor.moveToPosition(checkedItemPositions.keyAt(i));
                        StringBuilder sb = new StringBuilder();
                        sb.append(str2);
                        sb.append(str2.length() > 0 ? "," : str);
                        sb.append(cursor.getString(0));
                        str2 = sb.toString();
                    }
                }
                if (str2.length() > 0) {
                    Intent intent = new Intent();
                    intent.setClass(ActivityContacts.this, ActivityPrintContacts.class);
                    intent.putExtra("data", str2);
                    ActivityContacts.this.startActivity(intent);
                    return;
                }
                Toast.makeText(ActivityContacts.this, R.string.toast_nothing_selected, 1).show();
            }
        });
        ListView listView = (ListView) findViewById(R.id.list);
        this.mListView = listView;
        listView.setFastScrollEnabled(true);
        this.mListView.setChoiceMode(2);
        this.mListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                View findViewById = view != null ? view.findViewById(R.id.selected) : null;
                if (findViewById != null) {
                    findViewById.setVisibility(ActivityContacts.this.mListView.isItemChecked(i) ? 0 : 8);
                }
            }
        });
        this.mListView.setFocusable(true);
        this.mListView.setOnCreateContextMenuListener(this);
        ContactItemListAdapter contactItemListAdapter = new ContactItemListAdapter(this);
        this.mAdapter = contactItemListAdapter;
        this.mListView.setAdapter(contactItemListAdapter);
        this.mListView.setOnScrollListener(this.mAdapter);
        this.mListView.setSaveEnabled(false);
        this.mQueryHandler = new QueryHandler(this);
        this.mJustCreated = true;
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.mAdapter.mBitmapCache != null) {
            this.mAdapter.mBitmapCache.clear();
        }
        this.mScrollState = 0;
        if (this.mJustCreated) {
            startQuery();
        }
        this.mJustCreated = false;
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
        if (TextUtils.isEmpty(this.mListView.getTextFilter())) {
            startQuery();
        } else {
            ((ContactItemListAdapter) this.mListView.getAdapter()).onContentChanged();
        }
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable(LIST_STATE_KEY, this.mListView.onSaveInstanceState());
        bundle.putBoolean(FOCUS_KEY, this.mListView.hasFocus());
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.mListState = bundle.getParcelable(LIST_STATE_KEY);
        this.mListHasFocus = bundle.getBoolean(FOCUS_KEY);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.mAdapter.setLoading(true);
        this.mAdapter.changeCursor(null);
        this.mAdapter.clearImageFetching();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, R.string.menu_select_all);
        menu.add(0, 2, 0, R.string.menu_unselect_all);
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 1) {
            for (int i2 = 0; i2 < this.mListView.getAdapter().getCount(); i2++) {
                this.mListView.setItemChecked(i2, true);
            }
            return true;
        } else if (itemId != 2) {
            return false;
        } else {
            for (int i3 = 0; i3 < this.mListView.getAdapter().getCount(); i3++) {
                this.mListView.setItemChecked(i3, false);
            }
            return true;
        }
    }

    /* access modifiers changed from: 0000 */
    public Uri getUriToQuery() {
        return Impl.CONTACTS_CONTENT_URI;
    }

    /* access modifiers changed from: 0000 */
    public String[] getProjectionForQuery() {
        return Impl.CONTACTS_PROJECTION;
    }

    private Uri getContactFilterUri(String str) {
        if (!TextUtils.isEmpty(str)) {
            return Uri.withAppendedPath(Impl.CONTACTS_CONTENT_FILTER_URI, Uri.encode(str));
        }
        return Impl.CONTACTS_CONTENT_URI;
    }

    private String getSortOrder(String[] strArr) {
        StringBuilder sb = new StringBuilder();
        sb.append(Impl.NAME_COLUMN);
        sb.append(" COLLATE LOCALIZED ASC");
        return sb.toString();
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x001f  */
    public void startQuery() {
        boolean z;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                z = true;
                if (z) {
                    final boolean[] zArr = new boolean[1];
                    new Object() {
                        {
                            String str = "android.permission.READ_CONTACTS";
                            if (ActivityContacts.this.checkSelfPermission(str) != 0) {
                                ActivityContacts.this.requestPermissions(new String[]{str}, 444555);
                                zArr[0] = true;
                            }
                        }
                    };
                    if (zArr[0]) {
                        return;
                    }
                }
                this.mAdapter.setLoading(true);
                this.mQueryHandler.cancelOperation(42);
                String[] projectionForQuery = getProjectionForQuery();
                this.mQueryHandler.startQuery(42, null, getUriToQuery(), projectionForQuery, Impl.CONTACTS_SELECTION, null, getSortOrder(projectionForQuery));
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        z = false;
        if (z) {
        }
        this.mAdapter.setLoading(true);
        this.mQueryHandler.cancelOperation(42);
        String[] projectionForQuery2 = getProjectionForQuery();
        this.mQueryHandler.startQuery(42, null, getUriToQuery(), projectionForQuery2, Impl.CONTACTS_SELECTION, null, getSortOrder(projectionForQuery2));
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        startQuery();
    }

    /* access modifiers changed from: 0000 */
    public Cursor doFilter(String str) {
        ContentResolver contentResolver = getContentResolver();
        String[] projectionForQuery = getProjectionForQuery();
        return contentResolver.query(getContactFilterUri(str), projectionForQuery, Impl.CONTACTS_SELECTION, null, getSortOrder(projectionForQuery));
    }

    /* access modifiers changed from: 0000 */
    public Cursor getItemForView(View view) {
        int positionForView = this.mListView.getPositionForView(view);
        if (positionForView < 0) {
            return null;
        }
        return (Cursor) this.mListView.getAdapter().getItem(positionForView);
    }
}
