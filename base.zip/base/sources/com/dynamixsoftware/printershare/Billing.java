package com.dynamixsoftware.printershare;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.RestrictionsManager;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.widget.TextView;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClient.SkuType;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.Purchase.PurchasesResult;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.flurry.android.FlurryAgent;
import com.flurry.android.FlurryConfig;
import com.google.android.play.core.assetpacks.AssetPackLocation;
import com.google.android.play.core.assetpacks.AssetPackManager;
import com.google.android.play.core.assetpacks.AssetPackManagerFactory;
import com.google.android.play.core.assetpacks.AssetPackState;
import com.google.android.play.core.assetpacks.AssetPackStateUpdateListener;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class Billing {
    public static final Action action = new Action();
    /* access modifiers changed from: private */
    public static final boolean[] flg = new boolean[1];
    /* access modifiers changed from: private */
    public static final Boolean[] is_prm = new Boolean[2];
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    public static class Action {
        public void run(Runnable runnable, Runnable runnable2) {
            if (Boolean.TRUE.equals(Billing.is_prm[0]) || Boolean.TRUE.equals(Billing.is_prm[1])) {
                if (runnable2 != null) {
                    runnable2.run();
                }
            } else if (runnable != null) {
                runnable.run();
            }
        }
    }

    public static void init(Activity activity) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0090, code lost:
        if (android.provider.Settings.Secure.getInt(r7.getContentResolver(), "install_non_market_apps", 0) == 0) goto L_0x0095;
     */
    public static void showUpgradeDialog(final ActivityCore activityCore) {
        final Hashtable createEventParams = activityCore.createEventParams();
        Builder builder = new Builder(activityCore);
        builder.setIcon(R.drawable.icon_title);
        builder.setTitle(R.string.dialog_premium_upgrade_title);
        builder.setMessage(R.string.dialog_premium_upgrade_text);
        final Intent intent = new Intent();
        String str = "android.intent.action.VIEW";
        intent.setAction(str);
        intent.setData(Uri.parse("market://details?id=com.dynamixsoftware.printershare.premium"));
        intent.setPackage("com.android.vending");
        final AnonymousClass1 r4 = new Runnable() {
            public void run() {
                String str = "0";
                final String string = FlurryConfig.getInstance().getString("subs_monthly_enabled", str);
                final String string2 = FlurryConfig.getInstance().getString("subs_enabled", str);
                final String string3 = FlurryConfig.getInstance().getString("inapp_enabled", str);
                String str2 = "1";
                if (str2.equals(string2) || str2.equals(string) || str2.equals(string3)) {
                    ActivityCore activityCore = activityCore;
                    activityCore.showProgress(activityCore.getResources().getString(R.string.label_processing));
                    activityCore.getWindow().getDecorView().post(new Runnable() {
                        public void run() {
                            final AnonymousClass1 r0 = new Runnable() {
                                public void run() {
                                    try {
                                        activityCore.hideProgress();
                                        activityCore.startActivity(intent);
                                        FlurryAgent.logEvent("btn_premium_google_key", (Map<String, String>) createEventParams);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                }
                            };
                            try {
                                final SkuDetails[] skuDetailsArr = new SkuDetails[3];
                                final BillingClient[] billingClientArr = {BillingClient.newBuilder(activityCore).setListener(new PurchasesUpdatedListener() {
                                    /* JADX WARNING: Removed duplicated region for block: B:40:0x009b A[SYNTHETIC, Splitter:B:40:0x009b] */
                                    /* JADX WARNING: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
                                    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                                        boolean z;
                                        try {
                                            int responseCode = billingResult.getResponseCode();
                                            if (responseCode == 0) {
                                                if (list != null) {
                                                    z = false;
                                                    for (Purchase purchase : list) {
                                                        try {
                                                            if (purchase.getPurchaseState() == 1) {
                                                                try {
                                                                    if (!purchase.isAcknowledged()) {
                                                                        try {
                                                                            billingClientArr[0].acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
                                                                                public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                                                                                    try {
                                                                                        if (billingResult.getResponseCode() != 0) {
                                                                                            StringBuilder sb = new StringBuilder();
                                                                                            sb.append("Billing error ");
                                                                                            sb.append(billingResult.getResponseCode());
                                                                                            sb.append(" | ");
                                                                                            sb.append(billingResult.getDebugMessage());
                                                                                            throw new Exception(sb.toString());
                                                                                        }
                                                                                    } catch (Exception e) {
                                                                                        e.printStackTrace();
                                                                                        App.reportThrowable(e);
                                                                                    }
                                                                                }
                                                                            });
                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                            App.reportThrowable(e);
                                                                        }
                                                                    }
                                                                    z = true;
                                                                } catch (Exception e2) {
                                                                    e = e2;
                                                                    z = true;
                                                                    e.printStackTrace();
                                                                    App.reportThrowable(e);
                                                                    billingClientArr[0].endConnection();
                                                                    if (!z) {
                                                                    }
                                                                }
                                                            }
                                                        } catch (Exception e3) {
                                                            e = e3;
                                                            e.printStackTrace();
                                                            App.reportThrowable(e);
                                                            billingClientArr[0].endConnection();
                                                            if (!z) {
                                                            }
                                                        }
                                                    }
                                                    billingClientArr[0].endConnection();
                                                    if (!z) {
                                                        try {
                                                            Billing.is_prm[1] = Boolean.valueOf(true);
                                                            Editor edit = activityCore.prefs.edit();
                                                            edit.putBoolean("prm1", Billing.is_prm[1].booleanValue());
                                                            edit.commit();
                                                            if (!activityCore.isFinishing()) {
                                                                activityCore.update();
                                                                return;
                                                            }
                                                            return;
                                                        } catch (Exception e4) {
                                                            e4.printStackTrace();
                                                            App.reportThrowable(e4);
                                                            return;
                                                        }
                                                    } else {
                                                        return;
                                                    }
                                                }
                                            } else if (responseCode != 7) {
                                                if (responseCode == 1) {
                                                    z = false;
                                                    billingClientArr[0].endConnection();
                                                    if (!z) {
                                                    }
                                                } else {
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append("Billing error ");
                                                    sb.append(billingResult.getResponseCode());
                                                    sb.append(" | ");
                                                    sb.append(billingResult.getDebugMessage());
                                                    throw new Exception(sb.toString());
                                                }
                                            }
                                            z = true;
                                        } catch (Exception e5) {
                                            e = e5;
                                            z = false;
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            billingClientArr[0].endConnection();
                                            if (!z) {
                                            }
                                        }
                                        try {
                                            billingClientArr[0].endConnection();
                                        } catch (Exception e6) {
                                            e6.printStackTrace();
                                            App.reportThrowable(e6);
                                        }
                                        if (!z) {
                                        }
                                    }
                                }).enablePendingPurchases().build()};
                                final AnonymousClass3 r3 = new Runnable() {
                                    public void run() {
                                        String str = " | ";
                                        String str2 = "Billing error ";
                                        final boolean[] zArr = new boolean[2];
                                        try {
                                            PurchasesResult queryPurchases = billingClientArr[0].queryPurchases(SkuType.INAPP);
                                            if (queryPurchases.getResponseCode() == 0) {
                                                List<Purchase> purchasesList = queryPurchases.getPurchasesList();
                                                if (purchasesList != null) {
                                                    for (Purchase purchase : purchasesList) {
                                                        if (purchase.getPurchaseState() == 1) {
                                                            zArr[0] = true;
                                                        } else if (purchase.getPurchaseState() == 2) {
                                                            zArr[1] = true;
                                                        }
                                                    }
                                                }
                                                try {
                                                    PurchasesResult queryPurchases2 = billingClientArr[0].queryPurchases(SkuType.SUBS);
                                                    if (queryPurchases2.getResponseCode() == 0) {
                                                        List<Purchase> purchasesList2 = queryPurchases2.getPurchasesList();
                                                        if (purchasesList2 != null) {
                                                            for (Purchase purchaseState : purchasesList2) {
                                                                if (purchaseState.getPurchaseState() == 1) {
                                                                    zArr[0] = true;
                                                                }
                                                            }
                                                        }
                                                        if (zArr[0]) {
                                                            try {
                                                                billingClientArr[0].endConnection();
                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                                App.reportThrowable(e);
                                                            }
                                                            try {
                                                                Billing.is_prm[1] = Boolean.valueOf(true);
                                                                Editor edit = activityCore.prefs.edit();
                                                                edit.putBoolean("prm1", Billing.is_prm[1].booleanValue());
                                                                edit.commit();
                                                                if (!activityCore.isFinishing()) {
                                                                    activityCore.update();
                                                                }
                                                            } catch (Exception e2) {
                                                                e2.printStackTrace();
                                                                App.reportThrowable(e2);
                                                            }
                                                        } else {
                                                            final ArrayList arrayList = new ArrayList();
                                                            final ArrayList arrayList2 = new ArrayList();
                                                            String str3 = "1";
                                                            String str4 = " ";
                                                            if (str3.equals(string) && skuDetailsArr[1] != null) {
                                                                StringBuilder sb = new StringBuilder();
                                                                sb.append(activityCore.getString(R.string.dialog_payment_options_label_monthly_subscription));
                                                                sb.append(str4);
                                                                sb.append(skuDetailsArr[1].getPrice());
                                                                arrayList.add(sb.toString());
                                                                arrayList2.add(Integer.valueOf(0));
                                                            }
                                                            if (str3.equals(string2) && skuDetailsArr[2] != null) {
                                                                StringBuilder sb2 = new StringBuilder();
                                                                sb2.append(activityCore.getString(R.string.dialog_payment_options_label_annual_subscription));
                                                                sb2.append(str4);
                                                                sb2.append(skuDetailsArr[2].getPrice());
                                                                arrayList.add(sb2.toString());
                                                                arrayList2.add(Integer.valueOf(1));
                                                            }
                                                            StringBuilder sb3 = new StringBuilder();
                                                            sb3.append(activityCore.getString(R.string.dialog_payment_options_label_onetime_payment));
                                                            String str5 = "";
                                                            if (skuDetailsArr[0] != null) {
                                                                StringBuilder sb4 = new StringBuilder();
                                                                sb4.append(str4);
                                                                sb4.append(skuDetailsArr[0].getPrice());
                                                                if (zArr[1]) {
                                                                    str5 = " (Pending)";
                                                                }
                                                                sb4.append(str5);
                                                                str5 = sb4.toString();
                                                            }
                                                            sb3.append(str5);
                                                            arrayList.add(sb3.toString());
                                                            arrayList2.add(Integer.valueOf(2));
                                                            final AnonymousClass1 r2 = new OnClickListener() {
                                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                                    int intValue = ((Integer) arrayList2.get(i)).intValue();
                                                                    if (intValue == 0) {
                                                                        try {
                                                                            billingClientArr[0].launchBillingFlow(activityCore, BillingFlowParams.newBuilder().setSkuDetails(skuDetailsArr[1]).build());
                                                                            FlurryAgent.logEvent("btn_premium_google_subs_monthly", (Map<String, String>) createEventParams);
                                                                            return;
                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                            App.reportThrowable(e);
                                                                        }
                                                                    } else if (intValue == 1) {
                                                                        try {
                                                                            billingClientArr[0].launchBillingFlow(activityCore, BillingFlowParams.newBuilder().setSkuDetails(skuDetailsArr[2]).build());
                                                                            FlurryAgent.logEvent("btn_premium_google_subs_annual", (Map<String, String>) createEventParams);
                                                                            return;
                                                                        } catch (Exception e2) {
                                                                            e2.printStackTrace();
                                                                            App.reportThrowable(e2);
                                                                        }
                                                                    } else if (intValue == 2) {
                                                                        try {
                                                                            if (!"1".equals(string3)) {
                                                                                activityCore.startActivity(intent);
                                                                                FlurryAgent.logEvent("btn_premium_google_key", (Map<String, String>) createEventParams);
                                                                            } else if (zArr[1]) {
                                                                                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/account/orderhistory"));
                                                                                intent.addFlags(1208483840);
                                                                                activityCore.startActivity(intent);
                                                                            } else {
                                                                                billingClientArr[0].launchBillingFlow(activityCore, BillingFlowParams.newBuilder().setSkuDetails(skuDetailsArr[0]).build());
                                                                                FlurryAgent.logEvent("btn_premium_google_inapp", (Map<String, String>) createEventParams);
                                                                                return;
                                                                            }
                                                                        } catch (Exception e3) {
                                                                            e3.printStackTrace();
                                                                            App.reportThrowable(e3);
                                                                        }
                                                                    }
                                                                    try {
                                                                        billingClientArr[0].endConnection();
                                                                    } catch (Exception e4) {
                                                                        e4.printStackTrace();
                                                                        App.reportThrowable(e4);
                                                                    }
                                                                }
                                                            };
                                                            if (arrayList.size() > 1) {
                                                                activityCore.runOnUiThread(new Runnable() {
                                                                    public void run() {
                                                                        try {
                                                                            AlertDialog create = new Builder(activityCore).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_payment_options_title).setItems((CharSequence[]) arrayList.toArray(new CharSequence[arrayList.size()]), r2).create();
                                                                            activityCore.hideProgress();
                                                                            create.show();
                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                            App.reportThrowable(e);
                                                                            r0.run();
                                                                        }
                                                                    }
                                                                });
                                                            } else {
                                                                activityCore.runOnUiThread(new Runnable() {
                                                                    public void run() {
                                                                        try {
                                                                            activityCore.hideProgress();
                                                                            r2.onClick(null, 0);
                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                            App.reportThrowable(e);
                                                                        }
                                                                    }
                                                                });
                                                            }
                                                        }
                                                    } else {
                                                        StringBuilder sb5 = new StringBuilder();
                                                        sb5.append(str2);
                                                        sb5.append(queryPurchases2.getResponseCode());
                                                        sb5.append(str);
                                                        sb5.append(queryPurchases2.getBillingResult().getDebugMessage());
                                                        throw new Exception(sb5.toString());
                                                    }
                                                } catch (Exception e3) {
                                                    e3.printStackTrace();
                                                    App.reportThrowable(e3);
                                                }
                                            } else {
                                                StringBuilder sb6 = new StringBuilder();
                                                sb6.append(str2);
                                                sb6.append(queryPurchases.getResponseCode());
                                                sb6.append(str);
                                                sb6.append(queryPurchases.getBillingResult().getDebugMessage());
                                                throw new Exception(sb6.toString());
                                            }
                                        } catch (Exception e4) {
                                            e4.printStackTrace();
                                            App.reportThrowable(e4);
                                        }
                                    }
                                };
                                final AnonymousClass4 r5 = new Runnable() {
                                    public void run() {
                                        try {
                                            ArrayList arrayList = new ArrayList();
                                            arrayList.add("subs_premium_annual");
                                            billingClientArr[0].querySkuDetailsAsync(SkuDetailsParams.newBuilder().setSkusList(arrayList).setType(SkuType.SUBS).build(), new SkuDetailsResponseListener() {
                                                public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                                                    try {
                                                        if (billingResult.getResponseCode() == 0) {
                                                            if (list != null && list.size() > 0) {
                                                                skuDetailsArr[2] = (SkuDetails) list.get(0);
                                                            }
                                                            r3.run();
                                                            return;
                                                        }
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append("Billing error ");
                                                        sb.append(billingResult.getResponseCode());
                                                        sb.append(" | ");
                                                        sb.append(billingResult.getDebugMessage());
                                                        throw new Exception(sb.toString());
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        App.reportThrowable(e);
                                                    }
                                                }
                                            });
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            r3.run();
                                        }
                                    }
                                };
                                final AnonymousClass5 r32 = new Runnable() {
                                    public void run() {
                                        try {
                                            ArrayList arrayList = new ArrayList();
                                            arrayList.add("subs_premium_montly");
                                            billingClientArr[0].querySkuDetailsAsync(SkuDetailsParams.newBuilder().setSkusList(arrayList).setType(SkuType.SUBS).build(), new SkuDetailsResponseListener() {
                                                public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                                                    try {
                                                        if (billingResult.getResponseCode() == 0) {
                                                            if (list != null && list.size() > 0) {
                                                                skuDetailsArr[1] = (SkuDetails) list.get(0);
                                                            }
                                                            r5.run();
                                                            return;
                                                        }
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append("Billing error ");
                                                        sb.append(billingResult.getResponseCode());
                                                        sb.append(" | ");
                                                        sb.append(billingResult.getDebugMessage());
                                                        throw new Exception(sb.toString());
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        App.reportThrowable(e);
                                                    }
                                                }
                                            });
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            r5.run();
                                        }
                                    }
                                };
                                final AnonymousClass6 r52 = new Runnable() {
                                    public void run() {
                                        try {
                                            ArrayList arrayList = new ArrayList();
                                            arrayList.add("inapp_premium");
                                            billingClientArr[0].querySkuDetailsAsync(SkuDetailsParams.newBuilder().setSkusList(arrayList).setType(SkuType.INAPP).build(), new SkuDetailsResponseListener() {
                                                public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                                                    try {
                                                        if (billingResult.getResponseCode() == 0) {
                                                            if (list != null && list.size() > 0) {
                                                                skuDetailsArr[0] = (SkuDetails) list.get(0);
                                                            }
                                                            r32.run();
                                                            return;
                                                        }
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append("Billing error ");
                                                        sb.append(billingResult.getResponseCode());
                                                        sb.append(" | ");
                                                        sb.append(billingResult.getDebugMessage());
                                                        throw new Exception(sb.toString());
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                        App.reportThrowable(e);
                                                    }
                                                }
                                            });
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            r32.run();
                                        }
                                    }
                                };
                                billingClientArr[0].startConnection(new BillingClientStateListener() {
                                    public void onBillingServiceDisconnected() {
                                    }

                                    public void onBillingSetupFinished(BillingResult billingResult) {
                                        try {
                                            if (billingResult.getResponseCode() == 0) {
                                                r52.run();
                                                return;
                                            }
                                            StringBuilder sb = new StringBuilder();
                                            sb.append("Billing error ");
                                            sb.append(billingResult.getResponseCode());
                                            sb.append(" | ");
                                            sb.append(billingResult.getDebugMessage());
                                            throw new Exception(sb.toString());
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            try {
                                                billingClientArr[0].endConnection();
                                            } catch (Exception e2) {
                                                e2.printStackTrace();
                                                App.reportThrowable(e2);
                                            }
                                            activityCore.runOnUiThread(r0);
                                        }
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                                App.reportThrowable(e);
                                r0.run();
                            }
                        }
                    });
                } else {
                    try {
                        activityCore.startActivity(intent);
                        FlurryAgent.logEvent("btn_premium_google_key", (Map<String, String>) createEventParams);
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
                FlurryAgent.logEvent("btn_premium_google", (Map<String, String>) createEventParams);
            }
        };
        final Intent intent2 = new Intent();
        intent2.setAction(str);
        intent2.addCategory("android.intent.category.BROWSABLE");
        StringBuilder sb = new StringBuilder();
        sb.append("http://www.printershare.com/action?name=buy-android-key&country=");
        sb.append(App.getUserCountry());
        intent2.setData(Uri.parse(sb.toString()));
        final AnonymousClass2 r3 = new Runnable() {
            /* JADX WARNING: Failed to process nested try/catch */
            /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x000a */
            public void run() {
                activityCore.startActivity(intent2);
                try {
                    activityCore.startActivity(Intent.createChooser(intent2, null));
                    FlurryAgent.logEvent("btn_premium_paypal", (Map<String, String>) createEventParams);
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
        };
        List queryIntentActivities = activityCore.getPackageManager().queryIntentActivities(intent, 65536);
        boolean z = true;
        boolean z2 = false;
        if (queryIntentActivities == null || queryIntentActivities.size() <= 0) {
            z = false;
        } else {
            if ("US".equals(App.getUserCountry())) {
            }
        }
        z2 = true;
        if (z) {
            builder.setPositiveButton(R.string.button_buynow_market_google, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    r4.run();
                }
            });
        }
        if (z2) {
            builder.setNeutralButton(R.string.button_buynow_online, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    r3.run();
                }
            });
        }
        builder.setNegativeButton(R.string.button_print_test_page, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent();
                intent.setClass(activityCore, ActivityPrintTestPage.class);
                activityCore.startActivity(intent);
            }
        });
        builder.show();
    }

    public static void checkPremiumKey(final ActivityRoot activityRoot) {
        PackageInfo packageInfo;
        String str = "prmd";
        String str2 = ".printershare";
        String str3 = "";
        String str4 = "prm0";
        Boolean bool = is_prm[0];
        Boolean valueOf = Boolean.valueOf(true);
        if (bool == null && !Boolean.TRUE.equals(is_prm[1])) {
            PackageInfo packageInfo2 = null;
            try {
                RestrictionsManager restrictionsManager = (RestrictionsManager) activityRoot.getSystemService("restrictions");
                Bundle applicationRestrictions = restrictionsManager != null ? restrictionsManager.getApplicationRestrictions() : null;
                if (applicationRestrictions != null) {
                    final String string = applicationRestrictions.getString("pid", str3);
                    if (string != null && string.length() > 0) {
                        new Thread() {
                            public void run() {
                                final int[] iArr = {0};
                                try {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append("http://www.printershare.com/device-activation.aspx?pid=");
                                    sb.append(string);
                                    sb.append("&device=");
                                    sb.append(App.getDeviceID());
                                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
                                    httpURLConnection.setConnectTimeout(NanoHTTPD.SOCKET_READ_TIMEOUT);
                                    httpURLConnection.setReadTimeout(NanoHTTPD.SOCKET_READ_TIMEOUT);
                                    httpURLConnection.setUseCaches(false);
                                    int responseCode = httpURLConnection.getResponseCode();
                                    if (responseCode == 200) {
                                        iArr[0] = -1;
                                    } else if (responseCode == 400) {
                                        iArr[0] = 1;
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    App.reportThrowable(e);
                                }
                                activityRoot.runOnUiThread(new Runnable() {
                                    public void run() {
                                        Billing.onActivityResult(activityRoot, 539, iArr[0], null);
                                    }
                                });
                            }
                        }.start();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            try {
                if (activityRoot.prefs.getBoolean(str4, false)) {
                    is_prm[0] = valueOf;
                }
                String packageName = activityRoot.getPackageName();
                try {
                    packageInfo = activityRoot.getPackageManager().getPackageInfo(packageName, 64);
                } catch (NameNotFoundException unused) {
                    packageInfo = null;
                }
                String str5 = ".premium";
                if (!packageName.endsWith(str2)) {
                    try {
                        StringBuilder sb = new StringBuilder();
                        sb.append(packageName);
                        sb.append(str5);
                        packageInfo2 = activityRoot.getPackageManager().getPackageInfo(sb.toString(), 64);
                    } catch (NameNotFoundException unused2) {
                    }
                }
                if (packageInfo2 == null) {
                    try {
                        int lastIndexOf = packageName.lastIndexOf(str2);
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(packageName.substring(0, lastIndexOf + 13));
                        sb2.append(str5);
                        packageInfo2 = activityRoot.getPackageManager().getPackageInfo(sb2.toString(), 64);
                    } catch (NameNotFoundException unused3) {
                    }
                }
                if (!(packageInfo == null || packageInfo2 == null)) {
                    if (packageInfo.signatures[0].toCharsString().equals(packageInfo2.signatures[0].toCharsString()) && packageInfo2.versionCode > 9) {
                        String format = sdf.format(new Date());
                        if (!activityRoot.prefs.getString(str, str3).equals(format) || !Boolean.TRUE.equals(is_prm[0])) {
                            activityRoot.showProgress(activityRoot.getResources().getString(R.string.label_processing));
                            final Intent intent = new Intent();
                            intent.setClassName(packageInfo2.packageName, "com.dynamixsoftware.printershare.premium.Validate");
                            intent.putExtra("device_id", App.getDeviceID());
                            activityRoot.getWindow().getDecorView().post(new Runnable() {
                                public void run() {
                                    try {
                                        activityRoot.startActivityForResult(intent, 539);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                        Billing.onActivityResult(activityRoot, 539, 0, null);
                                    }
                                }
                            });
                            Editor edit = activityRoot.prefs.edit();
                            edit.putString(str, format);
                            edit.commit();
                        }
                    }
                }
                if (Boolean.TRUE.equals(is_prm[0])) {
                    is_prm[0] = Boolean.valueOf(false);
                    Editor edit2 = activityRoot.prefs.edit();
                    edit2.putBoolean(str4, is_prm[0].booleanValue());
                    edit2.commit();
                    activityRoot.update();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }
        if (is_prm[1] == null && !Boolean.TRUE.equals(is_prm[0])) {
            try {
                if (activityRoot.prefs.getBoolean("prm1", false)) {
                    is_prm[1] = valueOf;
                }
                final BillingClient build = BillingClient.newBuilder(activityRoot).setListener(new PurchasesUpdatedListener() {
                    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
                    }
                }).enablePendingPurchases().build();
                build.startConnection(new BillingClientStateListener() {
                    public void onBillingServiceDisconnected() {
                    }

                    public void onBillingSetupFinished(BillingResult billingResult) {
                        boolean[] zArr = new boolean[2];
                        try {
                            String str = " | ";
                            String str2 = "Billing error ";
                            if (billingResult.getResponseCode() == 0) {
                                zArr[0] = true;
                                try {
                                    PurchasesResult queryPurchases = build.queryPurchases(SkuType.INAPP);
                                    if (queryPurchases.getResponseCode() == 0) {
                                        List<Purchase> purchasesList = queryPurchases.getPurchasesList();
                                        if (purchasesList != null) {
                                            for (Purchase purchase : purchasesList) {
                                                if (purchase.getPurchaseState() == 1) {
                                                    zArr[1] = true;
                                                    if (!purchase.isAcknowledged()) {
                                                        try {
                                                            build.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
                                                                public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                                                                    try {
                                                                        if (billingResult.getResponseCode() != 0) {
                                                                            StringBuilder sb = new StringBuilder();
                                                                            sb.append("Billing error ");
                                                                            sb.append(billingResult.getResponseCode());
                                                                            sb.append(" | ");
                                                                            sb.append(billingResult.getDebugMessage());
                                                                            throw new Exception(sb.toString());
                                                                        }
                                                                    } catch (Exception e) {
                                                                        e.printStackTrace();
                                                                        App.reportThrowable(e);
                                                                    }
                                                                }
                                                            });
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                            App.reportThrowable(e);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        try {
                                            PurchasesResult queryPurchases2 = build.queryPurchases(SkuType.SUBS);
                                            if (queryPurchases2.getResponseCode() == 0) {
                                                List<Purchase> purchasesList2 = queryPurchases2.getPurchasesList();
                                                if (purchasesList2 != null) {
                                                    for (Purchase purchase2 : purchasesList2) {
                                                        if (purchase2.getPurchaseState() == 1) {
                                                            zArr[1] = true;
                                                            if (!purchase2.isAcknowledged()) {
                                                                try {
                                                                    build.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase2.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
                                                                        public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                                                                            try {
                                                                                if (billingResult.getResponseCode() != 0) {
                                                                                    StringBuilder sb = new StringBuilder();
                                                                                    sb.append("Billing error ");
                                                                                    sb.append(billingResult.getResponseCode());
                                                                                    sb.append(" | ");
                                                                                    sb.append(billingResult.getDebugMessage());
                                                                                    throw new Exception(sb.toString());
                                                                                }
                                                                            } catch (Exception e) {
                                                                                e.printStackTrace();
                                                                                App.reportThrowable(e);
                                                                            }
                                                                        }
                                                                    });
                                                                } catch (Exception e2) {
                                                                    e2.printStackTrace();
                                                                    App.reportThrowable(e2);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                try {
                                                    build.endConnection();
                                                } catch (Exception e3) {
                                                    e3.printStackTrace();
                                                    App.reportThrowable(e3);
                                                }
                                                if (zArr[0]) {
                                                    try {
                                                        Billing.is_prm[1] = Boolean.valueOf(zArr[1]);
                                                        Editor edit = activityRoot.prefs.edit();
                                                        edit.putBoolean("prm1", Billing.is_prm[1].booleanValue());
                                                        edit.commit();
                                                        activityRoot.runOnUiThread(new Runnable() {
                                                            public void run() {
                                                                activityRoot.update();
                                                            }
                                                        });
                                                    } catch (Exception e4) {
                                                        e4.printStackTrace();
                                                        App.reportThrowable(e4);
                                                    }
                                                }
                                            } else {
                                                StringBuilder sb = new StringBuilder();
                                                sb.append(str2);
                                                sb.append(queryPurchases2.getResponseCode());
                                                sb.append(str);
                                                sb.append(queryPurchases2.getBillingResult().getDebugMessage());
                                                throw new Exception(sb.toString());
                                            }
                                        } catch (Exception e5) {
                                            e5.printStackTrace();
                                            App.reportThrowable(e5);
                                        }
                                    } else {
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append(str2);
                                        sb2.append(queryPurchases.getResponseCode());
                                        sb2.append(str);
                                        sb2.append(queryPurchases.getBillingResult().getDebugMessage());
                                        throw new Exception(sb2.toString());
                                    }
                                } catch (Exception e6) {
                                    e6.printStackTrace();
                                    App.reportThrowable(e6);
                                }
                            } else {
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append(str2);
                                sb3.append(billingResult.getResponseCode());
                                sb3.append(str);
                                sb3.append(billingResult.getDebugMessage());
                                throw new Exception(sb3.toString());
                            }
                        } catch (Exception e7) {
                            e7.printStackTrace();
                            App.reportThrowable(e7);
                        }
                    }
                });
            } catch (Exception e3) {
                e3.printStackTrace();
                App.reportThrowable(e3);
            }
        }
    }

    public static void onActivityResult(ActivityRoot activityRoot, int i, int i2, Intent intent) {
        if (i == 539) {
            if (i2 == -1) {
                is_prm[0] = Boolean.valueOf(true);
            } else if (i2 == 1) {
                is_prm[0] = Boolean.valueOf(false);
            }
            Boolean[] boolArr = is_prm;
            if (boolArr[0] == null) {
                boolArr[0] = Boolean.valueOf(true);
            }
            Editor edit = activityRoot.prefs.edit();
            edit.putBoolean("prm0", is_prm[0].booleanValue());
            edit.commit();
            if (!activityRoot.isFinishing()) {
                activityRoot.update();
                activityRoot.hideProgress();
                if (!is_prm[0].booleanValue()) {
                    try {
                        SpannableString spannableString = new SpannableString(activityRoot.getString(R.string.dialog_key_activation_error_text));
                        Linkify.addLinks(spannableString, 2);
                        ((TextView) new Builder(activityRoot).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_key_activation_error_title).setMessage(spannableString).setNeutralButton(R.string.button_ok, null).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
            }
        }
    }

    public static String getAssetPack(final ActivityCore activityCore, final String str) {
        try {
            final AssetPackManager instance = AssetPackManagerFactory.getInstance(activityCore.getApplicationContext());
            AssetPackLocation packLocation = instance.getPackLocation(str);
            if (packLocation == null) {
                synchronized (flg) {
                    flg[0] = false;
                }
                instance.registerListener(new AssetPackStateUpdateListener() {
                    public void onStateUpdate(AssetPackState assetPackState) {
                        if (str.equals(assetPackState.name())) {
                            switch (assetPackState.status()) {
                                case 1:
                                case 2:
                                case 3:
                                    final long bytesDownloaded = ((assetPackState.bytesDownloaded() * 60) / assetPackState.totalBytesToDownload()) + ((long) ((assetPackState.transferProgressPercentage() * 40) / 100));
                                    activityCore.runOnUiThread(new Runnable() {
                                        public void run() {
                                            long j = bytesDownloaded;
                                            if (j <= 0 || j > 100) {
                                                activityCore.showProgress(activityCore.getResources().getString(R.string.label_loading));
                                                return;
                                            }
                                            ActivityCore activityCore = activityCore;
                                            String string = activityCore.getResources().getString(R.string.label_loading_progress);
                                            StringBuilder sb = new StringBuilder();
                                            sb.append(bytesDownloaded);
                                            sb.append("%");
                                            activityCore.showProgress(String.format(string, new Object[]{sb.toString()}));
                                        }
                                    });
                                    return;
                                case 4:
                                case 5:
                                case 6:
                                    activityCore.runOnUiThread(new Runnable() {
                                        public void run() {
                                            activityCore.showProgress(activityCore.getResources().getString(R.string.label_processing));
                                        }
                                    });
                                    synchronized (Billing.flg) {
                                        Billing.flg[0] = true;
                                        Billing.flg.notifyAll();
                                    }
                                    return;
                                case 7:
                                    instance.showCellularDataConfirmation(activityCore).addOnSuccessListener(new OnSuccessListener<Integer>() {
                                        public void onSuccess(Integer num) {
                                            if (num.intValue() == 0) {
                                                try {
                                                    ArrayList arrayList = new ArrayList();
                                                    arrayList.add(str);
                                                    instance.cancel(arrayList);
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                    App.reportThrowable(e);
                                                }
                                            }
                                        }
                                    });
                                    return;
                                default:
                                    return;
                            }
                        }
                    }
                });
                ArrayList arrayList = new ArrayList();
                arrayList.add(str);
                instance.fetch(arrayList).addOnFailureListener(new OnFailureListener() {
                    public void onFailure(Exception exc) {
                        synchronized (Billing.flg) {
                            Billing.flg[0] = true;
                            Billing.flg.notifyAll();
                        }
                        exc.printStackTrace();
                        App.reportThrowable(exc);
                    }
                });
                synchronized (flg) {
                    if (!flg[0]) {
                        flg.wait();
                    }
                }
                instance.clearListeners();
                packLocation = instance.getPackLocation(str);
            }
            if (packLocation != null) {
                return packLocation.assetsPath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        return null;
    }

    public static void removeAssetPack(ActivityCore activityCore, String str) {
        try {
            AssetPackManagerFactory.getInstance(activityCore.getApplicationContext()).removePack(str);
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }
}
