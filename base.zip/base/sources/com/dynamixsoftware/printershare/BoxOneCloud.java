package com.dynamixsoftware.printershare;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.box.onecloud.android.BoxOneCloudReceiver;
import com.box.onecloud.android.OneCloudData;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class BoxOneCloud extends BoxOneCloudReceiver {
    public void onCreateFileRequested(Context context, OneCloudData oneCloudData) {
    }

    public void onEditFileRequested(Context context, OneCloudData oneCloudData) {
    }

    public void onViewFileRequested(Context context, OneCloudData oneCloudData) {
        try {
            String mimeType = oneCloudData.getMimeType();
            File tempDir = App.getTempDir();
            StringBuilder sb = new StringBuilder();
            sb.append("printershare_temp_file");
            sb.append(App.getExtByMimeType(mimeType));
            File file = new File(tempDir, sb.toString());
            InputStream inputStream = oneCloudData.getInputStream();
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[4096];
            while (true) {
                int read = inputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            fileOutputStream.close();
            inputStream.close();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.putExtra("temp_file", file.getAbsolutePath());
            if (mimeType.startsWith("image/")) {
                intent.setClass(context, ActivityPrintPictures.class);
            } else if (mimeType.equals(NanoHTTPD.MIME_HTML)) {
                intent.setClass(context, ActivityPrintWeb.class);
            } else if (mimeType.equals("application/pdf")) {
                intent.setClass(context, ActivityPrintPDF.class);
            } else {
                intent.setClass(context, ActivityPrintDocuments.class);
            }
            intent.setDataAndType(Uri.fromFile(file), mimeType);
            intent.setFlags(335544320);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }

    public void onLaunchRequested(Context context, OneCloudData oneCloudData) {
        Intent intent = new Intent(context, ActivityMain.class);
        intent.setFlags(335544320);
        context.startActivity(intent);
    }
}
