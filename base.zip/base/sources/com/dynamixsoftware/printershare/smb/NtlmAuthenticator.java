package com.dynamixsoftware.printershare.smb;

abstract class NtlmAuthenticator {
    private static NtlmAuthenticator auth;

    private NtlmPasswordAuthentication getNtlmPasswordAuthentication() {
        return null;
    }

    NtlmAuthenticator() {
    }

    static NtlmPasswordAuthentication requestNtlmPasswordAuthentication(String str, SmbAuthException smbAuthException) {
        NtlmPasswordAuthentication ntlmPasswordAuthentication;
        NtlmAuthenticator ntlmAuthenticator = auth;
        if (ntlmAuthenticator == null) {
            return null;
        }
        synchronized (ntlmAuthenticator) {
            ntlmPasswordAuthentication = auth.getNtlmPasswordAuthentication();
        }
        return ntlmPasswordAuthentication;
    }
}
