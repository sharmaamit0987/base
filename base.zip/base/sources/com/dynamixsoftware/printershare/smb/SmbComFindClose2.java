package com.dynamixsoftware.printershare.smb;

class SmbComFindClose2 extends ServerMessageBlock {
    private int sid;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComFindClose2(int i) {
        this.sid = i;
        this.command = 52;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.sid, bArr, i);
        return 2;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComFindClose2[");
        sb.append(super.toString());
        sb.append(",sid=");
        sb.append(this.sid);
        sb.append("]");
        return new String(sb.toString());
    }
}
