package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.ipp.IppAttribute;

class TransPeekNamedPipe extends SmbComTransaction {
    private int fid;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    TransPeekNamedPipe(String str, int i) {
        this.name = str;
        this.fid = i;
        this.command = 37;
        this.subCommand = IppAttribute.TYPE_ENUM;
        this.timeout = -1;
        this.maxParameterCount = 6;
        this.maxDataCount = 1;
        this.maxSetupCount = 0;
        this.setupCount = 2;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = this.subCommand;
        int i3 = i2 + 1;
        bArr[i2] = 0;
        writeInt2((long) this.fid, bArr, i3);
        return 4;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TransPeekNamedPipe[");
        sb.append(super.toString());
        sb.append(",pipeName=");
        sb.append(this.name);
        sb.append("]");
        return new String(sb.toString());
    }
}
