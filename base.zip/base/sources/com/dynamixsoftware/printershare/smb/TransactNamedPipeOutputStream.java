package com.dynamixsoftware.printershare.smb;

import java.io.IOException;

class TransactNamedPipeOutputStream extends SmbFileOutputStream {
    private boolean dcePipe;
    private String path;
    private SmbNamedPipe pipe;
    private byte[] tmp = new byte[1];

    TransactNamedPipeOutputStream(SmbNamedPipe smbNamedPipe) throws IOException {
        boolean z = false;
        super(smbNamedPipe, false, (smbNamedPipe.pipeType & -65281) | 32);
        this.pipe = smbNamedPipe;
        if ((smbNamedPipe.pipeType & SmbNamedPipe.PIPE_TYPE_DCE_TRANSACT) == 1536) {
            z = true;
        }
        this.dcePipe = z;
        this.path = smbNamedPipe.unc;
    }

    public void close() throws IOException {
        this.pipe.close();
    }

    public void write(int i) throws IOException {
        byte[] bArr = this.tmp;
        bArr[0] = (byte) i;
        write(bArr, 0, 1);
    }

    public void write(byte[] bArr) throws IOException {
        write(bArr, 0, bArr.length);
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        if (i2 < 0) {
            i2 = 0;
        }
        if ((this.pipe.pipeType & 256) == 256) {
            this.pipe.send(new TransWaitNamedPipe(this.path), new TransWaitNamedPipeResponse());
            this.pipe.send(new TransCallNamedPipe(this.path, bArr, i, i2), new TransCallNamedPipeResponse(this.pipe));
        } else if ((this.pipe.pipeType & 512) == 512) {
            ensureOpen();
            TransTransactNamedPipe transTransactNamedPipe = new TransTransactNamedPipe(this.pipe.fid, bArr, i, i2);
            if (this.dcePipe) {
                transTransactNamedPipe.maxDataCount = 1024;
            }
            this.pipe.send(transTransactNamedPipe, new TransTransactNamedPipeResponse(this.pipe));
        }
    }
}
