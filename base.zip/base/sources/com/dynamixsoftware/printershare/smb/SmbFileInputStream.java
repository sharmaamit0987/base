package com.dynamixsoftware.printershare.smb;

import com.flurry.android.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

public class SmbFileInputStream extends InputStream {
    private int access;
    private SmbFile file;
    private long fp;
    private int openFlags;
    private int readSize;
    private byte[] tmp = new byte[1];

    SmbFileInputStream(SmbFile smbFile, int i) throws SmbException, MalformedURLException, UnknownHostException {
        this.file = smbFile;
        this.openFlags = i & 65535;
        this.access = 65535 & (i >>> 16);
        if (smbFile.type != 16) {
            smbFile.open(i, this.access, 128, 0);
            this.openFlags &= -81;
        } else {
            smbFile.connect0();
        }
        this.readSize = Math.min(smbFile.tree.session.transport.rcv_buf_size - 70, smbFile.tree.session.transport.server.maxBufferSize - 70);
    }

    /* JADX WARNING: type inference failed for: r3v1, types: [java.io.IOException] */
    /* JADX WARNING: type inference failed for: r3v4, types: [com.dynamixsoftware.printershare.smb.TransportException] */
    /* JADX WARNING: type inference failed for: r0v2 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 2 */
    private IOException seToIoe(SmbException smbException) {
        Throwable cause = smbException.getCause();
        if (cause instanceof TransportException) {
            r3 = (TransportException) cause;
            cause = ((TransportException) r3).getCause();
            smbException = r3;
        }
        if (!(cause instanceof InterruptedException)) {
            return smbException;
        }
        InterruptedIOException interruptedIOException = new InterruptedIOException(cause.getMessage());
        interruptedIOException.initCause(cause);
        return interruptedIOException;
    }

    public void close() throws IOException {
        try {
            this.file.close();
            this.tmp = null;
        } catch (SmbException e) {
            throw seToIoe(e);
        }
    }

    public int read() throws IOException {
        if (read(this.tmp, 0, 1) == -1) {
            return -1;
        }
        return this.tmp[0] & Constants.UNKNOWN;
    }

    public int read(byte[] bArr) throws IOException {
        return read(bArr, 0, bArr.length);
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        return readDirect(bArr, i, i2);
    }

    public int readDirect(byte[] bArr, int i, int i2) throws IOException {
        int i3;
        int i4;
        if (i2 <= 0) {
            return 0;
        }
        long j = this.fp;
        if (this.tmp != null) {
            this.file.open(this.openFlags, this.access, 128, 0);
            SmbComReadAndXResponse smbComReadAndXResponse = new SmbComReadAndXResponse(bArr, i);
            do {
                i3 = this.readSize;
                if (i2 <= i3) {
                    i3 = i2;
                }
                try {
                    SmbComReadAndX smbComReadAndX = new SmbComReadAndX(this.file.fid, this.fp, i3, null);
                    if (this.file.type == 16) {
                        smbComReadAndX.remaining = 1024;
                        smbComReadAndX.maxCount = 1024;
                        smbComReadAndX.minCount = 1024;
                    }
                    this.file.send(smbComReadAndX, smbComReadAndXResponse);
                    i4 = smbComReadAndXResponse.dataLength;
                    if (i4 > 0) {
                        this.fp += (long) i4;
                        i2 -= i4;
                        smbComReadAndXResponse.off += i4;
                        if (i2 <= 0) {
                            break;
                        }
                    } else {
                        long j2 = this.fp;
                        return (int) (j2 - j > 0 ? j2 - j : -1);
                    }
                } catch (SmbException e) {
                    if (this.file.type == 16 && e.getNtStatus() == -1073741493) {
                        return -1;
                    }
                    throw seToIoe(e);
                }
            } while (i4 == i3);
            return (int) (this.fp - j);
        }
        throw new IOException("Bad file descriptor");
    }

    public int available() throws IOException {
        if (this.file.type != 16) {
            return 0;
        }
        try {
            SmbNamedPipe smbNamedPipe = (SmbNamedPipe) this.file;
            this.file.open(32, smbNamedPipe.pipeType & 16711680, 128, 0);
            TransPeekNamedPipe transPeekNamedPipe = new TransPeekNamedPipe(this.file.unc, this.file.fid);
            TransPeekNamedPipeResponse transPeekNamedPipeResponse = new TransPeekNamedPipeResponse(smbNamedPipe);
            smbNamedPipe.send(transPeekNamedPipe, transPeekNamedPipeResponse);
            if (transPeekNamedPipeResponse.status != 1) {
                if (transPeekNamedPipeResponse.status != 4) {
                    return transPeekNamedPipeResponse.available;
                }
            }
            this.file.opened = false;
            return 0;
        } catch (SmbException e) {
            throw seToIoe(e);
        }
    }

    public long skip(long j) throws IOException {
        if (j <= 0) {
            return 0;
        }
        this.fp += j;
        return j;
    }
}
