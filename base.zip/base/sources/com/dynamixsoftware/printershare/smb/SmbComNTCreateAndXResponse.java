package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.util.Date;

class SmbComNTCreateAndXResponse extends AndXServerMessageBlock {
    private long allocationSize;
    private long changeTime;
    private int createAction;
    private long creationTime;
    private int deviceState;
    private boolean directory;
    private long endOfFile;
    private int extFileAttributes;
    int fid;
    private int fileType;
    boolean isExtended;
    private long lastAccessTime;
    private long lastWriteTime;
    private byte oplockLevel;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComNTCreateAndXResponse() {
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        this.oplockLevel = bArr[i];
        this.fid = readInt2(bArr, i2);
        int i3 = i2 + 2;
        this.createAction = readInt4(bArr, i3);
        int i4 = i3 + 4;
        this.creationTime = readTime(bArr, i4);
        int i5 = i4 + 8;
        this.lastAccessTime = readTime(bArr, i5);
        int i6 = i5 + 8;
        this.lastWriteTime = readTime(bArr, i6);
        int i7 = i6 + 8;
        this.changeTime = readTime(bArr, i7);
        int i8 = i7 + 8;
        this.extFileAttributes = readInt4(bArr, i8);
        int i9 = i8 + 4;
        this.allocationSize = readInt8(bArr, i9);
        int i10 = i9 + 8;
        this.endOfFile = readInt8(bArr, i10);
        int i11 = i10 + 8;
        this.fileType = readInt2(bArr, i11);
        int i12 = i11 + 2;
        this.deviceState = readInt2(bArr, i12);
        int i13 = i12 + 2;
        int i14 = i13 + 1;
        this.directory = (bArr[i13] & Constants.UNKNOWN) > 0;
        return i14 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComNTCreateAndXResponse[");
        sb.append(super.toString());
        sb.append(",oplockLevel=");
        sb.append(this.oplockLevel);
        sb.append(",fid=");
        sb.append(this.fid);
        sb.append(",createAction=0x");
        sb.append(Dumper.toHexString(this.createAction, 4));
        sb.append(",creationTime=");
        sb.append(new Date(this.creationTime));
        sb.append(",lastAccessTime=");
        sb.append(new Date(this.lastAccessTime));
        sb.append(",lastWriteTime=");
        sb.append(new Date(this.lastWriteTime));
        sb.append(",changeTime=");
        sb.append(new Date(this.changeTime));
        sb.append(",extFileAttributes=0x");
        sb.append(Dumper.toHexString(this.extFileAttributes, 4));
        sb.append(",allocationSize=");
        sb.append(this.allocationSize);
        sb.append(",endOfFile=");
        sb.append(this.endOfFile);
        sb.append(",fileType=");
        sb.append(this.fileType);
        sb.append(",deviceState=");
        sb.append(this.deviceState);
        sb.append(",directory=");
        sb.append(this.directory);
        sb.append("]");
        return new String(sb.toString());
    }
}
