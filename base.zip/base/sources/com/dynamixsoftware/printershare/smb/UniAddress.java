package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.App;
import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;

class UniAddress {
    private static final int RESOLVER_BCAST = 1;
    private static final int RESOLVER_DNS = 2;
    private static final int RESOLVER_WINS = 0;
    private static int[] resolveOrder;
    private Object addr;
    private String calledName;

    private static class QueryThread extends Thread {
        /* access modifiers changed from: private */
        public NbtAddress ans;
        private String host;
        private String scope;
        private Sem sem;
        private InetAddress svr;
        private int type;
        /* access modifiers changed from: private */
        public UnknownHostException uhe;

        private QueryThread(Sem sem2, String str, int i, String str2, InetAddress inetAddress) {
            StringBuilder sb = new StringBuilder();
            sb.append("QueryThread: ");
            sb.append(str);
            super(sb.toString());
            this.ans = null;
            this.sem = sem2;
            this.host = str;
            this.type = i;
            this.scope = str2;
            this.svr = inetAddress;
        }

        /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
        public void run() {
            try {
                this.ans = NbtAddress.getByName(this.host, this.type, this.scope, this.svr);
                synchronized (this.sem) {
                    this.sem.count = this.sem.count - 1;
                    this.sem.notify();
                }
            } catch (UnknownHostException e) {
                this.uhe = e;
                synchronized (this.sem) {
                    this.sem.count = this.sem.count - 1;
                    this.sem.notify();
                }
            } catch (Exception e2) {
                try {
                    this.uhe = new UnknownHostException(e2.getMessage());
                    synchronized (this.sem) {
                        this.sem.count = this.sem.count - 1;
                        this.sem.notify();
                    }
                } catch (Throwable th) {
                    synchronized (this.sem) {
                        this.sem.count = this.sem.count - 1;
                        this.sem.notify();
                        throw th;
                    }
                }
            }
        }
    }

    private static class Sem {
        /* access modifiers changed from: private */
        public int count;

        private Sem(int i) {
            this.count = i;
        }
    }

    static {
        if (NbtAddress.getWINSAddress() == null) {
            int[] iArr = new int[2];
            resolveOrder = iArr;
            iArr[0] = 1;
            iArr[1] = 2;
            return;
        }
        int[] iArr2 = new int[3];
        resolveOrder = iArr2;
        iArr2[0] = 1;
        iArr2[1] = 0;
        iArr2[2] = 2;
    }

    private static NbtAddress lookupServerOrWorkgroup(String str, InetAddress inetAddress) throws UnknownHostException {
        Sem sem = new Sem(2);
        Sem sem2 = sem;
        String str2 = str;
        InetAddress inetAddress2 = inetAddress;
        QueryThread queryThread = new QueryThread(sem2, str2, NbtAddress.isWINS(inetAddress) ? 27 : 29, null, inetAddress2);
        QueryThread queryThread2 = new QueryThread(sem2, str2, 0, null, inetAddress2);
        queryThread.setDaemon(true);
        queryThread2.setDaemon(true);
        try {
            synchronized (sem) {
                queryThread.start();
                queryThread2.start();
                while (sem.count > 0 && queryThread.ans == null && queryThread2.ans == null) {
                    sem.wait();
                }
            }
            if (queryThread.ans != null) {
                return queryThread.ans;
            }
            if (queryThread2.ans != null) {
                return queryThread2.ans;
            }
            throw queryThread.uhe;
        } catch (InterruptedException unused) {
            throw new UnknownHostException(str);
        }
    }

    static UniAddress getByName(String str) throws UnknownHostException {
        return getByName(str, false);
    }

    private static boolean isDotQuadIP(String str) {
        if (Character.isDigit(str.charAt(0))) {
            int length = str.length();
            char[] charArray = str.toCharArray();
            int i = 0;
            int i2 = 0;
            while (i < length) {
                int i3 = i + 1;
                if (!Character.isDigit(charArray[i])) {
                    break;
                } else if (i3 == length && i2 == 3) {
                    return true;
                } else {
                    if (i3 >= length || charArray[i3] != '.') {
                        i = i3;
                    } else {
                        i2++;
                        i = i3 + 1;
                    }
                }
            }
        }
        return false;
    }

    private static boolean isAllDigits(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static UniAddress getByName(String str, boolean z) throws UnknownHostException {
        return getAllByName(str, z)[0];
    }

    static UniAddress[] getAllByName(String str, boolean z) throws UnknownHostException {
        if (str == null || str.length() == 0) {
            throw new UnknownHostException();
        } else if (isDotQuadIP(str)) {
            return new UniAddress[]{new UniAddress(NbtAddress.getByName(str))};
        } else {
            NbtAddress nbtAddress = null;
            int i = 0;
            while (true) {
                int[] iArr = resolveOrder;
                if (i < iArr.length) {
                    try {
                        int i2 = iArr[i];
                        if (i2 == 0) {
                            if (str == NbtAddress.MASTER_BROWSER_NAME) {
                                continue;
                            } else if (str.length() <= 15) {
                                if (z) {
                                    nbtAddress = lookupServerOrWorkgroup(str, NbtAddress.getWINSAddress());
                                } else {
                                    nbtAddress = NbtAddress.getByName(str, 0, null, NbtAddress.getWINSAddress());
                                }
                            }
                            i++;
                        } else if (i2 != 1) {
                            if (i2 != 2) {
                                throw new UnknownHostException(str);
                            } else if (!isAllDigits(str)) {
                                InetAddress[] allByName = InetAddress.getAllByName(str);
                                UniAddress[] uniAddressArr = new UniAddress[allByName.length];
                                for (int i3 = 0; i3 < allByName.length; i3++) {
                                    uniAddressArr[i3] = new UniAddress(allByName[i3]);
                                }
                                return uniAddressArr;
                            } else {
                                throw new UnknownHostException(str);
                            }
                        } else if (str.length() > 15) {
                            i++;
                        } else {
                            Vector broadcastAdrresses = App.getBroadcastAdrresses();
                            int i4 = 0;
                            while (true) {
                                if (i4 < broadcastAdrresses.size()) {
                                    if (!z) {
                                        nbtAddress = NbtAddress.getByName(str, 0, null, (InetAddress) broadcastAdrresses.get(i4));
                                        break;
                                    }
                                    try {
                                        nbtAddress = lookupServerOrWorkgroup(str, (InetAddress) broadcastAdrresses.get(i4));
                                        break;
                                    } catch (UnknownHostException unused) {
                                        i4++;
                                    }
                                } else {
                                    break;
                                }
                            }
                            if (nbtAddress != null) {
                                break;
                            }
                            throw new UnknownHostException(str);
                        }
                    } catch (IOException unused2) {
                    }
                } else {
                    throw new UnknownHostException(str);
                }
            }
            return new UniAddress[]{new UniAddress(nbtAddress)};
        }
    }

    private UniAddress(Object obj) {
        if (obj != null) {
            this.addr = obj;
            return;
        }
        throw new IllegalArgumentException();
    }

    public int hashCode() {
        return this.addr.hashCode();
    }

    public boolean equals(Object obj) {
        return (obj instanceof UniAddress) && this.addr.equals(((UniAddress) obj).addr);
    }

    /* access modifiers changed from: 0000 */
    public String firstCalledName() {
        Object obj = this.addr;
        if (obj instanceof NbtAddress) {
            return ((NbtAddress) obj).firstCalledName();
        }
        String hostName = ((InetAddress) obj).getHostName();
        this.calledName = hostName;
        boolean isDotQuadIP = isDotQuadIP(hostName);
        String str = NbtAddress.SMBSERVER_NAME;
        if (isDotQuadIP) {
            this.calledName = str;
        } else {
            int indexOf = this.calledName.indexOf(46);
            if (indexOf > 1 && indexOf < 15) {
                this.calledName = this.calledName.substring(0, indexOf).toUpperCase();
            } else if (this.calledName.length() > 15) {
                this.calledName = str;
            } else {
                this.calledName = this.calledName.toUpperCase();
            }
        }
        return this.calledName;
    }

    /* access modifiers changed from: 0000 */
    public String nextCalledName() {
        Object obj = this.addr;
        if (obj instanceof NbtAddress) {
            return ((NbtAddress) obj).nextCalledName();
        }
        String str = this.calledName;
        String str2 = NbtAddress.SMBSERVER_NAME;
        if (str == str2) {
            return null;
        }
        this.calledName = str2;
        return str2;
    }

    public Object getAddress() {
        return this.addr;
    }

    public String getHostName() {
        Object obj = this.addr;
        if (obj instanceof NbtAddress) {
            return ((NbtAddress) obj).getHostName();
        }
        return ((InetAddress) obj).getHostName();
    }

    public String getHostAddress() {
        Object obj = this.addr;
        if (obj instanceof NbtAddress) {
            return ((NbtAddress) obj).getHostAddress();
        }
        return ((InetAddress) obj).getHostAddress();
    }

    public String toString() {
        return this.addr.toString();
    }
}
