package com.dynamixsoftware.printershare.smb;

import java.io.UnsupportedEncodingException;

class SmbComTreeConnectAndXResponse extends AndXServerMessageBlock {
    private static final int SMB_SHARE_IS_IN_DFS = 2;
    private static final int SMB_SUPPORT_SEARCH_BITS = 1;
    private String nativeFileSystem = "";
    String service;
    boolean shareIsInDfs;
    private boolean supportSearchBits;

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComTreeConnectAndXResponse(ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        boolean z = true;
        this.supportSearchBits = (bArr[i] & 1) == 1;
        if ((bArr[i] & 2) != 2) {
            z = false;
        }
        this.shareIsInDfs = z;
        return 2;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        int readStringLength = readStringLength(bArr, i, 32);
        try {
            this.service = new String(bArr, i, readStringLength, "ASCII");
            return ((readStringLength + 1) + i) - i;
        } catch (UnsupportedEncodingException unused) {
            return 0;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComTreeConnectAndXResponse[");
        sb.append(super.toString());
        sb.append(",supportSearchBits=");
        sb.append(this.supportSearchBits);
        sb.append(",shareIsInDfs=");
        sb.append(this.shareIsInDfs);
        sb.append(",service=");
        sb.append(this.service);
        sb.append(",nativeFileSystem=");
        sb.append(this.nativeFileSystem);
        sb.append("]");
        return new String(sb.toString());
    }
}
