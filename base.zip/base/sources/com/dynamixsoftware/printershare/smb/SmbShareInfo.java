package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;

public class SmbShareInfo implements FileEntry {
    protected String netName;
    protected String remark;
    protected int type;

    public long createTime() {
        return 0;
    }

    public int getAttributes() {
        return 17;
    }

    public long lastModified() {
        return 0;
    }

    public long length() {
        return 0;
    }

    public String getName() {
        return this.netName;
    }

    public int getType() {
        int i = this.type & 65535;
        if (i != 1) {
            return i != 3 ? 8 : 16;
        }
        return 32;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof SmbShareInfo)) {
            return false;
        }
        return this.netName.equals(((SmbShareInfo) obj).netName);
    }

    public int hashCode() {
        return this.netName.hashCode();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbShareInfo[netName=");
        sb.append(this.netName);
        sb.append(",type=0x");
        sb.append(Dumper.toHexString(this.type, 8));
        sb.append(",remark=");
        sb.append(this.remark);
        sb.append("]");
        return new String(sb.toString());
    }
}
