package com.dynamixsoftware.printershare.smb;

import java.io.UnsupportedEncodingException;
import java.util.Date;

class Trans2FindFirst2Response extends SmbComTransactionResponse {
    private int eaErrorOffset;
    boolean isEndOfSearch;
    String lastName;
    private int lastNameBufferIndex;
    private int lastNameOffset;
    int resumeKey;
    int sid;

    private class SmbFindFileBothDirectoryInfo implements FileEntry {
        private long allocationSize;
        private long changeTime;
        /* access modifiers changed from: private */
        public long creationTime;
        private int eaSize;
        /* access modifiers changed from: private */
        public long endOfFile;
        /* access modifiers changed from: private */
        public int extFileAttributes;
        /* access modifiers changed from: private */
        public int fileIndex;
        /* access modifiers changed from: private */
        public int fileNameLength;
        /* access modifiers changed from: private */
        public String filename;
        private long lastAccessTime;
        /* access modifiers changed from: private */
        public long lastWriteTime;
        /* access modifiers changed from: private */
        public int nextEntryOffset;
        private String shortName;
        private int shortNameLength;

        public int getType() {
            return 1;
        }

        private SmbFindFileBothDirectoryInfo() {
        }

        public String getName() {
            return this.filename;
        }

        public int getAttributes() {
            return this.extFileAttributes;
        }

        public long createTime() {
            return this.creationTime;
        }

        public long lastModified() {
            return this.lastWriteTime;
        }

        public long length() {
            return this.endOfFile;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("SmbFindFileBothDirectoryInfo[nextEntryOffset=");
            sb.append(this.nextEntryOffset);
            sb.append(",fileIndex=");
            sb.append(this.fileIndex);
            sb.append(",creationTime=");
            sb.append(new Date(this.creationTime));
            sb.append(",lastAccessTime=");
            sb.append(new Date(this.lastAccessTime));
            sb.append(",lastWriteTime=");
            sb.append(new Date(this.lastWriteTime));
            sb.append(",changeTime=");
            sb.append(new Date(this.changeTime));
            sb.append(",endOfFile=");
            sb.append(this.endOfFile);
            sb.append(",allocationSize=");
            sb.append(this.allocationSize);
            sb.append(",extFileAttributes=");
            sb.append(this.extFileAttributes);
            sb.append(",fileNameLength=");
            sb.append(this.fileNameLength);
            sb.append(",eaSize=");
            sb.append(this.eaSize);
            sb.append(",shortNameLength=");
            sb.append(this.shortNameLength);
            sb.append(",shortName=");
            sb.append(this.shortName);
            sb.append(",filename=");
            sb.append(this.filename);
            sb.append("]");
            return new String(sb.toString());
        }
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    Trans2FindFirst2Response() {
        this.command = 50;
        this.subCommand = 1;
    }

    private String readString(byte[] bArr, int i, int i2) {
        try {
            if (this.useUnicode) {
                return new String(bArr, i, i2, SmbConstants.UNI_ENCODING);
            }
            if (i2 > 0 && bArr[(i + i2) - 1] == 0) {
                i2--;
            }
            return new String(bArr, i, i2, SmbConstants.OEM_ENCODING);
        } catch (UnsupportedEncodingException unused) {
            return null;
        }
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        int i3;
        boolean z = true;
        if (this.subCommand == 1) {
            this.sid = readInt2(bArr, i);
            i3 = i + 2;
        } else {
            i3 = i;
        }
        this.numEntries = readInt2(bArr, i3);
        int i4 = i3 + 2;
        if ((bArr[i4] & 1) != 1) {
            z = false;
        }
        this.isEndOfSearch = z;
        int i5 = i4 + 2;
        this.eaErrorOffset = readInt2(bArr, i5);
        int i6 = i5 + 2;
        this.lastNameOffset = readInt2(bArr, i6);
        return (i6 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        this.lastNameBufferIndex = this.lastNameOffset + i;
        this.results = new SmbFindFileBothDirectoryInfo[this.numEntries];
        for (int i3 = 0; i3 < this.numEntries; i3++) {
            FileEntry[] fileEntryArr = this.results;
            SmbFindFileBothDirectoryInfo smbFindFileBothDirectoryInfo = new SmbFindFileBothDirectoryInfo();
            fileEntryArr[i3] = smbFindFileBothDirectoryInfo;
            smbFindFileBothDirectoryInfo.nextEntryOffset = readInt4(bArr, i);
            smbFindFileBothDirectoryInfo.fileIndex = readInt4(bArr, i + 4);
            smbFindFileBothDirectoryInfo.creationTime = readTime(bArr, i + 8);
            smbFindFileBothDirectoryInfo.lastWriteTime = readTime(bArr, i + 24);
            smbFindFileBothDirectoryInfo.endOfFile = readInt8(bArr, i + 40);
            smbFindFileBothDirectoryInfo.extFileAttributes = readInt4(bArr, i + 56);
            smbFindFileBothDirectoryInfo.fileNameLength = readInt4(bArr, i + 60);
            smbFindFileBothDirectoryInfo.filename = readString(bArr, i + 94, smbFindFileBothDirectoryInfo.fileNameLength);
            if (this.lastNameBufferIndex >= i && (smbFindFileBothDirectoryInfo.nextEntryOffset == 0 || this.lastNameBufferIndex < smbFindFileBothDirectoryInfo.nextEntryOffset + i)) {
                this.lastName = smbFindFileBothDirectoryInfo.filename;
                this.resumeKey = smbFindFileBothDirectoryInfo.fileIndex;
            }
            i += smbFindFileBothDirectoryInfo.nextEntryOffset;
        }
        return this.dataCount;
    }

    public String toString() {
        String str = this.subCommand == 1 ? "Trans2FindFirst2Response[" : "Trans2FindNext2Response[";
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(super.toString());
        sb.append(",sid=");
        sb.append(this.sid);
        sb.append(",searchCount=");
        sb.append(this.numEntries);
        sb.append(",isEndOfSearch=");
        sb.append(this.isEndOfSearch);
        sb.append(",eaErrorOffset=");
        sb.append(this.eaErrorOffset);
        sb.append(",lastNameOffset=");
        sb.append(this.lastNameOffset);
        sb.append(",lastName=");
        sb.append(this.lastName);
        sb.append("]");
        return new String(sb.toString());
    }
}
