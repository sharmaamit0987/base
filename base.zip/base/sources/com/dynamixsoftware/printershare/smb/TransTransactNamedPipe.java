package com.dynamixsoftware.printershare.smb;

class TransTransactNamedPipe extends SmbComTransaction {
    private byte[] pipeData;
    private int pipeDataLen;
    private int pipeDataOff;
    private int pipeFid;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    TransTransactNamedPipe(int i, byte[] bArr, int i2, int i3) {
        this.pipeFid = i;
        this.pipeData = bArr;
        this.pipeDataOff = i2;
        this.pipeDataLen = i3;
        this.command = 37;
        this.subCommand = 38;
        this.maxParameterCount = 0;
        this.maxDataCount = 65535;
        this.maxSetupCount = 0;
        this.setupCount = 2;
        this.name = "\\PIPE\\";
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = this.subCommand;
        int i3 = i2 + 1;
        bArr[i2] = 0;
        writeInt2((long) this.pipeFid, bArr, i3);
        return 4;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        int length = bArr.length - i;
        int i2 = this.pipeDataLen;
        if (length < i2) {
            return 0;
        }
        System.arraycopy(this.pipeData, this.pipeDataOff, bArr, i, i2);
        return this.pipeDataLen;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TransTransactNamedPipe[");
        sb.append(super.toString());
        sb.append(",pipeFid=");
        sb.append(this.pipeFid);
        sb.append("]");
        return new String(sb.toString());
    }
}
