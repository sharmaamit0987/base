package com.dynamixsoftware.printershare.smb.netbios;

class NameQueryRequest extends NameServicePacket {
    /* access modifiers changed from: 0000 */
    public int readRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NameQueryRequest(Name name) {
        this.questionName = name;
        this.questionType = 32;
    }

    /* access modifiers changed from: 0000 */
    public int writeBodyWireFormat(byte[] bArr, int i) {
        return writeQuestionSectionWireFormat(bArr, i);
    }

    /* access modifiers changed from: 0000 */
    public int readBodyWireFormat(byte[] bArr, int i) {
        return readQuestionSectionWireFormat(bArr, i);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NameQueryRequest[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
