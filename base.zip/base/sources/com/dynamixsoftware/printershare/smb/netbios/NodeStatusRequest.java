package com.dynamixsoftware.printershare.smb.netbios;

class NodeStatusRequest extends NameServicePacket {
    /* access modifiers changed from: 0000 */
    public int readBodyWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NodeStatusRequest(Name name) {
        this.questionName = name;
        this.questionType = 33;
        this.isRecurDesired = false;
        this.isBroadcast = false;
    }

    /* access modifiers changed from: 0000 */
    public int writeBodyWireFormat(byte[] bArr, int i) {
        int i2 = this.questionName.hexCode;
        this.questionName.hexCode = 0;
        int writeQuestionSectionWireFormat = writeQuestionSectionWireFormat(bArr, i);
        this.questionName.hexCode = i2;
        return writeQuestionSectionWireFormat;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NodeStatusRequest[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
