package com.dynamixsoftware.printershare.smb.netbios;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.net.InetAddress;

abstract class NameServicePacket {
    private static final int A = 1;
    private static final int ADDITIONAL_OFFSET = 10;
    private static final int ANSWER_OFFSET = 6;
    private static final int AUTHORITY_OFFSET = 8;
    private static final int HEADER_LENGTH = 12;
    private static final int IN = 1;
    static final int NB = 32;
    static final int NBSTAT = 33;
    private static final int NS = 2;
    private static final int NULL = 10;
    private static final int OPCODE_OFFSET = 2;
    static final int QUERY = 0;
    private static final int QUESTION_OFFSET = 4;
    private static final int WACK = 7;
    private int additionalCount;
    InetAddress addr;
    NbtAddress[] addrEntry;
    int addrIndex;
    private int answerCount;
    private int authorityCount;
    private boolean isAuthAnswer;
    boolean isBroadcast = true;
    private boolean isRecurAvailable;
    boolean isRecurDesired = true;
    private boolean isResponse;
    private boolean isTruncated;
    int nameTrnId;
    int opCode;
    private int questionClass = 1;
    private int questionCount = 1;
    Name questionName;
    int questionType;
    int rDataLength;
    boolean received;
    private int recordClass;
    Name recordName;
    int recordType;
    int resultCode;
    private int ttl;

    /* access modifiers changed from: 0000 */
    public abstract int readBodyWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int readRDataWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeBodyWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeRDataWireFormat(byte[] bArr, int i);

    private static void writeInt2(int i, byte[] bArr, int i2) {
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >> 8) & 255);
        bArr[i3] = (byte) (i & 255);
    }

    private static int readInt2(byte[] bArr, int i) {
        return ((bArr[i] & Constants.UNKNOWN) << 8) + (bArr[i + 1] & Constants.UNKNOWN);
    }

    static int readInt4(byte[] bArr, int i) {
        return ((bArr[i] & Constants.UNKNOWN) << 24) + ((bArr[i + 1] & Constants.UNKNOWN) << 16) + ((bArr[i + 2] & Constants.UNKNOWN) << 8) + (bArr[i + 3] & Constants.UNKNOWN);
    }

    static int readNameTrnId(byte[] bArr, int i) {
        return readInt2(bArr, i);
    }

    NameServicePacket() {
    }

    /* access modifiers changed from: 0000 */
    public int writeWireFormat(byte[] bArr, int i) {
        int writeHeaderWireFormat = writeHeaderWireFormat(bArr, i) + i;
        return (writeHeaderWireFormat + writeBodyWireFormat(bArr, writeHeaderWireFormat)) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readWireFormat(byte[] bArr, int i) {
        int readHeaderWireFormat = readHeaderWireFormat(bArr, i) + i;
        return (readHeaderWireFormat + readBodyWireFormat(bArr, readHeaderWireFormat)) - i;
    }

    private int writeHeaderWireFormat(byte[] bArr, int i) {
        writeInt2(this.nameTrnId, bArr, i);
        int i2 = i + 2;
        int i3 = 128;
        int i4 = 0;
        bArr[i2] = (byte) ((this.isResponse ? 128 : 0) + ((this.opCode << 3) & 120) + (this.isAuthAnswer ? 4 : 0) + (this.isTruncated ? 2 : 0) + (this.isRecurDesired ? 1 : 0));
        int i5 = i2 + 1;
        if (!this.isRecurAvailable) {
            i3 = 0;
        }
        if (this.isBroadcast) {
            i4 = 16;
        }
        bArr[i5] = (byte) (i3 + i4 + (this.resultCode & 15));
        writeInt2(this.questionCount, bArr, i + 4);
        writeInt2(this.answerCount, bArr, i + 6);
        writeInt2(this.authorityCount, bArr, i + 8);
        writeInt2(this.additionalCount, bArr, i + 10);
        return 12;
    }

    private int readHeaderWireFormat(byte[] bArr, int i) {
        this.nameTrnId = readInt2(bArr, i);
        int i2 = i + 2;
        boolean z = false;
        this.isResponse = (bArr[i2] & 128) != 0;
        this.opCode = (bArr[i2] & 120) >> 3;
        this.isAuthAnswer = (bArr[i2] & 4) != 0;
        this.isTruncated = (bArr[i2] & 2) != 0;
        this.isRecurDesired = (bArr[i2] & 1) != 0;
        int i3 = i2 + 1;
        this.isRecurAvailable = (bArr[i3] & 128) != 0;
        if ((bArr[i3] & 16) != 0) {
            z = true;
        }
        this.isBroadcast = z;
        this.resultCode = bArr[i3] & 15;
        this.questionCount = readInt2(bArr, i + 4);
        this.answerCount = readInt2(bArr, i + 6);
        this.authorityCount = readInt2(bArr, i + 8);
        this.additionalCount = readInt2(bArr, i + 10);
        return 12;
    }

    /* access modifiers changed from: 0000 */
    public int writeQuestionSectionWireFormat(byte[] bArr, int i) {
        int writeWireFormat = this.questionName.writeWireFormat(bArr, i) + i;
        writeInt2(this.questionType, bArr, writeWireFormat);
        int i2 = writeWireFormat + 2;
        writeInt2(this.questionClass, bArr, i2);
        return (i2 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readQuestionSectionWireFormat(byte[] bArr, int i) {
        int readWireFormat = this.questionName.readWireFormat(bArr, i) + i;
        this.questionType = readInt2(bArr, readWireFormat);
        int i2 = readWireFormat + 2;
        this.questionClass = readInt2(bArr, i2);
        return (i2 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readResourceRecordWireFormat(byte[] bArr, int i) {
        int i2;
        if ((bArr[i] & 192) == 192) {
            this.recordName = this.questionName;
            i2 = i + 2;
        } else {
            i2 = this.recordName.readWireFormat(bArr, i) + i;
        }
        this.recordType = readInt2(bArr, i2);
        int i3 = i2 + 2;
        this.recordClass = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.ttl = readInt4(bArr, i4);
        int i5 = i4 + 4;
        int readInt2 = readInt2(bArr, i5);
        this.rDataLength = readInt2;
        int i6 = i5 + 2;
        this.addrEntry = new NbtAddress[(readInt2 / 6)];
        int i7 = readInt2 + i6;
        int i8 = 0;
        while (true) {
            this.addrIndex = i8;
            if (i6 >= i7) {
                return i6 - i;
            }
            i6 += readRDataWireFormat(bArr, i6);
            i8 = this.addrIndex + 1;
        }
    }

    public String toString() {
        String str;
        String str2;
        int i = this.opCode;
        String str3 = i != 0 ? i != 7 ? Integer.toString(i) : "WACK" : "QUERY";
        int i2 = this.questionType;
        String str4 = "NBSTAT";
        String str5 = "NB";
        String str6 = "0x";
        if (i2 == 32) {
            str = str5;
        } else if (i2 != 33) {
            StringBuilder sb = new StringBuilder();
            sb.append(str6);
            sb.append(Dumper.toHexString(this.questionType, 4));
            str = sb.toString();
        } else {
            str = str4;
        }
        int i3 = this.recordType;
        if (i3 == 1) {
            str4 = "A";
        } else if (i3 == 2) {
            str4 = "NS";
        } else if (i3 == 10) {
            str4 = "NULL";
        } else if (i3 == 32) {
            str4 = str5;
        } else if (i3 != 33) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str6);
            sb2.append(Dumper.toHexString(this.recordType, 4));
            str4 = sb2.toString();
        }
        StringBuilder sb3 = new StringBuilder();
        sb3.append("nameTrnId=");
        sb3.append(this.nameTrnId);
        sb3.append(",isResponse=");
        sb3.append(this.isResponse);
        sb3.append(",opCode=");
        sb3.append(str3);
        sb3.append(",isAuthAnswer=");
        sb3.append(this.isAuthAnswer);
        sb3.append(",isTruncated=");
        sb3.append(this.isTruncated);
        sb3.append(",isRecurAvailable=");
        sb3.append(this.isRecurAvailable);
        sb3.append(",isRecurDesired=");
        sb3.append(this.isRecurDesired);
        sb3.append(",isBroadcast=");
        sb3.append(this.isBroadcast);
        sb3.append(",resultCode=");
        sb3.append(this.resultCode);
        sb3.append(",questionCount=");
        sb3.append(this.questionCount);
        sb3.append(",answerCount=");
        sb3.append(this.answerCount);
        sb3.append(",authorityCount=");
        sb3.append(this.authorityCount);
        sb3.append(",additionalCount=");
        sb3.append(this.additionalCount);
        sb3.append(",questionName=");
        sb3.append(this.questionName);
        sb3.append(",questionType=");
        sb3.append(str);
        sb3.append(",questionClass=");
        String str7 = "IN";
        if (this.questionClass == 1) {
            str2 = str7;
        } else {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str6);
            sb4.append(Dumper.toHexString(this.questionClass, 4));
            str2 = sb4.toString();
        }
        sb3.append(str2);
        sb3.append(",recordName=");
        sb3.append(this.recordName);
        sb3.append(",recordType=");
        sb3.append(str4);
        sb3.append(",recordClass=");
        if (this.recordClass != 1) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(str6);
            sb5.append(Dumper.toHexString(this.recordClass, 4));
            str7 = sb5.toString();
        }
        sb3.append(str7);
        sb3.append(",ttl=");
        sb3.append(this.ttl);
        sb3.append(",rDataLength=");
        sb3.append(this.rDataLength);
        return new String(sb3.toString());
    }
}
