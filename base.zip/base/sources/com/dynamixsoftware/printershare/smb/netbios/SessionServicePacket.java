package com.dynamixsoftware.printershare.smb.netbios;

import java.io.IOException;
import java.io.InputStream;

public abstract class SessionServicePacket {
    private static final int HEADER_LENGTH = 4;
    public static final int NEGATIVE_SESSION_RESPONSE = 131;
    public static final int POSITIVE_SESSION_RESPONSE = 130;
    static final int SESSION_REQUEST = 129;
    int length;
    int type;

    /* access modifiers changed from: 0000 */
    public abstract int readTrailerWireFormat(InputStream inputStream, byte[] bArr, int i) throws IOException;

    /* access modifiers changed from: 0000 */
    public abstract int writeTrailerWireFormat(byte[] bArr, int i);

    private static void writeInt2(int i, byte[] bArr, int i2) {
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >> 8) & 255);
        bArr[i3] = (byte) (i & 255);
    }

    public int writeWireFormat(byte[] bArr, int i) {
        this.length = writeTrailerWireFormat(bArr, i + 4);
        writeHeaderWireFormat(bArr, i);
        return this.length + 4;
    }

    private int writeHeaderWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = (byte) this.type;
        if (this.length > 65535) {
            bArr[i2] = 1;
        }
        writeInt2(this.length, bArr, i2 + 1);
        return 4;
    }
}
