package com.dynamixsoftware.printershare.smb.netbios;

import com.dynamixsoftware.printershare.App;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Vector;

public final class NbtAddress {
    private static final HashMap<Name, CacheEntry> ADDRESS_CACHE = new HashMap<>();
    static final String ANY_HOSTS_NAME = "*\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000";
    private static final int B_NODE = 0;
    private static final int CACHE_POLICY = 30;
    private static final NameServiceClient CLIENT = new NameServiceClient();
    private static final int DEFAULT_CACHE_POLICY = 30;
    private static final int FOREVER = -1;
    private static final HashMap<Name, Name> LOOKUP_TABLE = new HashMap<>();
    public static final String MASTER_BROWSER_NAME = "\u0001\u0002__MSBROWSE__\u0002";
    static final InetAddress[] NBNS = new InetAddress[0];
    public static final String SMBSERVER_NAME = "*SMBSERVER     ";
    private static final NbtAddress UNKNOWN_ADDRESS = new NbtAddress(UNKNOWN_NAME, 0, false, 0);
    private static final byte[] UNKNOWN_MAC_ADDRESS = {0, 0, 0, 0, 0, 0};
    static final Name UNKNOWN_NAME = new Name("0.0.0.0", 0, null);
    private static NbtAddress localhost;
    private static int nbnsIndex = 0;
    int address;
    private String calledName;
    boolean groupName;
    Name hostName;
    boolean isActive;
    boolean isBeingDeleted;
    boolean isDataFromNodeStatus;
    boolean isInConflict;
    boolean isPermanent;
    byte[] macAddress;
    int nodeType;

    private static final class CacheEntry {
        /* access modifiers changed from: private */
        public NbtAddress address;
        /* access modifiers changed from: private */
        public long expiration;

        private CacheEntry(Name name, NbtAddress nbtAddress, long j) {
            this.address = nbtAddress;
            this.expiration = j;
        }
    }

    static {
        InetAddress inetAddress;
        HashMap<Name, CacheEntry> hashMap = ADDRESS_CACHE;
        Name name = UNKNOWN_NAME;
        CacheEntry cacheEntry = new CacheEntry(UNKNOWN_NAME, UNKNOWN_ADDRESS, -1);
        hashMap.put(name, cacheEntry);
        try {
            inetAddress = InetAddress.getLocalHost();
        } catch (UnknownHostException unused) {
            try {
                inetAddress = InetAddress.getByName("127.0.0.1");
            } catch (UnknownHostException unused2) {
                inetAddress = null;
            }
        }
        byte[] address2 = inetAddress.getAddress();
        StringBuilder sb = new StringBuilder();
        sb.append("HOST");
        sb.append(address2[2] & Constants.UNKNOWN);
        String str = "_";
        sb.append(str);
        sb.append(address2[3] & Constants.UNKNOWN);
        sb.append(str);
        sb.append(Dumper.toHexString((int) (Math.random() * 255.0d), 2));
        Name name2 = new Name(sb.toString(), 0, null);
        NbtAddress nbtAddress = new NbtAddress(name2, inetAddress.hashCode(), false, 0, false, false, true, false, UNKNOWN_MAC_ADDRESS);
        localhost = nbtAddress;
        cacheAddress(name2, nbtAddress, -1);
    }

    private static void cacheAddress(Name name, NbtAddress nbtAddress) {
        cacheAddress(name, nbtAddress, System.currentTimeMillis() + 30000);
    }

    private static void cacheAddress(Name name, NbtAddress nbtAddress, long j) {
        synchronized (ADDRESS_CACHE) {
            CacheEntry cacheEntry = (CacheEntry) ADDRESS_CACHE.get(name);
            if (cacheEntry == null) {
                CacheEntry cacheEntry2 = new CacheEntry(name, nbtAddress, j);
                ADDRESS_CACHE.put(name, cacheEntry2);
            } else {
                cacheEntry.address = nbtAddress;
                cacheEntry.expiration = j;
            }
        }
    }

    private static void cacheAddressArray(NbtAddress[] nbtAddressArr) {
        long currentTimeMillis = System.currentTimeMillis() + 30000;
        synchronized (ADDRESS_CACHE) {
            for (int i = 0; i < nbtAddressArr.length; i++) {
                CacheEntry cacheEntry = (CacheEntry) ADDRESS_CACHE.get(nbtAddressArr[i].hostName);
                if (cacheEntry == null) {
                    CacheEntry cacheEntry2 = new CacheEntry(nbtAddressArr[i].hostName, nbtAddressArr[i], currentTimeMillis);
                    ADDRESS_CACHE.put(nbtAddressArr[i].hostName, cacheEntry2);
                } else {
                    cacheEntry.address = nbtAddressArr[i];
                    cacheEntry.expiration = currentTimeMillis;
                }
            }
        }
    }

    private static NbtAddress getCachedAddress(Name name) {
        NbtAddress nbtAddress;
        synchronized (ADDRESS_CACHE) {
            CacheEntry cacheEntry = (CacheEntry) ADDRESS_CACHE.get(name);
            nbtAddress = null;
            if (cacheEntry != null && cacheEntry.expiration < System.currentTimeMillis() && cacheEntry.expiration >= 0) {
                cacheEntry = null;
            }
            if (cacheEntry != null) {
                nbtAddress = cacheEntry.address;
            }
        }
        return nbtAddress;
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Can't wrap try/catch for region: R(3:26|27|28) */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0051, code lost:
        r8 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        r4 = UNKNOWN_ADDRESS;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x005e, code lost:
        cacheAddress(r7, r4);
        updateLookupTable(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0064, code lost:
        throw r8;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:26:0x0053 */
    private static NbtAddress doNameQuery(Name name, InetAddress inetAddress) throws UnknownHostException {
        int i = 1;
        boolean z = name.hexCode == 29 && inetAddress == null;
        Vector broadcastAdrresses = z ? App.getBroadcastAdrresses() : new Vector();
        NbtAddress nbtAddress = UNKNOWN_ADDRESS;
        if (z) {
            i = broadcastAdrresses.size();
        }
        int i2 = 0;
        while (true) {
            if (i2 < i) {
                if (z) {
                    inetAddress = (InetAddress) broadcastAdrresses.get(i2);
                }
                name.srcHashCode = inetAddress != null ? inetAddress.hashCode() : 0;
                nbtAddress = getCachedAddress(name);
                if (nbtAddress != null) {
                    break;
                }
                nbtAddress = (NbtAddress) checkLookupTable(name);
                if (nbtAddress != null) {
                    break;
                }
                nbtAddress = CLIENT.getByName(name, inetAddress);
                cacheAddress(name, nbtAddress);
                updateLookupTable(name);
                break;
            }
            break;
            cacheAddress(name, nbtAddress);
            updateLookupTable(name);
            i2++;
        }
        if (nbtAddress != UNKNOWN_ADDRESS) {
            return nbtAddress;
        }
        throw new UnknownHostException(name.toString());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0022, code lost:
        r0 = getCachedAddress(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0026, code lost:
        if (r0 != null) goto L_0x0035;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0028, code lost:
        r1 = LOOKUP_TABLE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002a, code lost:
        monitor-enter(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        LOOKUP_TABLE.put(r3, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0030, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0035, code lost:
        return r0;
     */
    private static Object checkLookupTable(Name name) {
        synchronized (LOOKUP_TABLE) {
            if (!LOOKUP_TABLE.containsKey(name)) {
                LOOKUP_TABLE.put(name, name);
                return null;
            }
            while (LOOKUP_TABLE.containsKey(name)) {
                try {
                    LOOKUP_TABLE.wait();
                } catch (InterruptedException unused) {
                }
            }
        }
    }

    private static void updateLookupTable(Name name) {
        synchronized (LOOKUP_TABLE) {
            LOOKUP_TABLE.remove(name);
            LOOKUP_TABLE.notifyAll();
        }
    }

    public static NbtAddress getLocalHost() throws UnknownHostException {
        return localhost;
    }

    public static Name getLocalName() {
        return localhost.hostName;
    }

    public static NbtAddress getByName(String str) throws UnknownHostException {
        return getByName(str, 0, null);
    }

    public static NbtAddress getByName(String str, int i, String str2) throws UnknownHostException {
        return getByName(str, i, str2, null);
    }

    public static NbtAddress getByName(String str, int i, String str2, InetAddress inetAddress) throws UnknownHostException {
        if (str == null || str.length() == 0) {
            return getLocalHost();
        }
        if (!Character.isDigit(str.charAt(0))) {
            return doNameQuery(new Name(str, i, str2), inetAddress);
        }
        char[] charArray = str.toCharArray();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (i2 < charArray.length) {
            char c = charArray[i2];
            if (c < '0' || c > '9') {
                return doNameQuery(new Name(str, i, str2), inetAddress);
            }
            int i5 = 0;
            while (c != '.') {
                if (c < '0' || c > '9') {
                    return doNameQuery(new Name(str, i, str2), inetAddress);
                }
                i5 = ((i5 * 10) + c) - 48;
                i2++;
                if (i2 >= charArray.length) {
                    break;
                }
                c = charArray[i2];
            }
            if (i5 > 255) {
                return doNameQuery(new Name(str, i, str2), inetAddress);
            }
            i4 = (i4 << 8) + i5;
            i3++;
            i2++;
        }
        if (i3 != 4 || str.endsWith(".")) {
            return doNameQuery(new Name(str, i, str2), inetAddress);
        }
        return new NbtAddress(UNKNOWN_NAME, i4, false, 0);
    }

    private static NbtAddress[] getAllByAddress(NbtAddress nbtAddress) throws UnknownHostException {
        String str;
        try {
            NbtAddress[] nodeStatus = CLIENT.getNodeStatus(nbtAddress);
            cacheAddressArray(nodeStatus);
            return nodeStatus;
        } catch (UnknownHostException unused) {
            StringBuilder sb = new StringBuilder();
            sb.append("no name with type 0x");
            sb.append(Dumper.toHexString(nbtAddress.hostName.hexCode, 2));
            if (nbtAddress.hostName.scope == null || nbtAddress.hostName.scope.length() == 0) {
                str = " with no scope";
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(" with scope ");
                sb2.append(nbtAddress.hostName.scope);
                str = sb2.toString();
            }
            sb.append(str);
            sb.append(" for host ");
            sb.append(nbtAddress.getHostAddress());
            throw new UnknownHostException(sb.toString());
        }
    }

    public static InetAddress getWINSAddress() {
        InetAddress[] inetAddressArr = NBNS;
        if (inetAddressArr.length == 0) {
            return null;
        }
        return inetAddressArr[nbnsIndex];
    }

    public static boolean isWINS(InetAddress inetAddress) {
        int i = 0;
        while (inetAddress != null && i < NBNS.length) {
            if (inetAddress.hashCode() == NBNS[i].hashCode()) {
                return true;
            }
            i++;
        }
        return false;
    }

    static InetAddress switchWINS() {
        int i = nbnsIndex;
        int i2 = i + 1 < NBNS.length ? i + 1 : 0;
        nbnsIndex = i2;
        InetAddress[] inetAddressArr = NBNS;
        if (inetAddressArr.length == 0) {
            return null;
        }
        return inetAddressArr[i2];
    }

    NbtAddress(Name name, int i, boolean z, int i2) {
        this.hostName = name;
        this.address = i;
        this.groupName = z;
        this.nodeType = i2;
    }

    NbtAddress(Name name, int i, boolean z, int i2, boolean z2, boolean z3, boolean z4, boolean z5, byte[] bArr) {
        this.hostName = name;
        this.address = i;
        this.groupName = z;
        this.nodeType = i2;
        this.isBeingDeleted = z2;
        this.isInConflict = z3;
        this.isActive = z4;
        this.isPermanent = z5;
        this.macAddress = bArr;
        this.isDataFromNodeStatus = true;
    }

    public String firstCalledName() {
        String str = this.hostName.name;
        this.calledName = str;
        int i = 0;
        boolean isDigit = Character.isDigit(str.charAt(0));
        String str2 = SMBSERVER_NAME;
        if (!isDigit) {
            switch (this.hostName.hexCode) {
                case 27:
                case 28:
                case 29:
                    this.calledName = str2;
                    break;
            }
        } else {
            int length = this.calledName.length();
            char[] charArray = this.calledName.toCharArray();
            int i2 = 0;
            while (true) {
                if (i >= length) {
                    break;
                }
                int i3 = i + 1;
                if (Character.isDigit(charArray[i])) {
                    if (i3 == length && i2 == 3) {
                        this.calledName = str2;
                        break;
                    } else if (i3 >= length || charArray[i3] != '.') {
                        i = i3;
                    } else {
                        i2++;
                        i = i3 + 1;
                    }
                } else {
                    break;
                }
            }
        }
        return this.calledName;
    }

    public String nextCalledName() {
        String str = this.calledName;
        String str2 = this.hostName.name;
        String str3 = SMBSERVER_NAME;
        if (str == str2) {
            this.calledName = str3;
        } else if (this.calledName == str3) {
            try {
                NbtAddress[] nodeStatus = CLIENT.getNodeStatus(this);
                if (this.hostName.hexCode == 29) {
                    for (int i = 0; i < nodeStatus.length; i++) {
                        if (nodeStatus[i].hostName.hexCode == 32) {
                            return nodeStatus[i].hostName.name;
                        }
                    }
                    return null;
                } else if (this.isDataFromNodeStatus) {
                    this.calledName = null;
                    return this.hostName.name;
                }
            } catch (UnknownHostException unused) {
                this.calledName = null;
            }
        } else {
            this.calledName = null;
        }
        return this.calledName;
    }

    private void checkData() throws UnknownHostException {
        if (this.hostName == UNKNOWN_NAME) {
            getAllByAddress(this);
        }
    }

    private void checkNodeStatusData() throws UnknownHostException {
        if (!this.isDataFromNodeStatus) {
            getAllByAddress(this);
        }
    }

    public boolean isGroupAddress() throws UnknownHostException {
        checkData();
        return this.groupName;
    }

    public int getNodeType() throws UnknownHostException {
        checkData();
        return this.nodeType;
    }

    public boolean isBeingDeleted() throws UnknownHostException {
        checkNodeStatusData();
        return this.isBeingDeleted;
    }

    public boolean isInConflict() throws UnknownHostException {
        checkNodeStatusData();
        return this.isInConflict;
    }

    public boolean isActive() throws UnknownHostException {
        checkNodeStatusData();
        return this.isActive;
    }

    public boolean isPermanent() throws UnknownHostException {
        checkNodeStatusData();
        return this.isPermanent;
    }

    public byte[] getMacAddress() throws UnknownHostException {
        checkNodeStatusData();
        return this.macAddress;
    }

    public String getHostName() {
        Name name = this.hostName;
        if (name == UNKNOWN_NAME) {
            return getHostAddress();
        }
        return name.name;
    }

    public byte[] getAddress() {
        int i = this.address;
        return new byte[]{(byte) ((i >>> 24) & 255), (byte) ((i >>> 16) & 255), (byte) ((i >>> 8) & 255), (byte) (i & 255)};
    }

    public InetAddress getInetAddress() throws UnknownHostException {
        return InetAddress.getByName(getHostAddress());
    }

    public String getHostAddress() {
        StringBuilder sb = new StringBuilder();
        sb.append((this.address >>> 24) & 255);
        String str = ".";
        sb.append(str);
        sb.append((this.address >>> 16) & 255);
        sb.append(str);
        sb.append((this.address >>> 8) & 255);
        sb.append(str);
        sb.append((this.address >>> 0) & 255);
        return sb.toString();
    }

    public int getNameType() {
        return this.hostName.hexCode;
    }

    public int hashCode() {
        return this.address;
    }

    public boolean equals(Object obj) {
        return obj != null && (obj instanceof NbtAddress) && ((NbtAddress) obj).address == this.address;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.hostName.toString());
        sb.append("/");
        sb.append(getHostAddress());
        return sb.toString();
    }
}
