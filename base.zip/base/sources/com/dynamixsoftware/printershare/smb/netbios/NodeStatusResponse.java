package com.dynamixsoftware.printershare.smb.netbios;

import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;

class NodeStatusResponse extends NameServicePacket {
    NbtAddress[] addressArray;
    private byte[] macAddress;
    private int numberOfNames;
    private NbtAddress queryAddress;
    private byte[] stats;

    /* access modifiers changed from: 0000 */
    public int writeBodyWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NodeStatusResponse(NbtAddress nbtAddress) {
        this.queryAddress = nbtAddress;
        this.recordName = new Name();
        this.macAddress = new byte[6];
    }

    /* access modifiers changed from: 0000 */
    public int readBodyWireFormat(byte[] bArr, int i) {
        return readResourceRecordWireFormat(bArr, i);
    }

    /* access modifiers changed from: 0000 */
    public int readRDataWireFormat(byte[] bArr, int i) {
        byte b = bArr[i] & Constants.UNKNOWN;
        this.numberOfNames = b;
        int i2 = b * 18;
        int i3 = (this.rDataLength - i2) - 1;
        int i4 = i + 1;
        this.numberOfNames = bArr[i] & Constants.UNKNOWN;
        System.arraycopy(bArr, i2 + i4, this.macAddress, 0, 6);
        int readNodeNameArray = i4 + readNodeNameArray(bArr, i4);
        byte[] bArr2 = new byte[i3];
        this.stats = bArr2;
        System.arraycopy(bArr, readNodeNameArray, bArr2, 0, i3);
        return (readNodeNameArray + i3) - i;
    }

    private int readNodeNameArray(byte[] bArr, int i) {
        byte[] bArr2 = bArr;
        this.addressArray = new NbtAddress[this.numberOfNames];
        String str = this.queryAddress.hostName.scope;
        int i2 = i;
        int i3 = 0;
        boolean z = false;
        while (i3 < this.numberOfNames) {
            try {
                int i4 = i2 + 14;
                while (bArr2[i4] == 32) {
                    i4--;
                }
                String str2 = new String(bArr2, i2, (i4 - i2) + 1, SmbConstants.OEM_ENCODING);
                byte b = bArr2[i2 + 15] & Constants.UNKNOWN;
                int i5 = i2 + 16;
                boolean z2 = (bArr2[i5] & 128) == 128;
                int i6 = (bArr2[i5] & 96) >> 5;
                boolean z3 = (bArr2[i5] & 16) == 16;
                boolean z4 = (bArr2[i5] & 8) == 8;
                boolean z5 = (bArr2[i5] & 4) == 4;
                boolean z6 = (bArr2[i5] & 2) == 2;
                if (z || this.queryAddress.hostName.hexCode != b || (this.queryAddress.hostName != NbtAddress.UNKNOWN_NAME && !this.queryAddress.hostName.name.equals(str2))) {
                    NbtAddress[] nbtAddressArr = this.addressArray;
                    NbtAddress nbtAddress = new NbtAddress(new Name(str2, b, str), this.queryAddress.address, z2, i6, z3, z4, z5, z6, this.macAddress);
                    nbtAddressArr[i3] = nbtAddress;
                } else {
                    if (this.queryAddress.hostName == NbtAddress.UNKNOWN_NAME) {
                        this.queryAddress.hostName = new Name(str2, b, str);
                    }
                    this.queryAddress.groupName = z2;
                    this.queryAddress.nodeType = i6;
                    this.queryAddress.isBeingDeleted = z3;
                    this.queryAddress.isInConflict = z4;
                    this.queryAddress.isActive = z5;
                    this.queryAddress.isPermanent = z6;
                    this.queryAddress.macAddress = this.macAddress;
                    z = true;
                    this.queryAddress.isDataFromNodeStatus = true;
                    this.addressArray[i3] = this.queryAddress;
                }
                i2 += 18;
                i3++;
            } catch (UnsupportedEncodingException unused) {
            }
        }
        return i2 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NodeStatusResponse[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
