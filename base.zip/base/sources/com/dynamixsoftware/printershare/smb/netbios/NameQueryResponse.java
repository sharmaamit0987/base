package com.dynamixsoftware.printershare.smb.netbios;

class NameQueryResponse extends NameServicePacket {
    /* access modifiers changed from: 0000 */
    public int writeBodyWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeRDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NameQueryResponse() {
        this.recordName = new Name();
    }

    /* access modifiers changed from: 0000 */
    public int readBodyWireFormat(byte[] bArr, int i) {
        return readResourceRecordWireFormat(bArr, i);
    }

    /* access modifiers changed from: 0000 */
    public int readRDataWireFormat(byte[] bArr, int i) {
        boolean z = false;
        if (this.resultCode != 0 || this.opCode != 0) {
            return 0;
        }
        if ((bArr[i] & 128) == 128) {
            z = true;
        }
        int i2 = (bArr[i] & 96) >> 5;
        int readInt4 = readInt4(bArr, i + 2);
        if (readInt4 != 0) {
            this.addrEntry[this.addrIndex] = new NbtAddress(this.recordName, readInt4, z, i2);
        } else {
            this.addrEntry[this.addrIndex] = null;
        }
        return 6;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NameQueryResponse[");
        sb.append(super.toString());
        sb.append(",addrEntry=");
        sb.append(this.addrEntry);
        sb.append("]");
        return new String(sb.toString());
    }
}
