package com.dynamixsoftware.printershare.smb.netbios;

import com.dynamixsoftware.printershare.App;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;

class NameServiceClient {
    private static final int RESOLVER_BCAST = 1;
    private static final int RESOLVER_WINS = 2;
    private int nextNameTrnId;
    private int[] resolveOrder;

    NameServiceClient() {
        if (NbtAddress.getWINSAddress() == null) {
            int[] iArr = new int[1];
            this.resolveOrder = iArr;
            iArr[0] = 1;
            return;
        }
        int[] iArr2 = new int[2];
        this.resolveOrder = iArr2;
        iArr2[0] = 2;
        iArr2[1] = 1;
    }

    /* JADX WARNING: type inference failed for: r7v0 */
    /* JADX WARNING: type inference failed for: r7v9, types: [boolean] */
    /* JADX WARNING: type inference failed for: r7v10 */
    /* JADX WARNING: type inference failed for: r7v11, types: [int] */
    /* JADX WARNING: type inference failed for: r7v12, types: [int] */
    /* JADX WARNING: type inference failed for: r7v13 */
    /* JADX WARNING: type inference failed for: r7v14 */
    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r7v0
  assigns: [?[int, float, boolean, short, byte, char, OBJECT, ARRAY], int, ?[boolean, int, float, short, byte, char]]
  uses: [boolean, ?[int, byte, short, char], int]
  mth insns count: 133
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 3 */
    public NbtAddress getByName(Name name, InetAddress inetAddress) throws UnknownHostException {
        boolean z;
        Name name2 = name;
        InetAddress inetAddress2 = inetAddress;
        NameQueryRequest nameQueryRequest = new NameQueryRequest(name2);
        NameQueryResponse nameQueryResponse = new NameQueryResponse();
        int i = 3000;
        int i2 = 3;
        ? r7 = 0;
        if (inetAddress2 != null) {
            Vector broadcastAdrresses = App.getBroadcastAdrresses();
            nameQueryRequest.addr = inetAddress2;
            if (broadcastAdrresses == null || broadcastAdrresses.size() <= 0) {
                if (inetAddress.getAddress()[3] == -1) {
                    r7 = 1;
                }
                nameQueryRequest.isBroadcast = r7;
            } else {
                while (true) {
                    if (r7 < broadcastAdrresses.size()) {
                        if (((InetAddress) broadcastAdrresses.get(r7)).equals(inetAddress2)) {
                            nameQueryRequest.isBroadcast = true;
                            break;
                        }
                        r7++;
                    }
                }
            }
            do {
                try {
                    send(nameQueryRequest, nameQueryResponse, 3000);
                    if (nameQueryResponse.received && nameQueryResponse.resultCode == 0) {
                        int length = nameQueryResponse.addrEntry.length - 1;
                        while (length >= 0) {
                            try {
                                getNodeStatus(nameQueryResponse.addrEntry[length]);
                                nameQueryResponse.addrEntry[length].hostName.srcHashCode = inetAddress.hashCode();
                                return nameQueryResponse.addrEntry[length];
                            } catch (UnknownHostException unused) {
                                length--;
                            }
                        }
                    }
                    i2--;
                    if (i2 <= 0) {
                        break;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new UnknownHostException(name2.name);
                }
            } while (nameQueryRequest.isBroadcast);
            throw new UnknownHostException(name2.name);
        }
        int i3 = 0;
        while (true) {
            int[] iArr = this.resolveOrder;
            if (i3 < iArr.length) {
                int i4 = iArr[i3];
                if (i4 == 1 || i4 == 2) {
                    if (this.resolveOrder[i3] != 2 || name2.name == NbtAddress.MASTER_BROWSER_NAME || name2.hexCode == 29) {
                        nameQueryRequest.isBroadcast = true;
                        z = true;
                    } else {
                        nameQueryRequest.addr = NbtAddress.getWINSAddress();
                        nameQueryRequest.isBroadcast = false;
                        z = false;
                    }
                    Vector broadcastAdrresses2 = z ? App.getBroadcastAdrresses() : new Vector();
                    int size = z ? broadcastAdrresses2.size() : 1;
                    int i5 = 0;
                    while (i5 < size) {
                        if (z) {
                            nameQueryRequest.addr = (InetAddress) broadcastAdrresses2.get(i5);
                        }
                        int i6 = 3;
                        while (true) {
                            int i7 = i6 - 1;
                            if (i6 <= 0) {
                                break;
                            }
                            try {
                                send(nameQueryRequest, nameQueryResponse, i);
                                if (nameQueryResponse.received && nameQueryResponse.resultCode == 0) {
                                    int length2 = nameQueryResponse.addrEntry.length - 1;
                                    while (length2 >= 0) {
                                        try {
                                            getNodeStatus(nameQueryResponse.addrEntry[length2]);
                                            nameQueryResponse.addrEntry[length2].hostName.srcHashCode = nameQueryRequest.addr.hashCode();
                                            return nameQueryResponse.addrEntry[length2];
                                        } catch (UnknownHostException unused2) {
                                            length2--;
                                        }
                                    }
                                    continue;
                                    i6 = i7;
                                    i = 3000;
                                } else if (this.resolveOrder[i3] == 2) {
                                    break;
                                } else {
                                    i6 = i7;
                                    i = 3000;
                                }
                            } catch (IOException unused3) {
                            }
                        }
                        i5++;
                        i = 3000;
                    }
                    continue;
                }
                i3++;
                i = 3000;
            } else {
                throw new UnknownHostException(name2.name);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public NbtAddress[] getNodeStatus(NbtAddress nbtAddress) throws UnknownHostException {
        NodeStatusResponse nodeStatusResponse = new NodeStatusResponse(nbtAddress);
        NodeStatusRequest nodeStatusRequest = new NodeStatusRequest(new Name("*\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000", 0, null));
        nodeStatusRequest.addr = nbtAddress.getInetAddress();
        int i = 3;
        while (true) {
            int i2 = i - 1;
            if (i > 0) {
                try {
                    send(nodeStatusRequest, nodeStatusResponse, 1000);
                    if (!nodeStatusResponse.received || nodeStatusResponse.resultCode != 0) {
                        i = i2;
                    } else {
                        int hashCode = nodeStatusRequest.addr.hashCode();
                        for (NbtAddress nbtAddress2 : nodeStatusResponse.addressArray) {
                            nbtAddress2.hostName.srcHashCode = hashCode;
                        }
                        return nodeStatusResponse.addressArray;
                    }
                } catch (IOException unused) {
                    throw new UnknownHostException(nbtAddress.toString());
                }
            } else {
                throw new UnknownHostException(nbtAddress.hostName.name);
            }
        }
    }

    private void send(NameServicePacket nameServicePacket, NameServicePacket nameServicePacket2, int i) throws IOException {
        int i2;
        NameServicePacket nameServicePacket3 = nameServicePacket;
        NameServicePacket nameServicePacket4 = nameServicePacket2;
        int length = NbtAddress.NBNS.length;
        if (length == 0) {
            length = 1;
        }
        byte[] bArr = new byte[1024];
        byte[] bArr2 = new byte[1024];
        Vector broadcastAdrresses = App.getBroadcastAdrresses();
        DatagramSocket datagramSocket = new DatagramSocket();
        datagramSocket.setBroadcast(true);
        boolean z = false;
        int i3 = 0;
        while (!z) {
            try {
                if (i3 >= broadcastAdrresses.size()) {
                    break;
                }
                while (true) {
                    i2 = length - 1;
                    if (length <= 0) {
                        int i4 = i;
                        break;
                    }
                    while (true) {
                        DatagramPacket datagramPacket = new DatagramPacket(bArr, 1024, (InetAddress) broadcastAdrresses.get(i3), 137);
                        DatagramPacket datagramPacket2 = new DatagramPacket(bArr2, 1024);
                        nameServicePacket3.nameTrnId = getNextNameTrnId();
                        nameServicePacket4.received = false;
                        datagramPacket.setAddress(nameServicePacket3.addr);
                        datagramPacket.setLength(nameServicePacket3.writeWireFormat(bArr, 0));
                        datagramSocket.send(datagramPacket);
                        datagramSocket.setSoTimeout(i);
                        try {
                            datagramSocket.receive(datagramPacket2);
                            nameServicePacket4.readWireFormat(bArr2, 0);
                            nameServicePacket4.received = true;
                            if (nameServicePacket4.nameTrnId == nameServicePacket3.nameTrnId && nameServicePacket3.questionType == nameServicePacket4.recordType) {
                                break;
                            }
                        } catch (InterruptedIOException unused) {
                        }
                    }
                    if (nameServicePacket4.received) {
                        z = true;
                        break;
                    } else if (!NbtAddress.isWINS(nameServicePacket3.addr)) {
                        break;
                    } else {
                        if (nameServicePacket3.addr == NbtAddress.getWINSAddress()) {
                            NbtAddress.switchWINS();
                        }
                        nameServicePacket3.addr = NbtAddress.getWINSAddress();
                        length = i2;
                    }
                }
                i3++;
                length = i2;
            } catch (Throwable th) {
                datagramSocket.close();
                throw th;
            }
        }
        datagramSocket.close();
    }

    private int getNextNameTrnId() {
        int i = this.nextNameTrnId + 1;
        this.nextNameTrnId = i;
        if ((i & 65535) == 0) {
            this.nextNameTrnId = 1;
        }
        return this.nextNameTrnId;
    }
}
