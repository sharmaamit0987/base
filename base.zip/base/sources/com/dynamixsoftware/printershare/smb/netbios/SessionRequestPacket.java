package com.dynamixsoftware.printershare.smb.netbios;

import com.dynamixsoftware.printershare.bjnp.BJNPMain;
import java.io.IOException;
import java.io.InputStream;

public class SessionRequestPacket extends SessionServicePacket {
    private Name calledName;
    private Name callingName;

    SessionRequestPacket() {
        this.calledName = new Name();
        this.callingName = new Name();
    }

    public SessionRequestPacket(Name name, Name name2) {
        this.type = BJNPMain.BJNP_RES_PRINT;
        this.calledName = name;
        this.callingName = name2;
    }

    /* access modifiers changed from: 0000 */
    public int writeTrailerWireFormat(byte[] bArr, int i) {
        int writeWireFormat = this.calledName.writeWireFormat(bArr, i) + i;
        return (writeWireFormat + this.callingName.writeWireFormat(bArr, writeWireFormat)) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readTrailerWireFormat(InputStream inputStream, byte[] bArr, int i) throws IOException {
        if (inputStream.read(bArr, i, this.length) == this.length) {
            int readWireFormat = this.calledName.readWireFormat(bArr, i) + i;
            return (readWireFormat + this.callingName.readWireFormat(bArr, readWireFormat)) - i;
        }
        throw new IOException("invalid session request wire format");
    }
}
