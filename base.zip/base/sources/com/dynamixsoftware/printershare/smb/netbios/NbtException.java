package com.dynamixsoftware.printershare.smb.netbios;

import java.io.IOException;

public class NbtException extends IOException {
    public static final int CALLED_NOT_PRESENT = 130;
    public static final int CONNECTION_REFUSED = -1;
    private static final int ERR_NAM_SRVC = 1;
    public static final int ERR_SSN_SRVC = 2;
    private static final int FMT_ERR = 1;
    public static final int NOT_LISTENING_CALLED = 128;
    private static final int NOT_LISTENING_CALLING = 129;
    private static final int NO_RESOURCES = 131;
    private static final int SUCCESS = 0;
    private static final int UNSPECIFIED = 143;
    private int errorClass;
    private int errorCode;

    private static String getErrorString(int i, int i2) {
        String str = "";
        if (i != 0) {
            String str2 = "Unknown error code: ";
            if (i == 1) {
                String str3 = "ERR_NAM_SRVC/";
                if (i2 == 1) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(str3);
                    sb.append("FMT_ERR: Format Error");
                    str3 = sb.toString();
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str3);
                sb2.append(str2);
                sb2.append(i2);
                return sb2.toString();
            } else if (i != 2) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str);
                sb3.append("unknown error class: ");
                sb3.append(i);
                return sb3.toString();
            } else {
                String str4 = "ERR_SSN_SRVC/";
                if (i2 == -1) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(str4);
                    sb4.append("Connection refused");
                    return sb4.toString();
                } else if (i2 != UNSPECIFIED) {
                    switch (i2) {
                        case 128:
                            StringBuilder sb5 = new StringBuilder();
                            sb5.append(str4);
                            sb5.append("Not listening on called name");
                            return sb5.toString();
                        case 129:
                            StringBuilder sb6 = new StringBuilder();
                            sb6.append(str4);
                            sb6.append("Not listening for calling name");
                            return sb6.toString();
                        case 130:
                            StringBuilder sb7 = new StringBuilder();
                            sb7.append(str4);
                            sb7.append("Called name not present");
                            return sb7.toString();
                        case 131:
                            StringBuilder sb8 = new StringBuilder();
                            sb8.append(str4);
                            sb8.append("Called name present, but insufficient resources");
                            return sb8.toString();
                        default:
                            StringBuilder sb9 = new StringBuilder();
                            sb9.append(str4);
                            sb9.append(str2);
                            sb9.append(i2);
                            return sb9.toString();
                    }
                } else {
                    StringBuilder sb10 = new StringBuilder();
                    sb10.append(str4);
                    sb10.append("Unspecified error");
                    return sb10.toString();
                }
            }
        } else {
            StringBuilder sb11 = new StringBuilder();
            sb11.append(str);
            sb11.append("SUCCESS");
            return sb11.toString();
        }
    }

    public NbtException(int i, int i2) {
        super(getErrorString(i, i2));
        this.errorClass = i;
        this.errorCode = i2;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("errorClass=");
        sb.append(this.errorClass);
        sb.append(",errorCode=");
        sb.append(this.errorCode);
        sb.append(",errorString=");
        sb.append(getErrorString(this.errorClass, this.errorCode));
        return new String(sb.toString());
    }
}
