package com.dynamixsoftware.printershare.smb.netbios;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.dynamixsoftware.printershare.snmp.SNMPBERCodec;
import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;

public class Name {
    private static final String DEFAULT_SCOPE = null;
    static final String OEM_ENCODING = "ISO-8859-1";
    private static final int SCOPE_OFFSET = 33;
    private static final int TYPE_OFFSET = 31;
    int hexCode;
    public String name;
    String scope;
    int srcHashCode;

    Name() {
    }

    public Name(String str, int i, String str2) {
        if (str.length() > 15) {
            str = str.substring(0, 15);
        }
        this.name = str.toUpperCase();
        this.hexCode = i;
        if (str2 == null || str2.length() <= 0) {
            str2 = DEFAULT_SCOPE;
        }
        this.scope = str2;
        this.srcHashCode = 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeWireFormat(byte[] bArr, int i) {
        bArr[i] = 32;
        try {
            byte[] bytes = this.name.getBytes("ISO-8859-1");
            int i2 = 0;
            while (i2 < bytes.length) {
                int i3 = i2 * 2;
                bArr[i3 + 1 + i] = (byte) (((bytes[i2] & 240) >> 4) + 65);
                bArr[i3 + 2 + i] = (byte) ((15 & bytes[i2]) + SNMPBERCodec.SNMPCOUNTER32);
                i2++;
            }
            while (i2 < 15) {
                int i4 = i2 * 2;
                bArr[i4 + 1 + i] = SNMPBERCodec.SNMPTIMETICKS;
                bArr[i4 + 2 + i] = SNMPBERCodec.SNMPCOUNTER32;
                i2++;
            }
            int i5 = i + 31;
            bArr[i5] = (byte) (((this.hexCode & 240) >> 4) + 65);
            bArr[i5 + 1] = (byte) ((this.hexCode & 15) + 65);
        } catch (UnsupportedEncodingException unused) {
        }
        return writeScopeWireFormat(bArr, i + 33) + 33;
    }

    /* access modifiers changed from: 0000 */
    public int readWireFormat(byte[] bArr, int i) {
        byte[] bArr2 = new byte[33];
        int i2 = 15;
        for (int i3 = 0; i3 < 15; i3++) {
            int i4 = i3 * 2;
            bArr2[i3] = (byte) (((bArr[(i4 + 1) + i] & Constants.UNKNOWN) - 65) << 4);
            bArr2[i3] = (byte) (((byte) (((bArr[(i4 + 2) + i] & Constants.UNKNOWN) - 65) & 15)) | bArr2[i3]);
            if (bArr2[i3] != 32) {
                i2 = i3 + 1;
            }
        }
        try {
            this.name = new String(bArr2, 0, i2, "ISO-8859-1");
        } catch (UnsupportedEncodingException unused) {
        }
        int i5 = i + 31;
        int i6 = ((bArr[i5] & Constants.UNKNOWN) - 65) << 4;
        this.hexCode = i6;
        this.hexCode = (((bArr[i5 + 1] & Constants.UNKNOWN) - 65) & 15) | i6;
        return readScopeWireFormat(bArr, i + 33) + 33;
    }

    private int writeScopeWireFormat(byte[] bArr, int i) {
        String str = this.scope;
        if (str == null) {
            bArr[i] = 0;
            return 1;
        }
        int i2 = i + 1;
        bArr[i] = 46;
        try {
            System.arraycopy(str.getBytes("ISO-8859-1"), 0, bArr, i2, this.scope.length());
        } catch (UnsupportedEncodingException unused) {
        }
        int length = i2 + this.scope.length();
        int i3 = length + 1;
        bArr[length] = 0;
        int i4 = i3 - 2;
        int length2 = i4 - this.scope.length();
        int i5 = 0;
        while (true) {
            if (bArr[i4] == 46) {
                bArr[i4] = (byte) i5;
                i5 = 0;
            } else {
                i5++;
            }
            int i6 = i4 - 1;
            if (i4 <= length2) {
                return this.scope.length() + 2;
            }
            i4 = i6;
        }
    }

    private int readScopeWireFormat(byte[] bArr, int i) {
        int i2;
        String str = "ISO-8859-1";
        int i3 = i + 1;
        byte b = bArr[i] & Constants.UNKNOWN;
        if (b == 0) {
            this.scope = null;
            return 1;
        }
        try {
            StringBuffer stringBuffer = new StringBuffer(new String(bArr, i3, b, str));
            int i4 = i3 + b;
            while (true) {
                i2 = i4 + 1;
                try {
                    byte b2 = bArr[i4] & Constants.UNKNOWN;
                    if (b2 == 0) {
                        break;
                    }
                    stringBuffer.append('.');
                    stringBuffer.append(new String(bArr, i2, b2, str));
                    i4 = b2 + i2;
                } catch (UnsupportedEncodingException unused) {
                    i3 = i2;
                    i2 = i3;
                    return i2 - i;
                }
            }
            this.scope = stringBuffer.toString();
        } catch (UnsupportedEncodingException unused2) {
            i2 = i3;
            return i2 - i;
        }
        return i2 - i;
    }

    public int hashCode() {
        int hashCode = this.name.hashCode() + (this.hexCode * 65599) + (this.srcHashCode * 65599);
        String str = this.scope;
        return (str == null || str.length() == 0) ? hashCode : hashCode + this.scope.hashCode();
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (!(obj instanceof Name)) {
            return false;
        }
        Name name2 = (Name) obj;
        if (this.scope == null && name2.scope == null) {
            if (this.name.equals(name2.name) && this.hexCode == name2.hexCode) {
                z = true;
            }
            return z;
        }
        if (this.name.equals(name2.name) && this.hexCode == name2.hexCode && this.scope.equals(name2.scope)) {
            z = true;
        }
        return z;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        String str = this.name;
        if (str == null) {
            str = "null";
        } else if (str.charAt(0) == 1) {
            char[] charArray = str.toCharArray();
            charArray[0] = '.';
            charArray[1] = '.';
            charArray[14] = '.';
            str = new String(charArray);
        }
        stringBuffer.append(str);
        stringBuffer.append("<");
        stringBuffer.append(Dumper.toHexString(this.hexCode, 2));
        stringBuffer.append(">");
        if (this.scope != null) {
            stringBuffer.append(".");
            stringBuffer.append(this.scope);
        }
        return stringBuffer.toString();
    }
}
