package com.dynamixsoftware.printershare.smb;

class SmbComWrite extends ServerMessageBlock {
    private byte[] b;
    private int count;
    private int fid;
    private int off;
    private int offset;
    private int remaining;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComWrite() {
        this.command = 11;
    }

    /* access modifiers changed from: 0000 */
    public void setParam(int i, long j, int i2, byte[] bArr, int i3, int i4) {
        this.fid = i;
        this.offset = (int) (j & 4294967295L);
        this.remaining = i2;
        this.b = bArr;
        this.off = i3;
        this.count = i4;
        this.digest = null;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.fid, bArr, i);
        int i2 = i + 2;
        writeInt2((long) this.count, bArr, i2);
        int i3 = i2 + 2;
        writeInt4((long) this.offset, bArr, i3);
        int i4 = i3 + 4;
        writeInt2((long) this.remaining, bArr, i4);
        return (i4 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = 1;
        writeInt2((long) this.count, bArr, i2);
        int i3 = i2 + 2;
        System.arraycopy(this.b, this.off, bArr, i3, this.count);
        return (i3 + this.count) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComWrite[");
        sb.append(super.toString());
        sb.append(",fid=");
        sb.append(this.fid);
        sb.append(",count=");
        sb.append(this.count);
        sb.append(",offset=");
        sb.append(this.offset);
        sb.append(",remaining=");
        sb.append(this.remaining);
        sb.append("]");
        return new String(sb.toString());
    }
}
