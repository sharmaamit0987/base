package com.dynamixsoftware.printershare.smb;

import java.io.UnsupportedEncodingException;
import org.nanohttpd.protocols.http.NanoHTTPD;

class NetShareEnum extends SmbComTransaction {
    private static final String DESCR = "WrLeh\u0000B13BWz\u0000";

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NetShareEnum() {
        this.command = 37;
        this.subCommand = 0;
        this.name = new String("\\PIPE\\LANMAN");
        this.maxParameterCount = 8;
        this.maxSetupCount = 0;
        this.setupCount = 0;
        this.timeout = NanoHTTPD.SOCKET_READ_TIMEOUT;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        try {
            byte[] bytes = DESCR.getBytes("ASCII");
            writeInt2(0, bArr, i);
            int i2 = i + 2;
            System.arraycopy(bytes, 0, bArr, i2, bytes.length);
            int length = i2 + bytes.length;
            writeInt2(1, bArr, length);
            int i3 = length + 2;
            writeInt2((long) this.maxDataCount, bArr, i3);
            return (i3 + 2) - i;
        } catch (UnsupportedEncodingException unused) {
            return 0;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NetShareEnum[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
