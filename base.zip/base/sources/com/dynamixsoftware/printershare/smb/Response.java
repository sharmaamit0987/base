package com.dynamixsoftware.printershare.smb;

abstract class Response {
    long expiration;
    boolean isReceived;

    Response() {
    }
}
