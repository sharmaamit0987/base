package com.dynamixsoftware.printershare.smb;

interface Request {
}
