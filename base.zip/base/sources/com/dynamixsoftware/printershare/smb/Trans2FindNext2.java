package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;

class Trans2FindNext2 extends SmbComTransaction {
    private String filename;
    private int flags;
    private int informationLevel;
    private int resumeKey;
    private int sid;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    Trans2FindNext2(int i, int i2, String str) {
        this.sid = i;
        this.resumeKey = i2;
        this.filename = str;
        this.command = 50;
        this.subCommand = 2;
        this.informationLevel = 260;
        this.flags = 0;
        this.maxParameterCount = 8;
        this.maxDataCount = 65535;
        this.maxSetupCount = 0;
    }

    /* access modifiers changed from: 0000 */
    public void reset(int i, String str) {
        super.reset();
        this.resumeKey = i;
        this.filename = str;
        this.flags2 = 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = this.subCommand;
        bArr[i2] = 0;
        return 2;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.sid, bArr, i);
        int i2 = i + 2;
        writeInt2(200, bArr, i2);
        int i3 = i2 + 2;
        writeInt2((long) this.informationLevel, bArr, i3);
        int i4 = i3 + 2;
        writeInt4((long) this.resumeKey, bArr, i4);
        int i5 = i4 + 4;
        writeInt2((long) this.flags, bArr, i5);
        int i6 = i5 + 2;
        return (i6 + writeString(this.filename, bArr, i6)) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Trans2FindNext2[");
        sb.append(super.toString());
        sb.append(",sid=");
        sb.append(this.sid);
        sb.append(",searchCount=");
        sb.append(65535);
        sb.append(",informationLevel=0x");
        sb.append(Dumper.toHexString(this.informationLevel, 3));
        sb.append(",resumeKey=0x");
        sb.append(Dumper.toHexString(this.resumeKey, 4));
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags, 2));
        sb.append(",filename=");
        sb.append(this.filename);
        sb.append("]");
        return new String(sb.toString());
    }
}
