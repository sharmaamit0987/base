package com.dynamixsoftware.printershare.smb;

class SmbComReadAndX extends AndXServerMessageBlock {
    private static final int BATCH_LIMIT = 1;
    private int fid;
    int maxCount;
    int minCount;
    private long offset;
    private int openTimeout;
    int remaining;

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b) {
        return b == 4 ? 1 : 0;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComReadAndX() {
        super(null);
        this.command = 46;
        this.openTimeout = -1;
    }

    SmbComReadAndX(int i, long j, int i2, ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        this.fid = i;
        this.offset = j;
        this.minCount = i2;
        this.maxCount = i2;
        this.command = 46;
        this.openTimeout = -1;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.fid, bArr, i);
        int i2 = i + 2;
        writeInt4(this.offset, bArr, i2);
        int i3 = i2 + 4;
        writeInt2((long) this.maxCount, bArr, i3);
        int i4 = i3 + 2;
        writeInt2((long) this.minCount, bArr, i4);
        int i5 = i4 + 2;
        writeInt4((long) this.openTimeout, bArr, i5);
        int i6 = i5 + 4;
        writeInt2((long) this.remaining, bArr, i6);
        int i7 = i6 + 2;
        writeInt4(this.offset >> 32, bArr, i7);
        return (i7 + 4) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComReadAndX[");
        sb.append(super.toString());
        sb.append(",fid=");
        sb.append(this.fid);
        String str = ",offset=";
        sb.append(str);
        sb.append(this.offset);
        sb.append(",maxCount=");
        sb.append(this.maxCount);
        sb.append(",minCount=");
        sb.append(this.minCount);
        sb.append(",openTimeout=");
        sb.append(this.openTimeout);
        sb.append(",remaining=");
        sb.append(this.remaining);
        sb.append(str);
        sb.append(this.offset);
        sb.append("]");
        return new String(sb.toString());
    }
}
