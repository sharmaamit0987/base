package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;

class SmbComTreeConnectAndX extends AndXServerMessageBlock {
    private static final boolean DISABLE_PLAIN_TEXT_PASSWORDS = true;
    private static byte[] batchLimits = {1, 1, 1, 1, 1, 1, 1, 1, 0};
    private boolean disconnectTid = false;
    private byte[] password;
    private int passwordLength;
    String path;
    private String service;
    private SmbSession session;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComTreeConnectAndX(SmbSession smbSession, String str, String str2, ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        this.session = smbSession;
        this.path = str;
        this.service = str2;
        this.command = 117;
    }

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b) {
        byte b2 = b & Constants.UNKNOWN;
        if (b2 == 0) {
            return batchLimits[2];
        }
        if (b2 == 1) {
            return batchLimits[4];
        }
        if (b2 == 6) {
            return batchLimits[3];
        }
        if (b2 == 7) {
            return batchLimits[6];
        }
        if (b2 == 8) {
            return batchLimits[8];
        }
        if (b2 == 16) {
            return batchLimits[0];
        }
        if (b2 == 37) {
            return batchLimits[7];
        }
        if (b2 != 45) {
            return 0;
        }
        return batchLimits[5];
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Incorrect type for immutable var: ssa=boolean, code=byte, for r1v0, types: [boolean, byte] */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        if (this.session.transport.server.security != 0 || (!this.session.auth.hashesExternal && this.session.auth.password.length() <= 0)) {
            this.passwordLength = 1;
        } else if (this.session.transport.server.encryptedPasswords) {
            byte[] ansiHash = this.session.auth.getAnsiHash(this.session.transport.server.encryptionKey);
            this.password = ansiHash;
            this.passwordLength = ansiHash.length;
        } else {
            throw new RuntimeException("Plain text passwords are disabled");
        }
        int i2 = i + 1;
        bArr[i] = this.disconnectTid;
        int i3 = i2 + 1;
        bArr[i2] = 0;
        writeInt2((long) this.passwordLength, bArr, i3);
        return 4;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2;
        if (this.session.transport.server.security != 0 || (!this.session.auth.hashesExternal && this.session.auth.password.length() <= 0)) {
            i2 = i + 1;
            bArr[i] = 0;
        } else {
            System.arraycopy(this.password, 0, bArr, i, this.passwordLength);
            i2 = this.passwordLength + i;
        }
        int writeString = i2 + writeString(this.path, bArr, i2);
        try {
            System.arraycopy(this.service.getBytes("ASCII"), 0, bArr, writeString, this.service.length());
            int length = writeString + this.service.length();
            int i3 = length + 1;
            bArr[length] = 0;
            return i3 - i;
        } catch (UnsupportedEncodingException unused) {
            return 0;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComTreeConnectAndX[");
        sb.append(super.toString());
        sb.append(",disconnectTid=");
        sb.append(this.disconnectTid);
        sb.append(",passwordLength=");
        sb.append(this.passwordLength);
        sb.append(",password=");
        sb.append(Dumper.toHexString(this.password, this.passwordLength, 0));
        sb.append(",path=");
        sb.append(this.path);
        sb.append(",service=");
        sb.append(this.service);
        sb.append("]");
        return new String(sb.toString());
    }
}
