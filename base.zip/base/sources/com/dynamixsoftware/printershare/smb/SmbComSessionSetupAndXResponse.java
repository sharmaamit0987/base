package com.dynamixsoftware.printershare.smb;

class SmbComSessionSetupAndXResponse extends AndXServerMessageBlock {
    byte[] blob = null;
    boolean isLoggedInAsGuest;
    private String nativeLanMan;
    private String nativeOs;
    private String primaryDomain;

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComSessionSetupAndXResponse(ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        String str = "";
        this.nativeOs = str;
        this.nativeLanMan = str;
        this.primaryDomain = str;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        boolean z = true;
        if ((bArr[i] & 1) != 1) {
            z = false;
        }
        this.isLoggedInAsGuest = z;
        int i2 = i + 2;
        if (this.extendedSecurity) {
            int readInt2 = readInt2(bArr, i2);
            i2 += 2;
            this.blob = new byte[readInt2];
        }
        return i2 - i;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        int i2;
        if (this.extendedSecurity) {
            byte[] bArr2 = this.blob;
            System.arraycopy(bArr, i, bArr2, 0, bArr2.length);
            i2 = this.blob.length + i;
        } else {
            i2 = i;
        }
        String readString = readString(bArr, i2);
        this.nativeOs = readString;
        int stringWireLength = i2 + stringWireLength(readString, i2);
        String readString2 = readString(bArr, stringWireLength, i + this.byteCount, 255, this.useUnicode);
        this.nativeLanMan = readString2;
        int stringWireLength2 = stringWireLength + stringWireLength(readString2, stringWireLength);
        if (!this.extendedSecurity) {
            String readString3 = readString(bArr, stringWireLength2, i + this.byteCount, 255, this.useUnicode);
            this.primaryDomain = readString3;
            stringWireLength2 += stringWireLength(readString3, stringWireLength2);
        }
        return stringWireLength2 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComSessionSetupAndXResponse[");
        sb.append(super.toString());
        sb.append(",isLoggedInAsGuest=");
        sb.append(this.isLoggedInAsGuest);
        sb.append(",nativeOs=");
        sb.append(this.nativeOs);
        sb.append(",nativeLanMan=");
        sb.append(this.nativeLanMan);
        sb.append(",primaryDomain=");
        sb.append(this.primaryDomain);
        sb.append("]");
        return new String(sb.toString());
    }
}
