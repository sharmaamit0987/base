package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.ipp.IppAttribute;
import com.dynamixsoftware.printershare.smb.util.DES;
import com.dynamixsoftware.printershare.smb.util.Encdec;
import com.dynamixsoftware.printershare.smb.util.HMACT64;
import com.dynamixsoftware.printershare.smb.util.MD4;
import com.dynamixsoftware.printershare.snmp.SNMPBERCodec;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.Principal;
import java.util.Arrays;
import java.util.Random;

public final class NtlmPasswordAuthentication implements Principal, Serializable {
    public static final NtlmPasswordAuthentication ANONYMOUS;
    static final String BLANK = "";
    public static final NtlmPasswordAuthentication DEFAULT = new NtlmPasswordAuthentication(null);
    private static String DEFAULT_DOMAIN = null;
    static String DEFAULT_PASSWORD = null;
    private static String DEFAULT_USERNAME = null;
    private static final int LM_COMPATIBILITY = 3;
    private static final Random RANDOM = new Random();
    private static final byte[] S8 = {75, 71, 83, IppAttribute.TYPE_INTEGER, SNMPBERCodec.SNMPIPADDRESS, IppAttribute.TYPE_ENUM, 36, 37};
    private byte[] ansiHash;
    private byte[] clientChallenge;
    String domain;
    boolean hashesExternal;
    String password;
    private byte[] unicodeHash;
    String username;

    static {
        String str = BLANK;
        ANONYMOUS = new NtlmPasswordAuthentication(str, str, str);
    }

    private static void E(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        byte[] bArr4 = new byte[7];
        byte[] bArr5 = new byte[8];
        for (int i = 0; i < bArr.length / 7; i++) {
            System.arraycopy(bArr, i * 7, bArr4, 0, 7);
            new DES(bArr4).encrypt(bArr2, bArr5);
            System.arraycopy(bArr5, 0, bArr3, i * 8, 8);
        }
    }

    private static void initDefaults() {
        if (DEFAULT_DOMAIN == null) {
            DEFAULT_DOMAIN = "?";
            DEFAULT_USERNAME = "GUEST";
            DEFAULT_PASSWORD = BLANK;
        }
    }

    public static byte[] getPreNTLMResponse(String str, byte[] bArr) {
        int i = 14;
        byte[] bArr2 = new byte[14];
        byte[] bArr3 = new byte[21];
        byte[] bArr4 = new byte[24];
        try {
            byte[] bytes = str.toUpperCase().getBytes(SmbConstants.OEM_ENCODING);
            int length = bytes.length;
            if (length <= 14) {
                i = length;
            }
            System.arraycopy(bytes, 0, bArr2, 0, i);
            E(bArr2, S8, bArr3);
            E(bArr3, bArr, bArr4);
            return bArr4;
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Try setting jcifs.encoding=US-ASCII", e);
        }
    }

    public static byte[] getNTLMResponse(String str, byte[] bArr) {
        byte[] bArr2;
        byte[] bArr3 = new byte[21];
        byte[] bArr4 = new byte[24];
        try {
            bArr2 = str.getBytes(SmbConstants.UNI_ENCODING);
        } catch (UnsupportedEncodingException unused) {
            bArr2 = null;
        }
        MD4 md4 = new MD4();
        md4.update(bArr2);
        try {
            md4.digest(bArr3, 0, 16);
        } catch (Exception unused2) {
        }
        E(bArr3, bArr, bArr4);
        return bArr4;
    }

    public static byte[] getLMv2Response(String str, String str2, String str3, byte[] bArr, byte[] bArr2) {
        String str4 = SmbConstants.UNI_ENCODING;
        try {
            byte[] bArr3 = new byte[24];
            MD4 md4 = new MD4();
            md4.update(str3.getBytes(str4));
            HMACT64 hmact64 = new HMACT64(md4.digest());
            hmact64.update(str2.toUpperCase().getBytes(str4));
            hmact64.update(str.toUpperCase().getBytes(str4));
            HMACT64 hmact642 = new HMACT64(hmact64.digest());
            hmact642.update(bArr);
            hmact642.update(bArr2);
            hmact642.digest(bArr3, 0, 16);
            System.arraycopy(bArr2, 0, bArr3, 16, 8);
            return bArr3;
        } catch (Exception unused) {
            return null;
        }
    }

    public static byte[] getNTLM2Response(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        String str = "MD5";
        byte[] bArr4 = new byte[8];
        try {
            MessageDigest instance = MessageDigest.getInstance(str);
            instance.update(bArr2);
            instance.update(bArr3, 0, 8);
            System.arraycopy(instance.digest(), 0, bArr4, 0, 8);
            byte[] bArr5 = new byte[21];
            System.arraycopy(bArr, 0, bArr5, 0, 16);
            byte[] bArr6 = new byte[24];
            E(bArr5, bArr4, bArr6);
            return bArr6;
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(str, e);
        }
    }

    public static byte[] nTOWFv1(String str) {
        if (str != null) {
            try {
                MD4 md4 = new MD4();
                md4.update(str.getBytes(SmbConstants.UNI_ENCODING));
                return md4.digest();
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e.getMessage());
            }
        } else {
            throw new RuntimeException("Password parameter is required");
        }
    }

    public static byte[] nTOWFv2(String str, String str2, String str3) {
        String str4 = SmbConstants.UNI_ENCODING;
        try {
            MD4 md4 = new MD4();
            md4.update(str3.getBytes(str4));
            HMACT64 hmact64 = new HMACT64(md4.digest());
            hmact64.update(str2.toUpperCase().getBytes(str4));
            hmact64.update(str.getBytes(str4));
            return hmact64.digest();
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    private static byte[] computeResponse(byte[] bArr, byte[] bArr2, byte[] bArr3, int i, int i2) {
        HMACT64 hmact64 = new HMACT64(bArr);
        hmact64.update(bArr2);
        hmact64.update(bArr3, i, i2);
        byte[] digest = hmact64.digest();
        byte[] bArr4 = new byte[(digest.length + bArr3.length)];
        System.arraycopy(digest, 0, bArr4, 0, digest.length);
        System.arraycopy(bArr3, 0, bArr4, digest.length, bArr3.length);
        return bArr4;
    }

    public static byte[] getNTLMv2Response(byte[] bArr, byte[] bArr2, byte[] bArr3, long j, byte[] bArr4) {
        int length = bArr4 != null ? bArr4.length : 0;
        int i = length + 28;
        int i2 = i + 4;
        byte[] bArr5 = new byte[i2];
        Encdec.enc_uint32le(257, bArr5, 0);
        Encdec.enc_uint32le(0, bArr5, 4);
        Encdec.enc_uint64le(j, bArr5, 8);
        System.arraycopy(bArr3, 0, bArr5, 16, 8);
        Encdec.enc_uint32le(0, bArr5, 24);
        if (bArr4 != null) {
            System.arraycopy(bArr4, 0, bArr5, 28, length);
        }
        Encdec.enc_uint32le(0, bArr5, i);
        return computeResponse(bArr, bArr2, bArr5, 0, i2);
    }

    public NtlmPasswordAuthentication(String str) {
        this.hashesExternal = false;
        this.clientChallenge = null;
        this.password = null;
        this.username = null;
        this.domain = null;
        if (str != null) {
            try {
                str = unescape(str);
            } catch (UnsupportedEncodingException unused) {
            }
            int length = str.length();
            int i = 0;
            int i2 = 0;
            while (true) {
                if (i >= length) {
                    break;
                }
                char charAt = str.charAt(i);
                if (charAt == ';') {
                    this.domain = str.substring(0, i);
                    i2 = i + 1;
                } else if (charAt == ':') {
                    this.password = str.substring(i + 1);
                    break;
                }
                i++;
            }
            this.username = str.substring(i2, i);
        }
        initDefaults();
        if (this.domain == null) {
            this.domain = DEFAULT_DOMAIN;
        }
        if (this.username == null) {
            this.username = DEFAULT_USERNAME;
        }
        if (this.password == null) {
            this.password = DEFAULT_PASSWORD;
        }
    }

    public NtlmPasswordAuthentication(String str, String str2, String str3) {
        this.hashesExternal = false;
        this.clientChallenge = null;
        int indexOf = str2.indexOf(64);
        if (indexOf > 0) {
            str = str2.substring(indexOf + 1);
            str2 = str2.substring(0, indexOf);
        } else {
            int indexOf2 = str2.indexOf(92);
            if (indexOf2 > 0) {
                str = str2.substring(0, indexOf2);
                str2 = str2.substring(indexOf2 + 1);
            }
        }
        this.domain = str;
        this.username = str2;
        this.password = str3;
        initDefaults();
        if (str == null) {
            this.domain = DEFAULT_DOMAIN;
        }
        if (str2 == null) {
            this.username = DEFAULT_USERNAME;
        }
        if (str3 == null) {
            this.password = DEFAULT_PASSWORD;
        }
    }

    public String getDomain() {
        return this.domain;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public String getName() {
        if (!(this.domain.length() > 0 && !this.domain.equals("?"))) {
            return this.username;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.domain);
        sb.append("\\");
        sb.append(this.username);
        return sb.toString();
    }

    /* access modifiers changed from: 0000 */
    public byte[] getAnsiHash(byte[] bArr) {
        if (this.hashesExternal) {
            return this.ansiHash;
        }
        if (this.clientChallenge == null) {
            byte[] bArr2 = new byte[8];
            this.clientChallenge = bArr2;
            RANDOM.nextBytes(bArr2);
        }
        return getLMv2Response(this.domain, this.username, this.password, bArr, this.clientChallenge);
    }

    /* access modifiers changed from: 0000 */
    public byte[] getUnicodeHash(byte[] bArr) {
        return this.hashesExternal ? this.unicodeHash : new byte[0];
    }

    /* access modifiers changed from: 0000 */
    public byte[] getSigningKey(byte[] bArr) throws SmbException {
        throw new SmbException("NTLMv2 requires extended security (jcifs.smb.client.useExtendedSecurity must be true if jcifs.smb.lmCompatibility >= 3)");
    }

    private void getUserSessionKey(byte[] bArr, byte[] bArr2, int i) throws SmbException {
        String str = SmbConstants.UNI_ENCODING;
        if (!this.hashesExternal) {
            try {
                MD4 md4 = new MD4();
                md4.update(this.password.getBytes(str));
                if (this.clientChallenge == null) {
                    byte[] bArr3 = new byte[8];
                    this.clientChallenge = bArr3;
                    RANDOM.nextBytes(bArr3);
                }
                HMACT64 hmact64 = new HMACT64(md4.digest());
                hmact64.update(this.username.toUpperCase().getBytes(str));
                hmact64.update(this.domain.toUpperCase().getBytes(str));
                byte[] digest = hmact64.digest();
                HMACT64 hmact642 = new HMACT64(digest);
                hmact642.update(bArr);
                hmact642.update(this.clientChallenge);
                HMACT64 hmact643 = new HMACT64(digest);
                hmact643.update(hmact642.digest());
                hmact643.digest(bArr2, i, 16);
            } catch (Exception e) {
                throw new SmbException(BLANK, (Throwable) e);
            }
        }
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (obj instanceof NtlmPasswordAuthentication) {
            NtlmPasswordAuthentication ntlmPasswordAuthentication = (NtlmPasswordAuthentication) obj;
            if (ntlmPasswordAuthentication.domain.toUpperCase().equals(this.domain.toUpperCase()) && ntlmPasswordAuthentication.username.toUpperCase().equals(this.username.toUpperCase())) {
                if (this.hashesExternal && ntlmPasswordAuthentication.hashesExternal) {
                    if (Arrays.equals(this.ansiHash, ntlmPasswordAuthentication.ansiHash) && Arrays.equals(this.unicodeHash, ntlmPasswordAuthentication.unicodeHash)) {
                        z = true;
                    }
                    return z;
                } else if (this.hashesExternal || !this.password.equals(ntlmPasswordAuthentication.password)) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        return getName().toUpperCase().hashCode();
    }

    public String toString() {
        return getName();
    }

    private static String unescape(String str) throws NumberFormatException, UnsupportedEncodingException {
        byte[] bArr = new byte[1];
        if (str == null) {
            return null;
        }
        int length = str.length();
        char[] cArr = new char[length];
        int i = 0;
        int i2 = 0;
        boolean z = false;
        while (i < length) {
            if (!z) {
                char charAt = str.charAt(i);
                if (charAt == '%') {
                    z = true;
                } else {
                    int i3 = i2 + 1;
                    cArr[i2] = charAt;
                    i2 = i3;
                }
            } else if (z) {
                bArr[0] = (byte) (Integer.parseInt(str.substring(i, i + 2), 16) & 255);
                int i4 = i2 + 1;
                cArr[i2] = new String(bArr, 0, 1, "ASCII").charAt(0);
                i++;
                i2 = i4;
                z = false;
            }
            i++;
        }
        return new String(cArr, 0, i2);
    }
}
