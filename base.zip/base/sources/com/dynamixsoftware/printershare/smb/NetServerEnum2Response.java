package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;

class NetServerEnum2Response extends SmbComTransactionResponse {
    private int converter;
    String lastName;
    private int totalAvailableEntries;

    private class ServerInfo1 implements FileEntry {
        /* access modifiers changed from: private */
        public String commentOrMasterBrowser;
        /* access modifiers changed from: private */
        public String name;
        /* access modifiers changed from: private */
        public int type;
        /* access modifiers changed from: private */
        public int versionMajor;
        /* access modifiers changed from: private */
        public int versionMinor;

        public long createTime() {
            return 0;
        }

        public int getAttributes() {
            return 17;
        }

        public long lastModified() {
            return 0;
        }

        public long length() {
            return 0;
        }

        private ServerInfo1() {
        }

        public String getName() {
            return this.name;
        }

        public int getType() {
            return (this.type & SmbConstants.CAP_EXTENDED_SECURITY) != 0 ? 2 : 4;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("ServerInfo1[name=");
            sb.append(this.name);
            sb.append(",versionMajor=");
            sb.append(this.versionMajor);
            sb.append(",versionMinor=");
            sb.append(this.versionMinor);
            sb.append(",type=0x");
            sb.append(Dumper.toHexString(this.type, 8));
            sb.append(",commentOrMasterBrowser=");
            sb.append(this.commentOrMasterBrowser);
            sb.append("]");
            return new String(sb.toString());
        }
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NetServerEnum2Response() {
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        this.status = readInt2(bArr, i);
        int i3 = i + 2;
        this.converter = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.numEntries = readInt2(bArr, i4);
        int i5 = i4 + 2;
        this.totalAvailableEntries = readInt2(bArr, i5);
        return (i5 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        this.results = new ServerInfo1[this.numEntries];
        String str = null;
        int i3 = i;
        ServerInfo1 serverInfo1 = null;
        int i4 = 0;
        while (i4 < this.numEntries) {
            FileEntry[] fileEntryArr = this.results;
            ServerInfo1 serverInfo12 = new ServerInfo1();
            fileEntryArr[i4] = serverInfo12;
            serverInfo12.name = readString(bArr, i3, 16, false);
            int i5 = i3 + 16;
            int i6 = i5 + 1;
            serverInfo12.versionMajor = bArr[i5] & Constants.UNKNOWN;
            int i7 = i6 + 1;
            serverInfo12.versionMinor = bArr[i6] & Constants.UNKNOWN;
            serverInfo12.type = readInt4(bArr, i7);
            int i8 = i7 + 4;
            int readInt4 = readInt4(bArr, i8);
            i3 = i8 + 4;
            serverInfo12.commentOrMasterBrowser = readString(bArr, ((readInt4 & 65535) - this.converter) + i, 48, false);
            i4++;
            serverInfo1 = serverInfo12;
        }
        if (this.numEntries != 0) {
            str = serverInfo1.name;
        }
        this.lastName = str;
        return i3 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NetServerEnum2Response[");
        sb.append(super.toString());
        sb.append(",status=");
        sb.append(this.status);
        sb.append(",converter=");
        sb.append(this.converter);
        sb.append(",entriesReturned=");
        sb.append(this.numEntries);
        sb.append(",totalAvailableEntries=");
        sb.append(this.totalAvailableEntries);
        sb.append(",lastName=");
        sb.append(this.lastName);
        sb.append("]");
        return new String(sb.toString());
    }
}
