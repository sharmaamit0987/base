package com.dynamixsoftware.printershare.smb;

public class BufferCache {
    private static final int MAX_BUFFERS = 16;
    private static Object[] cache = new Object[16];
    private static int freeBuffers;

    public static byte[] getBuffer() {
        synchronized (cache) {
            if (freeBuffers > 0) {
                for (int i = 0; i < 16; i++) {
                    if (cache[i] != null) {
                        byte[] bArr = (byte[]) cache[i];
                        cache[i] = null;
                        freeBuffers--;
                        return bArr;
                    }
                }
            }
            byte[] bArr2 = new byte[65535];
            return bArr2;
        }
    }

    static void getBuffers(SmbComTransaction smbComTransaction, SmbComTransactionResponse smbComTransactionResponse) {
        synchronized (cache) {
            smbComTransaction.txn_buf = getBuffer();
            smbComTransactionResponse.txn_buf = getBuffer();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0022, code lost:
        return;
     */
    public static void releaseBuffer(byte[] bArr) {
        synchronized (cache) {
            if (freeBuffers < 16) {
                for (int i = 0; i < 16; i++) {
                    if (cache[i] == null) {
                        cache[i] = bArr;
                        freeBuffers++;
                        return;
                    }
                }
            }
        }
    }
}
