package com.dynamixsoftware.printershare.smb;

class SmbComReadAndXResponse extends AndXServerMessageBlock {
    byte[] b;
    private int dataCompactionMode;
    int dataLength;
    int dataOffset;
    int off;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComReadAndXResponse() {
    }

    SmbComReadAndXResponse(byte[] bArr, int i) {
        this.b = bArr;
        this.off = i;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        int i2 = i + 2;
        this.dataCompactionMode = readInt2(bArr, i2);
        int i3 = i2 + 4;
        this.dataLength = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.dataOffset = readInt2(bArr, i4);
        return (i4 + 12) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComReadAndXResponse[");
        sb.append(super.toString());
        sb.append(",dataCompactionMode=");
        sb.append(this.dataCompactionMode);
        sb.append(",dataLength=");
        sb.append(this.dataLength);
        sb.append(",dataOffset=");
        sb.append(this.dataOffset);
        sb.append("]");
        return new String(sb.toString());
    }
}
