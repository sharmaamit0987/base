package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;

class Trans2FindFirst2 extends SmbComTransaction {
    private static final int DEFAULT_LIST_COUNT = 200;
    private static final int DEFAULT_LIST_SIZE = 65535;
    static final int LIST_COUNT = 200;
    static final int LIST_SIZE = 65535;
    static final int SMB_FILE_BOTH_DIRECTORY_INFO = 260;
    private int flags;
    private int informationLevel;
    private int searchAttributes;
    private int searchStorageType = 0;
    private String wildcard;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    Trans2FindFirst2(String str, String str2, int i) {
        String str3 = "\\";
        if (str.equals(str3)) {
            this.path = str;
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(str3);
            this.path = sb.toString();
        }
        this.wildcard = str2;
        this.searchAttributes = i & 55;
        this.command = 50;
        this.subCommand = 1;
        this.flags = 0;
        this.informationLevel = SMB_FILE_BOTH_DIRECTORY_INFO;
        this.totalDataCount = 0;
        this.maxParameterCount = 10;
        this.maxDataCount = 65535;
        this.maxSetupCount = 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = this.subCommand;
        bArr[i2] = 0;
        return 2;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.searchAttributes, bArr, i);
        int i2 = i + 2;
        writeInt2(200, bArr, i2);
        int i3 = i2 + 2;
        writeInt2((long) this.flags, bArr, i3);
        int i4 = i3 + 2;
        writeInt2((long) this.informationLevel, bArr, i4);
        int i5 = i4 + 2;
        writeInt4((long) this.searchStorageType, bArr, i5);
        int i6 = i5 + 4;
        StringBuilder sb = new StringBuilder();
        sb.append(this.path);
        sb.append(this.wildcard);
        return (i6 + writeString(sb.toString(), bArr, i6)) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Trans2FindFirst2[");
        sb.append(super.toString());
        sb.append(",searchAttributes=0x");
        sb.append(Dumper.toHexString(this.searchAttributes, 2));
        sb.append(",searchCount=");
        sb.append(200);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags, 2));
        sb.append(",informationLevel=0x");
        sb.append(Dumper.toHexString(this.informationLevel, 3));
        sb.append(",searchStorageType=");
        sb.append(this.searchStorageType);
        sb.append(",filename=");
        sb.append(this.path);
        sb.append("]");
        return new String(sb.toString());
    }
}
