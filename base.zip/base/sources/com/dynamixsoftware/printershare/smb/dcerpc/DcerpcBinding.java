package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.lsarpc;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.rprn;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.samr;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.srvsvc;
import java.util.HashMap;

class DcerpcBinding {
    private static HashMap<String, String> INTERFACES;
    String endpoint = null;
    int major;
    int minor;
    private HashMap<String, Object> options = null;
    private String proto;
    String server;
    UUID uuid = null;

    static {
        HashMap<String, String> hashMap = new HashMap<>();
        INTERFACES = hashMap;
        hashMap.put("srvsvc", srvsvc.getSyntax());
        INTERFACES.put("lsarpc", lsarpc.getSyntax());
        INTERFACES.put("samr", samr.getSyntax());
        INTERFACES.put("spoolss", rprn.getSyntax());
    }

    DcerpcBinding(String str, String str2) {
        this.proto = str;
        this.server = str2;
    }

    /* access modifiers changed from: 0000 */
    public void setOption(String str, Object obj) throws DcerpcException {
        if (str.equals("endpoint")) {
            String lowerCase = obj.toString().toLowerCase();
            this.endpoint = lowerCase;
            if (lowerCase.startsWith("\\pipe\\")) {
                String str2 = (String) INTERFACES.get(this.endpoint.substring(6));
                if (str2 != null) {
                    int indexOf = str2.indexOf(58);
                    int i = indexOf + 1;
                    int indexOf2 = str2.indexOf(46, i);
                    this.uuid = new UUID(str2.substring(0, indexOf));
                    this.major = Integer.parseInt(str2.substring(i, indexOf2));
                    this.minor = Integer.parseInt(str2.substring(indexOf2 + 1));
                    return;
                }
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Bad endpoint: ");
            sb.append(this.endpoint);
            throw new DcerpcException(sb.toString());
        }
        if (this.options == null) {
            this.options = new HashMap<>();
        }
        this.options.put(str, obj);
    }

    /* access modifiers changed from: 0000 */
    public Object getOption(String str) {
        if (str.equals("endpoint")) {
            return this.endpoint;
        }
        HashMap<String, Object> hashMap = this.options;
        if (hashMap != null) {
            return hashMap.get(str);
        }
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.proto);
        sb.append(":");
        sb.append(this.server);
        sb.append("[");
        sb.append(this.endpoint);
        String sb2 = sb.toString();
        HashMap<String, Object> hashMap = this.options;
        if (hashMap != null) {
            for (Object next : hashMap.keySet()) {
                Object obj = this.options.get(next);
                StringBuilder sb3 = new StringBuilder();
                sb3.append(sb2);
                sb3.append(",");
                sb3.append(next);
                sb3.append("=");
                sb3.append(obj);
                sb2 = sb3.toString();
            }
        }
        StringBuilder sb4 = new StringBuilder();
        sb4.append(sb2);
        sb4.append("]");
        return sb4.toString();
    }
}
