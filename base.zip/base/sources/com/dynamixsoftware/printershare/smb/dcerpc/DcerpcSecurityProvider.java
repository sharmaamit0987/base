package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;

interface DcerpcSecurityProvider {
    void unwrap(NdrBuffer ndrBuffer) throws DcerpcException;

    void wrap(NdrBuffer ndrBuffer) throws DcerpcException;
}
