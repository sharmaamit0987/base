package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrObject;

public abstract class DcerpcMessage extends NdrObject implements DcerpcConstants {
    protected int alloc_hint = 0;
    protected int call_id = 0;
    protected int flags = 0;
    protected int length = 0;
    protected int ptype = -1;
    protected int result = 0;

    public abstract void decode_out(NdrBuffer ndrBuffer) throws NdrException;

    public abstract void encode_in(NdrBuffer ndrBuffer) throws NdrException;

    public abstract int getOpnum();

    /* access modifiers changed from: 0000 */
    public boolean isFlagSet(int i) {
        return (this.flags & i) == i;
    }

    public void setFlag(int i) {
        this.flags = i | this.flags;
    }

    public DcerpcException getResult() {
        if (this.result != 0) {
            return new DcerpcException(this.result);
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    public void encode_header(NdrBuffer ndrBuffer) {
        ndrBuffer.enc_ndr_small(5);
        ndrBuffer.enc_ndr_small(0);
        ndrBuffer.enc_ndr_small(this.ptype);
        ndrBuffer.enc_ndr_small(this.flags);
        ndrBuffer.enc_ndr_long(16);
        ndrBuffer.enc_ndr_short(this.length);
        ndrBuffer.enc_ndr_short(0);
        ndrBuffer.enc_ndr_long(this.call_id);
    }

    /* access modifiers changed from: 0000 */
    public void decode_header(NdrBuffer ndrBuffer) throws NdrException {
        if (ndrBuffer.dec_ndr_small() == 5 && ndrBuffer.dec_ndr_small() == 0) {
            this.ptype = ndrBuffer.dec_ndr_small();
            this.flags = ndrBuffer.dec_ndr_small();
            if (ndrBuffer.dec_ndr_long() == 16) {
                this.length = ndrBuffer.dec_ndr_short();
                if (ndrBuffer.dec_ndr_short() == 0) {
                    this.call_id = ndrBuffer.dec_ndr_long();
                    return;
                }
                throw new NdrException("DCERPC authentication not supported");
            }
            throw new NdrException("Data representation not supported");
        }
        throw new NdrException("DCERPC version not supported");
    }

    public void encode(NdrBuffer ndrBuffer) throws NdrException {
        int index = ndrBuffer.getIndex();
        ndrBuffer.advance(16);
        int i = 0;
        if (this.ptype == 0) {
            int index2 = ndrBuffer.getIndex();
            ndrBuffer.enc_ndr_long(0);
            ndrBuffer.enc_ndr_short(0);
            ndrBuffer.enc_ndr_short(getOpnum());
            i = index2;
        }
        encode_in(ndrBuffer);
        this.length = ndrBuffer.getIndex() - index;
        if (this.ptype == 0) {
            ndrBuffer.setIndex(i);
            int i2 = this.length - i;
            this.alloc_hint = i2;
            ndrBuffer.enc_ndr_long(i2);
        }
        ndrBuffer.setIndex(index);
        encode_header(ndrBuffer);
        ndrBuffer.setIndex(index + this.length);
    }

    public void decode(NdrBuffer ndrBuffer) throws NdrException {
        decode_header(ndrBuffer);
        int i = this.ptype;
        if (i == 12 || i == 2 || i == 3 || i == 13) {
            int i2 = this.ptype;
            if (i2 == 2 || i2 == 3) {
                this.alloc_hint = ndrBuffer.dec_ndr_long();
                ndrBuffer.dec_ndr_short();
                ndrBuffer.dec_ndr_short();
            }
            int i3 = this.ptype;
            if (i3 == 3 || i3 == 13) {
                this.result = ndrBuffer.dec_ndr_long();
            } else {
                decode_out(ndrBuffer);
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Unexpected ptype: ");
            sb.append(this.ptype);
            throw new NdrException(sb.toString());
        }
    }
}
