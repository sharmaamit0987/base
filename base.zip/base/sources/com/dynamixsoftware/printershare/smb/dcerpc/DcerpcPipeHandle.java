package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication;
import com.dynamixsoftware.printershare.smb.SmbFileInputStream;
import com.dynamixsoftware.printershare.smb.SmbFileOutputStream;
import com.dynamixsoftware.printershare.smb.SmbNamedPipe;
import com.dynamixsoftware.printershare.smb.util.Encdec;
import com.flurry.android.Constants;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

class DcerpcPipeHandle extends DcerpcHandle {
    private SmbFileInputStream in = null;
    private boolean isStart = true;
    private SmbFileOutputStream out = null;
    SmbNamedPipe pipe;

    DcerpcPipeHandle(String str, NtlmPasswordAuthentication ntlmPasswordAuthentication) throws UnknownHostException, MalformedURLException, DcerpcException {
        this.binding = DcerpcHandle.parseBinding(str);
        StringBuilder sb = new StringBuilder();
        sb.append("smb://");
        sb.append(this.binding.server);
        sb.append("/IPC$/");
        sb.append(this.binding.endpoint.substring(6));
        String sb2 = sb.toString();
        String str2 = (String) this.binding.getOption("server");
        String str3 = "";
        if (str2 != null) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str3);
            sb3.append("&server=");
            sb3.append(str2);
            str3 = sb3.toString();
        }
        String str4 = (String) this.binding.getOption("address");
        if (str2 != null) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str3);
            sb4.append("&address=");
            sb4.append(str4);
            str3 = sb4.toString();
        }
        if (str3.length() > 0) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(sb2);
            sb5.append("?");
            sb5.append(str3.substring(1));
            sb2 = sb5.toString();
        }
        this.pipe = new SmbNamedPipe(sb2, 27198979, ntlmPasswordAuthentication);
    }

    /* access modifiers changed from: protected */
    public void doSendFragment(byte[] bArr, int i, int i2, boolean z) throws IOException {
        SmbFileOutputStream smbFileOutputStream = this.out;
        if (smbFileOutputStream == null || smbFileOutputStream.isOpen()) {
            if (this.in == null) {
                this.in = (SmbFileInputStream) this.pipe.getNamedPipeInputStream();
            }
            if (this.out == null) {
                this.out = (SmbFileOutputStream) this.pipe.getNamedPipeOutputStream();
            }
            if (z) {
                this.out.writeDirect(bArr, i, i2, 1);
            } else {
                this.out.write(bArr, i, i2);
            }
        } else {
            throw new IOException("DCERPC pipe is no longer open");
        }
    }

    /* access modifiers changed from: protected */
    public void doReceiveFragment(byte[] bArr, boolean z) throws IOException {
        int i;
        if (bArr.length >= this.max_recv) {
            boolean z2 = false;
            if (!this.isStart || z) {
                i = this.in.readDirect(bArr, 0, bArr.length);
            } else {
                i = this.in.read(bArr, 0, 1024);
            }
            if (bArr[0] == 5 || bArr[1] == 0) {
                if ((bArr[3] & Constants.UNKNOWN & 2) == 2) {
                    z2 = true;
                }
                this.isStart = z2;
                short dec_uint16le = Encdec.dec_uint16le(bArr, 8);
                if (dec_uint16le <= this.max_recv) {
                    while (i < dec_uint16le) {
                        i += this.in.readDirect(bArr, i, dec_uint16le - i);
                    }
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected fragment length: ");
                sb.append(dec_uint16le);
                throw new IOException(sb.toString());
            }
            throw new IOException("Unexpected DCERPC PDU header");
        }
        throw new IllegalArgumentException("buffer too small");
    }

    public void close() throws IOException {
        this.state = 0;
        SmbFileOutputStream smbFileOutputStream = this.out;
        if (smbFileOutputStream != null) {
            smbFileOutputStream.close();
        }
    }
}
