package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

import com.dynamixsoftware.printershare.smb.FileEntry;
import com.dynamixsoftware.printershare.smb.SmbShareInfo;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;

public class MsrpcShareEnum extends ShareEnumAll {

    private class MsrpcShareInfo1 extends SmbShareInfo {
        private MsrpcShareInfo1(ShareInfo1 shareInfo1) {
            this.netName = shareInfo1.netname;
            this.type = shareInfo1.type;
            this.remark = shareInfo1.remark;
        }
    }

    public /* bridge */ /* synthetic */ void decode_out(NdrBuffer ndrBuffer) throws NdrException {
        super.decode_out(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ void encode_in(NdrBuffer ndrBuffer) throws NdrException {
        super.encode_in(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ int getOpnum() {
        return super.getOpnum();
    }

    public MsrpcShareEnum(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append("\\\\");
        sb.append(str);
        super(sb.toString(), 1, new ShareInfoCtr1(), -1, 0, 0);
        this.ptype = 0;
        this.flags = 3;
    }

    public FileEntry[] getEntries() {
        ShareInfoCtr1 shareInfoCtr1 = (ShareInfoCtr1) this.info;
        MsrpcShareInfo1[] msrpcShareInfo1Arr = new MsrpcShareInfo1[shareInfoCtr1.count];
        for (int i = 0; i < shareInfoCtr1.count; i++) {
            msrpcShareInfo1Arr[i] = new MsrpcShareInfo1(shareInfoCtr1.array[i]);
        }
        return msrpcShareInfo1Arr;
    }
}
