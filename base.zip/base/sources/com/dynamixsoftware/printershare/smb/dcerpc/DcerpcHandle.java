package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.BufferCache;
import com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.security.Principal;

public abstract class DcerpcHandle implements DcerpcConstants {
    private static int call_id = 1;
    protected DcerpcBinding binding;
    protected int max_recv = 4280;
    protected int max_xmit = 4280;
    private DcerpcSecurityProvider securityProvider = null;
    protected int state = 0;

    public abstract void close() throws IOException;

    /* access modifiers changed from: protected */
    public abstract void doReceiveFragment(byte[] bArr, boolean z) throws IOException;

    /* access modifiers changed from: protected */
    public abstract void doSendFragment(byte[] bArr, int i, int i2, boolean z) throws IOException;

    /* JADX WARNING: Removed duplicated region for block: B:25:0x004c  */
    protected static DcerpcBinding parseBinding(String str) throws DcerpcException {
        char[] charArray = str.toCharArray();
        int i = 0;
        String str2 = null;
        DcerpcBinding dcerpcBinding = null;
        String str3 = null;
        char c = 0;
        int i2 = 0;
        do {
            char c2 = charArray[i];
            if (c != 0) {
                if (c != 1) {
                    if (c != 2) {
                        if (c != 5) {
                            i = charArray.length;
                        } else if (c2 == '=') {
                            str3 = str.substring(i2, i).trim();
                        } else if (c2 == ',' || c2 == ']') {
                            String trim = str.substring(i2, i).trim();
                            if (str3 == null) {
                                str3 = "endpoint";
                            }
                            dcerpcBinding.setOption(str3, trim);
                            str3 = null;
                        }
                    }
                    if (c2 == '[') {
                        int length = str.substring(i2, i).trim().length();
                        dcerpcBinding = new DcerpcBinding(str2, str.substring(i2, i));
                        i2 = i + 1;
                        c = 5;
                    }
                } else if (c2 != '\\') {
                    c = 2;
                    if (c2 == '[') {
                    }
                }
                i2 = i + 1;
            } else if (c2 == ':') {
                str2 = str.substring(i2, i);
                i2 = i + 1;
                c = 1;
            }
            i++;
        } while (i < charArray.length);
        if (dcerpcBinding != null && dcerpcBinding.endpoint != null) {
            return dcerpcBinding;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Invalid binding URL: ");
        sb.append(str);
        throw new DcerpcException(sb.toString());
    }

    public static DcerpcHandle getHandle(String str, NtlmPasswordAuthentication ntlmPasswordAuthentication) throws UnknownHostException, MalformedURLException, DcerpcException {
        if (str.startsWith("ncacn_np:")) {
            return new DcerpcPipeHandle(str, ntlmPasswordAuthentication);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("DCERPC transport not supported: ");
        sb.append(str);
        throw new DcerpcException(sb.toString());
    }

    private void bind() throws DcerpcException, IOException {
        synchronized (this) {
            try {
                this.state = 1;
                sendrecv(new DcerpcBind(this.binding, this));
            } catch (IOException e) {
                this.state = 0;
                throw e;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    public void sendrecv(DcerpcMessage dcerpcMessage) throws DcerpcException, IOException {
        if (this.state == 0) {
            bind();
        }
        byte[] buffer = BufferCache.getBuffer();
        try {
            NdrBuffer ndrBuffer = new NdrBuffer(buffer, 0);
            dcerpcMessage.flags = 3;
            int i = call_id;
            call_id = i + 1;
            dcerpcMessage.call_id = i;
            dcerpcMessage.encode(ndrBuffer);
            if (this.securityProvider != null) {
                ndrBuffer.setIndex(0);
                this.securityProvider.wrap(ndrBuffer);
            }
            int length = ndrBuffer.getLength() - 24;
            boolean z = true;
            int i2 = 0;
            while (i2 < length) {
                int i3 = length - i2;
                if (i3 + 24 > this.max_xmit) {
                    dcerpcMessage.flags &= -3;
                    i3 = this.max_xmit - 24;
                } else {
                    dcerpcMessage.flags |= 2;
                    dcerpcMessage.alloc_hint = i3;
                    z = false;
                }
                dcerpcMessage.length = i3 + 24;
                if (i2 > 0) {
                    dcerpcMessage.flags &= -2;
                }
                if ((dcerpcMessage.flags & 3) != 3) {
                    ndrBuffer.start = i2;
                    ndrBuffer.reset();
                    dcerpcMessage.encode_header(ndrBuffer);
                    ndrBuffer.enc_ndr_long(dcerpcMessage.alloc_hint);
                    ndrBuffer.enc_ndr_short(0);
                    ndrBuffer.enc_ndr_short(dcerpcMessage.getOpnum());
                }
                doSendFragment(buffer, i2, dcerpcMessage.length, z);
                i2 += i3;
            }
            doReceiveFragment(buffer, z);
            ndrBuffer.reset();
            ndrBuffer.setIndex(8);
            ndrBuffer.setLength(ndrBuffer.dec_ndr_short());
            if (this.securityProvider != null) {
                this.securityProvider.unwrap(ndrBuffer);
            }
            ndrBuffer.setIndex(0);
            dcerpcMessage.decode_header(ndrBuffer);
            int i4 = (dcerpcMessage.ptype != 2 || dcerpcMessage.isFlagSet(2)) ? 24 : dcerpcMessage.length;
            byte[] bArr = null;
            NdrBuffer ndrBuffer2 = null;
            while (!dcerpcMessage.isFlagSet(2)) {
                if (bArr == null) {
                    bArr = new byte[this.max_recv];
                    ndrBuffer2 = new NdrBuffer(bArr, 0);
                }
                doReceiveFragment(bArr, z);
                ndrBuffer2.reset();
                ndrBuffer2.setIndex(8);
                ndrBuffer2.setLength(ndrBuffer2.dec_ndr_short());
                if (this.securityProvider != null) {
                    this.securityProvider.unwrap(ndrBuffer2);
                }
                ndrBuffer2.reset();
                dcerpcMessage.decode_header(ndrBuffer2);
                int i5 = dcerpcMessage.length - 24;
                int i6 = i4 + i5;
                if (i6 > buffer.length) {
                    byte[] bArr2 = new byte[i6];
                    System.arraycopy(buffer, 0, bArr2, 0, i4);
                    buffer = bArr2;
                }
                System.arraycopy(bArr, 24, buffer, i4, i5);
                i4 = i6;
            }
            dcerpcMessage.decode(new NdrBuffer(buffer, 0));
            BufferCache.releaseBuffer(buffer);
            DcerpcException result = dcerpcMessage.getResult();
            if (result != null) {
                throw result;
            }
        } catch (Throwable th) {
            BufferCache.releaseBuffer(buffer);
            throw th;
        }
    }

    public void setDcerpcSecurityProvider(DcerpcSecurityProvider dcerpcSecurityProvider) {
        this.securityProvider = dcerpcSecurityProvider;
    }

    public String getServer() {
        if (this instanceof DcerpcPipeHandle) {
            return ((DcerpcPipeHandle) this).pipe.getServer();
        }
        return null;
    }

    public Principal getPrincipal() {
        if (this instanceof DcerpcPipeHandle) {
            return ((DcerpcPipeHandle) this).pipe.getPrincipal();
        }
        return null;
    }

    public String toString() {
        return this.binding.toString();
    }
}
