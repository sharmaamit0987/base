package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

public class lsarpc {
    public static String getSyntax() {
        return "12345778-1234-abcd-ef00-0123456789ab:0.0";
    }
}
