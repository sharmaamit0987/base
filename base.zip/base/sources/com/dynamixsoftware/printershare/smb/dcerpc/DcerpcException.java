package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.WinError;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.io.IOException;

class DcerpcException extends IOException implements DcerpcError, WinError {
    private int error;

    private static String getMessageByDcerpcError(int i) {
        int length = DCERPC_FAULT_CODES.length;
        int i2 = 0;
        while (length >= i2) {
            int i3 = (i2 + length) / 2;
            if (i > DCERPC_FAULT_CODES[i3]) {
                i2 = i3 + 1;
            } else if (i >= DCERPC_FAULT_CODES[i3]) {
                return DCERPC_FAULT_MESSAGES[i3];
            } else {
                length = i3 - 1;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("0x");
        sb.append(Dumper.toHexString(i, 8));
        return sb.toString();
    }

    DcerpcException(int i) {
        super(getMessageByDcerpcError(i));
        this.error = i;
    }

    DcerpcException(String str) {
        super(str);
    }

    public int getErrorCode() {
        return this.error;
    }
}
