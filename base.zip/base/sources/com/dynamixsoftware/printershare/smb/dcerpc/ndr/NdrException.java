package com.dynamixsoftware.printershare.smb.dcerpc.ndr;

import java.io.IOException;

public class NdrException extends IOException {
    public static final String INVALID_CONFORMANCE = "invalid array conformance";

    public NdrException(String str) {
        super(str);
    }
}
