package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

import com.dynamixsoftware.printershare.smb.dcerpc.DcerpcMessage;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrObject;
import java.io.UnsupportedEncodingException;

public class rprn {

    private static class PrinterInfo1Struct extends NdrObject {
        private String comment;
        private String description;
        private int flags;
        private String name;

        private PrinterInfo1Struct() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_long(this.flags);
            ndrBuffer.enc_ndr_referent(this.description, 1);
            ndrBuffer.enc_ndr_referent(this.name, 1);
            ndrBuffer.enc_ndr_referent(this.comment, 1);
            if (this.comment != null) {
                ndrBuffer = ndrBuffer.deferred;
                ndrBuffer.enc_ndr_string(this.comment);
            }
            if (this.name != null) {
                ndrBuffer = ndrBuffer.deferred;
                ndrBuffer.enc_ndr_string(this.name);
            }
            if (this.description != null) {
                ndrBuffer.deferred.enc_ndr_string(this.description);
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            this.flags = ndrBuffer.dec_ndr_long();
            int dec_ndr_long = ndrBuffer.dec_ndr_long();
            int dec_ndr_long2 = ndrBuffer.dec_ndr_long();
            int dec_ndr_long3 = ndrBuffer.dec_ndr_long();
            int i = 0;
            int i2 = 16;
            do {
                String str = SmbConstants.UNI_ENCODING;
                if (i2 == dec_ndr_long) {
                    int i3 = ndrBuffer.index;
                    do {
                    } while (ndrBuffer.dec_ndr_short() != 0);
                    try {
                        this.description = new String(ndrBuffer.buf, i3, (ndrBuffer.index - i3) - 2, str);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    i++;
                }
                if (i2 == dec_ndr_long2) {
                    int i4 = ndrBuffer.index;
                    do {
                    } while (ndrBuffer.dec_ndr_short() != 0);
                    try {
                        this.name = new String(ndrBuffer.buf, i4, (ndrBuffer.index - i4) - 2, str);
                    } catch (UnsupportedEncodingException e2) {
                        e2.printStackTrace();
                    }
                    i++;
                }
                if (i2 == dec_ndr_long3) {
                    int i5 = ndrBuffer.index;
                    do {
                    } while (ndrBuffer.dec_ndr_short() != 0);
                    try {
                        this.comment = new String(ndrBuffer.buf, i5, (ndrBuffer.index - i5) - 2, str);
                    } catch (UnsupportedEncodingException e3) {
                        e3.printStackTrace();
                    }
                    i++;
                }
                ndrBuffer.dec_ndr_small();
                i2++;
            } while (i < 3);
        }
    }

    private static class PrinterInfo2Struct extends NdrObject {
        private int Attributes;
        private int AveragePPM;
        private int DefaultPriority;
        private int Priority;
        private int StartTime;
        private int Status;
        private int UntilTime;
        private int cJobs;
        private String pComment;
        private String pDatatype;
        private int pDevMode;
        /* access modifiers changed from: private */
        public String pDriverName;
        /* access modifiers changed from: private */
        public String pLocation;
        private String pParameters;
        private String pPortName;
        private String pPrintProcessor;
        /* access modifiers changed from: private */
        public String pPrinterName;
        private byte[] pSecurityDescriptor;
        private String pSepFile;
        /* access modifiers changed from: private */
        public String pServerName;
        private String pShareName;

        private PrinterInfo2Struct() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_referent(this.pServerName, 1);
            ndrBuffer.enc_ndr_referent(this.pPrinterName, 1);
            ndrBuffer.enc_ndr_referent(this.pShareName, 1);
            ndrBuffer.enc_ndr_referent(this.pPortName, 1);
            ndrBuffer.enc_ndr_referent(this.pDriverName, 1);
            ndrBuffer.enc_ndr_referent(this.pComment, 1);
            ndrBuffer.enc_ndr_referent(this.pLocation, 1);
            ndrBuffer.enc_ndr_long(this.pDevMode);
            ndrBuffer.enc_ndr_referent(this.pSepFile, 1);
            ndrBuffer.enc_ndr_referent(this.pPrintProcessor, 1);
            ndrBuffer.enc_ndr_referent(this.pDatatype, 1);
            ndrBuffer.enc_ndr_referent(this.pParameters, 1);
            ndrBuffer.enc_ndr_referent(this.pSecurityDescriptor, 1);
            ndrBuffer.enc_ndr_long(this.Attributes);
            ndrBuffer.enc_ndr_long(this.Priority);
            ndrBuffer.enc_ndr_long(this.DefaultPriority);
            ndrBuffer.enc_ndr_long(this.StartTime);
            ndrBuffer.enc_ndr_long(this.UntilTime);
            ndrBuffer.enc_ndr_long(this.Status);
            ndrBuffer.enc_ndr_long(this.cJobs);
            ndrBuffer.enc_ndr_long(this.AveragePPM);
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            int i;
            int i2;
            NdrBuffer ndrBuffer2 = ndrBuffer;
            ndrBuffer2.align(4);
            int dec_ndr_long = ndrBuffer.dec_ndr_long();
            int i3 = dec_ndr_long == 0 ? 1 : 0;
            int dec_ndr_long2 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long2 == 0) {
                i3++;
            }
            int dec_ndr_long3 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long3 == 0) {
                i3++;
            }
            int dec_ndr_long4 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long4 == 0) {
                i3++;
            }
            int dec_ndr_long5 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long5 == 0) {
                i3++;
            }
            int dec_ndr_long6 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long6 == 0) {
                i3++;
            }
            int dec_ndr_long7 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long7 == 0) {
                i3++;
            }
            this.pDevMode = ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            this.Attributes = ndrBuffer.dec_ndr_long();
            this.Priority = ndrBuffer.dec_ndr_long();
            this.DefaultPriority = ndrBuffer.dec_ndr_long();
            this.StartTime = ndrBuffer.dec_ndr_long();
            this.UntilTime = ndrBuffer.dec_ndr_long();
            this.Status = ndrBuffer.dec_ndr_long();
            this.cJobs = ndrBuffer.dec_ndr_long();
            this.AveragePPM = ndrBuffer.dec_ndr_long();
            int i4 = 84;
            while (true) {
                String str = SmbConstants.UNI_ENCODING;
                if (i4 == dec_ndr_long) {
                    try {
                        int i5 = ndrBuffer2.index;
                        while (ndrBuffer.dec_ndr_short() != 0) {
                        }
                        this.pServerName = new String(ndrBuffer2.buf, i5, (ndrBuffer2.index - i5) - 2, str);
                        i4 += ndrBuffer2.index - i5;
                        i = i3 + 1;
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        return;
                    }
                } else {
                    i = i3;
                }
                if (i4 == dec_ndr_long2) {
                    int i6 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    i2 = dec_ndr_long;
                    this.pPrinterName = new String(ndrBuffer2.buf, i6, (ndrBuffer2.index - i6) - 2, str);
                    i4 += ndrBuffer2.index - i6;
                    i++;
                } else {
                    i2 = dec_ndr_long;
                }
                if (i4 == dec_ndr_long3) {
                    int i7 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    this.pShareName = new String(ndrBuffer2.buf, i7, (ndrBuffer2.index - i7) - 2, str);
                    i4 += ndrBuffer2.index - i7;
                    i++;
                }
                if (i4 == dec_ndr_long4) {
                    int i8 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    this.pPortName = new String(ndrBuffer2.buf, i8, (ndrBuffer2.index - i8) - 2, str);
                    i4 += ndrBuffer2.index - i8;
                    i++;
                }
                if (i4 == dec_ndr_long5) {
                    int i9 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    this.pDriverName = new String(ndrBuffer2.buf, i9, (ndrBuffer2.index - i9) - 2, str);
                    i4 += ndrBuffer2.index - i9;
                    i++;
                }
                if (i4 == dec_ndr_long6) {
                    int i10 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    this.pComment = new String(ndrBuffer2.buf, i10, (ndrBuffer2.index - i10) - 2, str);
                    i4 += ndrBuffer2.index - i10;
                    i++;
                }
                if (i4 == dec_ndr_long7) {
                    int i11 = ndrBuffer2.index;
                    while (ndrBuffer.dec_ndr_short() != 0) {
                    }
                    this.pLocation = new String(ndrBuffer2.buf, i11, (ndrBuffer2.index - i11) - 2, str);
                    i4 += ndrBuffer2.index - i11;
                    i++;
                }
                if (i3 == i) {
                    ndrBuffer.dec_ndr_small();
                    i4++;
                }
                if (i < 7) {
                    i3 = i;
                    dec_ndr_long = i2;
                } else {
                    return;
                }
            }
        }
    }

    static class RpcClosePrinter extends DcerpcMessage {
        private byte[] printerhandle;
        public int retval;

        public int getOpnum() {
            return 29;
        }

        RpcClosePrinter(byte[] bArr) {
            this.printerhandle = bArr;
        }

        public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
            int i = 0;
            while (true) {
                byte[] bArr = this.printerhandle;
                if (i < bArr.length) {
                    ndrBuffer.enc_ndr_small(bArr[i]);
                    i++;
                } else {
                    return;
                }
            }
        }

        public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
            int i = this.alloc_hint - 4;
            ndrBuffer.readOctetArray(new byte[i], 0, i);
            this.retval = ndrBuffer.dec_ndr_long();
        }
    }

    static class RpcGetPrinter extends DcerpcMessage {
        private int cbBuf;
        protected String driverName;
        private NdrObject info;
        private int level;
        String location;
        public int pcbneeded;
        protected String printerName;
        private byte[] printerhandle;
        public int retval;
        protected String serverName;

        public int getOpnum() {
            return 8;
        }

        RpcGetPrinter(byte[] bArr, int i, int i2) {
            this.printerhandle = bArr;
            this.level = i;
            this.cbBuf = i2;
            if (i2 == 0) {
                this.info = null;
            } else if (i == 1) {
                this.info = new PrinterInfo1Struct();
            } else if (i == 2) {
                this.info = new PrinterInfo2Struct();
            }
        }

        public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
            int i = 0;
            while (true) {
                byte[] bArr = this.printerhandle;
                if (i >= bArr.length) {
                    break;
                }
                ndrBuffer.enc_ndr_small(bArr[i]);
                i++;
            }
            ndrBuffer.enc_ndr_long(this.level);
            ndrBuffer.enc_ndr_referent(this.info, 1);
            if (this.info != null) {
                ndrBuffer.enc_ndr_long(this.cbBuf);
                int i2 = this.cbBuf;
                ndrBuffer.writeOctetArray(new byte[i2], 0, i2);
            }
            ndrBuffer.enc_ndr_long(this.cbBuf);
        }

        public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
            if (ndrBuffer.dec_ndr_long() != 0) {
                ndrBuffer.dec_ndr_long();
                if (this.info != null) {
                    ndrBuffer = ndrBuffer.deferred;
                    this.info.decode(ndrBuffer);
                    if (this.level == 2) {
                        this.driverName = ((PrinterInfo2Struct) this.info).pDriverName;
                        this.printerName = ((PrinterInfo2Struct) this.info).pPrinterName;
                        this.serverName = ((PrinterInfo2Struct) this.info).pServerName;
                        this.location = ((PrinterInfo2Struct) this.info).pLocation;
                    } else {
                        String str = "";
                        this.driverName = str;
                        this.printerName = str;
                        this.serverName = str;
                        this.location = str;
                    }
                }
            }
            this.pcbneeded = ndrBuffer.dec_ndr_long();
            this.retval = ndrBuffer.dec_ndr_long();
        }
    }

    static class RpcOpenPrinter extends DcerpcMessage {
        private String PrinterName;
        protected byte[] printerhandle;
        public int retval;

        public int getOpnum() {
            return 1;
        }

        RpcOpenPrinter(String str) {
            this.PrinterName = str;
        }

        public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.enc_ndr_referent(this.PrinterName, 1);
            String str = this.PrinterName;
            if (str != null) {
                ndrBuffer.enc_ndr_string(str);
            }
            ndrBuffer.enc_ndr_referent(this.PrinterName, 1);
            ndrBuffer.enc_ndr_string("RAW");
            ndrBuffer.enc_ndr_long(0);
            ndrBuffer.enc_ndr_long(0);
            ndrBuffer.enc_ndr_long(8);
        }

        public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
            int i = this.alloc_hint - 4;
            byte[] bArr = new byte[i];
            this.printerhandle = bArr;
            ndrBuffer.readOctetArray(bArr, 0, i);
            this.retval = ndrBuffer.dec_ndr_long();
        }
    }

    static class RpcStartDocPrinter extends DcerpcMessage {
        public int job_id;
        private String job_name;
        private byte[] printerhandle;
        public int retval;

        public int getOpnum() {
            return 17;
        }

        RpcStartDocPrinter(byte[] bArr, String str) {
            this.printerhandle = bArr;
            this.job_name = str;
        }

        public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
            int i = 0;
            while (true) {
                byte[] bArr = this.printerhandle;
                if (i < bArr.length) {
                    ndrBuffer.enc_ndr_small(bArr[i]);
                    i++;
                } else {
                    ndrBuffer.enc_ndr_long(1);
                    ndrBuffer.enc_ndr_referent(this.job_name, 1);
                    ndrBuffer.enc_ndr_string(this.job_name);
                    ndrBuffer.enc_ndr_referent(null, 1);
                    ndrBuffer.enc_ndr_referent(null, 1);
                    return;
                }
            }
        }

        public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
            this.job_id = ndrBuffer.dec_ndr_long();
            this.retval = ndrBuffer.dec_ndr_long();
        }
    }

    public static String getSyntax() {
        return "12345678-1234-abcd-ef00-0123456789ab:1.0";
    }
}
