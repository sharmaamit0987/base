package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

import com.dynamixsoftware.printershare.smb.dcerpc.DcerpcMessage;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrObject;

public class srvsvc {

    static class ShareEnumAll extends DcerpcMessage {
        NdrObject info;
        private int level;
        private int prefmaxlen;
        private int resume_handle;
        public int retval;
        private String servername;

        public int getOpnum() {
            return 15;
        }

        ShareEnumAll(String str, int i, NdrObject ndrObject, int i2, int i3, int i4) {
            this.servername = str;
            this.level = i;
            this.info = ndrObject;
            this.prefmaxlen = i2;
            this.resume_handle = i4;
        }

        public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.enc_ndr_referent(this.servername, 1);
            String str = this.servername;
            if (str != null) {
                ndrBuffer.enc_ndr_string(str);
            }
            ndrBuffer.enc_ndr_long(this.level);
            ndrBuffer.enc_ndr_long(this.level);
            ndrBuffer.enc_ndr_referent(this.info, 1);
            if (this.info != null) {
                ndrBuffer = ndrBuffer.deferred;
                this.info.encode(ndrBuffer);
            }
            ndrBuffer.enc_ndr_long(this.prefmaxlen);
            ndrBuffer.enc_ndr_long(this.resume_handle);
        }

        public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
            this.level = ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
            if (ndrBuffer.dec_ndr_long() != 0) {
                if (this.info == null) {
                    this.info = new ShareInfoCtr0();
                }
                ndrBuffer = ndrBuffer.deferred;
                this.info.decode(ndrBuffer);
            }
            ndrBuffer.dec_ndr_long();
            this.resume_handle = ndrBuffer.dec_ndr_long();
            ndrBuffer.dec_ndr_long();
        }
    }

    private static class ShareInfo0 extends NdrObject {
        private String netname;

        private ShareInfo0() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_referent(this.netname, 1);
            if (this.netname != null) {
                ndrBuffer.deferred.enc_ndr_string(this.netname);
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            if (ndrBuffer.dec_ndr_long() != 0) {
                this.netname = ndrBuffer.deferred.dec_ndr_string();
            }
        }
    }

    static class ShareInfo1 extends NdrObject {
        String netname;
        String remark;
        int type;

        ShareInfo1() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_referent(this.netname, 1);
            ndrBuffer.enc_ndr_long(this.type);
            ndrBuffer.enc_ndr_referent(this.remark, 1);
            if (this.netname != null) {
                ndrBuffer = ndrBuffer.deferred;
                ndrBuffer.enc_ndr_string(this.netname);
            }
            if (this.remark != null) {
                ndrBuffer.deferred.enc_ndr_string(this.remark);
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            int dec_ndr_long = ndrBuffer.dec_ndr_long();
            this.type = ndrBuffer.dec_ndr_long();
            int dec_ndr_long2 = ndrBuffer.dec_ndr_long();
            if (dec_ndr_long != 0) {
                ndrBuffer = ndrBuffer.deferred;
                this.netname = ndrBuffer.dec_ndr_string();
            }
            if (dec_ndr_long2 != 0) {
                this.remark = ndrBuffer.deferred.dec_ndr_string();
            }
        }
    }

    private static class ShareInfoCtr0 extends NdrObject {
        private ShareInfo0[] array;
        private int count;

        private ShareInfoCtr0() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_long(this.count);
            ndrBuffer.enc_ndr_referent(this.array, 1);
            if (this.array != null) {
                NdrBuffer ndrBuffer2 = ndrBuffer.deferred;
                int i = this.count;
                ndrBuffer2.enc_ndr_long(i);
                int i2 = ndrBuffer2.index;
                ndrBuffer2.advance(i * 4);
                NdrBuffer derive = ndrBuffer2.derive(i2);
                for (int i3 = 0; i3 < i; i3++) {
                    this.array[i3].encode(derive);
                }
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            this.count = ndrBuffer.dec_ndr_long();
            if (ndrBuffer.dec_ndr_long() != 0) {
                NdrBuffer ndrBuffer2 = ndrBuffer.deferred;
                int dec_ndr_long = ndrBuffer2.dec_ndr_long();
                int i = ndrBuffer2.index;
                ndrBuffer2.advance(dec_ndr_long * 4);
                if (this.array == null) {
                    if (dec_ndr_long < 0 || dec_ndr_long > 65535) {
                        throw new NdrException(NdrException.INVALID_CONFORMANCE);
                    }
                    this.array = new ShareInfo0[dec_ndr_long];
                }
                NdrBuffer derive = ndrBuffer2.derive(i);
                for (int i2 = 0; i2 < dec_ndr_long; i2++) {
                    ShareInfo0[] shareInfo0Arr = this.array;
                    if (shareInfo0Arr[i2] == null) {
                        shareInfo0Arr[i2] = new ShareInfo0();
                    }
                    this.array[i2].decode(derive);
                }
            }
        }
    }

    static class ShareInfoCtr1 extends NdrObject {
        ShareInfo1[] array;
        int count;

        ShareInfoCtr1() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_long(this.count);
            ndrBuffer.enc_ndr_referent(this.array, 1);
            if (this.array != null) {
                NdrBuffer ndrBuffer2 = ndrBuffer.deferred;
                int i = this.count;
                ndrBuffer2.enc_ndr_long(i);
                int i2 = ndrBuffer2.index;
                ndrBuffer2.advance(i * 12);
                NdrBuffer derive = ndrBuffer2.derive(i2);
                for (int i3 = 0; i3 < i; i3++) {
                    this.array[i3].encode(derive);
                }
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            this.count = ndrBuffer.dec_ndr_long();
            if (ndrBuffer.dec_ndr_long() != 0) {
                NdrBuffer ndrBuffer2 = ndrBuffer.deferred;
                int dec_ndr_long = ndrBuffer2.dec_ndr_long();
                int i = ndrBuffer2.index;
                ndrBuffer2.advance(dec_ndr_long * 12);
                if (this.array == null) {
                    if (dec_ndr_long < 0 || dec_ndr_long > 65535) {
                        throw new NdrException(NdrException.INVALID_CONFORMANCE);
                    }
                    this.array = new ShareInfo1[dec_ndr_long];
                }
                NdrBuffer derive = ndrBuffer2.derive(i);
                for (int i2 = 0; i2 < dec_ndr_long; i2++) {
                    ShareInfo1[] shareInfo1Arr = this.array;
                    if (shareInfo1Arr[i2] == null) {
                        shareInfo1Arr[i2] = new ShareInfo1();
                    }
                    this.array[i2].decode(derive);
                }
            }
        }
    }

    public static String getSyntax() {
        return "4b324fc8-1670-01d3-1278-5a47bf6ee188:3.0";
    }
}
