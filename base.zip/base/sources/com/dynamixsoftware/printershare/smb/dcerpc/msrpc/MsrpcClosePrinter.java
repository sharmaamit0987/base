package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;

public class MsrpcClosePrinter extends RpcClosePrinter {
    public /* bridge */ /* synthetic */ void decode_out(NdrBuffer ndrBuffer) throws NdrException {
        super.decode_out(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ void encode_in(NdrBuffer ndrBuffer) throws NdrException {
        super.encode_in(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ int getOpnum() {
        return super.getOpnum();
    }

    public MsrpcClosePrinter(byte[] bArr) {
        super(bArr);
        this.ptype = 0;
        this.flags = 3;
    }
}
