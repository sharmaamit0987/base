package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrObject;

class rpc {

    static class uuid_t extends NdrObject {
        byte clock_seq_hi_and_reserved;
        byte clock_seq_low;
        byte[] node;
        short time_hi_and_version;
        int time_low;
        short time_mid;

        uuid_t() {
        }

        public void encode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            ndrBuffer.enc_ndr_long(this.time_low);
            ndrBuffer.enc_ndr_short(this.time_mid);
            ndrBuffer.enc_ndr_short(this.time_hi_and_version);
            ndrBuffer.enc_ndr_small(this.clock_seq_hi_and_reserved);
            ndrBuffer.enc_ndr_small(this.clock_seq_low);
            int i = ndrBuffer.index;
            ndrBuffer.advance(6);
            NdrBuffer derive = ndrBuffer.derive(i);
            for (int i2 = 0; i2 < 6; i2++) {
                derive.enc_ndr_small(this.node[i2]);
            }
        }

        public void decode(NdrBuffer ndrBuffer) throws NdrException {
            ndrBuffer.align(4);
            this.time_low = ndrBuffer.dec_ndr_long();
            this.time_mid = (short) ndrBuffer.dec_ndr_short();
            this.time_hi_and_version = (short) ndrBuffer.dec_ndr_short();
            this.clock_seq_hi_and_reserved = (byte) ndrBuffer.dec_ndr_small();
            this.clock_seq_low = (byte) ndrBuffer.dec_ndr_small();
            int i = ndrBuffer.index;
            ndrBuffer.advance(6);
            if (this.node == null) {
                this.node = new byte[6];
            }
            NdrBuffer derive = ndrBuffer.derive(i);
            for (int i2 = 0; i2 < 6; i2++) {
                this.node[i2] = (byte) derive.dec_ndr_small();
            }
        }
    }

    rpc() {
    }
}
