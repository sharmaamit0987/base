package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

public class samr {
    public static String getSyntax() {
        return "12345778-1234-abcd-ef00-0123456789ac:1.0";
    }
}
