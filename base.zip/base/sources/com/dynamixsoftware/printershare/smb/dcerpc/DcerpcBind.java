package com.dynamixsoftware.printershare.smb.dcerpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;
import com.dynamixsoftware.printershare.smb.util.Dumper;

class DcerpcBind extends DcerpcMessage {
    private static final String[] result_message = {"0", "DCERPC_BIND_ERR_ABSTRACT_SYNTAX_NOT_SUPPORTED", "DCERPC_BIND_ERR_PROPOSED_TRANSFER_SYNTAXES_NOT_SUPPORTED", "DCERPC_BIND_ERR_LOCAL_LIMIT_EXCEEDED"};
    private DcerpcBinding binding;
    private int max_recv;
    private int max_xmit;

    public int getOpnum() {
        return 0;
    }

    private static String getResultMessage(int i) {
        if (i < 4) {
            return result_message[i];
        }
        StringBuilder sb = new StringBuilder();
        sb.append("0x");
        sb.append(Dumper.toHexString(i, 4));
        return sb.toString();
    }

    public DcerpcException getResult() {
        if (this.result != 0) {
            return new DcerpcException(getResultMessage(this.result));
        }
        return null;
    }

    public DcerpcBind() {
    }

    DcerpcBind(DcerpcBinding dcerpcBinding, DcerpcHandle dcerpcHandle) {
        this.binding = dcerpcBinding;
        this.max_xmit = dcerpcHandle.max_xmit;
        this.max_recv = dcerpcHandle.max_recv;
        this.ptype = 11;
        this.flags = 3;
    }

    public void encode_in(NdrBuffer ndrBuffer) throws NdrException {
        ndrBuffer.enc_ndr_short(this.max_xmit);
        ndrBuffer.enc_ndr_short(this.max_recv);
        ndrBuffer.enc_ndr_long(0);
        ndrBuffer.enc_ndr_small(1);
        ndrBuffer.enc_ndr_small(0);
        ndrBuffer.enc_ndr_short(0);
        ndrBuffer.enc_ndr_short(0);
        ndrBuffer.enc_ndr_small(1);
        ndrBuffer.enc_ndr_small(0);
        this.binding.uuid.encode(ndrBuffer);
        ndrBuffer.enc_ndr_short(this.binding.major);
        ndrBuffer.enc_ndr_short(this.binding.minor);
        DCERPC_UUID_SYNTAX_NDR.encode(ndrBuffer);
        ndrBuffer.enc_ndr_long(2);
    }

    public void decode_out(NdrBuffer ndrBuffer) throws NdrException {
        ndrBuffer.dec_ndr_short();
        ndrBuffer.dec_ndr_short();
        ndrBuffer.dec_ndr_long();
        ndrBuffer.advance(ndrBuffer.dec_ndr_short());
        ndrBuffer.align(4);
        ndrBuffer.dec_ndr_small();
        ndrBuffer.align(4);
        this.result = ndrBuffer.dec_ndr_short();
        ndrBuffer.dec_ndr_short();
        ndrBuffer.advance(20);
    }
}
