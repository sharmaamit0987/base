package com.dynamixsoftware.printershare.smb.dcerpc.msrpc;

import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrBuffer;
import com.dynamixsoftware.printershare.smb.dcerpc.ndr.NdrException;

public class MsrpcGetPrinter extends RpcGetPrinter {
    public /* bridge */ /* synthetic */ void decode_out(NdrBuffer ndrBuffer) throws NdrException {
        super.decode_out(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ void encode_in(NdrBuffer ndrBuffer) throws NdrException {
        super.encode_in(ndrBuffer);
    }

    public /* bridge */ /* synthetic */ int getOpnum() {
        return super.getOpnum();
    }

    public MsrpcGetPrinter(byte[] bArr, int i, int i2) {
        super(bArr, i, i2);
        this.ptype = 0;
        this.flags = 3;
    }

    public String getDriverName() {
        return this.driverName;
    }

    public String getPrinterName() {
        return this.printerName;
    }

    public String getLocation() {
        return this.location;
    }

    public String getServerName() {
        return this.serverName;
    }
}
