package com.dynamixsoftware.printershare.smb;

class SmbComSessionSetupAndX extends AndXServerMessageBlock {
    private static final int BATCH_LIMIT = 1;
    private static final boolean DISABLE_PLAIN_TEXT_PASSWORDS = true;
    private String accountName;
    private byte[] blob;
    private int capabilities;
    private byte[] lmHash;
    private byte[] ntHash;
    private String primaryDomain;
    private SmbSession session;
    private int sessionKey;

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b) {
        return b == 117 ? 1 : 0;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComSessionSetupAndX(SmbSession smbSession, ServerMessageBlock serverMessageBlock, Object obj) throws SmbException {
        super(serverMessageBlock);
        this.blob = null;
        this.command = 115;
        this.session = smbSession;
        this.sessionKey = smbSession.transport.sessionKey;
        this.capabilities = smbSession.transport.capabilities;
        String str = "Unsupported credential type";
        if (smbSession.transport.server.security == 1) {
            if (obj instanceof NtlmPasswordAuthentication) {
                NtlmPasswordAuthentication ntlmPasswordAuthentication = (NtlmPasswordAuthentication) obj;
                if (ntlmPasswordAuthentication == NtlmPasswordAuthentication.ANONYMOUS) {
                    this.lmHash = new byte[0];
                    this.ntHash = new byte[0];
                    this.capabilities &= Integer.MAX_VALUE;
                } else if (smbSession.transport.server.encryptedPasswords) {
                    this.lmHash = ntlmPasswordAuthentication.getAnsiHash(smbSession.transport.server.encryptionKey);
                    byte[] unicodeHash = ntlmPasswordAuthentication.getUnicodeHash(smbSession.transport.server.encryptionKey);
                    this.ntHash = unicodeHash;
                    if (this.lmHash.length == 0 && unicodeHash.length == 0) {
                        throw new RuntimeException("Null setup prohibited.");
                    }
                } else {
                    throw new RuntimeException("Plain text passwords are disabled");
                }
                this.accountName = ntlmPasswordAuthentication.username;
                if (this.useUnicode) {
                    this.accountName = this.accountName.toUpperCase();
                }
                this.primaryDomain = ntlmPasswordAuthentication.domain.toUpperCase();
            } else if (obj instanceof byte[]) {
                this.blob = (byte[]) obj;
            } else {
                throw new SmbException(str);
            }
        } else if (smbSession.transport.server.security != 0) {
            throw new SmbException("Unsupported");
        } else if (obj instanceof NtlmPasswordAuthentication) {
            NtlmPasswordAuthentication ntlmPasswordAuthentication2 = (NtlmPasswordAuthentication) obj;
            this.lmHash = new byte[0];
            this.ntHash = new byte[0];
            this.accountName = ntlmPasswordAuthentication2.username;
            if (this.useUnicode) {
                this.accountName = this.accountName.toUpperCase();
            }
            this.primaryDomain = ntlmPasswordAuthentication2.domain.toUpperCase();
        } else {
            throw new SmbException(str);
        }
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.session.transport.snd_buf_size, bArr, i);
        int i2 = i + 2;
        writeInt2((long) this.session.transport.maxMpxCount, bArr, i2);
        int i3 = i2 + 2;
        writeInt2(1, bArr, i3);
        int i4 = i3 + 2;
        writeInt4((long) this.sessionKey, bArr, i4);
        int i5 = i4 + 4;
        byte[] bArr2 = this.blob;
        if (bArr2 != null) {
            writeInt2((long) bArr2.length, bArr, i5);
        } else {
            writeInt2((long) this.lmHash.length, bArr, i5);
            i5 += 2;
            writeInt2((long) this.ntHash.length, bArr, i5);
        }
        int i6 = i5 + 2;
        int i7 = i6 + 1;
        bArr[i6] = 0;
        int i8 = i7 + 1;
        bArr[i7] = 0;
        int i9 = i8 + 1;
        bArr[i8] = 0;
        int i10 = i9 + 1;
        bArr[i9] = 0;
        writeInt4((long) this.capabilities, bArr, i10);
        return (i10 + 4) - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2;
        byte[] bArr2 = this.blob;
        if (bArr2 != null) {
            System.arraycopy(bArr2, 0, bArr, i, bArr2.length);
            i2 = this.blob.length + i;
        } else {
            byte[] bArr3 = this.lmHash;
            System.arraycopy(bArr3, 0, bArr, i, bArr3.length);
            int length = this.lmHash.length + i;
            byte[] bArr4 = this.ntHash;
            System.arraycopy(bArr4, 0, bArr, length, bArr4.length);
            int length2 = length + this.ntHash.length;
            int writeString = length2 + writeString(this.accountName, bArr, length2);
            i2 = writeString + writeString(this.primaryDomain, bArr, writeString);
        }
        int writeString2 = i2 + writeString(SmbConstants.NATIVE_OS, bArr, i2);
        return (writeString2 + writeString(SmbConstants.NATIVE_LANMAN, bArr, writeString2)) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComSessionSetupAndX[");
        sb.append(super.toString());
        sb.append(",snd_buf_size=");
        sb.append(this.session.transport.snd_buf_size);
        sb.append(",maxMpxCount=");
        sb.append(this.session.transport.maxMpxCount);
        sb.append(",VC_NUMBER=");
        sb.append(1);
        sb.append(",sessionKey=");
        sb.append(this.sessionKey);
        sb.append(",lmHash.length=");
        byte[] bArr = this.lmHash;
        int i = 0;
        sb.append(bArr == null ? 0 : bArr.length);
        sb.append(",ntHash.length=");
        byte[] bArr2 = this.ntHash;
        if (bArr2 != null) {
            i = bArr2.length;
        }
        sb.append(i);
        sb.append(",capabilities=");
        sb.append(this.capabilities);
        sb.append(",accountName=");
        sb.append(this.accountName);
        sb.append(",primaryDomain=");
        sb.append(this.primaryDomain);
        sb.append(",NATIVE_OS=");
        sb.append(SmbConstants.NATIVE_OS);
        sb.append(",NATIVE_LANMAN=");
        sb.append(SmbConstants.NATIVE_LANMAN);
        sb.append("]");
        return new String(sb.toString());
    }
}
