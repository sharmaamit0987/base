package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.util.Enumeration;

abstract class SmbComTransaction extends ServerMessageBlock implements Enumeration<Object> {
    private static final int DEFAULT_MAX_DATA_COUNT = 65023;
    static final int NET_SERVER_ENUM2 = 104;
    static final int NET_SERVER_ENUM3 = 215;
    static final int NET_SHARE_ENUM = 0;
    private static final int PADDING_SIZE = 2;
    private static final int PRIMARY_SETUP_OFFSET = 61;
    private static final int SECONDARY_PARAMETER_OFFSET = 51;
    static final byte TRANS2_FIND_FIRST2 = 1;
    static final byte TRANS2_FIND_NEXT2 = 2;
    static final byte TRANS2_GET_DFS_REFERRAL = 16;
    static final byte TRANS2_PRINT_ENUM = 69;
    static final int TRANSACTION_BUF_SIZE = 65535;
    static final byte TRANS_CALL_NAMED_PIPE = 84;
    static final byte TRANS_PEEK_NAMED_PIPE = 35;
    static final byte TRANS_TRANSACT_NAMED_PIPE = 38;
    static final byte TRANS_WAIT_NAMED_PIPE = 83;
    private int bufDataOffset;
    private int bufParameterOffset;
    protected int dataCount;
    protected int dataDisplacement;
    protected int dataOffset;
    private int flags = 0;
    private boolean hasMore = true;
    private boolean isPrimary = true;
    int maxBufferSize;
    int maxDataCount = DEFAULT_MAX_DATA_COUNT;
    int maxParameterCount = 1024;
    byte maxSetupCount;
    String name = "";
    private int pad = 0;
    private int pad1 = 0;
    protected int parameterCount;
    protected int parameterDisplacement;
    protected int parameterOffset;
    protected int primarySetupOffset = PRIMARY_SETUP_OFFSET;
    int setupCount = 1;
    byte subCommand;
    int timeout = 0;
    int totalDataCount;
    int totalParameterCount;
    byte[] txn_buf;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public abstract int readDataWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public abstract int readParametersWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public abstract int readSetupWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public abstract int writeDataWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeParametersWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeSetupWireFormat(byte[] bArr, int i);

    SmbComTransaction() {
    }

    /* access modifiers changed from: 0000 */
    public void reset() {
        super.reset();
        this.hasMore = true;
        this.isPrimary = true;
    }

    /* access modifiers changed from: 0000 */
    public void reset(int i, String str) {
        reset();
    }

    public boolean hasMoreElements() {
        return this.hasMore;
    }

    public Object nextElement() {
        if (this.isPrimary) {
            this.isPrimary = false;
            this.parameterOffset = this.primarySetupOffset + (this.setupCount * 2) + 2;
            if (this.command != -96) {
                if (this.command == 37 && !isResponse()) {
                    int i = this.parameterOffset;
                    this.parameterOffset = i + stringWireLength(this.name, i);
                }
            } else if (this.command == -96) {
                this.parameterOffset += 2;
            }
            int i2 = this.parameterOffset % 2;
            this.pad = i2;
            int i3 = i2 == 0 ? 0 : 2 - i2;
            this.pad = i3;
            this.parameterOffset += i3;
            int writeParametersWireFormat = writeParametersWireFormat(this.txn_buf, this.bufParameterOffset);
            this.totalParameterCount = writeParametersWireFormat;
            this.bufDataOffset = writeParametersWireFormat;
            int i4 = this.maxBufferSize - this.parameterOffset;
            int min = Math.min(writeParametersWireFormat, i4);
            this.parameterCount = min;
            int i5 = i4 - min;
            int i6 = this.parameterOffset + min;
            this.dataOffset = i6;
            int i7 = i6 % 2;
            this.pad1 = i7;
            int i8 = i7 == 0 ? 0 : 2 - i7;
            this.pad1 = i8;
            this.dataOffset += i8;
            int writeDataWireFormat = writeDataWireFormat(this.txn_buf, this.bufDataOffset);
            this.totalDataCount = writeDataWireFormat;
            this.dataCount = Math.min(writeDataWireFormat, i5);
        } else {
            if (this.command != -96) {
                this.command = TRANS_TRANSACT_NAMED_PIPE;
            } else {
                this.command = -95;
            }
            this.parameterOffset = SECONDARY_PARAMETER_OFFSET;
            if (this.totalParameterCount - this.parameterDisplacement > 0) {
                int i9 = SECONDARY_PARAMETER_OFFSET % 2;
                this.pad = i9;
                int i10 = i9 == 0 ? 0 : 2 - i9;
                this.pad = i10;
                this.parameterOffset += i10;
            }
            int i11 = this.parameterDisplacement + this.parameterCount;
            this.parameterDisplacement = i11;
            int i12 = (this.maxBufferSize - this.parameterOffset) - this.pad;
            int min2 = Math.min(this.totalParameterCount - i11, i12);
            this.parameterCount = min2;
            int i13 = i12 - min2;
            int i14 = this.parameterOffset + min2;
            this.dataOffset = i14;
            int i15 = i14 % 2;
            this.pad1 = i15;
            int i16 = i15 == 0 ? 0 : 2 - i15;
            this.pad1 = i16;
            this.dataOffset += i16;
            int i17 = this.dataDisplacement + this.dataCount;
            this.dataDisplacement = i17;
            this.dataCount = Math.min(this.totalDataCount - i17, i13 - i16);
        }
        if (this.parameterDisplacement + this.parameterCount >= this.totalParameterCount && this.dataDisplacement + this.dataCount >= this.totalDataCount) {
            this.hasMore = false;
        }
        return this;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        int i2;
        writeInt2((long) this.totalParameterCount, bArr, i);
        int i3 = i + 2;
        writeInt2((long) this.totalDataCount, bArr, i3);
        int i4 = i3 + 2;
        if (this.command != 38) {
            writeInt2((long) this.maxParameterCount, bArr, i4);
            int i5 = i4 + 2;
            writeInt2((long) this.maxDataCount, bArr, i5);
            int i6 = i5 + 2;
            int i7 = i6 + 1;
            bArr[i6] = this.maxSetupCount;
            int i8 = i7 + 1;
            bArr[i7] = 0;
            writeInt2((long) this.flags, bArr, i8);
            int i9 = i8 + 2;
            writeInt4((long) this.timeout, bArr, i9);
            int i10 = i9 + 4;
            int i11 = i10 + 1;
            bArr[i10] = 0;
            i4 = i11 + 1;
            bArr[i11] = 0;
        }
        writeInt2((long) this.parameterCount, bArr, i4);
        int i12 = i4 + 2;
        writeInt2((long) this.parameterOffset, bArr, i12);
        int i13 = i12 + 2;
        if (this.command == 38) {
            writeInt2((long) this.parameterDisplacement, bArr, i13);
            i13 += 2;
        }
        writeInt2((long) this.dataCount, bArr, i13);
        int i14 = i13 + 2;
        writeInt2((long) (this.dataCount == 0 ? 0 : this.dataOffset), bArr, i14);
        int i15 = i14 + 2;
        if (this.command == 38) {
            writeInt2((long) this.dataDisplacement, bArr, i15);
            i2 = i15 + 2;
        } else {
            int i16 = i15 + 1;
            bArr[i15] = (byte) this.setupCount;
            int i17 = i16 + 1;
            bArr[i16] = 0;
            i2 = i17 + writeSetupWireFormat(bArr, i17);
        }
        return i2 - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2 = this.pad;
        int writeString = (this.command != 37 || isResponse()) ? i : writeString(this.name, bArr, i) + i;
        if (this.parameterCount > 0) {
            while (true) {
                int i3 = i2 - 1;
                if (i2 <= 0) {
                    break;
                }
                int i4 = writeString + 1;
                bArr[writeString] = 0;
                writeString = i4;
                i2 = i3;
            }
            System.arraycopy(this.txn_buf, this.bufParameterOffset, bArr, writeString, this.parameterCount);
            writeString += this.parameterCount;
        }
        if (this.dataCount > 0) {
            int i5 = this.pad1;
            while (true) {
                int i6 = i5 - 1;
                if (i5 <= 0) {
                    break;
                }
                int i7 = writeString + 1;
                bArr[writeString] = 0;
                writeString = i7;
                i5 = i6;
            }
            System.arraycopy(this.txn_buf, this.bufDataOffset, bArr, writeString, this.dataCount);
            int i8 = this.bufDataOffset;
            int i9 = this.dataCount;
            this.bufDataOffset = i8 + i9;
            writeString += i9;
        }
        return writeString - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(",totalParameterCount=");
        sb.append(this.totalParameterCount);
        sb.append(",totalDataCount=");
        sb.append(this.totalDataCount);
        sb.append(",maxParameterCount=");
        sb.append(this.maxParameterCount);
        sb.append(",maxDataCount=");
        sb.append(this.maxDataCount);
        sb.append(",maxSetupCount=");
        sb.append(this.maxSetupCount);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags, 2));
        sb.append(",timeout=");
        sb.append(this.timeout);
        sb.append(",parameterCount=");
        sb.append(this.parameterCount);
        sb.append(",parameterOffset=");
        sb.append(this.parameterOffset);
        sb.append(",parameterDisplacement=");
        sb.append(this.parameterDisplacement);
        sb.append(",dataCount=");
        sb.append(this.dataCount);
        sb.append(",dataOffset=");
        sb.append(this.dataOffset);
        sb.append(",dataDisplacement=");
        sb.append(this.dataDisplacement);
        sb.append(",setupCount=");
        sb.append(this.setupCount);
        sb.append(",pad=");
        sb.append(this.pad);
        sb.append(",pad1=");
        sb.append(this.pad1);
        return new String(sb.toString());
    }
}
