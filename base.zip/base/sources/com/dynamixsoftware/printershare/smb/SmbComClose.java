package com.dynamixsoftware.printershare.smb;

class SmbComClose extends ServerMessageBlock {
    private int fid;
    private long lastWriteTime;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComClose(int i, long j) {
        this.fid = i;
        this.lastWriteTime = j;
        this.command = 4;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.fid, bArr, i);
        writeUTime(this.lastWriteTime, bArr, i + 2);
        return 6;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComClose[");
        sb.append(super.toString());
        sb.append(",fid=");
        sb.append(this.fid);
        sb.append(",lastWriteTime=");
        sb.append(this.lastWriteTime);
        sb.append("]");
        return new String(sb.toString());
    }
}
