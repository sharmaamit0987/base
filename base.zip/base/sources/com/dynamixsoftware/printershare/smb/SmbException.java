package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.io.IOException;

class SmbException extends IOException implements NtStatus, DosError, WinError {
    private int status;

    static String getMessageByCode(int i) {
        if (i == 0) {
            return "NT_STATUS_SUCCESS";
        }
        int i2 = 1;
        if ((i & -1073741824) == -1073741824) {
            int length = NT_STATUS_CODES.length - 1;
            while (length >= i2) {
                int i3 = (i2 + length) / 2;
                if (i > NT_STATUS_CODES[i3]) {
                    i2 = i3 + 1;
                } else if (i >= NT_STATUS_CODES[i3]) {
                    return NT_STATUS_MESSAGES[i3];
                } else {
                    length = i3 - 1;
                }
            }
        } else {
            int length2 = DOS_ERROR_CODES.length - 1;
            int i4 = 0;
            while (length2 >= i4) {
                int i5 = (i4 + length2) / 2;
                if (i > DOS_ERROR_CODES[i5][0]) {
                    i4 = i5 + 1;
                } else if (i >= DOS_ERROR_CODES[i5][0]) {
                    return DOS_ERROR_MESSAGES[i5];
                } else {
                    length2 = i5 - 1;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("0x");
        sb.append(Dumper.toHexString(i, 8));
        return sb.toString();
    }

    static int getStatusByCode(int i) {
        if ((-1073741824 & i) != 0) {
            return i;
        }
        int length = DOS_ERROR_CODES.length - 1;
        int i2 = 0;
        while (length >= i2) {
            int i3 = (i2 + length) / 2;
            if (i > DOS_ERROR_CODES[i3][0]) {
                i2 = i3 + 1;
            } else if (i >= DOS_ERROR_CODES[i3][0]) {
                return DOS_ERROR_CODES[i3][1];
            } else {
                length = i3 - 1;
            }
        }
        return NtStatus.NT_STATUS_UNSUCCESSFUL;
    }

    private static String getMessageByWinerrCode(int i) {
        int length = WINERR_CODES.length - 1;
        int i2 = 0;
        while (length >= i2) {
            int i3 = (i2 + length) / 2;
            if (i > WINERR_CODES[i3]) {
                i2 = i3 + 1;
            } else if (i >= WINERR_CODES[i3]) {
                return WINERR_MESSAGES[i3];
            } else {
                length = i3 - 1;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(i);
        sb.append("");
        return sb.toString();
    }

    SmbException() {
    }

    SmbException(int i, Throwable th) {
        super(getMessageByCode(i));
        if (th != null) {
            initCause(th);
        }
        this.status = getStatusByCode(i);
    }

    SmbException(String str) {
        super(str);
        this.status = NtStatus.NT_STATUS_UNSUCCESSFUL;
    }

    SmbException(String str, Throwable th) {
        super(str);
        if (th != null) {
            initCause(th);
        }
        this.status = NtStatus.NT_STATUS_UNSUCCESSFUL;
    }

    SmbException(int i, boolean z) {
        super(z ? getMessageByWinerrCode(i) : getMessageByCode(i));
        if (!z) {
            i = getStatusByCode(i);
        }
        this.status = i;
    }

    public int getNtStatus() {
        return this.status;
    }
}
