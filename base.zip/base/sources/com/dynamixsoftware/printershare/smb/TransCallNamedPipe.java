package com.dynamixsoftware.printershare.smb;

class TransCallNamedPipe extends SmbComTransaction {
    private byte[] pipeData;
    private int pipeDataLen;
    private int pipeDataOff;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    TransCallNamedPipe(String str, byte[] bArr, int i, int i2) {
        this.name = str;
        this.pipeData = bArr;
        this.pipeDataOff = i;
        this.pipeDataLen = i2;
        this.command = 37;
        this.subCommand = 84;
        this.timeout = -1;
        this.maxParameterCount = 0;
        this.maxDataCount = 65535;
        this.maxSetupCount = 0;
        this.setupCount = 2;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = this.subCommand;
        int i3 = i2 + 1;
        bArr[i2] = 0;
        int i4 = i3 + 1;
        bArr[i3] = 0;
        bArr[i4] = 0;
        return 4;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        int length = bArr.length - i;
        int i2 = this.pipeDataLen;
        if (length < i2) {
            return 0;
        }
        System.arraycopy(this.pipeData, this.pipeDataOff, bArr, i, i2);
        return this.pipeDataLen;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TransCallNamedPipe[");
        sb.append(super.toString());
        sb.append(",pipeName=");
        sb.append(this.name);
        sb.append("]");
        return new String(sb.toString());
    }
}
