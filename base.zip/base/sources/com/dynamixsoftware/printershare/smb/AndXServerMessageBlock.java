package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;

abstract class AndXServerMessageBlock extends ServerMessageBlock {
    private static final int ANDX_COMMAND_OFFSET = 1;
    private static final int ANDX_OFFSET_OFFSET = 3;
    private static final int ANDX_RESERVED_OFFSET = 2;
    private ServerMessageBlock andx = null;
    private byte andxCommand = -1;
    private int andxOffset = 0;

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b) {
        return 0;
    }

    AndXServerMessageBlock() {
    }

    AndXServerMessageBlock(ServerMessageBlock serverMessageBlock) {
        if (serverMessageBlock != null) {
            this.andx = serverMessageBlock;
            this.andxCommand = serverMessageBlock.command;
        }
    }

    /* access modifiers changed from: 0000 */
    public int encode(byte[] bArr, int i) {
        this.headerStart = i;
        int writeHeaderWireFormat = writeHeaderWireFormat(bArr, i) + i;
        this.length = (writeHeaderWireFormat + writeAndXWireFormat(bArr, writeHeaderWireFormat)) - i;
        if (this.digest != null) {
            this.digest.sign(bArr, this.headerStart, this.length, this, this.response);
        }
        return this.length;
    }

    /* access modifiers changed from: 0000 */
    public int decode(byte[] bArr, int i) {
        this.headerStart = i;
        int readHeaderWireFormat = readHeaderWireFormat(bArr, i) + i;
        this.length = (readHeaderWireFormat + readAndXWireFormat(bArr, readHeaderWireFormat)) - i;
        return this.length;
    }

    private int writeAndXWireFormat(byte[] bArr, int i) {
        int i2;
        int i3 = i + 3;
        this.wordCount = writeParameterWordsWireFormat(bArr, i3 + 2);
        this.wordCount += 4;
        int i4 = this.wordCount + 1 + i;
        this.wordCount /= 2;
        bArr[i] = (byte) (this.wordCount & 255);
        this.byteCount = writeBytesWireFormat(bArr, i4 + 2);
        int i5 = i4 + 1;
        bArr[i4] = (byte) (this.byteCount & 255);
        int i6 = i5 + 1;
        bArr[i5] = (byte) ((this.byteCount >> 8) & 255);
        int i7 = i6 + this.byteCount;
        if (this.andx == null || this.batchLevel >= getBatchLimit(this.andx.command)) {
            this.andxCommand = -1;
            this.andx = null;
            bArr[i + 1] = -1;
            bArr[i + 2] = 0;
            bArr[i3] = -34;
            bArr[i3 + 1] = -34;
            return i7 - i;
        }
        this.andx.batchLevel = this.batchLevel + 1;
        bArr[i + 1] = this.andxCommand;
        bArr[i + 2] = 0;
        int i8 = i7 - this.headerStart;
        this.andxOffset = i8;
        writeInt2((long) i8, bArr, i3);
        this.andx.useUnicode = this.useUnicode;
        ServerMessageBlock serverMessageBlock = this.andx;
        if (serverMessageBlock instanceof AndXServerMessageBlock) {
            serverMessageBlock.uid = this.uid;
            i2 = i7 + ((AndXServerMessageBlock) this.andx).writeAndXWireFormat(bArr, i7);
        } else {
            serverMessageBlock.wordCount = serverMessageBlock.writeParameterWordsWireFormat(bArr, i7);
            int i9 = this.andx.wordCount + 1 + i7;
            this.andx.wordCount /= 2;
            bArr[i7] = (byte) (this.andx.wordCount & 255);
            ServerMessageBlock serverMessageBlock2 = this.andx;
            serverMessageBlock2.byteCount = serverMessageBlock2.writeBytesWireFormat(bArr, i9 + 2);
            int i10 = i9 + 1;
            bArr[i9] = (byte) (this.andx.byteCount & 255);
            int i11 = i10 + 1;
            bArr[i10] = (byte) ((this.andx.byteCount >> 8) & 255);
            i2 = i11 + this.andx.byteCount;
        }
        return i2 - i;
    }

    private int readAndXWireFormat(byte[] bArr, int i) {
        int i2;
        int i3 = i + 1;
        this.wordCount = bArr[i];
        if (this.wordCount != 0) {
            this.andxCommand = bArr[i3];
            int readInt2 = readInt2(bArr, i3 + 2);
            this.andxOffset = readInt2;
            if (readInt2 == 0) {
                this.andxCommand = -1;
            }
            if (this.wordCount > 2) {
                readParameterWordsWireFormat(bArr, i3 + 4);
                if (this.command == -94 && ((SmbComNTCreateAndXResponse) this).isExtended) {
                    this.wordCount += 8;
                }
            }
            i3 += this.wordCount * 2;
        }
        this.byteCount = readInt2(bArr, i3);
        int i4 = i3 + 2;
        if (this.byteCount != 0) {
            readBytesWireFormat(bArr, i4);
            i4 += this.byteCount;
        }
        if (this.errorCode != 0 || this.andxCommand == -1) {
            this.andxCommand = -1;
            this.andx = null;
        } else if (this.andx != null) {
            int i5 = this.headerStart + this.andxOffset;
            this.andx.headerStart = this.headerStart;
            this.andx.command = this.andxCommand;
            this.andx.errorCode = this.errorCode;
            this.andx.flags = this.flags;
            this.andx.flags2 = this.flags2;
            this.andx.tid = this.tid;
            this.andx.pid = this.pid;
            this.andx.uid = this.uid;
            this.andx.mid = this.mid;
            this.andx.useUnicode = this.useUnicode;
            ServerMessageBlock serverMessageBlock = this.andx;
            if (serverMessageBlock instanceof AndXServerMessageBlock) {
                i2 = i5 + ((AndXServerMessageBlock) serverMessageBlock).readAndXWireFormat(bArr, i5);
            } else {
                int i6 = i5 + 1;
                bArr[i5] = (byte) (serverMessageBlock.wordCount & 255);
                if (this.andx.wordCount != 0 && this.andx.wordCount > 2) {
                    i6 += this.andx.readParameterWordsWireFormat(bArr, i6);
                }
                this.andx.byteCount = readInt2(bArr, i6);
                int i7 = i6 + 2;
                if (this.andx.byteCount != 0) {
                    this.andx.readBytesWireFormat(bArr, i7);
                    i7 += this.andx.byteCount;
                }
                i2 = i7;
            }
            this.andx.received = true;
        } else {
            this.andxCommand = -1;
            throw new RuntimeException("no andx command supplied with response");
        }
        return i2 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(",andxCommand=0x");
        sb.append(Dumper.toHexString(this.andxCommand, 2));
        sb.append(",andxOffset=");
        sb.append(this.andxOffset);
        return new String(sb.toString());
    }
}
