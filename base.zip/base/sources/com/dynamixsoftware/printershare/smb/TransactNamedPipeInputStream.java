package com.dynamixsoftware.printershare.smb;

import com.flurry.android.Constants;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

class TransactNamedPipeInputStream extends SmbFileInputStream {
    private static final int INIT_PIPE_SIZE = 4096;
    private int beg_idx;
    Object lock = new Object();
    private int nxt_idx;
    private byte[] pipe_buf = new byte[4096];
    private int used;

    public int available() throws IOException {
        return 0;
    }

    TransactNamedPipeInputStream(SmbNamedPipe smbNamedPipe) throws SmbException, MalformedURLException, UnknownHostException {
        super(smbNamedPipe, (smbNamedPipe.pipeType & -65281) | 32);
    }

    public int read() throws IOException {
        byte b;
        synchronized (this.lock) {
            while (this.used == 0) {
                try {
                    this.lock.wait();
                } catch (InterruptedException e) {
                    throw new IOException(e.getMessage());
                } catch (Throwable th) {
                    throw th;
                }
            }
            b = this.pipe_buf[this.beg_idx] & Constants.UNKNOWN;
            this.beg_idx = (this.beg_idx + 1) % this.pipe_buf.length;
        }
        return b;
    }

    public int read(byte[] bArr) throws IOException {
        return read(bArr, 0, bArr.length);
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        if (i2 <= 0) {
            return 0;
        }
        synchronized (this.lock) {
            while (this.used == 0) {
                try {
                    this.lock.wait();
                } catch (InterruptedException e) {
                    throw new IOException(e.getMessage());
                } catch (Throwable th) {
                    throw th;
                }
            }
            int length = this.pipe_buf.length - this.beg_idx;
            if (i2 > this.used) {
                i2 = this.used;
            }
            if (this.used <= length || i2 <= length) {
                System.arraycopy(this.pipe_buf, this.beg_idx, bArr, i, i2);
            } else {
                System.arraycopy(this.pipe_buf, this.beg_idx, bArr, i, length);
                System.arraycopy(this.pipe_buf, 0, bArr, i + length, i2 - length);
            }
            this.used -= i2;
            this.beg_idx = (this.beg_idx + i2) % this.pipe_buf.length;
        }
        return i2;
    }

    /* access modifiers changed from: 0000 */
    public int receive(byte[] bArr, int i, int i2) {
        byte[] bArr2 = this.pipe_buf;
        int length = bArr2.length;
        int i3 = this.used;
        if (i2 > length - i3) {
            int length2 = bArr2.length * 2;
            if (i2 > length2 - i3) {
                length2 = i2 + i3;
            }
            byte[] bArr3 = this.pipe_buf;
            byte[] bArr4 = new byte[length2];
            this.pipe_buf = bArr4;
            int length3 = bArr3.length;
            int i4 = this.beg_idx;
            int i5 = length3 - i4;
            int i6 = this.used;
            if (i6 > i5) {
                System.arraycopy(bArr3, i4, bArr4, 0, i5);
                System.arraycopy(bArr3, 0, this.pipe_buf, i5, this.used - i5);
            } else {
                System.arraycopy(bArr3, i4, bArr4, 0, i6);
            }
            this.beg_idx = 0;
            this.nxt_idx = this.used;
        }
        byte[] bArr5 = this.pipe_buf;
        int length4 = bArr5.length;
        int i7 = this.nxt_idx;
        int i8 = length4 - i7;
        if (i2 > i8) {
            System.arraycopy(bArr, i, bArr5, i7, i8);
            System.arraycopy(bArr, i + i8, this.pipe_buf, 0, i2 - i8);
        } else {
            System.arraycopy(bArr, i, bArr5, i7, i2);
        }
        this.nxt_idx = (this.nxt_idx + i2) % this.pipe_buf.length;
        this.used += i2;
        return i2;
    }
}
