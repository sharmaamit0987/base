package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.dcerpc.DcerpcHandle;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.MsrpcClosePrinter;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.MsrpcGetPrinter;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.MsrpcOpenPrinter;
import com.dynamixsoftware.printershare.smb.dcerpc.msrpc.MsrpcShareEnum;
import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;

public class SmbFile implements SmbConstants {
    static final int ATTR_DIRECTORY = 16;
    private static final int ATTR_HIDDEN = 2;
    static final int ATTR_NORMAL = 128;
    static final int ATTR_READONLY = 1;
    private static final int ATTR_SYSTEM = 4;
    private static final int FILE_SHARE_DELETE = 4;
    private static final int FILE_SHARE_READ = 1;
    private static final int FILE_SHARE_WRITE = 2;
    private static final int HASH_DOT = 46;
    private static final int HASH_DOT_DOT = 1472;
    static final int O_CREAT = 16;
    static final int O_EXCL = 32;
    static final int O_RDWR = 3;
    static final int O_TRUNC = 64;
    private static final int TYPE_COMM = 64;
    static final int TYPE_FILESYSTEM = 1;
    static final int TYPE_NAMED_PIPE = 16;
    public static final int TYPE_PRINTER = 32;
    public static final int TYPE_SERVER = 4;
    static final int TYPE_SHARE = 8;
    public static final int TYPE_WORKGROUP = 2;
    private static SmbOutpuStream sbmOutputStream;
    private int addressIndex;
    private UniAddress[] addresses;
    private NtlmPasswordAuthentication auth;
    private SmbComBlankResponse blank_resp;
    private String canon;
    int fid;
    boolean opened;
    private String share;
    private int shareAccess;
    SmbTree tree;
    private int tree_num;
    int type;
    String unc;
    private URL url;

    private class SmbOutpuStream extends OutputStream {
        private byte[] buf;
        private int bufLength;
        private int index;
        private int sndBufSize;

        public SmbOutpuStream() {
            int i = SmbFile.this.tree.session.transport.snd_buf_size;
            this.sndBufSize = i;
            if (i > 70) {
                i -= 70;
            }
            byte[] bArr = new byte[i];
            this.buf = bArr;
            this.bufLength = bArr.length;
            this.index = 0;
        }

        public void write(byte[] bArr) throws IOException {
            write(bArr, 0, bArr.length);
        }

        public void write(byte[] bArr, int i, int i2) throws IOException {
            int i3 = this.index;
            int i4 = i3 + i2;
            int i5 = this.bufLength;
            if (i4 < i5) {
                System.arraycopy(bArr, i, this.buf, i3, i2);
                this.index += i2;
                return;
            }
            int i6 = i5 - i3;
            System.arraycopy(bArr, i, this.buf, i3, i6);
            SmbFile.this.print_write(this.buf, this.bufLength);
            this.index = 0;
            write(bArr, i + i6, i2 - i6);
        }

        public void write(int i) throws IOException {
            int i2 = this.index;
            byte[] bArr = this.buf;
            if (i2 < bArr.length) {
                this.index = i2 + 1;
                bArr[i2] = (byte) i;
                return;
            }
            SmbFile.this.print_write(bArr, i2);
            this.index = 0;
            byte[] bArr2 = this.buf;
            this.index = 0 + 1;
            bArr2[0] = (byte) i;
        }

        public void flush() throws IOException {
            int i = this.index;
            if (i != 0) {
                SmbFile.this.print_write(this.buf, i);
            }
            this.index = 0;
        }

        public void close() throws IOException {
            flush();
        }
    }

    public SmbFile(String str) throws MalformedURLException {
        this(new URL(null, str, Handler.SMB_HANDLER));
    }

    public SmbFile(String str, NtlmPasswordAuthentication ntlmPasswordAuthentication) throws MalformedURLException {
        this(new URL(null, str, Handler.SMB_HANDLER), ntlmPasswordAuthentication);
    }

    private SmbFile(URL url2) {
        this(url2, new NtlmPasswordAuthentication(url2.getUserInfo()));
    }

    private SmbFile(URL url2, NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        this.shareAccess = 7;
        this.blank_resp = null;
        this.tree = null;
        this.url = url2;
        if (ntlmPasswordAuthentication == null) {
            ntlmPasswordAuthentication = new NtlmPasswordAuthentication(url2.getUserInfo());
        }
        this.auth = ntlmPasswordAuthentication;
        getUncPath0();
    }

    private SmbFile(SmbFile smbFile, String str, int i, int i2, long j, long j2, long j3) throws MalformedURLException, UnknownHostException {
        URL url2;
        String str2 = "/";
        if (smbFile.isWorkgroup0()) {
            StringBuilder sb = new StringBuilder();
            sb.append("smb://");
            sb.append(str);
            sb.append(str2);
            url2 = new URL(null, sb.toString(), Handler.SMB_HANDLER);
        } else {
            URL url3 = smbFile.url;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str);
            if ((i2 & 16) <= 0) {
                str2 = "";
            }
            sb2.append(str2);
            url2 = new URL(url3, sb2.toString());
        }
        this(url2);
        this.auth = smbFile.auth;
        if (smbFile.share != null) {
            this.tree = smbFile.tree;
        }
        int length = str.length() - 1;
        if (str.charAt(length) == '/') {
            str = str.substring(0, length);
        }
        String str3 = "\\";
        if (smbFile.share == null) {
            this.unc = str3;
        } else if (smbFile.unc.equals(str3)) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append('\\');
            sb3.append(str);
            this.unc = sb3.toString();
        } else {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(smbFile.unc);
            sb4.append('\\');
            sb4.append(str);
            this.unc = sb4.toString();
        }
        this.type = i;
    }

    private SmbComBlankResponse blank_resp() {
        if (this.blank_resp == null) {
            this.blank_resp = new SmbComBlankResponse();
        }
        return this.blank_resp;
    }

    /* access modifiers changed from: 0000 */
    public void send(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        this.tree.send(serverMessageBlock, serverMessageBlock2);
    }

    private UniAddress getAddress() throws UnknownHostException {
        int i = this.addressIndex;
        if (i == 0) {
            return getFirstAddress();
        }
        return this.addresses[i - 1];
    }

    private UniAddress getFirstAddress() throws UnknownHostException {
        this.addressIndex = 0;
        String host = this.url.getHost();
        String path = this.url.getPath();
        if (host.length() == 0) {
            NbtAddress byName = NbtAddress.getByName(NbtAddress.MASTER_BROWSER_NAME, 1, null);
            UniAddress[] uniAddressArr = new UniAddress[1];
            this.addresses = uniAddressArr;
            uniAddressArr[0] = UniAddress.getByName(byName.getHostAddress());
        } else if (path.length() == 0 || path.equals("/")) {
            this.addresses = UniAddress.getAllByName(host, true);
        } else {
            this.addresses = UniAddress.getAllByName(host, false);
        }
        return getNextAddress();
    }

    private UniAddress getNextAddress() {
        UniAddress[] uniAddressArr = this.addresses;
        if (uniAddressArr != null) {
            int i = this.addressIndex;
            if (i < uniAddressArr.length) {
                this.addressIndex = i + 1;
                return uniAddressArr[i];
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    public void connect0() throws SmbException {
        String str = "Failed to connect to server";
        try {
            connect();
        } catch (UnknownHostException e) {
            throw new SmbException(str, (Throwable) e);
        } catch (SmbException e2) {
            throw e2;
        } catch (IOException e3) {
            throw new SmbException(str, (Throwable) e3);
        }
    }

    private void doConnect() throws IOException {
        SmbTransport smbTransport;
        UniAddress address = getAddress();
        SmbTree smbTree = this.tree;
        if (smbTree != null) {
            smbTransport = smbTree.session.transport;
        } else {
            smbTransport = SmbTransport.getSmbTransport(address, this.url.getPort());
            this.tree = smbTransport.getSmbSession(this.auth).getSmbTree(this.share, null);
        }
        try {
            this.tree.treeConnect(null, null);
        } catch (SmbAuthException e) {
            if (this.share == null) {
                SmbTree smbTree2 = smbTransport.getSmbSession(NtlmPasswordAuthentication.ANONYMOUS).getSmbTree(null, null);
                this.tree = smbTree2;
                smbTree2.treeConnect(null, null);
                return;
            }
            NtlmPasswordAuthentication requestNtlmPasswordAuthentication = NtlmAuthenticator.requestNtlmPasswordAuthentication(this.url.toString(), e);
            if (requestNtlmPasswordAuthentication != null) {
                this.auth = requestNtlmPasswordAuthentication;
                SmbTree smbTree3 = smbTransport.getSmbSession(requestNtlmPasswordAuthentication).getSmbTree(this.share, null);
                this.tree = smbTree3;
                smbTree3.treeConnect(null, null);
                return;
            }
            throw e;
        }
    }

    private void connect() throws IOException {
        if (!isConnected()) {
            getUncPath0();
            do {
                try {
                    doConnect();
                    return;
                } catch (SmbAuthException e) {
                    throw e;
                } catch (IOException e2) {
                    if (getNextAddress() == null) {
                        throw e2;
                    }
                }
            } while (getNextAddress() == null);
            throw e2;
        }
    }

    private boolean isConnected() {
        SmbTree smbTree = this.tree;
        return smbTree != null && smbTree.connectionState == 2;
    }

    private int open0(int i, int i2, int i3, int i4) throws SmbException {
        if (this.tree.session.transport.hasCapability(16)) {
            SmbComNTCreateAndXResponse smbComNTCreateAndXResponse = new SmbComNTCreateAndXResponse();
            SmbComNTCreateAndX smbComNTCreateAndX = new SmbComNTCreateAndX(this.unc, i, i2, this.shareAccess, i3, i4, null);
            if (this instanceof SmbNamedPipe) {
                smbComNTCreateAndX.flags0 |= 22;
                smbComNTCreateAndX.desiredAccess |= 131072;
                smbComNTCreateAndXResponse.isExtended = true;
            }
            send(smbComNTCreateAndX, smbComNTCreateAndXResponse);
            return smbComNTCreateAndXResponse.fid;
        }
        SmbComOpenAndXResponse smbComOpenAndXResponse = new SmbComOpenAndXResponse();
        send(new SmbComOpenAndX(this.unc, i2, i, null), smbComOpenAndXResponse);
        return smbComOpenAndXResponse.fid;
    }

    /* access modifiers changed from: 0000 */
    public void open(int i, int i2, int i3, int i4) throws SmbException {
        if (!isOpen()) {
            this.fid = open0(i, i2, i3, i4);
            this.opened = true;
            this.tree_num = this.tree.tree_num;
        }
    }

    private void open_printJob(String str) throws SmbException {
        SmbComOpenPrintFile smbComOpenPrintFile = new SmbComOpenPrintFile(str);
        SmbComOpenPrintFileResponse smbComOpenPrintFileResponse = new SmbComOpenPrintFileResponse();
        send(smbComOpenPrintFile, smbComOpenPrintFileResponse);
        this.fid = (int) smbComOpenPrintFileResponse.fid;
        this.opened = true;
        this.tree_num = this.tree.tree_num;
    }

    /* access modifiers changed from: 0000 */
    public boolean isOpen() {
        return this.opened && isConnected() && this.tree_num == this.tree.tree_num;
    }

    private void close(int i, long j) throws SmbException {
        if (this.type != 32) {
            send(new SmbComClose(i, j), blank_resp());
        } else {
            send(new SmbComClosePrintFile((long) this.fid), blank_resp());
        }
    }

    private void close(long j) throws SmbException {
        if (isOpen()) {
            close(this.fid, j);
            this.opened = false;
        }
    }

    public void close() throws SmbException {
        close(0);
    }

    public Principal getPrincipal() {
        return this.auth;
    }

    public String getName() {
        getUncPath0();
        if (this.canon.length() > 1) {
            int length = this.canon.length() - 2;
            while (this.canon.charAt(length) != '/') {
                length--;
            }
            return this.canon.substring(length + 1);
        } else if (this.share != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(this.share);
            sb.append('/');
            return sb.toString();
        } else if (this.url.getHost().length() <= 0) {
            return "smb://";
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.url.getHost());
            sb2.append('/');
            return sb2.toString();
        }
    }

    public String getPath() {
        return this.url.toString();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0035, code lost:
        if (r0[r10] != '/') goto L_0x0039;
     */
    private String getUncPath0() {
        int i;
        if (this.unc == null) {
            char[] charArray = this.url.getPath().toCharArray();
            char[] cArr = new char[charArray.length];
            int length = charArray.length;
            int i2 = 0;
            int i3 = 0;
            char c = 0;
            while (i2 < length) {
                if (c != 0) {
                    if (c != 1) {
                        if (c != 2) {
                        }
                    } else if (charArray[i2] != '/') {
                        if (charArray[i2] == '.') {
                            i = i2 + 1;
                            if (i < length) {
                            }
                            i2 = i;
                        }
                        int i4 = i2 + 1;
                        if (i4 < length && charArray[i2] == '.' && charArray[i4] == '.') {
                            i = i2 + 2;
                            if (i >= length || charArray[i] == '/') {
                                if (i3 != 1) {
                                    do {
                                        i3--;
                                        if (i3 <= 1) {
                                            break;
                                        }
                                    } while (cArr[i3 - 1] != '/');
                                }
                                i2 = i;
                            }
                        }
                        c = 2;
                    }
                    if (charArray[i2] == '/') {
                        c = 1;
                    }
                    int i5 = i3 + 1;
                    cArr[i3] = charArray[i2];
                    i3 = i5;
                } else if (charArray[i2] != '/') {
                    return null;
                } else {
                    int i6 = i3 + 1;
                    cArr[i3] = charArray[i2];
                    i3 = i6;
                    c = 1;
                }
                i2++;
            }
            String str = new String(cArr, 0, i3);
            this.canon = str;
            String str2 = "\\";
            if (i3 > 1) {
                int i7 = i3 - 1;
                int indexOf = str.indexOf(47, 1);
                if (indexOf < 0) {
                    this.share = this.canon.substring(1);
                    this.unc = str2;
                } else if (indexOf == i7) {
                    this.share = this.canon.substring(1, indexOf);
                    this.unc = str2;
                } else {
                    this.share = this.canon.substring(1, indexOf);
                    String str3 = this.canon;
                    if (cArr[i7] != '/') {
                        i7++;
                    }
                    String substring = str3.substring(indexOf, i7);
                    this.unc = substring;
                    this.unc = substring.replace('/', '\\');
                }
            } else {
                this.share = null;
                this.unc = str2;
            }
        }
        return this.unc;
    }

    public String getUncPath() {
        getUncPath0();
        String str = "\\\\";
        if (this.share == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(this.url.getHost());
            return sb.toString();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(this.url.getHost());
        sb2.append(this.canon.replace('/', '\\'));
        return sb2.toString();
    }

    public String getServer() {
        String host = this.url.getHost();
        if (host.length() == 0) {
            return null;
        }
        return host;
    }

    public int getType() throws SmbException {
        if (this.type == 0) {
            if (getUncPath0().length() > 1) {
                this.type = 1;
            } else if (this.share != null) {
                connect0();
                if (this.share.equals("IPC$")) {
                    this.type = 16;
                } else if (this.tree.service.equals("LPT1:")) {
                    this.type = 32;
                } else if (this.tree.service.equals("COMM")) {
                    this.type = 64;
                } else {
                    this.type = 8;
                }
            } else if (this.url.getAuthority() == null || this.url.getAuthority().length() == 0) {
                this.type = 2;
            } else {
                try {
                    UniAddress address = getAddress();
                    if (address.getAddress() instanceof NbtAddress) {
                        int nameType = ((NbtAddress) address.getAddress()).getNameType();
                        if (nameType == 29 || nameType == 27) {
                            this.type = 2;
                            return 2;
                        }
                    }
                    this.type = 4;
                } catch (UnknownHostException e) {
                    throw new SmbException(this.url.toString(), (Throwable) e);
                }
            }
        }
        return this.type;
    }

    private boolean isWorkgroup0() throws UnknownHostException {
        if (this.type == 2 || this.url.getHost().length() == 0) {
            this.type = 2;
            return true;
        }
        getUncPath0();
        if (this.share == null) {
            UniAddress address = getAddress();
            if (address.getAddress() instanceof NbtAddress) {
                int nameType = ((NbtAddress) address.getAddress()).getNameType();
                if (nameType == 29 || nameType == 27) {
                    this.type = 2;
                    return true;
                }
            }
            this.type = 4;
        }
        return false;
    }

    public SmbFile[] listFiles() throws SmbException {
        return listFiles("*", 22);
    }

    private SmbFile[] listFiles(String str, int i) throws SmbException {
        ArrayList arrayList = new ArrayList();
        doEnum(arrayList, true, str, i);
        return (SmbFile[]) arrayList.toArray(new SmbFile[arrayList.size()]);
    }

    private void doEnum(ArrayList<Object> arrayList, boolean z, String str, int i) throws SmbException {
        try {
            if (this.url.getHost().length() != 0) {
                if (getType() != 2) {
                    if (this.share == null) {
                        doShareEnum(arrayList, z, str, i);
                        return;
                    } else {
                        doFindFirstNext(arrayList, z, str, i);
                        return;
                    }
                }
            }
            doNetServerEnum(arrayList, z, str, i);
        } catch (UnknownHostException e) {
            throw new SmbException(this.url.toString(), (Throwable) e);
        } catch (MalformedURLException e2) {
            throw new SmbException(this.url.toString(), (Throwable) e2);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:?, code lost:
        r2 = doNetShareEnum();
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x002d */
    private void doShareEnum(ArrayList<Object> arrayList, boolean z, String str, int i) throws SmbException, UnknownHostException, MalformedURLException {
        FileEntry[] fileEntryArr;
        ArrayList<Object> arrayList2 = arrayList;
        String path = this.url.getPath();
        if (path.lastIndexOf(47) != path.length() - 1) {
            StringBuilder sb = new StringBuilder();
            sb.append(this.url.toString());
            sb.append(" directory must end with '/'");
            throw new SmbException(sb.toString());
        } else if (getType() == 4) {
            HashMap hashMap = new HashMap();
            IOException e = null;
            while (true) {
                try {
                    doConnect();
                    fileEntryArr = doMsrpcShareEnum();
                    break;
                } catch (IOException e2) {
                    e = e2;
                    if (getNextAddress() == null) {
                        break;
                    }
                }
            }
            for (FileEntry fileEntry : fileEntryArr) {
                if (!hashMap.containsKey(fileEntry)) {
                    hashMap.put(fileEntry, fileEntry);
                }
            }
            if (e == null || !hashMap.isEmpty()) {
                for (FileEntry fileEntry2 : hashMap.keySet()) {
                    String name = fileEntry2.getName();
                    if (name.length() > 0) {
                        SmbFile smbFile = new SmbFile(this, name, fileEntry2.getType(), 17, 0, 0, 0);
                        if (z) {
                            arrayList2.add(smbFile);
                        } else {
                            arrayList2.add(name);
                        }
                    }
                }
            } else if (!(e instanceof SmbException)) {
                throw new SmbException(this.url.toString(), (Throwable) e);
            } else {
                throw ((SmbException) e);
            }
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("The requested list operations is invalid: ");
            sb2.append(this.url.toString());
            throw new SmbException(sb2.toString());
        }
    }

    private FileEntry[] doMsrpcShareEnum() throws IOException {
        MsrpcShareEnum msrpcShareEnum = new MsrpcShareEnum(this.url.getHost());
        StringBuilder sb = new StringBuilder();
        sb.append("ncacn_np:");
        sb.append(getAddress().getHostAddress());
        sb.append("[\\PIPE\\srvsvc]");
        DcerpcHandle handle = DcerpcHandle.getHandle(sb.toString(), this.auth);
        try {
            handle.sendrecv(msrpcShareEnum);
            if (msrpcShareEnum.retval == 0) {
                return msrpcShareEnum.getEntries();
            }
            throw new SmbException(msrpcShareEnum.retval, true);
        } finally {
            try {
                handle.close();
            } catch (IOException unused) {
            }
        }
    }

    private FileEntry[] doNetShareEnum() throws SmbException {
        NetShareEnum netShareEnum = new NetShareEnum();
        NetShareEnumResponse netShareEnumResponse = new NetShareEnumResponse();
        send(netShareEnum, netShareEnumResponse);
        if (netShareEnumResponse.status == 0) {
            return netShareEnumResponse.results;
        }
        throw new SmbException(netShareEnumResponse.status, true);
    }

    private void doNetServerEnum(ArrayList<Object> arrayList, boolean z, String str, int i) throws SmbException, UnknownHostException, MalformedURLException {
        NetServerEnum2 netServerEnum2;
        NetServerEnum2Response netServerEnum2Response;
        int i2;
        NetServerEnum2Response netServerEnum2Response2;
        int i3;
        ArrayList<Object> arrayList2 = arrayList;
        int type2 = this.url.getHost().length() == 0 ? 0 : getType();
        try {
            connect0();
            if (type2 == 0) {
                netServerEnum2 = new NetServerEnum2(this.tree.session.transport.server.oemDomainName, SmbConstants.CAP_EXTENDED_SECURITY);
                netServerEnum2Response = new NetServerEnum2Response();
            } else if (type2 == 2) {
                netServerEnum2 = new NetServerEnum2(this.url.getHost(), -1);
                netServerEnum2Response = new NetServerEnum2Response();
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("The requested list operations is invalid: ");
                sb.append(this.url.toString());
                throw new SmbException(sb.toString());
            }
            NetServerEnum2 netServerEnum22 = netServerEnum2;
            NetServerEnum2Response netServerEnum2Response3 = netServerEnum2Response;
            while (true) {
                send(netServerEnum22, netServerEnum2Response3);
                if (netServerEnum2Response3.status == 0 || netServerEnum2Response3.status == 234) {
                    boolean z2 = netServerEnum2Response3.status == 234;
                    int i4 = netServerEnum2Response3.numEntries;
                    if (z2) {
                        i4--;
                    }
                    int i5 = i4;
                    int i6 = 0;
                    while (i6 < i5) {
                        FileEntry fileEntry = netServerEnum2Response3.results[i6];
                        String name = fileEntry.getName();
                        if (name == null || name.length() <= 0) {
                            i3 = i6;
                            netServerEnum2Response2 = netServerEnum2Response3;
                            i2 = i5;
                        } else {
                            SmbFile smbFile = r1;
                            i3 = i6;
                            String str2 = name;
                            netServerEnum2Response2 = netServerEnum2Response3;
                            i2 = i5;
                            SmbFile smbFile2 = new SmbFile(this, name, fileEntry.getType(), 17, 0, 0, 0);
                            if (z) {
                                arrayList2.add(smbFile);
                            } else {
                                arrayList2.add(str2);
                            }
                        }
                        i6 = i3 + 1;
                        netServerEnum2Response3 = netServerEnum2Response2;
                        i5 = i2;
                    }
                    NetServerEnum2Response netServerEnum2Response4 = netServerEnum2Response3;
                    if (getType() != 2) {
                        break;
                    }
                    netServerEnum22.subCommand = -41;
                    netServerEnum22.reset(0, netServerEnum2Response4.lastName);
                    netServerEnum2Response4.reset();
                    if (!z2) {
                        break;
                    }
                    netServerEnum2Response3 = netServerEnum2Response4;
                } else {
                    throw new SmbException(netServerEnum2Response3.status, true);
                }
            }
        } catch (SmbException e) {
            SmbException smbException = e;
            if (type2 != 0 || !(smbException.getCause() instanceof UnknownHostException)) {
                throw smbException;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x005a, code lost:
        if (r1 != HASH_DOT_DOT) goto L_0x006d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x006a, code lost:
        if (r10.equals("..") == false) goto L_0x006d;
     */
    private void doFindFirstNext(ArrayList<Object> arrayList, boolean z, String str, int i) throws SmbException, UnknownHostException, MalformedURLException {
        int i2;
        int i3;
        ArrayList<Object> arrayList2 = arrayList;
        String uncPath0 = getUncPath0();
        String path = this.url.getPath();
        if (path.lastIndexOf(47) == path.length() - 1) {
            Trans2FindFirst2 trans2FindFirst2 = new Trans2FindFirst2(uncPath0, str, i);
            Trans2FindFirst2Response trans2FindFirst2Response = new Trans2FindFirst2Response();
            send(trans2FindFirst2, trans2FindFirst2Response);
            int i4 = trans2FindFirst2Response.sid;
            Trans2FindNext2 trans2FindNext2 = new Trans2FindNext2(i4, trans2FindFirst2Response.resumeKey, trans2FindFirst2Response.lastName);
            trans2FindFirst2Response.subCommand = 2;
            while (true) {
                int i5 = 0;
                while (i5 < trans2FindFirst2Response.numEntries) {
                    FileEntry fileEntry = trans2FindFirst2Response.results[i5];
                    String name = fileEntry.getName();
                    if (name.length() < 3) {
                        int hashCode = name.hashCode();
                        if (hashCode != HASH_DOT) {
                        }
                        if (!name.equals(".")) {
                        }
                        i3 = i5;
                        i2 = i4;
                        i5 = i3 + 1;
                        i4 = i2;
                    }
                    if (name.length() > 0) {
                        int attributes = fileEntry.getAttributes();
                        long createTime = fileEntry.createTime();
                        SmbFile smbFile = r0;
                        long lastModified = fileEntry.lastModified();
                        i3 = i5;
                        i2 = i4;
                        String str2 = name;
                        SmbFile smbFile2 = new SmbFile(this, name, 1, attributes, createTime, lastModified, fileEntry.length());
                        if (z) {
                            arrayList2.add(smbFile);
                        } else {
                            arrayList2.add(str2);
                        }
                        i5 = i3 + 1;
                        i4 = i2;
                    }
                    i3 = i5;
                    i2 = i4;
                    i5 = i3 + 1;
                    i4 = i2;
                }
                int i6 = i4;
                if (trans2FindFirst2Response.isEndOfSearch || trans2FindFirst2Response.numEntries == 0) {
                    try {
                        send(new SmbComFindClose2(i6), blank_resp());
                        return;
                    } catch (SmbException unused) {
                        return;
                    }
                } else {
                    trans2FindNext2.reset(trans2FindFirst2Response.resumeKey, trans2FindFirst2Response.lastName);
                    trans2FindFirst2Response.reset();
                    send(trans2FindNext2, trans2FindFirst2Response);
                    i4 = i6;
                }
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(this.url.toString());
            sb.append(" directory must end with '/'");
            throw new SmbException(sb.toString());
        }
    }

    public int hashCode() {
        int i;
        try {
            i = getAddress().hashCode();
        } catch (UnknownHostException unused) {
            i = getServer().toUpperCase().hashCode();
        }
        getUncPath0();
        return i + this.canon.toUpperCase().hashCode();
    }

    private boolean pathNamesPossiblyEqual(String str, String str2) {
        int lastIndexOf = str.lastIndexOf(47);
        int lastIndexOf2 = str2.lastIndexOf(47);
        int length = str.length() - lastIndexOf;
        int length2 = str2.length() - lastIndexOf2;
        boolean z = true;
        if (length > 1 && str.charAt(lastIndexOf + 1) == '.') {
            return true;
        }
        if (length2 > 1 && str2.charAt(lastIndexOf2 + 1) == '.') {
            return true;
        }
        if (length != length2 || !str.regionMatches(true, lastIndexOf, str2, lastIndexOf2, length)) {
            z = false;
        }
        return z;
    }

    public boolean equals(Object obj) {
        boolean z;
        if (obj instanceof SmbFile) {
            SmbFile smbFile = (SmbFile) obj;
            if (this == smbFile) {
                return true;
            }
            if (pathNamesPossiblyEqual(this.url.getPath(), smbFile.url.getPath())) {
                getUncPath0();
                smbFile.getUncPath0();
                if (this.canon.equalsIgnoreCase(smbFile.canon)) {
                    try {
                        z = getAddress().equals(smbFile.getAddress());
                    } catch (UnknownHostException unused) {
                        z = getServer().equalsIgnoreCase(smbFile.getServer());
                    }
                    return z;
                }
            }
        }
        return false;
    }

    public String toString() {
        return this.url.toString();
    }

    public SmbOutpuStream print_open(String str) throws IOException {
        connect0();
        if (getType() != 32) {
            return null;
        }
        open_printJob(str);
        SmbOutpuStream smbOutpuStream = new SmbOutpuStream();
        sbmOutputStream = smbOutpuStream;
        return smbOutpuStream;
    }

    /* access modifiers changed from: private */
    public void print_write(byte[] bArr, int i) throws IOException {
        SmbComWritePrintFile smbComWritePrintFile = new SmbComWritePrintFile((long) this.fid, (long) i, bArr);
        send(smbComWritePrintFile, blank_resp());
    }

    public void print_close() throws IOException {
        close();
    }

    public String[] printerGetInfo() throws IOException {
        do {
            try {
                return doPrinterGetInfo();
            } catch (SmbAuthException e) {
                throw e;
            } catch (IOException e2) {
                if (getNextAddress() == null) {
                    throw e2;
                }
            }
        } while (getNextAddress() == null);
        throw e2;
    }

    private String[] doPrinterGetInfo() throws IOException {
        String uncPath = getUncPath();
        if (uncPath.endsWith("\\")) {
            uncPath = uncPath.substring(0, uncPath.length() - 1);
        }
        MsrpcOpenPrinter msrpcOpenPrinter = new MsrpcOpenPrinter(uncPath);
        StringBuilder sb = new StringBuilder();
        sb.append("ncacn_np:");
        sb.append(getAddress().getHostAddress());
        sb.append("[\\PIPE\\spoolss]");
        DcerpcHandle handle = DcerpcHandle.getHandle(sb.toString(), this.auth);
        try {
            handle.sendrecv(msrpcOpenPrinter);
            if (msrpcOpenPrinter.retval == 0) {
                MsrpcGetPrinter msrpcGetPrinter = new MsrpcGetPrinter(msrpcOpenPrinter.getPrinteHandle(), 2, 0);
                handle.sendrecv(msrpcGetPrinter);
                if (msrpcGetPrinter.retval == 122) {
                    MsrpcGetPrinter msrpcGetPrinter2 = new MsrpcGetPrinter(msrpcOpenPrinter.getPrinteHandle(), 2, msrpcGetPrinter.pcbneeded);
                    handle.sendrecv(msrpcGetPrinter2);
                    msrpcGetPrinter = msrpcGetPrinter2;
                }
                if (msrpcGetPrinter.retval == 0) {
                    MsrpcClosePrinter msrpcClosePrinter = new MsrpcClosePrinter(msrpcOpenPrinter.getPrinteHandle());
                    handle.sendrecv(msrpcClosePrinter);
                    if (msrpcClosePrinter.retval == 0) {
                        return new String[]{msrpcGetPrinter.getPrinterName(), msrpcGetPrinter.getDriverName(), msrpcGetPrinter.getLocation(), msrpcGetPrinter.getServerName()};
                    }
                    throw new SmbException(msrpcClosePrinter.retval, true);
                }
                throw new SmbException(msrpcGetPrinter.retval, true);
            }
            throw new SmbException(msrpcOpenPrinter.retval, true);
        } finally {
            try {
                handle.close();
            } catch (IOException unused) {
            }
        }
    }

    public void setAuth(NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        this.auth = ntlmPasswordAuthentication;
    }
}
