package com.dynamixsoftware.printershare.smb;

import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;
import org.nanohttpd.protocols.http.NanoHTTPD;

class NetServerEnum2 extends SmbComTransaction {
    private static final String[] DESCR = {"WrLehDO\u0000B16BBDz\u0000", "WrLehDz\u0000B16BBDz\u0000"};
    static final int SV_TYPE_ALL = -1;
    static final int SV_TYPE_DOMAIN_ENUM = Integer.MIN_VALUE;
    private String domain;
    private String lastName = null;
    private int serverTypes;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NetServerEnum2(String str, int i) {
        this.domain = str;
        this.serverTypes = i;
        this.command = 37;
        this.subCommand = 104;
        this.name = "\\PIPE\\LANMAN";
        this.maxParameterCount = 8;
        this.maxDataCount = SmbConstants.FLAGS2_STATUS32;
        this.maxSetupCount = 0;
        this.setupCount = 0;
        this.timeout = NanoHTTPD.SOCKET_READ_TIMEOUT;
    }

    /* access modifiers changed from: 0000 */
    public void reset(int i, String str) {
        super.reset();
        this.lastName = str;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        char c = this.subCommand == 104 ? (char) 0 : 1;
        try {
            byte[] bytes = DESCR[c].getBytes("ASCII");
            writeInt2((long) (this.subCommand & Constants.UNKNOWN), bArr, i);
            int i2 = i + 2;
            System.arraycopy(bytes, 0, bArr, i2, bytes.length);
            int length = i2 + bytes.length;
            writeInt2(1, bArr, length);
            int i3 = length + 2;
            writeInt2((long) this.maxDataCount, bArr, i3);
            int i4 = i3 + 2;
            writeInt4((long) this.serverTypes, bArr, i4);
            int i5 = i4 + 4;
            int writeString = i5 + writeString(this.domain.toUpperCase(), bArr, i5, false);
            if (c == 1) {
                writeString += writeString(this.lastName.toUpperCase(), bArr, writeString, false);
            }
            return writeString - i;
        } catch (UnsupportedEncodingException unused) {
            return 0;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NetServerEnum2[");
        sb.append(super.toString());
        sb.append(",name=");
        sb.append(this.name);
        sb.append(",serverTypes=");
        sb.append(this.serverTypes == -1 ? "SV_TYPE_ALL" : "SV_TYPE_DOMAIN_ENUM");
        sb.append("]");
        return new String(sb.toString());
    }
}
