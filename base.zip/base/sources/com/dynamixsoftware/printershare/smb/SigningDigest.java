package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class SigningDigest implements SmbConstants {
    private boolean bypass = false;
    private MessageDigest digest;
    private byte[] macSigningKey;
    private int signSequence;

    SigningDigest(byte[] bArr, boolean z) throws SmbException {
        String str = "MD5";
        try {
            this.digest = MessageDigest.getInstance(str);
            this.macSigningKey = bArr;
            this.bypass = z;
            this.signSequence = 0;
        } catch (NoSuchAlgorithmException e) {
            throw new SmbException(str, (Throwable) e);
        }
    }

    private void update(byte[] bArr, int i, int i2) {
        if (i2 != 0) {
            this.digest.update(bArr, i, i2);
        }
    }

    private byte[] digest() {
        return this.digest.digest();
    }

    /* access modifiers changed from: 0000 */
    public void sign(byte[] bArr, int i, int i2, ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) {
        serverMessageBlock.signSeq = this.signSequence;
        if (serverMessageBlock2 != null) {
            serverMessageBlock2.signSeq = this.signSequence + 1;
            serverMessageBlock2.verifyFailed = false;
        }
        try {
            update(this.macSigningKey, 0, this.macSigningKey.length);
            int i3 = i + 14;
            for (int i4 = 0; i4 < 8; i4++) {
                bArr[i3 + i4] = 0;
            }
            ServerMessageBlock.writeInt4((long) this.signSequence, bArr, i3);
            update(bArr, i, i2);
            System.arraycopy(digest(), 0, bArr, i3, 8);
            if (this.bypass) {
                this.bypass = false;
                System.arraycopy("BSRSPYL ".getBytes(), 0, bArr, i3, 8);
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            this.signSequence += 2;
            throw th;
        }
        this.signSequence += 2;
    }

    /* access modifiers changed from: 0000 */
    public boolean verify(byte[] bArr, int i, ServerMessageBlock serverMessageBlock) {
        byte[] bArr2 = this.macSigningKey;
        update(bArr2, 0, bArr2.length);
        update(bArr, i, 14);
        int i2 = i + 14;
        byte[] bArr3 = new byte[8];
        ServerMessageBlock.writeInt4((long) serverMessageBlock.signSeq, bArr3, 0);
        update(bArr3, 0, 8);
        int i3 = i2 + 8;
        if (serverMessageBlock.command == 46) {
            SmbComReadAndXResponse smbComReadAndXResponse = (SmbComReadAndXResponse) serverMessageBlock;
            update(bArr, i3, ((serverMessageBlock.length - smbComReadAndXResponse.dataLength) - 14) - 8);
            update(smbComReadAndXResponse.b, smbComReadAndXResponse.off, smbComReadAndXResponse.dataLength);
        } else {
            update(bArr, i3, (serverMessageBlock.length - 14) - 8);
        }
        byte[] digest2 = digest();
        for (int i4 = 0; i4 < 8; i4++) {
            if (digest2[i4] != bArr[i2 + i4]) {
                serverMessageBlock.verifyFailed = true;
                return true;
            }
        }
        serverMessageBlock.verifyFailed = false;
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("LM_COMPATIBILITY=3 MacSigningKey=");
        byte[] bArr = this.macSigningKey;
        sb.append(Dumper.toHexString(bArr, 0, bArr.length));
        return sb.toString();
    }
}
