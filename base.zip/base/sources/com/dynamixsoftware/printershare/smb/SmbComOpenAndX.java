package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.util.Date;

class SmbComOpenAndX extends AndXServerMessageBlock {
    private static final int BATCH_LIMIT = 1;
    private static final int OPEN_FN_CREATE = 16;
    private static final int OPEN_FN_FAIL_IF_EXISTS = 0;
    private static final int OPEN_FN_OPEN = 1;
    private static final int OPEN_FN_TRUNC = 2;
    private static final int SHARING_DENY_NONE = 64;
    private int allocationSize;
    private int creationTime;
    private int desiredAccess;
    private int fileAttributes;
    private int flags;
    private int openFunction;
    private int searchAttributes;

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b) {
        return b == 46 ? 1 : 0;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComOpenAndX(String str, int i, int i2, ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        this.path = str;
        this.command = 45;
        int i3 = i & 3;
        this.desiredAccess = i3;
        if (i3 == 3) {
            this.desiredAccess = 2;
        }
        int i4 = this.desiredAccess | 64;
        this.desiredAccess = i4;
        this.desiredAccess = i4 & -2;
        this.searchAttributes = 22;
        this.fileAttributes = 0;
        if ((i2 & 64) == 64) {
            if ((i2 & 16) == 16) {
                this.openFunction = 18;
            } else {
                this.openFunction = 2;
            }
        } else if ((i2 & 16) != 16) {
            this.openFunction = 1;
        } else if ((i2 & 32) == 32) {
            this.openFunction = 16;
        } else {
            this.openFunction = 17;
        }
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2((long) this.flags, bArr, i);
        int i2 = i + 2;
        writeInt2((long) this.desiredAccess, bArr, i2);
        int i3 = i2 + 2;
        writeInt2((long) this.searchAttributes, bArr, i3);
        int i4 = i3 + 2;
        writeInt2((long) this.fileAttributes, bArr, i4);
        int i5 = i4 + 2;
        this.creationTime = 0;
        writeInt4((long) 0, bArr, i5);
        int i6 = i5 + 4;
        writeInt2((long) this.openFunction, bArr, i6);
        int i7 = i6 + 2;
        writeInt4((long) this.allocationSize, bArr, i7);
        int i8 = i7 + 4;
        int i9 = 0;
        while (i9 < 8) {
            int i10 = i8 + 1;
            bArr[i8] = 0;
            i9++;
            i8 = i10;
        }
        return i8 - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2;
        if (this.useUnicode) {
            i2 = i + 1;
            bArr[i] = 0;
        } else {
            i2 = i;
        }
        return (i2 + writeString(this.path, bArr, i2)) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComOpenAndX[");
        sb.append(super.toString());
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags, 2));
        sb.append(",desiredAccess=0x");
        sb.append(Dumper.toHexString(this.desiredAccess, 4));
        sb.append(",searchAttributes=0x");
        sb.append(Dumper.toHexString(this.searchAttributes, 4));
        sb.append(",fileAttributes=0x");
        sb.append(Dumper.toHexString(this.fileAttributes, 4));
        sb.append(",creationTime=");
        sb.append(new Date((long) this.creationTime));
        sb.append(",openFunction=0x");
        sb.append(Dumper.toHexString(this.openFunction, 2));
        sb.append(",allocationSize=");
        sb.append(this.allocationSize);
        sb.append(",fileName=");
        sb.append(this.path);
        sb.append("]");
        return new String(sb.toString());
    }
}
