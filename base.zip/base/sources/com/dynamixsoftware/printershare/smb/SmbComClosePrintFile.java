package com.dynamixsoftware.printershare.smb;

class SmbComClosePrintFile extends ServerMessageBlock {
    private long fid;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComClosePrintFile(long j) {
        this.fid = j;
        this.command = -62;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2(this.fid, bArr, i);
        return 2;
    }
}
