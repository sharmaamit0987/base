package com.dynamixsoftware.printershare.smb;

import java.io.IOException;

class TransportException extends IOException {
    public TransportException() {
    }

    TransportException(String str) {
        super(str);
    }

    TransportException(Throwable th) {
        if (th != null) {
            initCause(th);
        }
    }

    TransportException(String str, Throwable th) {
        super(str);
        if (th != null) {
            initCause(th);
        }
    }
}
