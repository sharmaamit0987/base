package com.dynamixsoftware.printershare.smb;

class SmbComWritePrintFile extends ServerMessageBlock {
    private byte[] data;
    private long dataLength;
    private long fid;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComWritePrintFile(long j, long j2, byte[] bArr) {
        this.fid = j;
        this.dataLength = j2;
        this.data = bArr;
        this.command = -63;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = 1;
        writeInt2(this.dataLength, bArr, i2);
        int i3 = i2 + 2;
        System.arraycopy(this.data, 0, bArr, i3, (int) this.dataLength);
        return ((int) (((long) i3) + this.dataLength)) - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2(this.fid, bArr, i);
        return 2;
    }
}
