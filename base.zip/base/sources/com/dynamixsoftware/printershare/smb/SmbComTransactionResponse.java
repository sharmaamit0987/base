package com.dynamixsoftware.printershare.smb;

import com.flurry.android.Constants;
import java.util.Enumeration;

abstract class SmbComTransactionResponse extends ServerMessageBlock implements Enumeration<Object> {
    private int bufDataStart;
    private int bufParameterStart;
    int dataCount;
    private int dataDisplacement;
    private boolean dataDone;
    private int dataOffset;
    private boolean hasMore = true;
    private boolean isPrimary = true;
    int numEntries;
    private int pad;
    private int pad1;
    private int parameterCount;
    private int parameterDisplacement;
    private int parameterOffset;
    private boolean parametersDone;
    FileEntry[] results;
    private int setupCount;
    int status;
    byte subCommand;
    private int totalDataCount;
    private int totalParameterCount;
    byte[] txn_buf = null;

    /* access modifiers changed from: 0000 */
    public abstract int readDataWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public abstract int readParametersWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public abstract int readSetupWireFormat(byte[] bArr, int i, int i2);

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public abstract int writeDataWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public abstract int writeParametersWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeSetupWireFormat(byte[] bArr, int i);

    SmbComTransactionResponse() {
    }

    /* access modifiers changed from: 0000 */
    public void reset() {
        super.reset();
        this.bufDataStart = 0;
        this.hasMore = true;
        this.isPrimary = true;
        this.dataDone = false;
        this.parametersDone = false;
    }

    public boolean hasMoreElements() {
        return this.errorCode == 0 && this.hasMore;
    }

    public Object nextElement() {
        if (this.isPrimary) {
            this.isPrimary = false;
        }
        return this;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        int readInt2 = readInt2(bArr, i);
        this.totalParameterCount = readInt2;
        if (this.bufDataStart == 0) {
            this.bufDataStart = readInt2;
        }
        int i2 = i + 2;
        this.totalDataCount = readInt2(bArr, i2);
        int i3 = i2 + 4;
        this.parameterCount = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.parameterOffset = readInt2(bArr, i4);
        int i5 = i4 + 2;
        this.parameterDisplacement = readInt2(bArr, i5);
        int i6 = i5 + 2;
        this.dataCount = readInt2(bArr, i6);
        int i7 = i6 + 2;
        this.dataOffset = readInt2(bArr, i7);
        int i8 = i7 + 2;
        this.dataDisplacement = readInt2(bArr, i8);
        int i9 = i8 + 2;
        this.setupCount = bArr[i9] & Constants.UNKNOWN;
        return (i9 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        this.pad1 = 0;
        this.pad = 0;
        if (this.parameterCount > 0) {
            int i2 = this.parameterOffset - (i - this.headerStart);
            this.pad = i2;
            int i3 = i + i2;
            System.arraycopy(bArr, i3, this.txn_buf, this.bufParameterStart + this.parameterDisplacement, this.parameterCount);
            i = i3 + this.parameterCount;
        }
        if (this.dataCount > 0) {
            int i4 = this.dataOffset - (i - this.headerStart);
            this.pad1 = i4;
            System.arraycopy(bArr, i + i4, this.txn_buf, this.bufDataStart + this.dataDisplacement, this.dataCount);
        }
        if (!this.parametersDone && this.parameterDisplacement + this.parameterCount == this.totalParameterCount) {
            this.parametersDone = true;
        }
        if (!this.dataDone && this.dataDisplacement + this.dataCount == this.totalDataCount) {
            this.dataDone = true;
        }
        if (this.parametersDone && this.dataDone) {
            this.hasMore = false;
            readParametersWireFormat(this.txn_buf, this.bufParameterStart, this.totalParameterCount);
            readDataWireFormat(this.txn_buf, this.bufDataStart, this.totalDataCount);
        }
        return this.pad + this.parameterCount + this.pad1 + this.dataCount;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(",totalParameterCount=");
        sb.append(this.totalParameterCount);
        sb.append(",totalDataCount=");
        sb.append(this.totalDataCount);
        sb.append(",parameterCount=");
        sb.append(this.parameterCount);
        sb.append(",parameterOffset=");
        sb.append(this.parameterOffset);
        sb.append(",parameterDisplacement=");
        sb.append(this.parameterDisplacement);
        sb.append(",dataCount=");
        sb.append(this.dataCount);
        sb.append(",dataOffset=");
        sb.append(this.dataOffset);
        sb.append(",dataDisplacement=");
        sb.append(this.dataDisplacement);
        sb.append(",setupCount=");
        sb.append(this.setupCount);
        sb.append(",pad=");
        sb.append(this.pad);
        sb.append(",pad1=");
        sb.append(this.pad1);
        return new String(sb.toString());
    }
}
