package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.mdns.DnsConstants;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;
import java.util.Date;

abstract class ServerMessageBlock extends Response implements Request, SmbConstants {
    static final byte SMB_COM_CHECK_DIRECTORY = 16;
    static final byte SMB_COM_CLOSE = 4;
    static final byte SMB_COM_CLOSE_PRINT_FILE = -62;
    static final byte SMB_COM_CREATE_DIRECTORY = 0;
    static final byte SMB_COM_DELETE = 6;
    static final byte SMB_COM_DELETE_DIRECTORY = 1;
    private static final byte SMB_COM_ECHO = 43;
    static final byte SMB_COM_FIND_CLOSE2 = 52;
    static final byte SMB_COM_LOGOFF_ANDX = 116;
    private static final byte SMB_COM_MOVE = 42;
    static final byte SMB_COM_NEGOTIATE = 114;
    static final byte SMB_COM_NT_CREATE_ANDX = -94;
    static final byte SMB_COM_NT_TRANSACT = -96;
    static final byte SMB_COM_NT_TRANSACT_SECONDARY = -95;
    static final byte SMB_COM_OPEN_ANDX = 45;
    static final byte SMB_COM_OPEN_PRINT_FILE = -64;
    static final byte SMB_COM_QUERY_INFORMATION = 8;
    static final byte SMB_COM_READ_ANDX = 46;
    static final byte SMB_COM_RENAME = 7;
    static final byte SMB_COM_SESSION_SETUP_ANDX = 115;
    static final byte SMB_COM_TRANSACTION = 37;
    static final byte SMB_COM_TRANSACTION2 = 50;
    static final byte SMB_COM_TRANSACTION_SECONDARY = 38;
    static final byte SMB_COM_TREE_CONNECT_ANDX = 117;
    static final byte SMB_COM_TREE_DISCONNECT = 113;
    static final byte SMB_COM_WRITE = 11;
    static final byte SMB_COM_WRITE_ANDX = 47;
    static final byte SMB_COM_WRITE_PRINT_FILE = -63;
    private static final byte[] header = {-1, 83, 77, 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    NtlmPasswordAuthentication auth = null;
    int batchLevel = 0;
    int byteCount;
    byte command;
    SigningDigest digest = null;
    int errorCode;
    boolean extendedSecurity;
    byte flags = 24;
    int flags2;
    int headerStart;
    int length;
    int mid;
    String path;
    int pid = PID;
    boolean received;
    ServerMessageBlock response;
    int signSeq;
    int tid;
    int uid;
    boolean useUnicode;
    boolean verifyFailed;
    int wordCount;

    /* access modifiers changed from: 0000 */
    public abstract int readBytesWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int readParameterWordsWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeBytesWireFormat(byte[] bArr, int i);

    /* access modifiers changed from: 0000 */
    public abstract int writeParameterWordsWireFormat(byte[] bArr, int i);

    static void writeInt2(long j, byte[] bArr, int i) {
        bArr[i] = (byte) ((int) j);
        bArr[i + 1] = (byte) ((int) (j >> 8));
    }

    static void writeInt4(long j, byte[] bArr, int i) {
        bArr[i] = (byte) ((int) j);
        int i2 = i + 1;
        long j2 = j >> 8;
        bArr[i2] = (byte) ((int) j2);
        int i3 = i2 + 1;
        long j3 = j2 >> 8;
        bArr[i3] = (byte) ((int) j3);
        bArr[i3 + 1] = (byte) ((int) (j3 >> 8));
    }

    static int readInt2(byte[] bArr, int i) {
        return (bArr[i] & Constants.UNKNOWN) + ((bArr[i + 1] & Constants.UNKNOWN) << SMB_COM_QUERY_INFORMATION);
    }

    static int readInt4(byte[] bArr, int i) {
        return (bArr[i] & Constants.UNKNOWN) + ((bArr[i + 1] & Constants.UNKNOWN) << SMB_COM_QUERY_INFORMATION) + ((bArr[i + 2] & Constants.UNKNOWN) << SMB_COM_CHECK_DIRECTORY) + ((bArr[i + 3] & Constants.UNKNOWN) << 24);
    }

    static long readInt8(byte[] bArr, int i) {
        return (((long) readInt4(bArr, i)) & 4294967295L) + (((long) readInt4(bArr, i + 4)) << 32);
    }

    static void writeInt8(long j, byte[] bArr, int i) {
        bArr[i] = (byte) ((int) j);
        int i2 = i + 1;
        long j2 = j >> 8;
        bArr[i2] = (byte) ((int) j2);
        int i3 = i2 + 1;
        long j3 = j2 >> 8;
        bArr[i3] = (byte) ((int) j3);
        int i4 = i3 + 1;
        long j4 = j3 >> 8;
        bArr[i4] = (byte) ((int) j4);
        int i5 = i4 + 1;
        long j5 = j4 >> 8;
        bArr[i5] = (byte) ((int) j5);
        int i6 = i5 + 1;
        long j6 = j5 >> 8;
        bArr[i6] = (byte) ((int) j6);
        int i7 = i6 + 1;
        long j7 = j6 >> 8;
        bArr[i7] = (byte) ((int) j7);
        bArr[i7 + 1] = (byte) ((int) (j7 >> 8));
    }

    static long readTime(byte[] bArr, int i) {
        return (((((long) readInt4(bArr, i + 4)) << 32) | (((long) readInt4(bArr, i)) & 4294967295L)) / 10000) - SmbConstants.MILLISECONDS_BETWEEN_1970_AND_1601;
    }

    static long readUTime(byte[] bArr, int i) {
        return ((long) readInt4(bArr, i)) * 1000;
    }

    static void writeUTime(long j, byte[] bArr, int i) {
        if (j == 0 || j == -1) {
            writeInt4(-1, bArr, i);
            return;
        }
        synchronized (TZ) {
            if (TZ.inDaylightTime(new Date())) {
                if (!TZ.inDaylightTime(new Date(j))) {
                    j -= 3600000;
                }
            } else if (TZ.inDaylightTime(new Date(j))) {
                j += 3600000;
            }
        }
        writeInt4((long) ((int) (j / 1000)), bArr, i);
    }

    ServerMessageBlock() {
    }

    /* access modifiers changed from: 0000 */
    public void reset() {
        this.flags = 24;
        this.flags2 = 0;
        this.errorCode = 0;
        this.received = false;
        this.digest = null;
    }

    /* access modifiers changed from: 0000 */
    public int writeString(String str, byte[] bArr, int i) {
        return writeString(str, bArr, i, this.useUnicode);
    }

    /* access modifiers changed from: 0000 */
    public int writeString(String str, byte[] bArr, int i, boolean z) {
        int i2;
        if (z) {
            try {
                if ((i - this.headerStart) % 2 != 0) {
                    i2 = i + 1;
                    try {
                        bArr[i] = 0;
                    } catch (UnsupportedEncodingException unused) {
                    }
                } else {
                    i2 = i;
                }
                System.arraycopy(str.getBytes(SmbConstants.UNI_ENCODING), 0, bArr, i2, str.length() * 2);
                int length2 = i2 + (str.length() * 2);
                int i3 = length2 + 1;
                try {
                    bArr[length2] = 0;
                    i2 = i3 + 1;
                    bArr[i3] = 0;
                } catch (UnsupportedEncodingException unused2) {
                    i2 = i3;
                }
            } catch (UnsupportedEncodingException unused3) {
                i2 = i;
            }
        } else {
            byte[] bytes = str.getBytes(SmbConstants.OEM_ENCODING);
            System.arraycopy(bytes, 0, bArr, i, bytes.length);
            int length3 = bytes.length + i;
            i2 = length3 + 1;
            bArr[length3] = 0;
        }
        return i2 - i;
    }

    /* access modifiers changed from: 0000 */
    public String readString(byte[] bArr, int i) {
        return readString(bArr, i, 256, this.useUnicode);
    }

    /* access modifiers changed from: 0000 */
    public String readString(byte[] bArr, int i, int i2, boolean z) {
        String str = "zero termination not found";
        int i3 = 0;
        if (z) {
            try {
                if ((i - this.headerStart) % 2 != 0) {
                    i++;
                }
                while (true) {
                    int i4 = i + i3;
                    if (bArr[i4] == 0) {
                        if (bArr[i4 + 1] == 0) {
                            return new String(bArr, i, i3, SmbConstants.UNI_ENCODING);
                        }
                    }
                    i3 += 2;
                    if (i3 > i2) {
                        throw new RuntimeException(str);
                    }
                }
            } catch (UnsupportedEncodingException unused) {
                return null;
            }
        } else {
            while (bArr[i + i3] != 0) {
                i3++;
                if (i3 > i2) {
                    throw new RuntimeException(str);
                }
            }
            return new String(bArr, i, i3, SmbConstants.OEM_ENCODING);
        }
    }

    /* access modifiers changed from: 0000 */
    public String readString(byte[] bArr, int i, int i2, int i3, boolean z) {
        String str = "zero termination not found";
        int i4 = 0;
        if (z) {
            try {
                if ((i - this.headerStart) % 2 != 0) {
                    i++;
                }
                while (true) {
                    int i5 = i + i4;
                    int i6 = i5 + 1;
                    if (i6 < i2) {
                        if (bArr[i5] == 0 && bArr[i6] == 0) {
                            break;
                        } else if (i4 <= i3) {
                            i4 += 2;
                        } else {
                            throw new RuntimeException(str);
                        }
                    } else {
                        break;
                    }
                }
                return new String(bArr, i, i4, SmbConstants.UNI_ENCODING);
            } catch (UnsupportedEncodingException unused) {
                return null;
            }
        } else {
            while (true) {
                if (i >= i2) {
                    break;
                } else if (bArr[i + i4] == 0) {
                    break;
                } else if (i4 <= i3) {
                    i4++;
                } else {
                    throw new RuntimeException(str);
                }
            }
            return new String(bArr, i, i4, SmbConstants.OEM_ENCODING);
        }
    }

    /* access modifiers changed from: 0000 */
    public int stringWireLength(String str, int i) {
        int length2 = str.length() + 1;
        if (!this.useUnicode) {
            return length2;
        }
        int length3 = (str.length() * 2) + 2;
        if (i % 2 != 0) {
            length3++;
        }
        return length3;
    }

    /* access modifiers changed from: 0000 */
    public int readStringLength(byte[] bArr, int i, int i2) {
        int i3 = 0;
        while (bArr[i + i3] != 0) {
            int i4 = i3 + 1;
            if (i3 <= i2) {
                i3 = i4;
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("zero termination not found: ");
                sb.append(this);
                throw new RuntimeException(sb.toString());
            }
        }
        return i3;
    }

    /* access modifiers changed from: 0000 */
    public int encode(byte[] bArr, int i) {
        this.headerStart = i;
        int writeHeaderWireFormat = writeHeaderWireFormat(bArr, i) + i;
        int i2 = writeHeaderWireFormat + 1;
        int writeParameterWordsWireFormat = writeParameterWordsWireFormat(bArr, i2);
        this.wordCount = writeParameterWordsWireFormat;
        bArr[writeHeaderWireFormat] = (byte) ((writeParameterWordsWireFormat / 2) & 255);
        int i3 = i2 + writeParameterWordsWireFormat;
        this.wordCount = writeParameterWordsWireFormat / 2;
        int writeBytesWireFormat = writeBytesWireFormat(bArr, i3 + 2);
        this.byteCount = writeBytesWireFormat;
        int i4 = i3 + 1;
        bArr[i3] = (byte) (writeBytesWireFormat & 255);
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((writeBytesWireFormat >> 8) & 255);
        int i6 = (i5 + writeBytesWireFormat) - i;
        this.length = i6;
        SigningDigest signingDigest = this.digest;
        if (signingDigest != null) {
            signingDigest.sign(bArr, this.headerStart, i6, this, this.response);
        }
        return this.length;
    }

    /* access modifiers changed from: 0000 */
    public int decode(byte[] bArr, int i) {
        this.headerStart = i;
        int readHeaderWireFormat = readHeaderWireFormat(bArr, i) + i;
        int i2 = readHeaderWireFormat + 1;
        byte b = bArr[readHeaderWireFormat];
        this.wordCount = b;
        if (b != 0) {
            readParameterWordsWireFormat(bArr, i2);
            i2 += this.wordCount * 2;
        }
        int readInt2 = readInt2(bArr, i2);
        this.byteCount = readInt2;
        int i3 = i2 + 2;
        if (readInt2 != 0) {
            readBytesWireFormat(bArr, i3);
            i3 += this.byteCount;
        }
        int i4 = i3 - i;
        this.length = i4;
        return i4;
    }

    /* access modifiers changed from: 0000 */
    public int writeHeaderWireFormat(byte[] bArr, int i) {
        byte[] bArr2 = header;
        System.arraycopy(bArr2, 0, bArr, i, bArr2.length);
        bArr[i + 4] = this.command;
        int i2 = i + 9;
        bArr[i2] = this.flags;
        writeInt2((long) this.flags2, bArr, i2 + 1);
        int i3 = i + 24;
        writeInt2((long) this.tid, bArr, i3);
        writeInt2((long) this.pid, bArr, i3 + 2);
        writeInt2((long) this.uid, bArr, i3 + 4);
        writeInt2((long) this.mid, bArr, i3 + 6);
        return 32;
    }

    /* access modifiers changed from: 0000 */
    public int readHeaderWireFormat(byte[] bArr, int i) {
        this.command = bArr[i + 4];
        this.errorCode = readInt4(bArr, i + 5);
        int i2 = i + 9;
        this.flags = bArr[i2];
        this.flags2 = readInt2(bArr, i2 + 1);
        int i3 = i + 24;
        this.tid = readInt2(bArr, i3);
        this.pid = readInt2(bArr, i3 + 2);
        this.uid = readInt2(bArr, i3 + 4);
        this.mid = readInt2(bArr, i3 + 6);
        return 32;
    }

    /* access modifiers changed from: 0000 */
    public boolean isResponse() {
        return (this.flags & 128) == 128;
    }

    public int hashCode() {
        return this.mid;
    }

    public boolean equals(Object obj) {
        return (obj instanceof ServerMessageBlock) && ((ServerMessageBlock) obj).mid == this.mid;
    }

    public String toString() {
        String str;
        byte b = this.command;
        if (b == 0) {
            str = "SMB_COM_CREATE_DIRECTORY";
        } else if (b == 1) {
            str = "SMB_COM_DELETE_DIRECTORY";
        } else if (b == 4) {
            str = "SMB_COM_CLOSE";
        } else if (b == 16) {
            str = "SMB_COM_CHECK_DIRECTORY";
        } else if (b == 50) {
            str = "SMB_COM_TRANSACTION2";
        } else if (b == 52) {
            str = "SMB_COM_FIND_CLOSE2";
        } else if (b == 6) {
            str = "SMB_COM_DELETE";
        } else if (b == 7) {
            str = "SMB_COM_RENAME";
        } else if (b == 8) {
            str = "SMB_COM_QUERY_INFORMATION";
        } else if (b == 37) {
            str = "SMB_COM_TRANSACTION";
        } else if (b == 38) {
            str = "SMB_COM_TRANSACTION_SECONDARY";
        } else if (b == 42) {
            str = "SMB_COM_MOVE";
        } else if (b != 43) {
            switch (b) {
                case -96:
                    str = "SMB_COM_NT_TRANSACT";
                    break;
                case -95:
                    str = "SMB_COM_NT_TRANSACT_SECONDARY";
                    break;
                case -94:
                    str = "SMB_COM_NT_CREATE_ANDX";
                    break;
                default:
                    switch (b) {
                        case 45:
                            str = "SMB_COM_OPEN_ANDX";
                            break;
                        case DnsConstants.TYPE_RRSIG /*46*/:
                            str = "SMB_COM_READ_ANDX";
                            break;
                        case DnsConstants.TYPE_NSEC /*47*/:
                            str = "SMB_COM_WRITE_ANDX";
                            break;
                        default:
                            switch (b) {
                                case 113:
                                    str = "SMB_COM_TREE_DISCONNECT";
                                    break;
                                case 114:
                                    str = "SMB_COM_NEGOTIATE";
                                    break;
                                case 115:
                                    str = "SMB_COM_SESSION_SETUP_ANDX";
                                    break;
                                case 116:
                                    str = "SMB_COM_LOGOFF_ANDX";
                                    break;
                                case 117:
                                    str = "SMB_COM_TREE_CONNECT_ANDX";
                                    break;
                                default:
                                    str = "UNKNOWN";
                                    break;
                            }
                    }
            }
        } else {
            str = "SMB_COM_ECHO";
        }
        int i = this.errorCode;
        String messageByCode = i == 0 ? "0" : SmbException.getMessageByCode(i);
        StringBuilder sb = new StringBuilder();
        sb.append("command=");
        sb.append(str);
        sb.append(",received=");
        sb.append(this.received);
        sb.append(",errorCode=");
        sb.append(messageByCode);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags & Constants.UNKNOWN, 4));
        sb.append(",flags2=0x");
        sb.append(Dumper.toHexString(this.flags2, 4));
        sb.append(",signSeq=");
        sb.append(this.signSeq);
        sb.append(",tid=");
        sb.append(this.tid);
        sb.append(",pid=");
        sb.append(this.pid);
        sb.append(",uid=");
        sb.append(this.uid);
        sb.append(",mid=");
        sb.append(this.mid);
        sb.append(",wordCount=");
        sb.append(this.wordCount);
        sb.append(",byteCount=");
        sb.append(this.byteCount);
        return new String(sb.toString());
    }
}
