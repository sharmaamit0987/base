package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.mdns.DnsConstants;
import com.flurry.android.Constants;

class SmbTree {
    private static int tree_conn_counter;
    int connectionState;
    private boolean inDfs;
    private boolean inDomainDfs;
    String service = "?????";
    private String service0;
    SmbSession session;
    private String share;
    private int tid;
    int tree_num;

    SmbTree(SmbSession smbSession, String str, String str2) {
        this.session = smbSession;
        this.share = str.toUpperCase();
        if (str2 != null && !str2.startsWith("??")) {
            this.service = str2;
        }
        this.service0 = this.service;
        this.connectionState = 0;
    }

    /* access modifiers changed from: 0000 */
    public boolean matches(String str, String str2) {
        return this.share.equalsIgnoreCase(str) && (str2 == null || str2.startsWith("??") || this.service.equalsIgnoreCase(str2));
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof SmbTree)) {
            return false;
        }
        SmbTree smbTree = (SmbTree) obj;
        return matches(smbTree.share, smbTree.service);
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x0108, code lost:
        return;
     */
    public void send(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        synchronized (this.session.transport()) {
            if (serverMessageBlock2 != null) {
                serverMessageBlock2.received = false;
            }
            treeConnect(serverMessageBlock, serverMessageBlock2);
            if (serverMessageBlock != null) {
                if (serverMessageBlock2 == null || !serverMessageBlock2.received) {
                    if (!this.service.equals("A:")) {
                        byte b = serverMessageBlock.command;
                        if (!(b == -94 || b == 4)) {
                            if (b == 37 || b == 50) {
                                byte b2 = ((SmbComTransaction) serverMessageBlock).subCommand & Constants.UNKNOWN;
                                if (!(b2 == 0 || b2 == 16 || b2 == 35 || b2 == 38 || b2 == 69 || b2 == 104 || b2 == 215 || b2 == 83)) {
                                    if (b2 != 84) {
                                        StringBuilder sb = new StringBuilder();
                                        sb.append("Invalid operation for ");
                                        sb.append(this.service);
                                        sb.append(" service");
                                        throw new SmbException(sb.toString());
                                    }
                                }
                            } else if (b != 113) {
                                switch (b) {
                                    case -64:
                                    case -63:
                                    case -62:
                                        break;
                                    default:
                                        switch (b) {
                                            case 45:
                                            case DnsConstants.TYPE_RRSIG /*46*/:
                                            case DnsConstants.TYPE_NSEC /*47*/:
                                                break;
                                            default:
                                                StringBuilder sb2 = new StringBuilder();
                                                sb2.append("Invalid operation for ");
                                                sb2.append(this.service);
                                                sb2.append(" service");
                                                sb2.append(serverMessageBlock);
                                                throw new SmbException(sb2.toString());
                                        }
                                }
                            }
                        }
                    }
                    serverMessageBlock.tid = this.tid;
                    if (this.inDfs && !this.service.equals("IPC") && serverMessageBlock.path != null && serverMessageBlock.path.length() > 0) {
                        serverMessageBlock.flags2 = 4096;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append('\\');
                        sb3.append(this.session.transport().tconHostName);
                        sb3.append('\\');
                        sb3.append(this.share);
                        sb3.append(serverMessageBlock.path);
                        serverMessageBlock.path = sb3.toString();
                    }
                    try {
                        this.session.send(serverMessageBlock, serverMessageBlock2);
                    } catch (SmbException e) {
                        if (e.getNtStatus() == -1073741623) {
                            treeDisconnect(true);
                        }
                        throw e;
                    }
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002a, code lost:
        return;
     */
    public void treeConnect(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        synchronized (this.session.transport()) {
            while (this.connectionState != 0) {
                if (this.connectionState != 2 && this.connectionState != 3) {
                    try {
                        this.session.transport.wait();
                    } catch (SmbException e) {
                        treeDisconnect(true);
                        this.connectionState = 0;
                        throw e;
                    } catch (InterruptedException e2) {
                        throw new SmbException(e2.getMessage(), (Throwable) e2);
                    }
                }
            }
            this.connectionState = 1;
            this.session.transport.connect();
            StringBuilder sb = new StringBuilder();
            sb.append("\\\\");
            sb.append(this.session.transport.tconHostName);
            sb.append('\\');
            sb.append(this.share);
            String sb2 = sb.toString();
            this.service = this.service0;
            SmbComTreeConnectAndXResponse smbComTreeConnectAndXResponse = new SmbComTreeConnectAndXResponse(serverMessageBlock2);
            this.session.send(new SmbComTreeConnectAndX(this.session, sb2, this.service, serverMessageBlock), smbComTreeConnectAndXResponse);
            this.tid = smbComTreeConnectAndXResponse.tid;
            this.service = smbComTreeConnectAndXResponse.service;
            this.inDfs = smbComTreeConnectAndXResponse.shareIsInDfs;
            int i = tree_conn_counter;
            tree_conn_counter = i + 1;
            this.tree_num = i;
            this.connectionState = 2;
        }
    }

    /* access modifiers changed from: 0000 */
    public void treeDisconnect(boolean z) {
        synchronized (this.session.transport()) {
            if (this.connectionState == 2) {
                this.connectionState = 3;
                if (!z && this.tid != 0) {
                    try {
                        send(new SmbComTreeDisconnect(), null);
                    } catch (SmbException unused) {
                    }
                }
                this.inDfs = false;
                this.inDomainDfs = false;
                this.connectionState = 0;
                this.session.transport.notifyAll();
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbTree[share=");
        sb.append(this.share);
        sb.append(",service=");
        sb.append(this.service);
        sb.append(",tid=");
        sb.append(this.tid);
        sb.append(",inDfs=");
        sb.append(this.inDfs);
        sb.append(",inDomainDfs=");
        sb.append(this.inDomainDfs);
        sb.append(",connectionState=");
        sb.append(this.connectionState);
        sb.append("]");
        return sb.toString();
    }
}
