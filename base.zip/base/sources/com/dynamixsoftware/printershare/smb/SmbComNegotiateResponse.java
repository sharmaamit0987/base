package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;
import java.util.Date;

class SmbComNegotiateResponse extends ServerMessageBlock {
    int dialectIndex;
    private ServerData server;

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComNegotiateResponse(ServerData serverData) {
        this.server = serverData;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        int readInt2 = readInt2(bArr, i);
        this.dialectIndex = readInt2;
        int i2 = i + 2;
        if (readInt2 > 10) {
            return i2 - i;
        }
        int i3 = i2 + 1;
        this.server.securityMode = bArr[i2] & Constants.UNKNOWN;
        ServerData serverData = this.server;
        boolean z = true;
        serverData.security = serverData.securityMode & 1;
        ServerData serverData2 = this.server;
        serverData2.encryptedPasswords = (serverData2.securityMode & 2) == 2;
        ServerData serverData3 = this.server;
        serverData3.signaturesEnabled = (serverData3.securityMode & 4) == 4;
        ServerData serverData4 = this.server;
        if ((serverData4.securityMode & 8) != 8) {
            z = false;
        }
        serverData4.signaturesRequired = z;
        this.server.maxMpxCount = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.server.maxNumberVcs = readInt2(bArr, i4);
        int i5 = i4 + 2;
        this.server.maxBufferSize = readInt4(bArr, i5);
        int i6 = i5 + 4;
        this.server.maxRawSize = readInt4(bArr, i6);
        int i7 = i6 + 4;
        this.server.sessionKey = readInt4(bArr, i7);
        int i8 = i7 + 4;
        this.server.capabilities = readInt4(bArr, i8);
        int i9 = i8 + 4;
        this.server.serverTime = readTime(bArr, i9);
        int i10 = i9 + 8;
        this.server.serverTimeZone = readInt2(bArr, i10);
        int i11 = i10 + 2;
        int i12 = i11 + 1;
        this.server.encryptionKeyLength = bArr[i11] & Constants.UNKNOWN;
        return i12 - i;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        int i2;
        int i3 = 0;
        if ((this.server.capabilities & SmbConstants.CAP_EXTENDED_SECURITY) == 0) {
            ServerData serverData = this.server;
            serverData.encryptionKey = new byte[serverData.encryptionKeyLength];
            System.arraycopy(bArr, i, this.server.encryptionKey, 0, this.server.encryptionKeyLength);
            i2 = this.server.encryptionKeyLength + i;
            if (this.byteCount > this.server.encryptionKeyLength) {
                try {
                    String str = "zero termination not found";
                    if ((this.flags2 & 32768) == 32768) {
                        while (true) {
                            int i4 = i2 + i3;
                            if (bArr[i4] == 0) {
                                if (bArr[i4 + 1] == 0) {
                                    this.server.oemDomainName = new String(bArr, i2, i3, SmbConstants.UNI_ENCODING);
                                    break;
                                }
                            }
                            i3 += 2;
                            if (i3 > 256) {
                                throw new RuntimeException(str);
                            }
                        }
                    } else {
                        while (bArr[i2 + i3] != 0) {
                            i3++;
                            if (i3 > 256) {
                                throw new RuntimeException(str);
                            }
                        }
                        this.server.oemDomainName = new String(bArr, i2, i3, SmbConstants.OEM_ENCODING);
                    }
                } catch (UnsupportedEncodingException unused) {
                }
                i2 += i3;
            } else {
                this.server.oemDomainName = new String();
            }
        } else {
            this.server.guid = new byte[16];
            System.arraycopy(bArr, i, this.server.guid, 0, 16);
            this.server.oemDomainName = new String();
            i2 = i;
        }
        return i2 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComNegotiateResponse[");
        sb.append(super.toString());
        sb.append(",wordCount=");
        sb.append(this.wordCount);
        sb.append(",dialectIndex=");
        sb.append(this.dialectIndex);
        sb.append(",securityMode=0x");
        sb.append(Dumper.toHexString(this.server.securityMode, 1));
        sb.append(",security=");
        sb.append(this.server.security == 0 ? "share" : "user");
        sb.append(",encryptedPasswords=");
        sb.append(this.server.encryptedPasswords);
        sb.append(",maxMpxCount=");
        sb.append(this.server.maxMpxCount);
        sb.append(",maxNumberVcs=");
        sb.append(this.server.maxNumberVcs);
        sb.append(",maxBufferSize=");
        sb.append(this.server.maxBufferSize);
        sb.append(",maxRawSize=");
        sb.append(this.server.maxRawSize);
        sb.append(",sessionKey=0x");
        sb.append(Dumper.toHexString(this.server.sessionKey, 8));
        sb.append(",capabilities=0x");
        sb.append(Dumper.toHexString(this.server.capabilities, 8));
        sb.append(",serverTime=");
        sb.append(new Date(this.server.serverTime));
        sb.append(",serverTimeZone=");
        sb.append(this.server.serverTimeZone);
        sb.append(",encryptionKeyLength=");
        sb.append(this.server.encryptionKeyLength);
        sb.append(",byteCount=");
        sb.append(this.byteCount);
        sb.append(",oemDomainName=");
        sb.append(this.server.oemDomainName);
        sb.append("]");
        return new String(sb.toString());
    }
}
