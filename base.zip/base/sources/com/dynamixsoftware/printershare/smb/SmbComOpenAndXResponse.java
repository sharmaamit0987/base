package com.dynamixsoftware.printershare.smb;

class SmbComOpenAndXResponse extends AndXServerMessageBlock {
    private int action;
    private int dataSize;
    private int deviceState;
    int fid;
    private int fileAttributes;
    private int fileType;
    private int grantedAccess;
    private long lastWriteTime;
    private int serverFid;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComOpenAndXResponse() {
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        this.fid = readInt2(bArr, i);
        int i2 = i + 2;
        this.fileAttributes = readInt2(bArr, i2);
        int i3 = i2 + 2;
        this.lastWriteTime = readUTime(bArr, i3);
        int i4 = i3 + 4;
        this.dataSize = readInt4(bArr, i4);
        int i5 = i4 + 4;
        this.grantedAccess = readInt2(bArr, i5);
        int i6 = i5 + 2;
        this.fileType = readInt2(bArr, i6);
        int i7 = i6 + 2;
        this.deviceState = readInt2(bArr, i7);
        int i8 = i7 + 2;
        this.action = readInt2(bArr, i8);
        int i9 = i8 + 2;
        this.serverFid = readInt4(bArr, i9);
        return (i9 + 6) - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComOpenAndXResponse[");
        sb.append(super.toString());
        sb.append(",fid=");
        sb.append(this.fid);
        sb.append(",fileAttributes=");
        sb.append(this.fileAttributes);
        sb.append(",lastWriteTime=");
        sb.append(this.lastWriteTime);
        sb.append(",dataSize=");
        sb.append(this.dataSize);
        sb.append(",grantedAccess=");
        sb.append(this.grantedAccess);
        sb.append(",fileType=");
        sb.append(this.fileType);
        sb.append(",deviceState=");
        sb.append(this.deviceState);
        sb.append(",action=");
        sb.append(this.action);
        sb.append(",serverFid=");
        sb.append(this.serverFid);
        sb.append("]");
        return new String(sb.toString());
    }
}
