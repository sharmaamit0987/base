package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.util.Dumper;

class SmbComNTCreateAndX extends AndXServerMessageBlock {
    private static final int FILE_CREATE = 2;
    private static final int FILE_OPEN = 1;
    private static final int FILE_OPEN_IF = 3;
    private static final int FILE_OVERWRITE = 4;
    private static final int FILE_OVERWRITE_IF = 5;
    private long allocationSize;
    private int createDisposition;
    private int createOptions;
    int desiredAccess;
    private int extFileAttributes;
    int flags0;
    private int impersonationLevel;
    private int namelen_index;
    private int rootDirectoryFid;
    private byte securityFlags;
    private int shareAccess;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComNTCreateAndX(String str, int i, int i2, int i3, int i4, int i5, ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        this.path = str;
        this.command = -94;
        this.desiredAccess = i2;
        this.desiredAccess = i2 | 137;
        this.extFileAttributes = i4;
        this.shareAccess = i3;
        if ((i & 64) == 64) {
            if ((i & 16) == 16) {
                this.createDisposition = 5;
            } else {
                this.createDisposition = 4;
            }
        } else if ((i & 16) != 16) {
            this.createDisposition = 1;
        } else if ((i & 32) == 32) {
            this.createDisposition = 2;
        } else {
            this.createDisposition = 3;
        }
        if ((i5 & 1) == 0) {
            this.createOptions = i5 | 64;
        } else {
            this.createOptions = i5;
        }
        this.impersonationLevel = 2;
        this.securityFlags = 3;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = 0;
        this.namelen_index = i2;
        int i3 = i2 + 2;
        writeInt4((long) this.flags0, bArr, i3);
        int i4 = i3 + 4;
        writeInt4((long) this.rootDirectoryFid, bArr, i4);
        int i5 = i4 + 4;
        writeInt4((long) this.desiredAccess, bArr, i5);
        int i6 = i5 + 4;
        writeInt8(this.allocationSize, bArr, i6);
        int i7 = i6 + 8;
        writeInt4((long) this.extFileAttributes, bArr, i7);
        int i8 = i7 + 4;
        writeInt4((long) this.shareAccess, bArr, i8);
        int i9 = i8 + 4;
        writeInt4((long) this.createDisposition, bArr, i9);
        int i10 = i9 + 4;
        writeInt4((long) this.createOptions, bArr, i10);
        int i11 = i10 + 4;
        writeInt4((long) this.impersonationLevel, bArr, i11);
        int i12 = i11 + 4;
        int i13 = i12 + 1;
        bArr[i12] = this.securityFlags;
        return i13 - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int writeString = writeString(this.path, bArr, i);
        writeInt2((long) (this.useUnicode ? this.path.length() * 2 : writeString), bArr, this.namelen_index);
        return writeString;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComNTCreateAndX[");
        sb.append(super.toString());
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(this.flags0, 2));
        sb.append(",rootDirectoryFid=");
        sb.append(this.rootDirectoryFid);
        sb.append(",desiredAccess=0x");
        sb.append(Dumper.toHexString(this.desiredAccess, 4));
        sb.append(",allocationSize=");
        sb.append(this.allocationSize);
        sb.append(",extFileAttributes=0x");
        sb.append(Dumper.toHexString(this.extFileAttributes, 4));
        sb.append(",shareAccess=0x");
        sb.append(Dumper.toHexString(this.shareAccess, 4));
        sb.append(",createDisposition=0x");
        sb.append(Dumper.toHexString(this.createDisposition, 4));
        sb.append(",createOptions=0x");
        sb.append(Dumper.toHexString(this.createOptions, 8));
        sb.append(",impersonationLevel=0x");
        sb.append(Dumper.toHexString(this.impersonationLevel, 4));
        sb.append(",securityFlags=0x");
        sb.append(Dumper.toHexString(this.securityFlags, 2));
        sb.append(",name=");
        sb.append(this.path);
        sb.append("]");
        return new String(sb.toString());
    }
}
