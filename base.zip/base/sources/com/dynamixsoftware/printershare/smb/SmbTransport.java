package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.mdns.DnsConstants;
import com.dynamixsoftware.printershare.smb.netbios.Name;
import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import com.dynamixsoftware.printershare.smb.netbios.NbtException;
import com.dynamixsoftware.printershare.smb.netbios.SessionRequestPacket;
import com.dynamixsoftware.printershare.smb.util.Encdec;
import com.flurry.android.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.Socket;
import java.util.LinkedList;
import java.util.ListIterator;

class SmbTransport extends Transport implements SmbConstants {
    private static final byte[] BUF = new byte[65535];
    private static final SmbComNegotiate NEGOTIATE_REQUEST = new SmbComNegotiate();
    private UniAddress address;
    int capabilities = 4180;
    SigningDigest digest = null;
    int flags2 = 51203;
    private InputStream in;
    private SmbComBlankResponse key = new SmbComBlankResponse();
    private InetAddress localAddr;
    private int localPort;
    int maxMpxCount = 10;
    private int mid;
    private OutputStream out;
    private int port;
    int rcv_buf_size = 60416;
    private byte[] sbuf = new byte[512];
    ServerData server = new ServerData();
    private long sessionExpiration = (System.currentTimeMillis() + 15000);
    int sessionKey = 0;
    private LinkedList sessions = new LinkedList();
    int snd_buf_size = 16644;
    private Socket socket;
    String tconHostName = null;
    private boolean useUnicode = true;

    class ServerData {
        int capabilities;
        boolean encryptedPasswords;
        byte[] encryptionKey;
        int encryptionKeyLength;
        byte[] guid;
        int maxBufferSize;
        int maxMpxCount;
        int maxNumberVcs;
        int maxRawSize;
        String oemDomainName;
        int security;
        int securityMode;
        long serverTime;
        int serverTimeZone;
        int sessionKey;
        boolean signaturesEnabled;
        boolean signaturesRequired;

        ServerData() {
        }
    }

    static synchronized SmbTransport getSmbTransport(UniAddress uniAddress, int i) {
        SmbTransport smbTransport;
        synchronized (SmbTransport.class) {
            smbTransport = getSmbTransport(uniAddress, i, LADDR, 0, null);
        }
        return smbTransport;
    }

    static synchronized SmbTransport getSmbTransport(UniAddress uniAddress, int i, InetAddress inetAddress, int i2, String str) {
        synchronized (SmbTransport.class) {
            synchronized (CONNECTIONS) {
                ListIterator listIterator = CONNECTIONS.listIterator();
                while (listIterator.hasNext()) {
                    SmbTransport smbTransport = (SmbTransport) listIterator.next();
                    if (smbTransport.matches(uniAddress, i, inetAddress, i2, str) && smbTransport.sessions.size() < 250) {
                        return smbTransport;
                    }
                }
                SmbTransport smbTransport2 = new SmbTransport(uniAddress, i, inetAddress, i2);
                CONNECTIONS.add(0, smbTransport2);
                return smbTransport2;
            }
        }
    }

    private SmbTransport(UniAddress uniAddress, int i, InetAddress inetAddress, int i2) {
        this.address = uniAddress;
        this.port = i;
        this.localAddr = inetAddress;
        this.localPort = i2;
    }

    /* access modifiers changed from: 0000 */
    public synchronized SmbSession getSmbSession(NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        ListIterator listIterator = this.sessions.listIterator();
        while (listIterator.hasNext()) {
            SmbSession smbSession = (SmbSession) listIterator.next();
            if (smbSession.matches(ntlmPasswordAuthentication)) {
                smbSession.auth = ntlmPasswordAuthentication;
                return smbSession;
            }
        }
        long j = this.sessionExpiration;
        long currentTimeMillis = System.currentTimeMillis();
        if (j < currentTimeMillis) {
            this.sessionExpiration = 15000 + currentTimeMillis;
            ListIterator listIterator2 = this.sessions.listIterator();
            while (listIterator2.hasNext()) {
                SmbSession smbSession2 = (SmbSession) listIterator2.next();
                if (smbSession2.expiration < currentTimeMillis) {
                    smbSession2.logoff(false);
                }
            }
        }
        SmbSession smbSession3 = new SmbSession(this.address, this.port, this.localAddr, this.localPort, ntlmPasswordAuthentication);
        smbSession3.transport = this;
        this.sessions.add(smbSession3);
        return smbSession3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0024, code lost:
        if (r2 != 139) goto L_0x0038;
     */
    private boolean matches(UniAddress uniAddress, int i, InetAddress inetAddress, int i2, String str) {
        if (str == null) {
            str = uniAddress.getHostName();
        }
        String str2 = this.tconHostName;
        if ((str2 == null || str.equalsIgnoreCase(str2)) && uniAddress.equals(this.address)) {
            if (i != 0) {
                int i3 = this.port;
                if (i != i3) {
                    if (i == 445) {
                    }
                }
            }
            InetAddress inetAddress2 = this.localAddr;
            if ((inetAddress == inetAddress2 || (inetAddress != null && inetAddress.equals(inetAddress2))) && i2 == this.localPort) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    public boolean hasCapability(int i) throws SmbException {
        try {
            connect(15000);
            return (this.capabilities & i) == i;
        } catch (IOException e) {
            throw new SmbException(e.getMessage(), (Throwable) e);
        }
    }

    /* access modifiers changed from: 0000 */
    public boolean isSignatureSetupRequired(NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        return (this.flags2 & 4) != 0 && this.digest == null && ntlmPasswordAuthentication != NtlmPasswordAuthentication.ANONYMOUS && !NtlmPasswordAuthentication.ANONYMOUS.equals(ntlmPasswordAuthentication);
    }

    private void ssn139() throws IOException {
        String nextCalledName;
        Name name = new Name(this.address.firstCalledName(), 32, null);
        do {
            Socket socket2 = new Socket();
            this.socket = socket2;
            if (this.localAddr != null) {
                socket2.bind(new InetSocketAddress(this.localAddr, this.localPort));
            }
            this.socket.connect(new InetSocketAddress(this.address.getHostAddress(), 139), 15000);
            this.out = this.socket.getOutputStream();
            this.in = this.socket.getInputStream();
            SessionRequestPacket sessionRequestPacket = new SessionRequestPacket(name, NbtAddress.getLocalName());
            OutputStream outputStream = this.out;
            byte[] bArr = this.sbuf;
            outputStream.write(bArr, 0, sessionRequestPacket.writeWireFormat(bArr, 0));
            if (readn(this.in, this.sbuf, 0, 4) >= 4) {
                byte b = this.sbuf[0] & Constants.UNKNOWN;
                if (b == -1) {
                    disconnect(true);
                    throw new NbtException(2, -1);
                } else if (b == 130) {
                    return;
                } else {
                    if (b == 131) {
                        int read = this.in.read() & 255;
                        if (read == 128 || read == 130) {
                            this.socket.close();
                            nextCalledName = this.address.nextCalledName();
                            name.name = nextCalledName;
                        } else {
                            disconnect(true);
                            throw new NbtException(2, read);
                        }
                    } else {
                        disconnect(true);
                        throw new NbtException(2, 0);
                    }
                }
            } else {
                try {
                    this.socket.close();
                } catch (IOException unused) {
                }
                throw new SmbException("EOF during NetBIOS session request");
            }
        } while (nextCalledName != null);
        StringBuilder sb = new StringBuilder();
        sb.append("Failed to establish session with ");
        sb.append(this.address);
        throw new IOException(sb.toString());
    }

    private void negotiate(int i, ServerMessageBlock serverMessageBlock) throws IOException {
        synchronized (this.sbuf) {
            if (i == 139) {
                try {
                    ssn139();
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                if (i == 0) {
                    i = SmbConstants.DEFAULT_PORT;
                }
                Socket socket2 = new Socket();
                this.socket = socket2;
                if (this.localAddr != null) {
                    socket2.bind(new InetSocketAddress(this.localAddr, this.localPort));
                }
                this.socket.connect(new InetSocketAddress(this.address.getHostAddress(), i), 15000);
                this.out = this.socket.getOutputStream();
                this.in = this.socket.getInputStream();
            }
            int i2 = this.mid + 1;
            this.mid = i2;
            if (i2 == 32000) {
                this.mid = 1;
            }
            NEGOTIATE_REQUEST.mid = this.mid;
            int encode = NEGOTIATE_REQUEST.encode(this.sbuf, 4);
            Encdec.enc_uint32be(encode & 65535, this.sbuf, 0);
            this.out.write(this.sbuf, 0, encode + 4);
            this.out.flush();
            if (peekKey() != null) {
                short dec_uint16be = Encdec.dec_uint16be(this.sbuf, 2) & 65535;
                if (dec_uint16be < 33 || dec_uint16be + 4 > this.sbuf.length) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Invalid payload size: ");
                    sb.append(dec_uint16be);
                    throw new IOException(sb.toString());
                }
                readn(this.in, this.sbuf, 36, dec_uint16be - 32);
                serverMessageBlock.decode(this.sbuf, 4);
            } else {
                throw new IOException("transport closed in negotiate");
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void connect() throws SmbException {
        try {
            super.connect(15000);
        } catch (TransportException e) {
            StringBuilder sb = new StringBuilder();
            sb.append("Failed to connect: ");
            sb.append(this.address);
            throw new SmbException(sb.toString(), (Throwable) e);
        }
    }

    /* access modifiers changed from: protected */
    public void doConnect() throws IOException {
        SmbComNegotiateResponse smbComNegotiateResponse = new SmbComNegotiateResponse(this.server);
        int i = 139;
        try {
            negotiate(this.port, smbComNegotiateResponse);
        } catch (ConnectException unused) {
            int i2 = this.port;
            if (!(i2 == 0 || i2 == 445)) {
                i = SmbConstants.DEFAULT_PORT;
            }
            this.port = i;
            negotiate(i, smbComNegotiateResponse);
        } catch (NoRouteToHostException unused2) {
            int i3 = this.port;
            if (!(i3 == 0 || i3 == 445)) {
                i = SmbConstants.DEFAULT_PORT;
            }
            this.port = i;
            negotiate(i, smbComNegotiateResponse);
        }
        if (smbComNegotiateResponse.dialectIndex <= 10) {
            this.tconHostName = this.address.getHostName();
            if (!this.server.signaturesRequired) {
                boolean z = this.server.signaturesEnabled;
                this.flags2 &= 65531;
            } else {
                this.flags2 |= 4;
            }
            int min = Math.min(this.maxMpxCount, this.server.maxMpxCount);
            this.maxMpxCount = min;
            if (min < 1) {
                this.maxMpxCount = 1;
            }
            this.snd_buf_size = Math.min(this.snd_buf_size, this.server.maxBufferSize);
            this.capabilities &= this.server.capabilities;
            if ((this.server.capabilities & SmbConstants.CAP_EXTENDED_SECURITY) == Integer.MIN_VALUE) {
                this.capabilities |= SmbConstants.CAP_EXTENDED_SECURITY;
            }
            if ((this.capabilities & 4) == 0) {
                this.useUnicode = false;
                this.flags2 &= DnsConstants.CLASS_MASK;
                return;
            }
            return;
        }
        throw new SmbException("This client does not support the negotiated dialect.");
    }

    /* access modifiers changed from: protected */
    public void doDisconnect(boolean z) throws IOException {
        ListIterator listIterator = this.sessions.listIterator();
        while (listIterator.hasNext()) {
            try {
                ((SmbSession) listIterator.next()).logoff(z);
            } finally {
                this.digest = null;
                this.socket = null;
                this.tconHostName = null;
            }
        }
        this.socket.shutdownOutput();
        this.out.close();
        this.in.close();
        this.socket.close();
    }

    /* access modifiers changed from: protected */
    public void makeKey(Request request) throws IOException {
        int i = this.mid + 1;
        this.mid = i;
        if (i == 32000) {
            this.mid = 1;
        }
        ((ServerMessageBlock) request).mid = this.mid;
    }

    /* access modifiers changed from: protected */
    public Request peekKey() throws IOException {
        while (readn(this.in, this.sbuf, 0, 4) >= 4) {
            byte[] bArr = this.sbuf;
            if (bArr[0] != -123) {
                if (readn(this.in, bArr, 4, 32) < 32) {
                    return null;
                }
                while (true) {
                    byte[] bArr2 = this.sbuf;
                    if (bArr2[0] == 0 && bArr2[1] == 0 && bArr2[4] == -1 && bArr2[5] == 83 && bArr2[6] == 77 && bArr2[7] == 66) {
                        this.key.mid = Encdec.dec_uint16le(bArr2, 34) & 65535;
                        return this.key;
                    }
                    int i = 0;
                    while (i < 35) {
                        byte[] bArr3 = this.sbuf;
                        int i2 = i + 1;
                        bArr3[i] = bArr3[i2];
                        i = i2;
                    }
                    int read = this.in.read();
                    if (read == -1) {
                        return null;
                    }
                    this.sbuf[35] = (byte) read;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void doSend(Request request) throws IOException {
        synchronized (BUF) {
            int encode = ((ServerMessageBlock) request).encode(BUF, 4);
            Encdec.enc_uint32be(65535 & encode, BUF, 0);
            this.out.write(BUF, 0, encode + 4);
        }
    }

    private void doSend0(Request request) throws IOException {
        try {
            doSend(request);
        } catch (IOException e) {
            try {
                disconnect(true);
            } catch (IOException unused) {
            }
            throw e;
        }
    }

    /* access modifiers changed from: protected */
    public void doRecv(Response response) throws IOException {
        ServerMessageBlock serverMessageBlock = (ServerMessageBlock) response;
        serverMessageBlock.useUnicode = this.useUnicode;
        serverMessageBlock.extendedSecurity = (this.capabilities & SmbConstants.CAP_EXTENDED_SECURITY) == Integer.MIN_VALUE;
        synchronized (BUF) {
            System.arraycopy(this.sbuf, 0, BUF, 0, 36);
            short dec_uint16be = Encdec.dec_uint16be(BUF, 2) & 65535;
            if (dec_uint16be < 33 || dec_uint16be + 4 > this.rcv_buf_size) {
                StringBuilder sb = new StringBuilder();
                sb.append("Invalid payload size: ");
                sb.append(dec_uint16be);
                throw new IOException(sb.toString());
            }
            int dec_uint32le = Encdec.dec_uint32le(BUF, 9) & -1;
            if (serverMessageBlock.command == 46 && (dec_uint32le == 0 || dec_uint32le == -2147483643)) {
                SmbComReadAndXResponse smbComReadAndXResponse = (SmbComReadAndXResponse) serverMessageBlock;
                readn(this.in, BUF, 36, 27);
                serverMessageBlock.decode(BUF, 4);
                int i = smbComReadAndXResponse.dataOffset - 59;
                if (smbComReadAndXResponse.byteCount > 0 && i > 0 && i < 4) {
                    readn(this.in, BUF, 63, i);
                }
                if (smbComReadAndXResponse.dataLength > 0) {
                    readn(this.in, smbComReadAndXResponse.b, smbComReadAndXResponse.off, smbComReadAndXResponse.dataLength);
                }
            } else {
                readn(this.in, BUF, 36, dec_uint16be - 32);
                serverMessageBlock.decode(BUF, 4);
                if (serverMessageBlock instanceof SmbComTransactionResponse) {
                    ((SmbComTransactionResponse) serverMessageBlock).nextElement();
                }
            }
            if (this.digest != null && serverMessageBlock.errorCode == 0) {
                this.digest.verify(BUF, 4, serverMessageBlock);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void doSkip() throws IOException {
        short dec_uint16be = Encdec.dec_uint16be(this.sbuf, 2) & 65535;
        if (dec_uint16be < 33 || dec_uint16be + 4 > this.rcv_buf_size) {
            InputStream inputStream = this.in;
            inputStream.skip((long) inputStream.available());
            return;
        }
        this.in.skip((long) (dec_uint16be - 32));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0036, code lost:
        throw new com.dynamixsoftware.printershare.smb.SmbAuthException(r4.errorCode);
     */
    private void checkStatus(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        serverMessageBlock2.errorCode = SmbException.getStatusByCode(serverMessageBlock2.errorCode);
        int i = serverMessageBlock2.errorCode;
        if (i != 0) {
            switch (i) {
                case -2147483643:
                case NtStatus.NT_STATUS_MORE_PROCESSING_REQUIRED /*-1073741802*/:
                case 0:
                    break;
                case NtStatus.NT_STATUS_ACCESS_DENIED /*-1073741790*/:
                case NtStatus.NT_STATUS_WRONG_PASSWORD /*-1073741718*/:
                case NtStatus.NT_STATUS_TRUSTED_DOMAIN_FAILURE /*-1073741428*/:
                case NtStatus.NT_STATUS_ACCOUNT_LOCKED_OUT /*-1073741260*/:
                    break;
                case NtStatus.NT_STATUS_PATH_NOT_COVERED /*-1073741225*/:
                    if (serverMessageBlock.auth == null) {
                        throw new SmbException(serverMessageBlock2.errorCode, (Throwable) null);
                    }
                    throw new SmbException(serverMessageBlock2.errorCode, (Throwable) null);
                default:
                    switch (i) {
                        case NtStatus.NT_STATUS_LOGON_FAILURE /*-1073741715*/:
                        case NtStatus.NT_STATUS_ACCOUNT_RESTRICTION /*-1073741714*/:
                        case NtStatus.NT_STATUS_INVALID_LOGON_HOURS /*-1073741713*/:
                        case NtStatus.NT_STATUS_INVALID_WORKSTATION /*-1073741712*/:
                        case NtStatus.NT_STATUS_PASSWORD_EXPIRED /*-1073741711*/:
                        case NtStatus.NT_STATUS_ACCOUNT_DISABLED /*-1073741710*/:
                            break;
                        default:
                            throw new SmbException(serverMessageBlock2.errorCode, (Throwable) null);
                    }
            }
        }
        if (serverMessageBlock2.verifyFailed) {
            throw new SmbException("Signature verification failed.");
        }
    }

    /* access modifiers changed from: 0000 */
    public void send(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        connect();
        serverMessageBlock.flags2 |= this.flags2;
        serverMessageBlock.useUnicode = this.useUnicode;
        serverMessageBlock.response = serverMessageBlock2;
        if (serverMessageBlock.digest == null) {
            serverMessageBlock.digest = this.digest;
        }
        if (serverMessageBlock2 == null) {
            try {
                doSend0(serverMessageBlock);
            } catch (SmbException e) {
                throw e;
            } catch (IOException e2) {
                throw new SmbException(e2.getMessage(), (Throwable) e2);
            }
        } else {
            long j = 15000;
            if (serverMessageBlock instanceof SmbComTransaction) {
                serverMessageBlock2.command = serverMessageBlock.command;
                SmbComTransaction smbComTransaction = (SmbComTransaction) serverMessageBlock;
                SmbComTransactionResponse smbComTransactionResponse = (SmbComTransactionResponse) serverMessageBlock2;
                smbComTransaction.maxBufferSize = this.snd_buf_size;
                smbComTransactionResponse.reset();
                try {
                    BufferCache.getBuffers(smbComTransaction, smbComTransactionResponse);
                    smbComTransaction.nextElement();
                    if (smbComTransaction.hasMoreElements()) {
                        SmbComBlankResponse smbComBlankResponse = new SmbComBlankResponse();
                        super.sendrecv(smbComTransaction, smbComBlankResponse, 15000);
                        if (smbComBlankResponse.errorCode != 0) {
                            checkStatus(smbComTransaction, smbComBlankResponse);
                        }
                        smbComTransaction.nextElement();
                    } else {
                        makeKey(smbComTransaction);
                    }
                    synchronized (this) {
                        serverMessageBlock2.received = false;
                        smbComTransactionResponse.isReceived = false;
                        try {
                            this.response_map.put(smbComTransaction, smbComTransactionResponse);
                            do {
                                doSend0(smbComTransaction);
                                if (!smbComTransaction.hasMoreElements()) {
                                    break;
                                }
                            } while (smbComTransaction.nextElement() != null);
                            smbComTransactionResponse.expiration = System.currentTimeMillis() + 15000;
                            while (smbComTransactionResponse.hasMoreElements()) {
                                wait(j);
                                j = smbComTransactionResponse.expiration - System.currentTimeMillis();
                                if (j <= 0) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(this);
                                    sb.append(" timedout waiting for response to ");
                                    sb.append(smbComTransaction);
                                    throw new TransportException(sb.toString());
                                }
                            }
                            if (serverMessageBlock2.errorCode != 0) {
                                checkStatus(smbComTransaction, smbComTransactionResponse);
                            }
                            this.response_map.remove(smbComTransaction);
                        } catch (InterruptedException e3) {
                            throw new TransportException((Throwable) e3);
                        } catch (Throwable th) {
                            this.response_map.remove(smbComTransaction);
                            throw th;
                        }
                    }
                } finally {
                    BufferCache.releaseBuffer(smbComTransaction.txn_buf);
                    BufferCache.releaseBuffer(smbComTransactionResponse.txn_buf);
                }
            } else {
                serverMessageBlock2.command = serverMessageBlock.command;
                super.sendrecv(serverMessageBlock, serverMessageBlock2, 15000);
            }
            checkStatus(serverMessageBlock, serverMessageBlock2);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[");
        sb.append(this.address);
        sb.append(":");
        sb.append(this.port);
        sb.append("]");
        return sb.toString();
    }
}
