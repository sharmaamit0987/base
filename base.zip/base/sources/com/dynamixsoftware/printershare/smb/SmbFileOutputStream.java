package com.dynamixsoftware.printershare.smb;

import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

public class SmbFileOutputStream extends OutputStream {
    private int access;
    private boolean append;
    private SmbFile file;
    private long fp;
    private int openFlags;
    private SmbComWrite req;
    private SmbComWriteAndX reqx;
    private SmbComWriteResponse rsp;
    private SmbComWriteAndXResponse rspx;
    private byte[] tmp = new byte[1];
    private boolean useNTSmbs;
    private int writeSize;

    SmbFileOutputStream(SmbFile smbFile, boolean z, int i) throws SmbException, MalformedURLException, UnknownHostException {
        this.file = smbFile;
        this.append = z;
        this.openFlags = i;
        this.access = (i >>> 16) & 65535;
        if (z) {
            this.fp = 0;
        }
        if ((smbFile instanceof SmbNamedPipe) && smbFile.unc.startsWith("\\pipe\\")) {
            smbFile.unc = smbFile.unc.substring(5);
            StringBuilder sb = new StringBuilder();
            sb.append("\\pipe");
            sb.append(smbFile.unc);
            smbFile.send(new TransWaitNamedPipe(sb.toString()), new TransWaitNamedPipeResponse());
        }
        smbFile.open(i, this.access | 2, 128, 0);
        this.openFlags &= -81;
        this.writeSize = smbFile.tree.session.transport.snd_buf_size - 70;
        boolean hasCapability = smbFile.tree.session.transport.hasCapability(16);
        this.useNTSmbs = hasCapability;
        if (hasCapability) {
            this.reqx = new SmbComWriteAndX();
            this.rspx = new SmbComWriteAndXResponse();
            return;
        }
        this.req = new SmbComWrite();
        this.rsp = new SmbComWriteResponse();
    }

    public void close() throws IOException {
        this.file.close();
        this.tmp = null;
    }

    public void write(int i) throws IOException {
        byte[] bArr = this.tmp;
        bArr[0] = (byte) i;
        write(bArr, 0, 1);
    }

    public void write(byte[] bArr) throws IOException {
        write(bArr, 0, bArr.length);
    }

    public boolean isOpen() {
        return this.file.isOpen();
    }

    /* access modifiers changed from: 0000 */
    public void ensureOpen() throws IOException {
        if (!this.file.isOpen()) {
            this.file.open(this.openFlags, this.access | 2, 128, 0);
            if (this.append) {
                this.fp = 0;
            }
        }
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        if (!this.file.isOpen()) {
            SmbFile smbFile = this.file;
            if (smbFile instanceof SmbNamedPipe) {
                StringBuilder sb = new StringBuilder();
                sb.append("\\pipe");
                sb.append(this.file.unc);
                smbFile.send(new TransWaitNamedPipe(sb.toString()), new TransWaitNamedPipeResponse());
            }
        }
        writeDirect(bArr, i, i2, 0);
    }

    public void writeDirect(byte[] bArr, int i, int i2, int i3) throws IOException {
        if (i2 > 0) {
            if (this.tmp != null) {
                ensureOpen();
                do {
                    int i4 = this.writeSize;
                    if (i2 <= i4) {
                        i4 = i2;
                    }
                    if (this.useNTSmbs) {
                        this.reqx.setParam(this.file.fid, this.fp, i2 - i4, bArr, i, i4);
                        if ((i3 & 1) != 0) {
                            this.reqx.setParam(this.file.fid, this.fp, i2, bArr, i, i4);
                            this.reqx.writeMode = 8;
                        } else {
                            this.reqx.writeMode = 0;
                        }
                        this.file.send(this.reqx, this.rspx);
                        this.fp += this.rspx.count;
                        i2 = (int) (((long) i2) - this.rspx.count);
                        i = (int) (((long) i) + this.rspx.count);
                        continue;
                    } else {
                        this.req.setParam(this.file.fid, this.fp, i2 - i4, bArr, i, i4);
                        this.fp += this.rsp.count;
                        i2 = (int) (((long) i2) - this.rsp.count);
                        i = (int) (((long) i) + this.rsp.count);
                        this.file.send(this.req, this.rsp);
                        continue;
                    }
                } while (i2 > 0);
                return;
            }
            throw new IOException("Bad file descriptor");
        }
    }
}
