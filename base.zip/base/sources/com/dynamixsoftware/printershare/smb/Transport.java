package com.dynamixsoftware.printershare.smb;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

abstract class Transport implements Runnable {
    private static int id;
    private String name;
    protected HashMap<Request, Response> response_map;
    private int state = 0;
    private TransportException te;
    private Thread thread;

    /* access modifiers changed from: protected */
    public abstract void doConnect() throws Exception;

    /* access modifiers changed from: protected */
    public abstract void doDisconnect(boolean z) throws IOException;

    /* access modifiers changed from: protected */
    public abstract void doRecv(Response response) throws IOException;

    /* access modifiers changed from: protected */
    public abstract void doSend(Request request) throws IOException;

    /* access modifiers changed from: protected */
    public abstract void doSkip() throws IOException;

    /* access modifiers changed from: protected */
    public abstract void makeKey(Request request) throws IOException;

    /* access modifiers changed from: protected */
    public abstract Request peekKey() throws IOException;

    Transport() {
        StringBuilder sb = new StringBuilder();
        sb.append("Transport");
        int i = id;
        id = i + 1;
        sb.append(i);
        this.name = sb.toString();
        this.response_map = new HashMap<>(4);
    }

    static int readn(InputStream inputStream, byte[] bArr, int i, int i2) throws IOException {
        int i3 = 0;
        while (i3 < i2) {
            int read = inputStream.read(bArr, i + i3, i2 - i3);
            if (read <= 0) {
                break;
            }
            i3 += read;
        }
        return i3;
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Can't wrap try/catch for region: R(6:21|22|23|24|25|26) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x005c */
    public synchronized void sendrecv(Request request, Response response, long j) throws IOException {
        makeKey(request);
        response.isReceived = false;
        try {
            this.response_map.put(request, response);
            doSend(request);
            response.expiration = System.currentTimeMillis() + j;
            while (!response.isReceived) {
                wait(j);
                j = response.expiration - System.currentTimeMillis();
                if (j <= 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(this.name);
                    sb.append(" timedout waiting for response to ");
                    sb.append(request);
                    throw new TransportException(sb.toString());
                }
            }
            this.response_map.remove(request);
        } catch (IOException e) {
            disconnect(true);
            throw e;
        } catch (InterruptedException e2) {
            throw new TransportException((Throwable) e2);
        } catch (Throwable th) {
            this.response_map.remove(request);
            throw th;
        }
    }

    private void loop() {
        while (this.thread == Thread.currentThread()) {
            try {
                Request peekKey = peekKey();
                if (peekKey != null) {
                    synchronized (this) {
                        Response response = (Response) this.response_map.get(peekKey);
                        if (response == null) {
                            doSkip();
                        } else {
                            doRecv(response);
                            response.isReceived = true;
                            notifyAll();
                        }
                    }
                } else {
                    throw new IOException("end of stream");
                }
            } catch (Exception e) {
                String message = e.getMessage();
                try {
                    disconnect(true ^ (message != null && message.equals("Read timed out")));
                } catch (IOException unused) {
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0045, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0071, code lost:
        if (r7.state == 0) goto L_0x007f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0075, code lost:
        if (r7.state == 3) goto L_0x007f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0079, code lost:
        if (r7.state == 4) goto L_0x007f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x007b, code lost:
        r7.state = 0;
        r7.thread = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x0080, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0088, code lost:
        if (3 == 0) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x008a, code lost:
        if (3 == 3) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x008c, code lost:
        if (3 == 4) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:?, code lost:
        r7.state = 0;
        r7.thread = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0093, code lost:
        return;
     */
    public synchronized void connect(long j) throws TransportException {
        try {
            int i = this.state;
            if (i == 0) {
                this.state = 1;
                this.te = null;
                Thread thread2 = new Thread(this, this.name);
                this.thread = thread2;
                thread2.setDaemon(true);
                synchronized (this.thread) {
                    this.thread.start();
                    this.thread.wait(j);
                    int i2 = this.state;
                    if (i2 == 1) {
                        this.state = 0;
                        this.thread = null;
                        throw new TransportException("Connection timeout");
                    } else if (i2 == 2) {
                        if (this.te == null) {
                            this.state = 3;
                        } else {
                            this.state = 4;
                            this.thread = null;
                            throw this.te;
                        }
                    }
                }
            } else if (i != 3) {
                if (i != 4) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Invalid state: ");
                    sb.append(this.state);
                    TransportException transportException = new TransportException(sb.toString());
                    this.state = 0;
                    throw transportException;
                }
                this.state = 0;
                throw new TransportException("Connection in error", this.te);
            } else if (!(this.state == 0 || this.state == 3 || this.state == 4)) {
                this.state = 0;
                this.thread = null;
            }
        } catch (InterruptedException e) {
            try {
                this.state = 0;
                this.thread = null;
                throw new TransportException((Throwable) e);
            } catch (Throwable th) {
                if (!(this.state == 0 || this.state == 3 || this.state == 4)) {
                    this.state = 0;
                    this.thread = null;
                }
                throw th;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x002e A[DONT_GENERATE] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0030 A[SYNTHETIC, Splitter:B:25:0x0030] */
    public synchronized void disconnect(boolean z) throws IOException {
        Throwable e;
        int i = this.state;
        if (i != 0) {
            Throwable th = null;
            if (i == 2) {
                z = true;
            } else if (i != 3) {
                if (i != 4) {
                    this.thread = null;
                    this.state = 0;
                    if (th != null) {
                        throw th;
                    }
                    return;
                }
                e = null;
                this.thread = null;
                this.state = 0;
                th = e;
                if (th != null) {
                }
            }
            if (this.response_map.size() == 0 || z) {
                try {
                    doDisconnect(z);
                    e = null;
                } catch (IOException e2) {
                    e = e2;
                }
                this.thread = null;
                this.state = 0;
                th = e;
            }
            if (th != null) {
            }
        }
    }

    public void run() {
        Thread currentThread = Thread.currentThread();
        try {
            doConnect();
            synchronized (currentThread) {
                if (currentThread == this.thread) {
                    this.state = 2;
                    currentThread.notify();
                    loop();
                }
            }
        } catch (Exception e) {
            synchronized (currentThread) {
                if (currentThread == this.thread) {
                    this.te = new TransportException((Throwable) e);
                    this.state = 2;
                    currentThread.notify();
                }
            }
        } catch (Throwable th) {
            synchronized (currentThread) {
                if (currentThread == this.thread) {
                    this.state = 2;
                    currentThread.notify();
                    throw th;
                }
            }
        }
    }

    public String toString() {
        return this.name;
    }
}
