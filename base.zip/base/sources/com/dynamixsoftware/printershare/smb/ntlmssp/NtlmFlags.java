package com.dynamixsoftware.printershare.smb.ntlmssp;

public interface NtlmFlags {
    public static final int NTLMSSP_NEGOTIATE_128 = 536870912;
    public static final int NTLMSSP_NEGOTIATE_ALWAYS_SIGN = 32768;
    public static final int NTLMSSP_NEGOTIATE_KEY_EXCH = 1073741824;
    public static final int NTLMSSP_NEGOTIATE_NTLM = 512;
    public static final int NTLMSSP_NEGOTIATE_NTLM2 = 524288;
    public static final int NTLMSSP_NEGOTIATE_OEM = 2;
    public static final int NTLMSSP_NEGOTIATE_OEM_DOMAIN_SUPPLIED = 4096;
    public static final int NTLMSSP_NEGOTIATE_OEM_WORKSTATION_SUPPLIED = 8192;
    public static final int NTLMSSP_NEGOTIATE_SIGN = 16;
    public static final int NTLMSSP_NEGOTIATE_TARGET_INFO = 8388608;
    public static final int NTLMSSP_NEGOTIATE_UNICODE = 1;
    public static final int NTLMSSP_REQUEST_TARGET = 4;
}
