package com.dynamixsoftware.printershare.smb.ntlmssp;

import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.io.IOException;
import java.net.UnknownHostException;

public class Type2Message extends NtlmMessage {
    private static final String DEFAULT_DOMAIN = null;
    private static final int DEFAULT_FLAGS = 513;
    private static final byte[] DEFAULT_TARGET_INFORMATION;
    private byte[] challenge;
    private byte[] context;
    private String target;
    private byte[] targetInformation;

    public /* bridge */ /* synthetic */ int getFlags() {
        return super.getFlags();
    }

    public /* bridge */ /* synthetic */ void setFlags(int i) {
        super.setFlags(i);
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    static {
        int i;
        byte[] bArr = new byte[0];
        String str = SmbConstants.UNI_ENCODING;
        String str2 = null;
        if (str2 != null) {
            try {
                bArr = str2.getBytes(str);
            } catch (IOException unused) {
            }
        }
        int length = bArr.length;
        byte[] bArr2 = new byte[0];
        String hostName = NbtAddress.getLocalHost().getHostName();
        if (hostName != null) {
            try {
                bArr2 = hostName.getBytes(str);
            } catch (UnknownHostException unused2) {
            }
        }
        int length2 = bArr2.length;
        byte[] bArr3 = new byte[((length > 0 ? length + 4 : 0) + (length2 > 0 ? length2 + 4 : 0) + 4)];
        if (length > 0) {
            writeUShort(bArr3, 0, 2);
            writeUShort(bArr3, 2, length);
            System.arraycopy(bArr, 0, bArr3, 4, length);
            i = 4 + length;
        } else {
            i = 0;
        }
        if (length2 > 0) {
            writeUShort(bArr3, i, 1);
            int i2 = i + 2;
            writeUShort(bArr3, i2, length2);
            System.arraycopy(bArr2, 0, bArr3, i2 + 2, length2);
        }
        DEFAULT_TARGET_INFORMATION = bArr3;
    }

    public Type2Message() {
        this(getDefaultFlags(), null, null);
    }

    private Type2Message(int i, byte[] bArr, String str) {
        setFlags(i);
        setChallenge(bArr);
        setTarget(str);
        if (str != null) {
            setTargetInformation(getDefaultTargetInformation());
        }
    }

    public Type2Message(byte[] bArr) throws IOException {
        parse(bArr);
    }

    public byte[] getChallenge() {
        return this.challenge;
    }

    public void setChallenge(byte[] bArr) {
        this.challenge = bArr;
    }

    public String getTarget() {
        return this.target;
    }

    public void setTarget(String str) {
        this.target = str;
    }

    public byte[] getTargetInformation() {
        return this.targetInformation;
    }

    public void setTargetInformation(byte[] bArr) {
        this.targetInformation = bArr;
    }

    public byte[] getContext() {
        return this.context;
    }

    public void setContext(byte[] bArr) {
        this.context = bArr;
    }

    public byte[] toByteArray() {
        byte[] bArr;
        try {
            String target2 = getTarget();
            byte[] challenge2 = getChallenge();
            byte[] context2 = getContext();
            byte[] targetInformation2 = getTargetInformation();
            int flags = getFlags();
            byte[] bArr2 = new byte[0];
            if ((flags & 4) != 0) {
                if (target2 == null || target2.length() == 0) {
                    flags &= -5;
                } else {
                    if ((flags & 1) != 0) {
                        bArr = target2.getBytes(SmbConstants.UNI_ENCODING);
                    } else {
                        bArr = target2.toUpperCase().getBytes(getOEMEncoding());
                    }
                    bArr2 = bArr;
                }
            }
            if (targetInformation2 != null) {
                flags |= NtlmFlags.NTLMSSP_NEGOTIATE_TARGET_INFO;
                if (context2 == null) {
                    context2 = new byte[8];
                }
            }
            int i = context2 != null ? 40 : 32;
            if (targetInformation2 != null) {
                i += 8;
            }
            byte[] bArr3 = new byte[(bArr2.length + i + (targetInformation2 != null ? targetInformation2.length : 0))];
            System.arraycopy(NTLMSSP_SIGNATURE, 0, bArr3, 0, 8);
            writeULong(bArr3, 8, 2);
            writeSecurityBuffer(bArr3, 12, i, bArr2);
            writeULong(bArr3, 20, flags);
            if (challenge2 == null) {
                challenge2 = new byte[8];
            }
            System.arraycopy(challenge2, 0, bArr3, 24, 8);
            if (context2 != null) {
                System.arraycopy(context2, 0, bArr3, 32, 8);
            }
            if (targetInformation2 != null) {
                writeSecurityBuffer(bArr3, 40, i + bArr2.length, targetInformation2);
            }
            return bArr3;
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    public String toString() {
        String str;
        String str2;
        String target2 = getTarget();
        byte[] challenge2 = getChallenge();
        byte[] context2 = getContext();
        byte[] targetInformation2 = getTargetInformation();
        StringBuilder sb = new StringBuilder();
        sb.append("Type2Message[target=");
        sb.append(target2);
        sb.append(",challenge=");
        String str3 = "null";
        String str4 = " bytes>";
        String str5 = "<";
        if (challenge2 == null) {
            str = str3;
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str5);
            sb2.append(challenge2.length);
            sb2.append(str4);
            str = sb2.toString();
        }
        sb.append(str);
        sb.append(",context=");
        if (context2 == null) {
            str2 = str3;
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str5);
            sb3.append(context2.length);
            sb3.append(str4);
            str2 = sb3.toString();
        }
        sb.append(str2);
        sb.append(",targetInformation=");
        if (targetInformation2 != null) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str5);
            sb4.append(targetInformation2.length);
            sb4.append(str4);
            str3 = sb4.toString();
        }
        sb.append(str3);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(getFlags(), 8));
        sb.append("]");
        return sb.toString();
    }

    private static int getDefaultFlags() {
        return DEFAULT_FLAGS;
    }

    private static byte[] getDefaultTargetInformation() {
        return DEFAULT_TARGET_INFORMATION;
    }

    private void parse(byte[] bArr) throws IOException {
        String str;
        int i = 0;
        while (i < 8) {
            if (bArr[i] == NTLMSSP_SIGNATURE[i]) {
                i++;
            } else {
                throw new IOException("Not an NTLMSSP message.");
            }
        }
        if (readULong(bArr, 8) == 2) {
            int readULong = readULong(bArr, 20);
            setFlags(readULong);
            String str2 = null;
            byte[] readSecurityBuffer = readSecurityBuffer(bArr, 12);
            if (readSecurityBuffer.length != 0) {
                if ((readULong & 1) != 0) {
                    str = SmbConstants.UNI_ENCODING;
                } else {
                    str = getOEMEncoding();
                }
                str2 = new String(readSecurityBuffer, str);
            }
            setTarget(str2);
            int i2 = 24;
            while (true) {
                if (i2 >= 32) {
                    break;
                } else if (bArr[i2] != 0) {
                    byte[] bArr2 = new byte[8];
                    System.arraycopy(bArr, 24, bArr2, 0, 8);
                    setChallenge(bArr2);
                    break;
                } else {
                    i2++;
                }
            }
            int readULong2 = readULong(bArr, 16);
            if (readULong2 != 32 && bArr.length != 32) {
                int i3 = 32;
                while (true) {
                    if (i3 >= 40) {
                        break;
                    } else if (bArr[i3] != 0) {
                        byte[] bArr3 = new byte[8];
                        System.arraycopy(bArr, 32, bArr3, 0, 8);
                        setContext(bArr3);
                        break;
                    } else {
                        i3++;
                    }
                }
                if (readULong2 != 40 && bArr.length != 40) {
                    byte[] readSecurityBuffer2 = readSecurityBuffer(bArr, 40);
                    if (readSecurityBuffer2.length != 0) {
                        setTargetInformation(readSecurityBuffer2);
                        return;
                    }
                    return;
                }
                return;
            }
            return;
        }
        throw new IOException("Not a Type 2 message.");
    }
}
