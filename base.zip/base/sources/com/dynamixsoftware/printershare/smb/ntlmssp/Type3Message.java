package com.dynamixsoftware.printershare.smb.ntlmssp;

import com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication;
import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import com.dynamixsoftware.printershare.smb.util.HMACT64;
import com.dynamixsoftware.printershare.smb.util.MD4;
import com.dynamixsoftware.printershare.smb.util.RC4;
import java.io.IOException;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.Arrays;

public class Type3Message extends NtlmMessage {
    private static final String DEFAULT_DOMAIN = null;
    private static final int DEFAULT_FLAGS = 513;
    private static final String DEFAULT_USER = null;
    private static final String DEFAULT_WORKSTATION;
    private static final int LM_COMPATIBILITY = 3;
    private static final long MILLISECONDS_BETWEEN_1970_AND_1601 = 11644473600000L;
    private static final SecureRandom RANDOM = new SecureRandom();
    private String domain;
    private byte[] lmResponse;
    private byte[] masterKey = null;
    private byte[] ntResponse;
    private byte[] sessionKey = null;
    private String user;
    private String workstation;

    public /* bridge */ /* synthetic */ int getFlags() {
        return super.getFlags();
    }

    public /* bridge */ /* synthetic */ void setFlags(int i) {
        super.setFlags(i);
    }

    static {
        String str = null;
        try {
            str = NbtAddress.getLocalHost().getHostName();
        } catch (UnknownHostException unused) {
        }
        DEFAULT_WORKSTATION = str;
    }

    public Type3Message() {
        setFlags(getDefaultFlags());
        setDomain(getDefaultDomain());
        setUser(getDefaultUser());
        setWorkstation(getDefaultWorkstation());
    }

    public Type3Message(Type2Message type2Message, String str, String str2, String str3, String str4, int i) {
        setFlags(i | getDefaultFlags(type2Message));
        if (str4 == null) {
            str4 = getDefaultWorkstation();
        }
        setWorkstation(str4);
        setDomain(str2);
        setUser(str3);
        int i2 = LM_COMPATIBILITY;
        if (i2 == 0 || i2 == 1) {
            if ((getFlags() & NtlmFlags.NTLMSSP_NEGOTIATE_NTLM2) == 0) {
                setLMResponse(getLMResponse(type2Message, str));
                setNTResponse(getNTResponse(type2Message, str));
                return;
            }
            byte[] bArr = new byte[24];
            RANDOM.nextBytes(bArr);
            Arrays.fill(bArr, 8, 24, 0);
            byte[] nTOWFv1 = NtlmPasswordAuthentication.nTOWFv1(str);
            byte[] nTLM2Response = NtlmPasswordAuthentication.getNTLM2Response(nTOWFv1, type2Message.getChallenge(), bArr);
            setLMResponse(bArr);
            setNTResponse(nTLM2Response);
            if ((getFlags() & 16) == 16) {
                byte[] bArr2 = new byte[16];
                System.arraycopy(type2Message.getChallenge(), 0, bArr2, 0, 8);
                System.arraycopy(bArr, 0, bArr2, 8, 8);
                MD4 md4 = new MD4();
                md4.update(nTOWFv1);
                HMACT64 hmact64 = new HMACT64(md4.digest());
                hmact64.update(bArr2);
                byte[] digest = hmact64.digest();
                if ((getFlags() & NtlmFlags.NTLMSSP_NEGOTIATE_KEY_EXCH) != 0) {
                    byte[] bArr3 = new byte[16];
                    this.masterKey = bArr3;
                    RANDOM.nextBytes(bArr3);
                    byte[] bArr4 = new byte[16];
                    new RC4(digest).update(this.masterKey, 0, 16, bArr4, 0);
                    setSessionKey(bArr4);
                    return;
                }
                this.masterKey = digest;
                setSessionKey(digest);
            }
        } else if (i2 == 2) {
            byte[] nTResponse = getNTResponse(type2Message, str);
            setLMResponse(nTResponse);
            setNTResponse(nTResponse);
        } else if (i2 == 3 || i2 == 4 || i2 == 5) {
            byte[] nTOWFv2 = NtlmPasswordAuthentication.nTOWFv2(str2, str3, str);
            byte[] bArr5 = new byte[8];
            RANDOM.nextBytes(bArr5);
            setLMResponse(getLMv2Response(type2Message, str2, str3, str, bArr5));
            byte[] bArr6 = new byte[8];
            RANDOM.nextBytes(bArr6);
            setNTResponse(getNTLMv2Response(type2Message, nTOWFv2, bArr6));
            if ((getFlags() & 16) == 16) {
                HMACT64 hmact642 = new HMACT64(nTOWFv2);
                hmact642.update(this.ntResponse, 0, 16);
                byte[] digest2 = hmact642.digest();
                if ((getFlags() & NtlmFlags.NTLMSSP_NEGOTIATE_KEY_EXCH) != 0) {
                    byte[] bArr7 = new byte[16];
                    this.masterKey = bArr7;
                    RANDOM.nextBytes(bArr7);
                    byte[] bArr8 = new byte[16];
                    new RC4(digest2).update(this.masterKey, 0, 16, bArr8, 0);
                    setSessionKey(bArr8);
                    return;
                }
                this.masterKey = digest2;
                setSessionKey(digest2);
            }
        } else {
            setLMResponse(getLMResponse(type2Message, str));
            setNTResponse(getNTResponse(type2Message, str));
        }
    }

    public byte[] getLMResponse() {
        return this.lmResponse;
    }

    public void setLMResponse(byte[] bArr) {
        this.lmResponse = bArr;
    }

    public byte[] getNTResponse() {
        return this.ntResponse;
    }

    public void setNTResponse(byte[] bArr) {
        this.ntResponse = bArr;
    }

    public String getDomain() {
        return this.domain;
    }

    public void setDomain(String str) {
        this.domain = str;
    }

    public String getUser() {
        return this.user;
    }

    public void setUser(String str) {
        this.user = str;
    }

    public String getWorkstation() {
        return this.workstation;
    }

    public void setWorkstation(String str) {
        this.workstation = str;
    }

    public byte[] getMasterKey() {
        return this.masterKey;
    }

    public byte[] getSessionKey() {
        return this.sessionKey;
    }

    public void setSessionKey(byte[] bArr) {
        this.sessionKey = bArr;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0032 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0034 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0054 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0056 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0065 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x006a A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0075 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0077 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x007e A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0080 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0087 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0089 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0090 A[Catch:{ IOException -> 0x00d2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0092 A[Catch:{ IOException -> 0x00d2 }] */
    public byte[] toByteArray() {
        String str;
        byte[] bArr;
        byte[] bArr2;
        try {
            int flags = getFlags();
            boolean z = (flags & 1) != 0;
            byte[] bArr3 = null;
            if (z) {
                str = null;
            } else {
                str = getOEMEncoding();
            }
            String domain2 = getDomain();
            String str2 = SmbConstants.UNI_ENCODING;
            if (domain2 != null) {
                if (domain2.length() != 0) {
                    bArr = z ? domain2.getBytes(str2) : domain2.getBytes(str);
                    int length = bArr == null ? bArr.length : 0;
                    String user2 = getUser();
                    byte[] bArr4 = (user2 != null || user2.length() == 0) ? null : z ? user2.getBytes(str2) : user2.toUpperCase().getBytes(str);
                    int length2 = bArr4 == null ? bArr4.length : 0;
                    String workstation2 = getWorkstation();
                    if (!(workstation2 == null || workstation2.length() == 0)) {
                        if (!z) {
                            bArr2 = workstation2.getBytes(str2);
                        } else {
                            bArr2 = workstation2.toUpperCase().getBytes(str);
                        }
                        bArr3 = bArr2;
                    }
                    int length3 = bArr3 == null ? bArr3.length : 0;
                    byte[] lMResponse = getLMResponse();
                    int length4 = lMResponse == null ? lMResponse.length : 0;
                    byte[] nTResponse = getNTResponse();
                    int length5 = nTResponse == null ? nTResponse.length : 0;
                    byte[] sessionKey2 = getSessionKey();
                    byte[] bArr5 = new byte[(length + 64 + length2 + length3 + length4 + length5 + (sessionKey2 == null ? sessionKey2.length : 0))];
                    System.arraycopy(NTLMSSP_SIGNATURE, 0, bArr5, 0, 8);
                    writeULong(bArr5, 8, 3);
                    writeSecurityBuffer(bArr5, 12, 64, lMResponse);
                    int i = length4 + 64;
                    writeSecurityBuffer(bArr5, 20, i, nTResponse);
                    int i2 = i + length5;
                    writeSecurityBuffer(bArr5, 28, i2, bArr);
                    int i3 = i2 + length;
                    writeSecurityBuffer(bArr5, 36, i3, bArr4);
                    int i4 = i3 + length2;
                    writeSecurityBuffer(bArr5, 44, i4, bArr3);
                    writeSecurityBuffer(bArr5, 52, i4 + length3, sessionKey2);
                    writeULong(bArr5, 60, flags);
                    return bArr5;
                }
            }
            bArr = null;
            if (bArr == null) {
            }
            String user22 = getUser();
            if (user22 != null) {
            }
            if (bArr4 == null) {
            }
            String workstation22 = getWorkstation();
            if (!z) {
            }
            bArr3 = bArr2;
            if (bArr3 == null) {
            }
            byte[] lMResponse2 = getLMResponse();
            if (lMResponse2 == null) {
            }
            byte[] nTResponse2 = getNTResponse();
            if (nTResponse2 == null) {
            }
            byte[] sessionKey22 = getSessionKey();
            byte[] bArr52 = new byte[(length + 64 + length2 + length3 + length4 + length5 + (sessionKey22 == null ? sessionKey22.length : 0))];
            System.arraycopy(NTLMSSP_SIGNATURE, 0, bArr52, 0, 8);
            writeULong(bArr52, 8, 3);
            writeSecurityBuffer(bArr52, 12, 64, lMResponse2);
            int i5 = length4 + 64;
            writeSecurityBuffer(bArr52, 20, i5, nTResponse2);
            int i22 = i5 + length5;
            writeSecurityBuffer(bArr52, 28, i22, bArr);
            int i32 = i22 + length;
            writeSecurityBuffer(bArr52, 36, i32, bArr4);
            int i42 = i32 + length2;
            writeSecurityBuffer(bArr52, 44, i42, bArr3);
            writeSecurityBuffer(bArr52, 52, i42 + length3, sessionKey22);
            writeULong(bArr52, 60, flags);
            return bArr52;
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    public String toString() {
        String str;
        String str2;
        String user2 = getUser();
        String domain2 = getDomain();
        String workstation2 = getWorkstation();
        byte[] lMResponse = getLMResponse();
        byte[] nTResponse = getNTResponse();
        byte[] sessionKey2 = getSessionKey();
        StringBuilder sb = new StringBuilder();
        sb.append("Type3Message[domain=");
        sb.append(domain2);
        sb.append(",user=");
        sb.append(user2);
        sb.append(",workstation=");
        sb.append(workstation2);
        sb.append(",lmResponse=");
        String str3 = "null";
        String str4 = " bytes>";
        String str5 = "<";
        if (lMResponse == null) {
            str = str3;
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str5);
            sb2.append(lMResponse.length);
            sb2.append(str4);
            str = sb2.toString();
        }
        sb.append(str);
        sb.append(",ntResponse=");
        if (nTResponse == null) {
            str2 = str3;
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str5);
            sb3.append(nTResponse.length);
            sb3.append(str4);
            str2 = sb3.toString();
        }
        sb.append(str2);
        sb.append(",sessionKey=");
        if (sessionKey2 != null) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str5);
            sb4.append(sessionKey2.length);
            sb4.append(str4);
            str3 = sb4.toString();
        }
        sb.append(str3);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(getFlags(), 8));
        sb.append("]");
        return sb.toString();
    }

    private static int getDefaultFlags() {
        return DEFAULT_FLAGS;
    }

    private static int getDefaultFlags(Type2Message type2Message) {
        if (type2Message == null) {
            return DEFAULT_FLAGS;
        }
        int i = 1;
        if ((type2Message.getFlags() & 1) == 0) {
            i = 2;
        }
        return i | 512;
    }

    private static byte[] getLMResponse(Type2Message type2Message, String str) {
        if (type2Message == null || str == null) {
            return null;
        }
        return NtlmPasswordAuthentication.getPreNTLMResponse(str, type2Message.getChallenge());
    }

    private static byte[] getLMv2Response(Type2Message type2Message, String str, String str2, String str3, byte[] bArr) {
        if (type2Message == null || str == null || str2 == null || str3 == null || bArr == null) {
            return null;
        }
        return NtlmPasswordAuthentication.getLMv2Response(str, str2, str3, type2Message.getChallenge(), bArr);
    }

    private static byte[] getNTLMv2Response(Type2Message type2Message, byte[] bArr, byte[] bArr2) {
        if (type2Message == null || bArr == null || bArr2 == null) {
            return null;
        }
        return NtlmPasswordAuthentication.getNTLMv2Response(bArr, type2Message.getChallenge(), bArr2, (System.currentTimeMillis() + 11644473600000L) * 10000, type2Message.getTargetInformation());
    }

    private static byte[] getNTResponse(Type2Message type2Message, String str) {
        if (type2Message == null || str == null) {
            return null;
        }
        return NtlmPasswordAuthentication.getNTLMResponse(str, type2Message.getChallenge());
    }

    private static String getDefaultDomain() {
        return DEFAULT_DOMAIN;
    }

    private static String getDefaultUser() {
        return DEFAULT_USER;
    }

    private static String getDefaultWorkstation() {
        return DEFAULT_WORKSTATION;
    }
}
