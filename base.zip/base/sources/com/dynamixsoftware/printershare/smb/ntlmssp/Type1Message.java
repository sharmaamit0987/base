package com.dynamixsoftware.printershare.smb.ntlmssp;

import com.dynamixsoftware.printershare.smb.netbios.NbtAddress;
import com.dynamixsoftware.printershare.smb.util.Dumper;
import java.io.IOException;
import java.net.UnknownHostException;

public class Type1Message extends NtlmMessage {
    private static final String DEFAULT_DOMAIN = null;
    private static final int DEFAULT_FLAGS = 513;
    private static final String DEFAULT_WORKSTATION;
    private String suppliedDomain;
    private String suppliedWorkstation;

    public /* bridge */ /* synthetic */ int getFlags() {
        return super.getFlags();
    }

    public /* bridge */ /* synthetic */ void setFlags(int i) {
        super.setFlags(i);
    }

    static {
        String str;
        try {
            str = NbtAddress.getLocalHost().getHostName();
        } catch (UnknownHostException unused) {
            str = null;
        }
        DEFAULT_WORKSTATION = str;
    }

    public Type1Message() {
        this(getDefaultFlags(), getDefaultDomain(), getDefaultWorkstation());
    }

    public Type1Message(int i, String str, String str2) {
        setFlags(i | getDefaultFlags());
        setSuppliedDomain(str);
        if (str2 == null) {
            str2 = getDefaultWorkstation();
        }
        setSuppliedWorkstation(str2);
    }

    public String getSuppliedDomain() {
        return this.suppliedDomain;
    }

    public void setSuppliedDomain(String str) {
        this.suppliedDomain = str;
    }

    public String getSuppliedWorkstation() {
        return this.suppliedWorkstation;
    }

    public void setSuppliedWorkstation(String str) {
        this.suppliedWorkstation = str;
    }

    public byte[] toByteArray() {
        int i;
        boolean z;
        int i2;
        try {
            String suppliedDomain2 = getSuppliedDomain();
            String suppliedWorkstation2 = getSuppliedWorkstation();
            int flags = getFlags();
            byte[] bArr = new byte[0];
            if (suppliedDomain2 == null || suppliedDomain2.length() == 0) {
                i = flags & -4097;
                z = false;
            } else {
                i = flags | 4096;
                bArr = suppliedDomain2.toUpperCase().getBytes(getOEMEncoding());
                z = true;
            }
            byte[] bArr2 = new byte[0];
            if (suppliedWorkstation2 == null || suppliedWorkstation2.length() == 0) {
                i2 = i & -8193;
            } else {
                int i3 = i | 8192;
                bArr2 = suppliedWorkstation2.toUpperCase().getBytes(getOEMEncoding());
                i2 = i3;
                z = true;
            }
            byte[] bArr3 = new byte[(z ? bArr.length + 32 + bArr2.length : 16)];
            System.arraycopy(NTLMSSP_SIGNATURE, 0, bArr3, 0, 8);
            writeULong(bArr3, 8, 1);
            writeULong(bArr3, 12, i2);
            if (z) {
                writeSecurityBuffer(bArr3, 16, 32, bArr);
                writeSecurityBuffer(bArr3, 24, bArr.length + 32, bArr2);
            }
            return bArr3;
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    public String toString() {
        String suppliedDomain2 = getSuppliedDomain();
        String suppliedWorkstation2 = getSuppliedWorkstation();
        StringBuilder sb = new StringBuilder();
        sb.append("Type1Message[suppliedDomain=");
        String str = "null";
        if (suppliedDomain2 == null) {
            suppliedDomain2 = str;
        }
        sb.append(suppliedDomain2);
        sb.append(",suppliedWorkstation=");
        if (suppliedWorkstation2 == null) {
            suppliedWorkstation2 = str;
        }
        sb.append(suppliedWorkstation2);
        sb.append(",flags=0x");
        sb.append(Dumper.toHexString(getFlags(), 8));
        sb.append("]");
        return sb.toString();
    }

    private static int getDefaultFlags() {
        return DEFAULT_FLAGS;
    }

    private static String getDefaultDomain() {
        return DEFAULT_DOMAIN;
    }

    public static String getDefaultWorkstation() {
        return DEFAULT_WORKSTATION;
    }
}
