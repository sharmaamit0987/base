package com.dynamixsoftware.printershare.smb;

class SmbComWriteAndX extends AndXServerMessageBlock {
    private static final int CLOSE_BATCH_LIMIT = 1;
    private static final int READ_ANDX_BATCH_LIMIT = 1;
    private byte[] b;
    private int dataLength;
    private int dataOffset;
    private int fid;
    private int off;
    private long offset;
    private int pad;
    private int remaining;
    int writeMode;

    /* access modifiers changed from: 0000 */
    public int getBatchLimit(byte b2) {
        return (b2 == 46 || b2 == 4) ? 1 : 0;
    }

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComWriteAndX() {
        super(null);
        this.command = 47;
    }

    /* access modifiers changed from: 0000 */
    public void setParam(int i, long j, int i2, byte[] bArr, int i3, int i4) {
        this.fid = i;
        this.offset = j;
        this.remaining = i2;
        this.b = bArr;
        this.off = i3;
        this.dataLength = i4;
        this.digest = null;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        int i2 = (i - this.headerStart) + 26;
        this.dataOffset = i2;
        int i3 = (i2 - this.headerStart) % 4;
        this.pad = i3;
        int i4 = i3 == 0 ? 0 : 4 - i3;
        this.pad = i4;
        this.dataOffset += i4;
        writeInt2((long) this.fid, bArr, i);
        int i5 = i + 2;
        writeInt4(this.offset, bArr, i5);
        int i6 = i5 + 4;
        int i7 = 0;
        while (i7 < 4) {
            int i8 = i6 + 1;
            bArr[i6] = -1;
            i7++;
            i6 = i8;
        }
        writeInt2((long) this.writeMode, bArr, i6);
        int i9 = i6 + 2;
        writeInt2((long) this.remaining, bArr, i9);
        int i10 = i9 + 2;
        int i11 = i10 + 1;
        bArr[i10] = 0;
        int i12 = i11 + 1;
        bArr[i11] = 0;
        writeInt2((long) this.dataLength, bArr, i12);
        int i13 = i12 + 2;
        writeInt2((long) this.dataOffset, bArr, i13);
        int i14 = i13 + 2;
        writeInt4(this.offset >> 32, bArr, i14);
        return (i14 + 4) - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2 = i;
        while (true) {
            int i3 = this.pad;
            this.pad = i3 - 1;
            if (i3 > 0) {
                int i4 = i2 + 1;
                bArr[i2] = -18;
                i2 = i4;
            } else {
                System.arraycopy(this.b, this.off, bArr, i2, this.dataLength);
                return (i2 + this.dataLength) - i;
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComWriteAndX[");
        sb.append(super.toString());
        sb.append(",fid=");
        sb.append(this.fid);
        sb.append(",offset=");
        sb.append(this.offset);
        sb.append(",writeMode=");
        sb.append(this.writeMode);
        sb.append(",remaining=");
        sb.append(this.remaining);
        sb.append(",dataLength=");
        sb.append(this.dataLength);
        sb.append(",dataOffset=");
        sb.append(this.dataOffset);
        sb.append("]");
        return new String(sb.toString());
    }
}
