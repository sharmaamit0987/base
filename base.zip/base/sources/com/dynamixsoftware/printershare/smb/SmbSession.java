package com.dynamixsoftware.printershare.smb;

import java.net.InetAddress;
import java.util.Enumeration;
import java.util.Vector;

final class SmbSession {
    private static final String LOGON_SHARE = null;
    private UniAddress address;
    NtlmPasswordAuthentication auth;
    private int connectionState;
    long expiration;
    private InetAddress localAddr;
    private int localPort;
    private String netbiosName = null;
    private int port;
    SmbTransport transport = null;
    private Vector<SmbTree> trees;
    private int uid;

    SmbSession(UniAddress uniAddress, int i, InetAddress inetAddress, int i2, NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        this.address = uniAddress;
        this.port = i;
        this.localAddr = inetAddress;
        this.localPort = i2;
        this.auth = ntlmPasswordAuthentication;
        this.trees = new Vector<>();
        this.connectionState = 0;
    }

    /* access modifiers changed from: 0000 */
    public synchronized SmbTree getSmbTree(String str, String str2) {
        if (str == null) {
            str = "IPC$";
        }
        Enumeration elements = this.trees.elements();
        while (elements.hasMoreElements()) {
            SmbTree smbTree = (SmbTree) elements.nextElement();
            if (smbTree.matches(str, str2)) {
                return smbTree;
            }
        }
        SmbTree smbTree2 = new SmbTree(this, str, str2);
        this.trees.addElement(smbTree2);
        return smbTree2;
    }

    /* access modifiers changed from: 0000 */
    public boolean matches(NtlmPasswordAuthentication ntlmPasswordAuthentication) {
        NtlmPasswordAuthentication ntlmPasswordAuthentication2 = this.auth;
        return ntlmPasswordAuthentication2 == ntlmPasswordAuthentication || ntlmPasswordAuthentication2.equals(ntlmPasswordAuthentication);
    }

    /* access modifiers changed from: 0000 */
    public synchronized SmbTransport transport() {
        if (this.transport == null) {
            this.transport = SmbTransport.getSmbTransport(this.address, this.port, this.localAddr, this.localPort, null);
        }
        return this.transport;
    }

    /* access modifiers changed from: 0000 */
    public void send(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        synchronized (transport()) {
            if (serverMessageBlock2 != null) {
                serverMessageBlock2.received = false;
            }
            this.expiration = System.currentTimeMillis() + 15000;
            sessionSetup(serverMessageBlock, serverMessageBlock2);
            if (serverMessageBlock2 == null || !serverMessageBlock2.received) {
                if (serverMessageBlock instanceof SmbComTreeConnectAndX) {
                    SmbComTreeConnectAndX smbComTreeConnectAndX = (SmbComTreeConnectAndX) serverMessageBlock;
                    if (this.netbiosName != null && smbComTreeConnectAndX.path.endsWith("\\IPC$")) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("\\\\");
                        sb.append(this.netbiosName);
                        sb.append("\\IPC$");
                        smbComTreeConnectAndX.path = sb.toString();
                    }
                }
                serverMessageBlock.uid = this.uid;
                serverMessageBlock.auth = this.auth;
                try {
                    this.transport.send(serverMessageBlock, serverMessageBlock2);
                } catch (SmbException e) {
                    if (serverMessageBlock instanceof SmbComTreeConnectAndX) {
                        logoff(true);
                    }
                    serverMessageBlock.digest = null;
                    throw e;
                }
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(10:40|41|(2:43|(1:45))|46|47|48|52|53|(2:55|(1:57)(3:136|58|59))|(3:61|(1:63)|64)(2:137|65)) */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002b, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:52:0x00ab */
    /* JADX WARNING: Missing exception handler attribute for start block: B:72:0x00e4 */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x01a7 A[SYNTHETIC, Splitter:B:112:0x01a7] */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x01ae A[LOOP:1: B:23:0x003e->B:116:0x01ae, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x00d5 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00af A[Catch:{ SmbAuthException -> 0x01b3, SmbException -> 0x016b, SmbException -> 0x00de, SmbAuthException -> 0x00d6, SmbException -> 0x00a5, SmbException -> 0x01b7 }] */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00c4 A[Catch:{ SmbAuthException -> 0x01b3, SmbException -> 0x016b, SmbException -> 0x00de, SmbAuthException -> 0x00d6, SmbException -> 0x00a5, SmbException -> 0x01b7 }] */
    private void sessionSetup(ServerMessageBlock serverMessageBlock, ServerMessageBlock serverMessageBlock2) throws SmbException {
        synchronized (transport()) {
            byte[] bArr = new byte[0];
            while (this.connectionState != 0) {
                if (this.connectionState != 2 && this.connectionState != 3) {
                    try {
                        this.transport.wait();
                    } catch (InterruptedException e) {
                        throw new SmbException(e.getMessage(), (Throwable) e);
                    } catch (Throwable th) {
                        this.transport.notifyAll();
                        throw th;
                    }
                }
            }
            this.connectionState = 1;
            this.transport.connect();
            this.uid = 0;
            int i = 10;
            byte[] bArr2 = bArr;
            SmbException e2 = null;
            NtlmContext ntlmContext = null;
            int i2 = 10;
            while (true) {
                if (i2 != i) {
                    if (i2 == 20) {
                        if (ntlmContext == null) {
                            ntlmContext = new NtlmContext(this.auth, (this.transport.flags2 & 4) != 0);
                        }
                        if (ntlmContext.isEstablished()) {
                            this.netbiosName = ntlmContext.getNetbiosName();
                            this.connectionState = 2;
                            ServerMessageBlock serverMessageBlock3 = serverMessageBlock;
                            ServerMessageBlock serverMessageBlock4 = serverMessageBlock2;
                        } else {
                            try {
                                bArr2 = ntlmContext.initSecContext(bArr2, 0, bArr2.length);
                                if (bArr2 != null) {
                                    SmbComSessionSetupAndX smbComSessionSetupAndX = new SmbComSessionSetupAndX(this, null, bArr2);
                                    SmbComSessionSetupAndXResponse smbComSessionSetupAndXResponse = new SmbComSessionSetupAndXResponse(null);
                                    if (this.transport.isSignatureSetupRequired(this.auth)) {
                                        byte[] signingKey = ntlmContext.getSigningKey();
                                        if (signingKey != null) {
                                            smbComSessionSetupAndX.digest = new SigningDigest(signingKey, true);
                                        }
                                    }
                                    smbComSessionSetupAndX.uid = this.uid;
                                    this.uid = 0;
                                    this.transport.send(smbComSessionSetupAndX, smbComSessionSetupAndXResponse);
                                    if (smbComSessionSetupAndXResponse.isLoggedInAsGuest) {
                                        if (!"GUEST".equalsIgnoreCase(this.auth.username)) {
                                            throw new SmbAuthException(NtStatus.NT_STATUS_LOGON_FAILURE);
                                        }
                                    }
                                    if (e2 != null) {
                                        this.uid = smbComSessionSetupAndXResponse.uid;
                                        if (smbComSessionSetupAndX.digest != null) {
                                            this.transport.digest = smbComSessionSetupAndX.digest;
                                        }
                                        bArr2 = smbComSessionSetupAndXResponse.blob;
                                    } else {
                                        throw e2;
                                    }
                                }
                            } catch (SmbAuthException e3) {
                                throw e3;
                            } catch (SmbException e4) {
                                e2 = e4;
                            } catch (SmbException e5) {
                                this.transport.disconnect(true);
                                this.uid = 0;
                                throw e5;
                            } catch (SmbAuthException e6) {
                                throw e6;
                            } catch (SmbException e7) {
                                e2 = e7;
                                this.transport.disconnect(true);
                            } catch (SmbException e8) {
                                logoff(true);
                                this.connectionState = 0;
                                throw e8;
                            }
                            ServerMessageBlock serverMessageBlock5 = serverMessageBlock;
                            ServerMessageBlock serverMessageBlock6 = serverMessageBlock2;
                            if (i2 == 0) {
                                this.transport.notifyAll();
                                return;
                            }
                            i = 10;
                        }
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Unexpected session setup state: ");
                        sb.append(i2);
                        throw new SmbException(sb.toString());
                    }
                } else if (this.auth == NtlmPasswordAuthentication.ANONYMOUS || !this.transport.hasCapability(SmbConstants.CAP_EXTENDED_SECURITY)) {
                    SmbComSessionSetupAndX smbComSessionSetupAndX2 = new SmbComSessionSetupAndX(this, serverMessageBlock, this.auth);
                    SmbComSessionSetupAndXResponse smbComSessionSetupAndXResponse2 = new SmbComSessionSetupAndXResponse(serverMessageBlock2);
                    if (this.transport.isSignatureSetupRequired(this.auth)) {
                        if (!this.auth.hashesExternal || NtlmPasswordAuthentication.DEFAULT_PASSWORD == "") {
                            smbComSessionSetupAndX2.digest = new SigningDigest(this.auth.getSigningKey(this.transport.server.encryptionKey), false);
                        } else {
                            this.transport.getSmbSession(NtlmPasswordAuthentication.DEFAULT).getSmbTree(LOGON_SHARE, null).treeConnect(null, null);
                        }
                    }
                    smbComSessionSetupAndX2.auth = this.auth;
                    this.transport.send(smbComSessionSetupAndX2, smbComSessionSetupAndXResponse2);
                    if (smbComSessionSetupAndXResponse2.isLoggedInAsGuest && !"GUEST".equalsIgnoreCase(this.auth.username) && this.transport.server.security != 0) {
                        if (this.auth != NtlmPasswordAuthentication.ANONYMOUS) {
                            throw new SmbAuthException(NtStatus.NT_STATUS_LOGON_FAILURE);
                        }
                    }
                    if (e2 == null) {
                        this.uid = smbComSessionSetupAndXResponse2.uid;
                        if (smbComSessionSetupAndX2.digest != null) {
                            this.transport.digest = smbComSessionSetupAndX2.digest;
                        }
                        this.connectionState = 2;
                    } else {
                        throw e2;
                    }
                } else {
                    ServerMessageBlock serverMessageBlock7 = serverMessageBlock;
                    ServerMessageBlock serverMessageBlock8 = serverMessageBlock2;
                    i2 = 20;
                    if (i2 == 0) {
                    }
                }
                i2 = 0;
                if (i2 == 0) {
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Can't wrap try/catch for region: R(5:15|16|17|18|19) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:18:0x0041 */
    public void logoff(boolean z) {
        synchronized (transport()) {
            if (this.connectionState == 2) {
                this.connectionState = 3;
                this.netbiosName = null;
                Enumeration elements = this.trees.elements();
                while (elements.hasMoreElements()) {
                    ((SmbTree) elements.nextElement()).treeDisconnect(z);
                }
                if (!z && this.transport.server.security != 0) {
                    SmbComLogoffAndX smbComLogoffAndX = new SmbComLogoffAndX(null);
                    smbComLogoffAndX.uid = this.uid;
                    this.transport.send(smbComLogoffAndX, null);
                    this.uid = 0;
                }
                this.connectionState = 0;
                this.transport.notifyAll();
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbSession[accountName=");
        sb.append(this.auth.username);
        sb.append(",primaryDomain=");
        sb.append(this.auth.domain);
        sb.append(",uid=");
        sb.append(this.uid);
        sb.append(",connectionState=");
        sb.append(this.connectionState);
        sb.append("]");
        return sb.toString();
    }
}
