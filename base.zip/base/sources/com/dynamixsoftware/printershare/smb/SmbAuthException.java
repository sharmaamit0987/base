package com.dynamixsoftware.printershare.smb;

public class SmbAuthException extends SmbException {
    public /* bridge */ /* synthetic */ int getNtStatus() {
        return super.getNtStatus();
    }

    SmbAuthException(int i) {
        super(i, (Throwable) null);
    }
}
