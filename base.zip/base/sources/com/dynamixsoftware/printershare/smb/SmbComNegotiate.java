package com.dynamixsoftware.printershare.smb;

import java.io.UnsupportedEncodingException;

class SmbComNegotiate extends ServerMessageBlock {
    private static final String DIALECTS = "\u0002NT LM 0.12\u0000";

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComNegotiate() {
        this.command = 114;
        this.flags2 = 51203;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        try {
            byte[] bytes = DIALECTS.getBytes("ASCII");
            System.arraycopy(bytes, 0, bArr, i, bytes.length);
            return bytes.length;
        } catch (UnsupportedEncodingException unused) {
            return 0;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComNegotiate[");
        sb.append(super.toString());
        sb.append(",wordCount=");
        sb.append(this.wordCount);
        sb.append(",dialects=NT LM 0.12]");
        return new String(sb.toString());
    }
}
