package com.dynamixsoftware.printershare.smb;

class NetShareEnumResponse extends SmbComTransactionResponse {
    private int converter;
    private int totalAvailableEntries;

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    NetShareEnumResponse() {
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        this.status = readInt2(bArr, i);
        int i3 = i + 2;
        this.converter = readInt2(bArr, i3);
        int i4 = i3 + 2;
        this.numEntries = readInt2(bArr, i4);
        int i5 = i4 + 2;
        this.totalAvailableEntries = readInt2(bArr, i5);
        return (i5 + 2) - i;
    }

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        this.useUnicode = false;
        this.results = new SmbShareInfo[this.numEntries];
        int i3 = i;
        for (int i4 = 0; i4 < this.numEntries; i4++) {
            FileEntry[] fileEntryArr = this.results;
            SmbShareInfo smbShareInfo = new SmbShareInfo();
            fileEntryArr[i4] = smbShareInfo;
            smbShareInfo.netName = readString(bArr, i3, 13, false);
            int i5 = i3 + 14;
            smbShareInfo.type = readInt2(bArr, i5);
            int i6 = i5 + 2;
            int readInt4 = readInt4(bArr, i6);
            i3 = i6 + 4;
            smbShareInfo.remark = readString(bArr, ((readInt4 & 65535) - this.converter) + i, 128, false);
        }
        return i3 - i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NetShareEnumResponse[");
        sb.append(super.toString());
        sb.append(",status=");
        sb.append(this.status);
        sb.append(",converter=");
        sb.append(this.converter);
        sb.append(",entriesReturned=");
        sb.append(this.numEntries);
        sb.append(",totalAvailableEntries=");
        sb.append(this.totalAvailableEntries);
        sb.append("]");
        return new String(sb.toString());
    }
}
