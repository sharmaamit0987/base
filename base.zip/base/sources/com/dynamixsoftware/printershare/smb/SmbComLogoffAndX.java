package com.dynamixsoftware.printershare.smb;

class SmbComLogoffAndX extends AndXServerMessageBlock {
    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComLogoffAndX(ServerMessageBlock serverMessageBlock) {
        super(serverMessageBlock);
        this.command = 116;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComLogoffAndX[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
