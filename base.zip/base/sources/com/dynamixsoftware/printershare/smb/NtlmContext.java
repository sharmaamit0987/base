package com.dynamixsoftware.printershare.smb;

import com.dynamixsoftware.printershare.smb.ntlmssp.NtlmFlags;
import com.dynamixsoftware.printershare.smb.ntlmssp.Type1Message;
import com.dynamixsoftware.printershare.smb.ntlmssp.Type2Message;
import com.dynamixsoftware.printershare.smb.ntlmssp.Type3Message;
import com.dynamixsoftware.printershare.smb.util.Dumper;

class NtlmContext {
    private NtlmPasswordAuthentication auth;
    private boolean isEstablished = false;
    private String netbiosName = null;
    private int ntlmsspFlags;
    private byte[] serverChallenge = null;
    private byte[] signingKey = null;
    private int state = 1;
    private String workstation;

    NtlmContext(NtlmPasswordAuthentication ntlmPasswordAuthentication, boolean z) {
        this.auth = ntlmPasswordAuthentication;
        int i = this.ntlmsspFlags | 4 | NtlmFlags.NTLMSSP_NEGOTIATE_NTLM2 | NtlmFlags.NTLMSSP_NEGOTIATE_128;
        this.ntlmsspFlags = i;
        if (z) {
            this.ntlmsspFlags = i | 1073774608;
        }
        this.workstation = Type1Message.getDefaultWorkstation();
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        sb.append("NtlmContext[auth=");
        sb.append(this.auth);
        sb.append(",ntlmsspFlags=0x");
        sb.append(Dumper.toHexString(this.ntlmsspFlags, 8));
        sb.append(",workstation=");
        sb.append(this.workstation);
        sb.append(",isEstablished=");
        sb.append(this.isEstablished);
        sb.append(",state=");
        sb.append(this.state);
        sb.append(",serverChallenge=");
        String sb2 = sb.toString();
        String str3 = "null";
        if (this.serverChallenge == null) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(sb2);
            sb3.append(str3);
            str = sb3.toString();
        } else {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(sb2);
            byte[] bArr = this.serverChallenge;
            sb4.append(Dumper.toHexString(bArr, 0, bArr.length * 2));
            str = sb4.toString();
        }
        StringBuilder sb5 = new StringBuilder();
        sb5.append(str);
        sb5.append(",signingKey=");
        String sb6 = sb5.toString();
        if (this.signingKey == null) {
            StringBuilder sb7 = new StringBuilder();
            sb7.append(sb6);
            sb7.append(str3);
            str2 = sb7.toString();
        } else {
            StringBuilder sb8 = new StringBuilder();
            sb8.append(sb6);
            byte[] bArr2 = this.signingKey;
            sb8.append(Dumper.toHexString(bArr2, 0, bArr2.length * 2));
            str2 = sb8.toString();
        }
        StringBuilder sb9 = new StringBuilder();
        sb9.append(str2);
        sb9.append("]");
        return sb9.toString();
    }

    public boolean isEstablished() {
        return this.isEstablished;
    }

    public byte[] getServerChallenge() {
        return this.serverChallenge;
    }

    public byte[] getSigningKey() {
        return this.signingKey;
    }

    public String getNetbiosName() {
        return this.netbiosName;
    }

    /* access modifiers changed from: 0000 */
    public byte[] initSecContext(byte[] bArr, int i, int i2) throws SmbException {
        int i3 = this.state;
        if (i3 == 1) {
            byte[] byteArray = new Type1Message(this.ntlmsspFlags, this.auth.getDomain(), this.workstation).toByteArray();
            this.state++;
            return byteArray;
        } else if (i3 == 2) {
            try {
                Type2Message type2Message = new Type2Message(bArr);
                this.serverChallenge = type2Message.getChallenge();
                this.ntlmsspFlags &= type2Message.getFlags();
                Type3Message type3Message = new Type3Message(type2Message, this.auth.getPassword(), this.auth.getDomain(), this.auth.getUsername(), this.workstation, this.ntlmsspFlags);
                byte[] byteArray2 = type3Message.toByteArray();
                if ((this.ntlmsspFlags & 16) != 0) {
                    this.signingKey = type3Message.getMasterKey();
                }
                this.isEstablished = true;
                this.state++;
                return byteArray2;
            } catch (Exception e) {
                throw new SmbException(e.getMessage(), (Throwable) e);
            }
        } else {
            throw new SmbException("Invalid state");
        }
    }
}
