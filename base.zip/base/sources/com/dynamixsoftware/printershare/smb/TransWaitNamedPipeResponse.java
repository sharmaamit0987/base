package com.dynamixsoftware.printershare.smb;

class TransWaitNamedPipeResponse extends SmbComTransactionResponse {
    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    TransWaitNamedPipeResponse() {
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TransWaitNamedPipeResponse[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
