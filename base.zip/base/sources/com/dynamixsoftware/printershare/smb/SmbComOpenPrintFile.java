package com.dynamixsoftware.printershare.smb;

class SmbComOpenPrintFile extends ServerMessageBlock {
    private String identifierString;
    private long mode = 1;
    private long setupLength = 0;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComOpenPrintFile(String str) {
        this.identifierString = str;
        this.command = -64;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = 4;
        return (i2 + writeString(this.identifierString, bArr, i2, false)) - i;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        writeInt2(this.setupLength, bArr, i);
        writeInt2(this.mode, bArr, i + 2);
        return 4;
    }
}
