package com.dynamixsoftware.printershare.smb;

class TransPeekNamedPipeResponse extends SmbComTransactionResponse {
    static final int STATUS_DISCONNECTED = 1;
    static final int STATUS_SERVER_END_CLOSED = 4;
    int available;
    int status;

    /* access modifiers changed from: 0000 */
    public int readDataWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int readSetupWireFormat(byte[] bArr, int i, int i2) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeDataWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParametersWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeSetupWireFormat(byte[] bArr, int i) {
        return 0;
    }

    TransPeekNamedPipeResponse(SmbNamedPipe smbNamedPipe) {
    }

    /* access modifiers changed from: 0000 */
    public int readParametersWireFormat(byte[] bArr, int i, int i2) {
        this.available = readInt2(bArr, i);
        int i3 = i + 2;
        readInt2(bArr, i3);
        this.status = readInt2(bArr, i3 + 2);
        return 6;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TransPeekNamedPipeResponse[");
        sb.append(super.toString());
        sb.append("]");
        return new String(sb.toString());
    }
}
