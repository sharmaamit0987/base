package com.dynamixsoftware.printershare.smb;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

class Handler extends URLStreamHandler {
    static final URLStreamHandler SMB_HANDLER = new Handler();

    /* access modifiers changed from: protected */
    public int getDefaultPort() {
        return SmbConstants.DEFAULT_PORT;
    }

    Handler() {
    }

    public URLConnection openConnection(URL url) throws IOException {
        throw new UnsupportedOperationException();
    }

    /* access modifiers changed from: protected */
    public void parseURL(URL url, String str, int i, int i2) {
        String host = url.getHost();
        String str2 = "smb://";
        if (str.equals(str2)) {
            i2 += 2;
            str = "smb:////";
        } else if (!str.startsWith(str2) && host != null && host.length() == 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("//");
            sb.append(str);
            str = sb.toString();
            i2 += 2;
        }
        super.parseURL(url, str, i, i2);
        String path = url.getPath();
        String ref = url.getRef();
        if (ref != null) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(path);
            sb2.append('#');
            sb2.append(ref);
            path = sb2.toString();
        }
        String str3 = path;
        int port = url.getPort();
        if (port == -1) {
            port = getDefaultPort();
        }
        String str4 = "smb";
        URL url2 = url;
        setURL(url2, str4, url.getHost(), port, url.getAuthority(), url.getUserInfo(), str3, url.getQuery(), null);
    }
}
