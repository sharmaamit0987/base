package com.dynamixsoftware.printershare.smb;

class SmbComWriteResponse extends ServerMessageBlock {
    long count;

    /* access modifiers changed from: 0000 */
    public int readBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeBytesWireFormat(byte[] bArr, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    public int writeParameterWordsWireFormat(byte[] bArr, int i) {
        return 0;
    }

    SmbComWriteResponse() {
    }

    /* access modifiers changed from: 0000 */
    public int readParameterWordsWireFormat(byte[] bArr, int i) {
        this.count = ((long) readInt2(bArr, i)) & 65535;
        return 8;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SmbComWriteResponse[");
        sb.append(super.toString());
        sb.append(",count=");
        sb.append(this.count);
        sb.append("]");
        return new String(sb.toString());
    }
}
