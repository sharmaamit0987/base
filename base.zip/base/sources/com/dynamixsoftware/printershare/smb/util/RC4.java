package com.dynamixsoftware.printershare.smb.util;

public class RC4 {
    private int i;
    private int j;
    private byte[] s;

    public RC4() {
    }

    public RC4(byte[] bArr) {
        init(bArr, 0, bArr.length);
    }

    private void init(byte[] bArr, int i2, int i3) {
        this.s = new byte[256];
        this.i = 0;
        while (true) {
            int i4 = this.i;
            if (i4 >= 256) {
                break;
            }
            this.s[i4] = (byte) i4;
            this.i = i4 + 1;
        }
        this.j = 0;
        this.i = 0;
        while (true) {
            int i5 = this.i;
            if (i5 < 256) {
                int i6 = this.j + bArr[(i5 % i3) + i2];
                byte[] bArr2 = this.s;
                int i7 = (i6 + bArr2[i5]) & 255;
                this.j = i7;
                byte b = bArr2[i5];
                bArr2[i5] = bArr2[i7];
                bArr2[i7] = b;
                this.i = i5 + 1;
            } else {
                this.j = 0;
                this.i = 0;
                return;
            }
        }
    }

    public void update(byte[] bArr, int i2, int i3, byte[] bArr2, int i4) {
        int i5 = i3 + i2;
        while (i2 < i5) {
            int i6 = (this.i + 1) & 255;
            this.i = i6;
            int i7 = this.j;
            byte[] bArr3 = this.s;
            int i8 = (i7 + bArr3[i6]) & 255;
            this.j = i8;
            byte b = bArr3[i6];
            bArr3[i6] = bArr3[i8];
            bArr3[i8] = b;
            int i9 = i4 + 1;
            int i10 = i2 + 1;
            bArr2[i4] = (byte) (bArr[i2] ^ bArr3[(bArr3[i6] + bArr3[i8]) & 255]);
            i4 = i9;
            i2 = i10;
        }
    }
}
