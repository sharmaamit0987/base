package com.dynamixsoftware.printershare.smb.util;

import com.flurry.android.Constants;

public class Encdec {
    public static int enc_uint32be(int i, byte[] bArr, int i2) {
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >> 24) & 255);
        int i4 = i3 + 1;
        bArr[i3] = (byte) ((i >> 16) & 255);
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((i >> 8) & 255);
        bArr[i5] = (byte) (i & 255);
        return 4;
    }

    public static int enc_uint16le(short s, byte[] bArr, int i) {
        int i2 = i + 1;
        bArr[i] = (byte) (s & 255);
        bArr[i2] = (byte) ((s >> 8) & 255);
        return 2;
    }

    public static int enc_uint32le(int i, byte[] bArr, int i2) {
        int i3 = i2 + 1;
        bArr[i2] = (byte) (i & 255);
        int i4 = i3 + 1;
        bArr[i3] = (byte) ((i >> 8) & 255);
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((i >> 16) & 255);
        bArr[i5] = (byte) ((i >> 24) & 255);
        return 4;
    }

    public static short dec_uint16be(byte[] bArr, int i) {
        return (short) ((bArr[i + 1] & Constants.UNKNOWN) | ((bArr[i] & Constants.UNKNOWN) << 8));
    }

    public static short dec_uint16le(byte[] bArr, int i) {
        return (short) (((bArr[i + 1] & Constants.UNKNOWN) << 8) | (bArr[i] & Constants.UNKNOWN));
    }

    public static int dec_uint32le(byte[] bArr, int i) {
        return ((bArr[i + 3] & Constants.UNKNOWN) << 24) | (bArr[i] & Constants.UNKNOWN) | ((bArr[i + 1] & Constants.UNKNOWN) << 8) | ((bArr[i + 2] & Constants.UNKNOWN) << 16);
    }

    public static int enc_uint64le(long j, byte[] bArr, int i) {
        enc_uint32le((int) (j & 4294967295L), bArr, i);
        enc_uint32le((int) ((j >> 32) & 4294967295L), bArr, i + 4);
        return 8;
    }
}
