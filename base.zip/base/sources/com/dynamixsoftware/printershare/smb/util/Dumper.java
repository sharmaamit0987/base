package com.dynamixsoftware.printershare.smb.util;

public class Dumper {
    private static final char[] HEX_DIGITS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public static String toHexString(int i, int i2) {
        char[] cArr = new char[i2];
        toHexChars(i, cArr, 0, i2);
        return new String(cArr);
    }

    public static String toHexString(byte[] bArr, int i, int i2) {
        char[] cArr = new char[i2];
        int i3 = i2 % 2 == 0 ? i2 / 2 : (i2 / 2) + 1;
        int i4 = 0;
        for (int i5 = 0; i5 < i3; i5++) {
            int i6 = i4 + 1;
            char[] cArr2 = HEX_DIGITS;
            cArr[i4] = cArr2[(bArr[i5] >> 4) & 15];
            if (i6 == i2) {
                break;
            }
            i4 = i6 + 1;
            cArr[i6] = cArr2[bArr[i5] & 15];
        }
        return new String(cArr);
    }

    private static void toHexChars(int i, char[] cArr, int i2, int i3) {
        while (i3 > 0) {
            int i4 = (i2 + i3) - 1;
            if (i4 < cArr.length) {
                cArr[i4] = HEX_DIGITS[i & 15];
            }
            if (i != 0) {
                i >>>= 4;
            }
            i3--;
        }
    }
}
