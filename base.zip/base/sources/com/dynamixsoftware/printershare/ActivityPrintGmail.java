package com.dynamixsoftware.printershare;

import android.os.Bundle;

public class ActivityPrintGmail extends ActivityPrintWeb {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.pic = ActivityGmailConversation.pp;
        ActivityGmailConversation.pp = null;
        this.orientation = 1;
    }
}
