package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.content.res.AssetManager;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

public class ActivityDriversBrowser extends ActivityRoot {
    /* access modifiers changed from: private */
    public FolderAdapter adapter;
    /* access modifiers changed from: private */
    public volatile Vector<Entry> data;
    private ListView list;
    /* access modifiers changed from: private */
    public Thread wt;

    static class Entry {
        public Vector<Entry> data;
        public String name;
        public int type_rid = R.drawable.icn_empty;

        public Entry(String str, boolean z) {
            this.name = str;
            if (z) {
                this.data = new Vector<>();
                this.type_rid = R.drawable.icn_folder;
            }
            if ("..".equals(str)) {
                this.type_rid = R.drawable.icn_up;
            }
        }
    }

    class FolderAdapter implements ListAdapter {
        /* access modifiers changed from: private */
        public Vector<Entry> chain = new Vector<>();
        private Vector<Entry> entries = new Vector<>();
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        public FolderAdapter() {
            changeFolder(null);
        }

        public void changeFolder(Entry entry) {
            if (entry != null) {
                if (this.chain.size() > 1) {
                    Vector<Entry> vector = this.chain;
                    if (vector.get(vector.size() - 2) == entry) {
                        Vector<Entry> vector2 = this.chain;
                        vector2.remove(vector2.size() - 1);
                    }
                }
                if (this.chain.size() == 0 || entry != this.chain.lastElement()) {
                    this.chain.add(entry);
                }
            } else {
                this.chain.clear();
            }
            this.entries.clear();
            if (entry != null) {
                this.entries.add(new Entry("..", true));
            }
            Vector<Entry> access$200 = entry == null ? ActivityDriversBrowser.this.data : entry.data;
            int size = this.entries.size();
            for (int i = 0; i < access$200.size(); i++) {
                Entry entry2 = (Entry) access$200.get(i);
                if (entry2.type_rid == 2130837534) {
                    int i2 = size + 1;
                    this.entries.add(size, entry2);
                    size = i2;
                } else {
                    this.entries.add(entry2);
                }
            }
            fireOnChanged();
        }

        public int getCount() {
            return this.entries.size();
        }

        public Object getItem(int i) {
            return this.entries.get(i);
        }

        public long getItemId(int i) {
            return (long) (((Entry) this.entries.get(i)).name.hashCode() << (i + 16));
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            LinearLayout linearLayout = (LinearLayout) view;
            if (linearLayout == null) {
                linearLayout = (LinearLayout) ActivityDriversBrowser.this.getLayoutInflater().inflate(R.layout.list_item_docs, viewGroup, false);
            }
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.image);
            TextView textView = (TextView) linearLayout.findViewById(R.id.name);
            int i2 = ((Entry) this.entries.get(i)).type_rid;
            if (imageView.getTag() == null || i2 != ((Integer) imageView.getTag()).intValue()) {
                imageView.setTag(Integer.valueOf(i2));
                imageView.setImageResource(i2);
            }
            linearLayout.setTag(Integer.valueOf(i));
            textView.setText(((Entry) this.entries.get(i)).name);
            return linearLayout;
        }

        public boolean isEmpty() {
            return this.entries.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.title_choose_printer_model);
        this.data = new Vector<>();
        this.adapter = new FolderAdapter();
        findViewById(R.id.bottom).setVisibility(8);
        ListView listView = (ListView) findViewById(R.id.list);
        this.list = listView;
        listView.setAdapter(this.adapter);
        this.list.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Entry entry = (Entry) ActivityDriversBrowser.this.adapter.getItem(((Integer) view.getTag()).intValue());
                if (entry.data != null) {
                    if (!"..".equals(entry.name)) {
                        ActivityDriversBrowser.this.adapter.changeFolder(entry);
                    } else {
                        ActivityDriversBrowser.this.adapter.changeFolder(ActivityDriversBrowser.this.adapter.chain.size() > 1 ? (Entry) ActivityDriversBrowser.this.adapter.chain.get(ActivityDriversBrowser.this.adapter.chain.size() - 2) : null);
                    }
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("model", entry.name);
                    Intent intent = new Intent();
                    intent.putExtras(bundle);
                    ActivityDriversBrowser.this.setResult(-1, intent);
                    ActivityDriversBrowser.this.finish();
                }
            }
        });
        showProgress(getResources().getString(R.string.label_processing));
        AnonymousClass2 r2 = new Thread() {
            public void run() {
                String str;
                String str2;
                String str3;
                int size;
                String str4;
                String str5;
                Entry entry;
                Entry entry2;
                TreeMap treeMap = new TreeMap();
                for (String str6 : ActivityCore.exact_generic_models) {
                    treeMap.put(str6.toLowerCase(), str6);
                }
                for (String append : ActivityCore.generic_models) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Generic ");
                    sb.append(append);
                    String sb2 = sb.toString();
                    treeMap.put(sb2.toLowerCase(), sb2);
                }
                int i = 0;
                while (true) {
                    str = "Brother ";
                    if (i >= ActivityCore.brother_laser_models.length) {
                        break;
                    }
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(str);
                    sb3.append(ActivityCore.brother_laser_models[i]);
                    String sb4 = sb3.toString();
                    treeMap.put(sb4.toLowerCase(), sb4);
                    i++;
                }
                for (String append2 : ActivityCore.brother_inkjet_models_bh9) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(str);
                    sb5.append(append2);
                    String sb6 = sb5.toString();
                    treeMap.put(sb6.toLowerCase(), sb6);
                }
                for (String append3 : ActivityCore.brother_inkjet_models_bh11) {
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append(str);
                    sb7.append(append3);
                    String sb8 = sb7.toString();
                    treeMap.put(sb8.toLowerCase(), sb8);
                }
                for (String append4 : ActivityCore.brother_inkjet_models_bhs13) {
                    StringBuilder sb9 = new StringBuilder();
                    sb9.append(str);
                    sb9.append(append4);
                    String sb10 = sb9.toString();
                    treeMap.put(sb10.toLowerCase(), sb10);
                }
                for (String append5 : ActivityCore.brother_pjmw_models) {
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(str);
                    sb11.append(append5);
                    String sb12 = sb11.toString();
                    treeMap.put(sb12.toLowerCase(), sb12);
                }
                for (String append6 : ActivityCore.able_models) {
                    StringBuilder sb13 = new StringBuilder();
                    sb13.append("Able ");
                    sb13.append(append6);
                    String sb14 = sb13.toString();
                    treeMap.put(sb14.toLowerCase(), sb14);
                }
                for (String append7 : ActivityCore.canon_models) {
                    StringBuilder sb15 = new StringBuilder();
                    sb15.append("Canon ");
                    sb15.append(append7);
                    String sb16 = sb15.toString();
                    treeMap.put(sb16.toLowerCase(), sb16);
                }
                int i2 = 0;
                while (true) {
                    str2 = "KODAK ";
                    if (i2 >= ActivityCore.kodak_gziptok_models.length) {
                        break;
                    }
                    StringBuilder sb17 = new StringBuilder();
                    sb17.append(str2);
                    sb17.append(ActivityCore.kodak_gziptok_models[i2]);
                    String sb18 = sb17.toString();
                    treeMap.put(sb18.toLowerCase(), sb18);
                    i2++;
                }
                for (String append8 : ActivityCore.kodak_jbig_models) {
                    StringBuilder sb19 = new StringBuilder();
                    sb19.append(str2);
                    sb19.append(append8);
                    String sb20 = sb19.toString();
                    treeMap.put(sb20.toLowerCase(), sb20);
                }
                int i3 = 0;
                while (true) {
                    str3 = "Kyocera ";
                    if (i3 >= ActivityCore.kyocera_pcl5e_models.length) {
                        break;
                    }
                    StringBuilder sb21 = new StringBuilder();
                    sb21.append(str3);
                    sb21.append(ActivityCore.kyocera_pcl5e_models[i3]);
                    String sb22 = sb21.toString();
                    treeMap.put(sb22.toLowerCase(), sb22);
                    i3++;
                }
                for (String append9 : ActivityCore.kyocera_pcl5c_models) {
                    StringBuilder sb23 = new StringBuilder();
                    sb23.append(str3);
                    sb23.append(append9);
                    String sb24 = sb23.toString();
                    treeMap.put(sb24.toLowerCase(), sb24);
                }
                for (String append10 : ActivityCore.oki_ml_9pin_models) {
                    StringBuilder sb25 = new StringBuilder();
                    sb25.append("OKI ML ");
                    sb25.append(append10);
                    String sb26 = sb25.toString();
                    treeMap.put(sb26.toLowerCase(), sb26);
                }
                for (String append11 : ActivityCore.ricoh_models) {
                    StringBuilder sb27 = new StringBuilder();
                    sb27.append("Ricoh ");
                    sb27.append(append11);
                    String sb28 = sb27.toString();
                    treeMap.put(sb28.toLowerCase(), sb28);
                }
                AssetManager assets = ActivityDriversBrowser.this.getAssets();
                for (int i4 = 0; i4 < ActivityCore.ext_drivers.length; i4++) {
                    try {
                        StringBuilder sb29 = new StringBuilder();
                        sb29.append("data/");
                        sb29.append(ActivityCore.ext_drivers[i4]);
                        sb29.append(".dat");
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(assets.open(sb29.toString())), 8192);
                        bufferedReader.readLine();
                        bufferedReader.readLine();
                        while (true) {
                            String readLine = bufferedReader.readLine();
                            if (readLine == null || readLine.length() <= 0) {
                                bufferedReader.close();
                            } else {
                                String substring = readLine.substring(0, readLine.indexOf("|"));
                                int indexOf = substring.indexOf(";");
                                if (indexOf >= 0) {
                                    substring = substring.substring(0, indexOf);
                                }
                                String lowerCase = substring.toLowerCase();
                                if (treeMap.get(lowerCase) == null) {
                                    treeMap.put(lowerCase, substring);
                                }
                            }
                        }
                        bufferedReader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
                Vector vector = new Vector();
                for (String str7 : treeMap.keySet()) {
                    Entry entry3 = new Entry((String) treeMap.get(str7), false);
                    while (true) {
                        size = vector.size() - 1;
                        str4 = "-";
                        str5 = " ";
                        if (size < 0) {
                            break;
                        }
                        String lowerCase2 = ((Entry) vector.get(size)).name.toLowerCase();
                        if (str7.startsWith(lowerCase2) && (str7.startsWith(lowerCase2.concat(str5)) || str7.startsWith(lowerCase2.concat(str4)))) {
                            break;
                        }
                        Entry entry4 = (Entry) vector.remove(size);
                        if (entry4.data.size() == 1 && vector.size() > 0) {
                            Entry entry5 = (Entry) entry4.data.elementAt(0);
                            entry4.name = entry5.name;
                            entry4.type_rid = entry5.type_rid;
                            entry4.data = entry5.data;
                        }
                    }
                    if (size < 2) {
                        int indexOf2 = entry3.name.indexOf(str5);
                        if (indexOf2 > 0) {
                            if (size < 0) {
                                entry = new Entry(entry3.name.substring(0, indexOf2).trim(), true);
                                if (ActivityDriversBrowser.this.data.size() > 0) {
                                    Entry entry6 = (Entry) ActivityDriversBrowser.this.data.lastElement();
                                    if (entry6.data == null && entry6.name.equalsIgnoreCase(entry.name)) {
                                        entry.data.add(ActivityDriversBrowser.this.data.remove(ActivityDriversBrowser.this.data.size() - 1));
                                    }
                                }
                                ActivityDriversBrowser.this.data.add(entry);
                                vector.add(entry);
                            } else {
                                entry = (Entry) vector.get(0);
                            }
                            int i5 = indexOf2 + 1;
                            int indexOf3 = entry3.name.indexOf(str5, i5);
                            int indexOf4 = entry3.name.indexOf(str4, i5);
                            if (indexOf3 < 0 || (indexOf4 > 0 && indexOf4 < indexOf3)) {
                                indexOf3 = indexOf4;
                            }
                            if (indexOf3 > 0) {
                                if (size < 1) {
                                    entry2 = new Entry(entry3.name.substring(0, indexOf3).trim(), true);
                                    if (entry.data.size() > 0) {
                                        Entry entry7 = (Entry) entry.data.lastElement();
                                        if (entry7.data == null && entry7.name.equalsIgnoreCase(entry2.name)) {
                                            entry2.data.add(entry.data.remove(entry.data.size() - 1));
                                        }
                                        if (entry7.data != null && entry7.data.size() == 1) {
                                            entry.data.set(entry.data.size() - 1, entry7.data.get(0));
                                        }
                                    }
                                    entry.data.add(entry2);
                                    vector.add(entry2);
                                } else {
                                    entry2 = (Entry) vector.get(1);
                                }
                                int indexOf5 = entry3.name.indexOf(str5, indexOf3 + 1);
                                if (indexOf5 > 0) {
                                    Entry entry8 = new Entry(entry3.name.substring(0, indexOf5).trim(), true);
                                    if (entry2.data.size() > 0) {
                                        Entry entry9 = (Entry) entry2.data.lastElement();
                                        if (entry9.data == null && entry9.name.equalsIgnoreCase(entry8.name)) {
                                            entry8.data.add(entry2.data.remove(entry2.data.size() - 1));
                                        }
                                        if (entry9.data != null && entry9.data.size() == 1) {
                                            entry2.data.set(entry2.data.size() - 1, entry9.data.get(0));
                                        }
                                    }
                                    entry2.data.add(entry8);
                                    vector.add(entry8);
                                }
                            }
                        }
                        size = vector.size() - 1;
                    }
                    if (size < 0) {
                        ActivityDriversBrowser.this.data.add(entry3);
                    } else {
                        ((Entry) vector.get(size)).data.add(entry3);
                    }
                }
                ActivityDriversBrowser.this.wt = null;
                ActivityDriversBrowser.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityDriversBrowser.this.adapter.changeFolder(null);
                        ActivityDriversBrowser.this.hideProgress();
                    }
                });
            }
        };
        this.wt = r2;
        r2.start();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || this.adapter.chain.size() <= 0) {
            return super.onKeyDown(i, keyEvent);
        }
        FolderAdapter folderAdapter = this.adapter;
        folderAdapter.changeFolder(folderAdapter.chain.size() > 1 ? (Entry) this.adapter.chain.get(this.adapter.chain.size() - 2) : null);
        return true;
    }
}
