package com.dynamixsoftware.printershare;

import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.lang.reflect.Field;

public class ActivityHelp extends ActivityRoot {
    /* access modifiers changed from: private */
    public Request request;
    private WebView wv;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.help);
        setTitle((int) R.string.header_help);
        WebView webView = (WebView) findViewById(R.id.help_view);
        this.wv = webView;
        webView.getSettings().setJavaScriptEnabled(true);
        this.wv.getSettings().setBlockNetworkImage(false);
        this.wv.getSettings().setLoadsImagesAutomatically(true);
        this.wv.getSettings().setSupportMultipleWindows(false);
        this.wv.getSettings().setBuiltInZoomControls(true);
        this.wv.getSettings().setSupportZoom(true);
        this.wv.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView webView, final int i) {
                if (i == 100) {
                    ActivityHelp.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityHelp.this.hideProgress();
                        }
                    });
                } else if (i == 0) {
                    ActivityHelp.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityHelp.this.showProgress(ActivityHelp.this.getResources().getString(R.string.label_loading));
                        }
                    });
                } else {
                    ActivityHelp.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityHelp activityHelp = ActivityHelp.this;
                            String string = ActivityHelp.this.getResources().getString(R.string.label_loading_progress);
                            StringBuilder sb = new StringBuilder();
                            sb.append(i);
                            sb.append("%");
                            activityHelp.showProgress(String.format(string, new Object[]{sb.toString()}));
                        }
                    });
                }
            }
        });
        this.wv.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (str == null || !str.startsWith("mailto:")) {
                    return false;
                }
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("plain/text");
                int indexOf = str.indexOf("?");
                String[] strArr = new String[1];
                if (indexOf <= 0) {
                    indexOf = str.length();
                }
                strArr[0] = str.substring(7, indexOf);
                intent.putExtra("android.intent.extra.EMAIL", strArr);
                int indexOf2 = str.indexOf("subject=");
                if (indexOf2 > 0) {
                    intent.putExtra("android.intent.extra.SUBJECT", str.substring(indexOf2 + 8));
                }
                ActivityHelp activityHelp = ActivityHelp.this;
                activityHelp.startActivity(Intent.createChooser(intent, activityHelp.getResources().getString(R.string.button_send_feedback)));
                return true;
            }

            public void onPageFinished(WebView webView, String str) {
                ActivityHelp.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityHelp.this.hideProgress();
                    }
                });
            }
        });
        this.wv.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                final boolean[] zArr = new boolean[2];
                try {
                    Field field = VERSION.class.getField("SDK_INT");
                    if (field.getInt(null) >= 11) {
                        zArr[0] = true;
                    }
                    if (field.getInt(null) >= 23) {
                        zArr[1] = true;
                    }
                } catch (NoSuchFieldException unused) {
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
                if (zArr[0]) {
                    final String str5 = str;
                    final String str6 = str4;
                    final String str7 = str2;
                    final String str8 = str3;
                    new Object() {
                        {
                            ActivityHelp.this.request = new Request(Uri.parse(str5));
                            ActivityHelp.this.request.setMimeType(str6);
                            ActivityHelp.this.request.addRequestHeader("cookie", CookieManager.getInstance().getCookie(str5));
                            ActivityHelp.this.request.addRequestHeader("User-Agent", str7);
                            ActivityHelp.this.request.setTitle(URLUtil.guessFileName(str5, str8, str6));
                            ActivityHelp.this.request.allowScanningByMediaScanner();
                            ActivityHelp.this.request.setNotificationVisibility(1);
                            ActivityHelp.this.request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(str5, str8, str6));
                            if (zArr[1]) {
                                new Object() {
                                    {
                                        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
                                        if (ActivityHelp.this.checkSelfPermission(str) != 0) {
                                            ActivityHelp.this.requestPermissions(new String[]{str}, 444555);
                                        } else {
                                            ActivityHelp.this.startDownload();
                                        }
                                    }
                                };
                            } else {
                                ActivityHelp.this.startDownload();
                            }
                        }
                    };
                    return;
                }
                ActivityHelp.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            }
        });
        String stringExtra = getIntent().getStringExtra("HELP_URL");
        if (stringExtra == null || stringExtra.isEmpty()) {
            stringExtra = "http://www.printershare.com/help?topic=android-index";
        }
        this.wv.loadUrl(stringExtra);
    }

    /* access modifiers changed from: private */
    public void startDownload() {
        if (this.request != null) {
            ((DownloadManager) getSystemService("download")).enqueue(this.request);
        }
        this.request = null;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            this.request = null;
        } else {
            startDownload();
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !this.wv.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.wv.goBack();
        return true;
    }
}
