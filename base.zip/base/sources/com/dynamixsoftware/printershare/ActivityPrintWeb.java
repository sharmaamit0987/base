package com.dynamixsoftware.printershare;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Picture;
import android.graphics.Rect;
import android.os.Bundle;
import com.dynamixsoftware.printershare.ActivityPrint.Page;
import java.util.Vector;

public class ActivityPrintWeb extends ActivityPrint {
    protected Picture pic;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.pic = ActivityWeb.pp;
        ActivityWeb.pp = null;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x010e A[LOOP:0: B:75:0x010c->B:76:0x010e, LOOP_END] */
    public void createPages() {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        this.pages = new Vector();
        Picture picture = this.pic;
        if (picture != null) {
            int width = picture.getWidth();
            int height = this.pic.getHeight();
            int i8 = this.paper.width;
            int i9 = this.paper.roll ? this.paper.height_orig : this.paper.height;
            boolean z = i8 > i9;
            int i10 = (i8 < i9 ? i8 : i9) / 15;
            if (this.margins == 0) {
                i10 = 0;
            } else if (this.margins == 1) {
                i10 /= 2;
            } else if (this.margins == 3) {
                i10 = (i10 * 3) / 2;
            }
            int i11 = ((this.paper.margin_left > i10 ? this.paper.margin_left : i10) * 96) / 254;
            int i12 = ((this.paper.margin_right > i10 ? this.paper.margin_right : i10) * 96) / 254;
            int i13 = ((this.paper.margin_top > i10 ? this.paper.margin_top : i10) * 96) / 254;
            if (this.paper.margin_bottom > i10) {
                i10 = this.paper.margin_bottom;
            }
            int i14 = (i10 * 96) / 254;
            int i15 = (i8 * 96) / 254;
            int i16 = (i9 * 96) / 254;
            if (!((this.orientation == 2 || (this.orientation == 0 && width > height)) ^ z)) {
                i = i14;
                i14 = i12;
                i2 = i13;
                i3 = i15;
                i15 = i16;
                i13 = i11;
            } else if (!this.paper.isLandscape270 ? !z : z) {
                i = i11;
                i2 = i12;
                i3 = i16;
            } else {
                i2 = i11;
                i = i12;
                i3 = i16;
                int i17 = i13;
                i13 = i14;
                i14 = i17;
            }
            int i18 = i3 - (i14 + i13);
            int i19 = i2 + i;
            int i20 = i15 - i19;
            if (width >= i18 || height >= i20) {
                if (width > height) {
                    i7 = (height * i18) / width;
                } else if (width >= i18) {
                    i7 = (height * i18) / width;
                }
                i5 = i18;
                i4 = i7;
                if (this.paper.roll) {
                    if (!((this.orientation == 2 || (this.orientation == 0 && width > height)) ^ z)) {
                        i15 = i4 + i2 + i;
                        this.paper.height = (i15 * 254) / 96;
                    }
                }
                int i21 = i15;
                i6 = i4;
                int i22 = 0;
                while (i6 > 0) {
                    final int i23 = i13;
                    final int i24 = i2;
                    final int i25 = i22;
                    final int i26 = i;
                    final int i27 = i5;
                    AnonymousClass1 r10 = r0;
                    final int i28 = i4;
                    int i29 = i13;
                    int i30 = i21;
                    final int i31 = i6;
                    AnonymousClass1 r0 = new Picture() {
                        public void draw(Canvas canvas) {
                            int width = getWidth();
                            int height = getHeight();
                            canvas.drawColor(-1);
                            Picture picture = ActivityPrintWeb.this.pic;
                            int i = i23;
                            int i2 = i24;
                            int i3 = i25;
                            int i4 = i26;
                            canvas.drawPicture(picture, new Rect(i, i2 - ((height - (i2 + i4)) * i3), i27 + i, (i28 + i2) - (i3 * (height - (i2 + i4)))));
                            Paint newPaint = App.newPaint();
                            newPaint.setColor(-1);
                            newPaint.setStyle(Style.FILL);
                            int i5 = (height - (i24 + i26)) - i31;
                            canvas.drawRect(new Rect(0, 0, width, i24), newPaint);
                            int i6 = height - i26;
                            if (i5 <= 0) {
                                i5 = 0;
                            }
                            canvas.drawRect(new Rect(0, i6 - i5, width, height), newPaint);
                        }
                    };
                    r10.beginRecording(i3, i30);
                    r10.endRecording();
                    this.pages.add(new Page((Picture) r10));
                    i6 -= i30 - i19;
                    i22++;
                    i21 = i30;
                    i13 = i29;
                }
            }
            i5 = width;
            i4 = height;
            if (this.paper.roll) {
            }
            int i212 = i15;
            i6 = i4;
            int i222 = 0;
            while (i6 > 0) {
            }
        }
    }
}
