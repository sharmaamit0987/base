package com.dynamixsoftware.printershare;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import com.flurry.android.FlurryAgent;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Hashtable;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public abstract class ActivityRoot extends Activity {
    private ProgressDialog current_progress_dialog;
    private boolean finishing;
    protected String last_error;
    protected SharedPreferences prefs;
    protected boolean skip_update;

    /* access modifiers changed from: protected */
    public Activity getActivity() {
        return this;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    /* access modifiers changed from: protected */
    public void update() {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        setTitleEx();
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        setTitleEx();
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x004c  */
    private void setTitleEx() {
        boolean z;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 11) {
                z = true;
                float f = getResources().getDisplayMetrics().density;
                if (!z) {
                    View findViewById = findViewById(16908332);
                    if (findViewById != null && findViewById.getPaddingRight() == 0) {
                        findViewById.setPadding(findViewById.getPaddingLeft(), findViewById.getPaddingTop(), (int) (f * 5.0f), findViewById.getPaddingBottom());
                        return;
                    }
                    return;
                }
                TextView textView = (TextView) findViewById(16908310);
                if (textView != null) {
                    textView.setCompoundDrawablePadding((int) (f * 5.0f));
                    textView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_title, 0, 0, 0);
                    textView.invalidate();
                    return;
                }
                return;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        z = false;
        float f2 = getResources().getDisplayMetrics().density;
        if (!z) {
        }
    }

    public void showProgress() {
        showProgress(null);
    }

    public void showProgress(String str) {
        if (this.current_progress_dialog == null && !isFinishing()) {
            ProgressDialog progressDialog = new ProgressDialog(getActivity());
            this.current_progress_dialog = progressDialog;
            progressDialog.setIndeterminate(true);
            this.current_progress_dialog.setCancelable(false);
            this.current_progress_dialog.show();
        }
        ProgressDialog progressDialog2 = this.current_progress_dialog;
        if (progressDialog2 != null) {
            if (str == null) {
                str = "";
            }
            progressDialog2.setMessage(str);
        }
    }

    public void hideProgress() {
        if (this.current_progress_dialog != null && !isFinishing()) {
            this.current_progress_dialog.dismiss();
            this.current_progress_dialog = null;
        }
    }

    public void displayLastError(OnClickListener onClickListener) {
        displayLastError(onClickListener, false);
    }

    public void displayLastError(OnClickListener onClickListener, boolean z) {
        String str;
        if (!isFinishing()) {
            String str2 = this.last_error;
            if (str2 != null) {
                int indexOf = str2.indexOf(":");
                if (indexOf < 0) {
                    str = "Error";
                } else {
                    str = this.last_error.substring(0, indexOf).trim();
                }
                SpannableString spannableString = new SpannableString(this.last_error.substring(indexOf + 1).trim());
                if (z) {
                    Linkify.addLinks(spannableString, 1);
                }
                this.last_error = null;
                AlertDialog show = new Builder(getActivity()).setIcon(R.drawable.icon_title).setTitle(str).setMessage(spannableString).setNeutralButton(R.string.button_ok, onClickListener).setCancelable(false).show();
                if (z) {
                    ((TextView) show.findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x00a4 A[SYNTHETIC, Splitter:B:20:0x00a4] */
    private void logVersion() {
        String str;
        SharedPreferences sharedPreferences;
        StringBuilder sb;
        final String[] strArr = {"fr".concat("ee")};
        Billing.action.run(null, new Runnable() {
            public void run() {
                strArr[0] = "pr".concat("emi").concat("um");
            }
        });
        String campaignID = getCampaignID();
        String str2 = "";
        String str3 = str2.equals(campaignID) ? "default" : campaignID;
        SharedPreferences sharedPreferences2 = this.prefs;
        StringBuilder sb2 = new StringBuilder();
        String str4 = "campaign_";
        sb2.append(str4);
        sb2.append(strArr[0]);
        if (!str3.equals(sharedPreferences2.getString(sb2.toString(), null))) {
            try {
                PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 64);
                if (!(packageInfo == null || packageInfo.signatures == null || packageInfo.signatures.length <= 0)) {
                    str = ((X509Certificate) CertificateFactory.getInstance("X509").generateCertificate(new ByteArrayInputStream(packageInfo.signatures[0].toByteArray()))).getIssuerDN().getName();
                    sharedPreferences = this.prefs;
                    sb = new StringBuilder();
                    sb.append(str4);
                    sb.append(strArr[0]);
                    if (sharedPreferences.getString(sb.toString(), null) == null) {
                        try {
                            Hashtable hashtable = new Hashtable();
                            String str5 = "certname";
                            if (str == null) {
                                str = str2;
                            }
                            hashtable.put(str5, str);
                            hashtable.put("cpu_abi", App.getRawCPUABI());
                            hashtable.put("country", App.getUserCountry());
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append("version_");
                            sb3.append(strArr[0]);
                            if (campaignID.length() > 0) {
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append("_");
                                sb4.append(campaignID);
                                str2 = sb4.toString();
                            }
                            sb3.append(str2);
                            FlurryAgent.logEvent(sb3.toString(), (Map<String, String>) hashtable);
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    }
                    Editor edit = this.prefs.edit();
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(str4);
                    sb5.append(strArr[0]);
                    edit.putString(sb5.toString(), str3);
                    edit.commit();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
            str = null;
            sharedPreferences = this.prefs;
            sb = new StringBuilder();
            sb.append(str4);
            sb.append(strArr[0]);
            if (sharedPreferences.getString(sb.toString(), null) == null) {
            }
            Editor edit2 = this.prefs.edit();
            StringBuilder sb52 = new StringBuilder();
            sb52.append(str4);
            sb52.append(strArr[0]);
            edit2.putString(sb52.toString(), str3);
            edit2.commit();
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (!this.skip_update) {
            try {
                String simpleName = getClass().getSimpleName();
                if (simpleName.startsWith("ActivityMain") || simpleName.startsWith("ActivityPrint")) {
                    Billing.checkPremiumKey(this);
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            update();
        }
        this.skip_update = false;
        logVersion();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        FlurryAgent.logEvent(getActivityClassName());
    }

    /* access modifiers changed from: protected */
    public String getActivityClassName() {
        String simpleName = getClass().getSimpleName();
        String str = "";
        int i = 0;
        String str2 = str;
        while (i < simpleName.length()) {
            int i2 = i + 1;
            String substring = simpleName.substring(i, i2);
            String lowerCase = substring.toLowerCase();
            StringBuilder sb = new StringBuilder();
            sb.append(str2);
            sb.append(substring.equals(lowerCase) ? str : "_");
            sb.append(lowerCase);
            str2 = sb.toString();
            i = i2;
        }
        return str2.length() > 1 ? str2.substring(1) : str2;
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        this.finishing = true;
        ProgressDialog progressDialog = this.current_progress_dialog;
        if (progressDialog != null) {
            progressDialog.dismiss();
            this.current_progress_dialog = null;
        }
    }

    public void finish() {
        this.finishing = true;
        super.finish();
    }

    public boolean isFinishing() {
        return this.finishing || super.isFinishing();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        Billing.onActivityResult(this, i, i2, intent);
    }

    public String getVendorID() {
        try {
            String packageName = getPackageName();
            int indexOf = packageName.indexOf(".", packageName.indexOf(".printershare") + 1);
            if (indexOf > 0) {
                String substring = packageName.substring(indexOf + 1);
                if (substring.length() > 0) {
                    return substring;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        return null;
    }

    public String getCampaignID() {
        String vendorID = getVendorID();
        if (vendorID != null) {
            return vendorID;
        }
        String str = "campaign_id";
        String string = this.prefs.getString(str, null);
        String str2 = "CID";
        if (string == null) {
            try {
                DataInputStream dataInputStream = new DataInputStream(getAssets().open(str2));
                String readLine = dataInputStream.readLine();
                dataInputStream.close();
                if (readLine != null && readLine.length() > 0) {
                    string = readLine;
                }
            } catch (FileNotFoundException unused) {
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
        if (string == null) {
            try {
                File[] listFiles = new File("/system/app").listFiles();
                if (listFiles != null) {
                    int i = 0;
                    while (true) {
                        if (i >= listFiles.length) {
                            break;
                        } else if (listFiles[i].getName().toLowerCase().indexOf(BuildConfig.FLAVOR_base) >= 0) {
                            FileInputStream fileInputStream = new FileInputStream(listFiles[i]);
                            ZipInputStream zipInputStream = new ZipInputStream(fileInputStream);
                            while (true) {
                                ZipEntry nextEntry = zipInputStream.getNextEntry();
                                if (nextEntry == null) {
                                    break;
                                } else if (nextEntry.getName().endsWith(str2)) {
                                    DataInputStream dataInputStream2 = new DataInputStream(zipInputStream);
                                    String readLine2 = dataInputStream2.readLine();
                                    dataInputStream2.close();
                                    if (readLine2 != null && readLine2.length() > 0) {
                                        string = readLine2;
                                    }
                                }
                            }
                            fileInputStream.close();
                        } else {
                            i++;
                        }
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }
        if (string == null) {
            string = "";
        }
        Editor edit = this.prefs.edit();
        edit.putString(str, string);
        edit.commit();
        return string;
    }

    public final String getTitleSuffix() {
        final String[] strArr = new String[1];
        Billing.action.run(new Runnable() {
            public void run() {
                strArr[0] = "";
            }
        }, new Runnable() {
            public void run() {
                String[] strArr = strArr;
                StringBuilder sb = new StringBuilder();
                sb.append(" ");
                sb.append(ActivityRoot.this.getString(R.string.label_premium));
                strArr[0] = sb.toString();
            }
        });
        return strArr[0];
    }
}
