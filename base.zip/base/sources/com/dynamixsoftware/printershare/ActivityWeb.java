package com.dynamixsoftware.printershare;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Picture;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.HttpAuthHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class ActivityWeb extends ActivityRoot {
    static final int DIALOG_BOOKMARKS = 0;
    public static volatile Picture pp;
    private Button buttonGo;
    private DialogBookmarks dialogBookmarks = null;
    private EditText enterUri;
    Thread lt;
    /* access modifiers changed from: private */
    public WebView webView;

    protected class BookmarksMenuAdapter extends BaseAdapter {
        LayoutInflater factory;
        Context mContext;
        private ArrayList<BookmarksMenuItem> mItems = new ArrayList<>();

        public long getItemId(int i) {
            return 0;
        }

        public BookmarksMenuAdapter(Context context) {
            this.factory = LayoutInflater.from(context);
            this.mContext = context;
        }

        public void addItem(String str, String str2, Bitmap bitmap) {
            this.mItems.add(new BookmarksMenuItem(str, str2, bitmap));
        }

        public int getCount() {
            return this.mItems.size();
        }

        public Object getItem(int i) {
            if (i < this.mItems.size()) {
                return this.mItems.get(i);
            }
            return null;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            BookmarksMenuItem bookmarksMenuItem = (BookmarksMenuItem) getItem(i);
            View inflate = this.factory.inflate(R.layout.dialog_bookmarks, null);
            ((TextView) inflate.findViewById(R.id.bookmark_title)).setText(bookmarksMenuItem.getTitle());
            ((TextView) inflate.findViewById(R.id.bookmark_url)).setText(bookmarksMenuItem.getUrl());
            ((ImageView) inflate.findViewById(R.id.bookmark_favicon)).setImageBitmap(bookmarksMenuItem.getIcon());
            return inflate;
        }

        public void addItem(BookmarksMenuItem bookmarksMenuItem) {
            this.mItems.add(bookmarksMenuItem);
        }

        public void removeAll() {
            this.mItems.clear();
        }
    }

    protected class BookmarksMenuItem {
        private Bitmap icon;
        private String title;
        private String url;

        public BookmarksMenuItem(String str, String str2, Bitmap bitmap) {
            this.title = str;
            this.url = str2;
            this.icon = bitmap;
        }

        public String getTitle() {
            return this.title;
        }

        public String getUrl() {
            return this.url;
        }

        public Bitmap getIcon() {
            return this.icon;
        }
    }

    public class DialogBookmarks implements OnCancelListener, OnDismissListener {
        /* access modifiers changed from: private */
        public BookmarksMenuAdapter menuAdapter;
        ActivityWeb parentActivity;

        public void onCancel(DialogInterface dialogInterface) {
        }

        public void onDismiss(DialogInterface dialogInterface) {
        }

        public DialogBookmarks(ActivityWeb activityWeb) {
            this.parentActivity = activityWeb;
        }

        public Dialog createMenu(String str) {
            this.menuAdapter = new BookmarksMenuAdapter(this.parentActivity);
            Builder builder = new Builder(this.parentActivity);
            builder.setIcon(R.drawable.icon_title);
            builder.setTitle(str);
            builder.setAdapter(this.menuAdapter, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityWeb.this.getEnterUri().setText(((BookmarksMenuItem) DialogBookmarks.this.menuAdapter.getItem(i)).getUrl());
                    ActivityWeb.this.goUrl();
                }
            });
            AlertDialog create = builder.create();
            create.setOnCancelListener(this);
            create.setOnDismissListener(this);
            return create;
        }

        public void refreshMenu() {
            this.menuAdapter.removeAll();
            Cursor query = this.parentActivity.getContentResolver().query(Uri.parse("content://browser/bookmarks"), new String[]{"title", "url", "favicon"}, "bookmark=1", null, "created ASC");
            if (query != null) {
                while (query.moveToNext()) {
                    byte[] blob = query.getBlob(2);
                    String string = query.getString(1);
                    if (!(string == null || string.length() == 0)) {
                        if (blob != null) {
                            this.menuAdapter.addItem(query.getString(0), string, BitmapFactory.decodeByteArray(blob, 0, blob.length));
                        } else {
                            this.menuAdapter.addItem(query.getString(0), string, null);
                        }
                    }
                }
                query.close();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        this.dialogBookmarks = new DialogBookmarks(this);
        setContentView(R.layout.web);
        setTitle((int) R.string.button_main_web_pages);
        setButtonGo((Button) findViewById(R.id.button_go));
        setEnterUri((EditText) findViewById(R.id.enter_url));
        setWebView((WebView) findViewById(R.id.web_view));
        ImageButton imageButton = (ImageButton) findViewById(R.id.button_favbookmarks);
        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityWeb.this.showDialog(0);
            }
        });
        String str2 = null;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                imageButton.setVisibility(8);
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        getEnterUri().setOnFocusChangeListener(new OnFocusChangeListener() {
            public void onFocusChange(View view, boolean z) {
                if (z) {
                    ActivityWeb.this.webView.clearFocus();
                    ActivityWeb.this.webView.onWindowFocusChanged(true);
                }
            }
        });
        this.webView.setWebChromeClient(new WebChromeClient() {
            public void onReceivedTitle(WebView webView, String str) {
            }

            public void onProgressChanged(WebView webView, final int i) {
                if (i == 100) {
                    ActivityWeb.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ((TextView) ActivityWeb.this.findViewById(R.id.hint1)).setText("");
                        }
                    });
                } else if (i == 0) {
                    ActivityWeb.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ((TextView) ActivityWeb.this.findViewById(R.id.hint1)).setText(R.string.label_loading);
                        }
                    });
                } else {
                    ActivityWeb.this.runOnUiThread(new Runnable() {
                        public void run() {
                            TextView textView = (TextView) ActivityWeb.this.findViewById(R.id.hint1);
                            String string = ActivityWeb.this.getResources().getString(R.string.label_loading_progress);
                            StringBuilder sb = new StringBuilder();
                            sb.append(i);
                            sb.append("%");
                            textView.setText(String.format(string, new Object[]{sb.toString()}));
                        }
                    });
                }
            }
        });
        this.webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                webView.loadUrl(str);
                return true;
            }

            public void onReceivedHttpAuthRequest(WebView webView, final HttpAuthHandler httpAuthHandler, String str, String str2) {
                String str3;
                String str4;
                if (httpAuthHandler.useHttpAuthUsernamePassword()) {
                    String[] httpAuthUsernamePassword = webView.getHttpAuthUsernamePassword(str, str2);
                    if (httpAuthUsernamePassword != null && httpAuthUsernamePassword.length == 2) {
                        str3 = httpAuthUsernamePassword[0];
                        str4 = httpAuthUsernamePassword[1];
                        if (str3 != null || str4 == null) {
                            final View inflate = LayoutInflater.from(ActivityWeb.this).inflate(R.layout.dialog_authorization, null);
                            new Builder(ActivityWeb.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_authorization_title).setView(inflate).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    String obj = ((EditText) inflate.findViewById(R.id.login_edit)).getText().toString();
                                    String obj2 = ((EditText) inflate.findViewById(R.id.password_edit)).getText().toString();
                                    if (obj != null && obj2 != null) {
                                        httpAuthHandler.proceed(obj, obj2);
                                    }
                                }
                            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    httpAuthHandler.cancel();
                                }
                            }).create().show();
                        }
                        httpAuthHandler.proceed(str3, str4);
                        return;
                    }
                }
                str4 = null;
                str3 = null;
                if (str3 != null) {
                }
                final View inflate2 = LayoutInflater.from(ActivityWeb.this).inflate(R.layout.dialog_authorization, null);
                new Builder(ActivityWeb.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_authorization_title).setView(inflate2).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String obj = ((EditText) inflate2.findViewById(R.id.login_edit)).getText().toString();
                        String obj2 = ((EditText) inflate2.findViewById(R.id.password_edit)).getText().toString();
                        if (obj != null && obj2 != null) {
                            httpAuthHandler.proceed(obj, obj2);
                        }
                    }
                }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        httpAuthHandler.cancel();
                    }
                }).create().show();
            }
        });
        this.webView.setHorizontalScrollBarEnabled(true);
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.getSettings().setBlockNetworkImage(false);
        this.webView.getSettings().setLoadsImagesAutomatically(true);
        this.webView.getSettings().setSupportMultipleWindows(false);
        this.webView.getSettings().setBuiltInZoomControls(true);
        this.webView.getSettings().setSupportZoom(true);
        this.webView.getSettings().setUseWideViewPort(true);
        this.webView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.NORMAL);
        getButtonGo().setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityWeb.this.goUrl();
            }
        });
        getEnterUri().setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (keyEvent.getAction() != 1 || i != 66) {
                    return false;
                }
                ActivityWeb.this.goUrl();
                return true;
            }
        });
        Button button = (Button) findViewById(R.id.button_print);
        button.setEnabled(false);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                WebView webView = ActivityWeb.this.getWebView();
                webView.scrollTo(0, 0);
                Picture capturePicture = webView.capturePicture();
                if (capturePicture != null) {
                    try {
                        ActivityWeb.pp = capturePicture;
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setClass(ActivityWeb.this, ActivityPrintWeb.class);
                        ActivityWeb.this.startActivityForResult(intent, 10);
                    } catch (Exception e) {
                        ActivityWeb.pp = null;
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
            }
        });
        Intent intent = getIntent();
        boolean equals = "android.intent.action.SEND".equals(intent.getAction());
        String str3 = "content://com.android.htmlfileprovider";
        String str4 = NanoHTTPD.MIME_PLAINTEXT;
        if (equals) {
            String type = intent.getType();
            Bundle extras = intent.getExtras();
            Object obj = extras != null ? extras.get("android.intent.extra.TEXT") : null;
            if (obj != null) {
                str2 = obj.toString();
            }
            String str5 = str2;
            if (str5 != null) {
                findViewById(R.id.url_bar).setVisibility(8);
                findViewById(R.id.button_print).setEnabled(true);
                if (!str4.equals(type)) {
                    getWebView().loadDataWithBaseURL(null, str5, type, "UTF-8", null);
                } else if (str5.startsWith("http:") || str5.startsWith("https:")) {
                    getWebView().loadUrl(str5);
                } else if (str5.startsWith("file:")) {
                    if (Integer.parseInt(VERSION.SDK) < 8) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(str3);
                        sb.append(Uri.parse(str5).getEncodedPath());
                        str5 = sb.toString();
                    }
                    getWebView().loadUrl(str5);
                } else {
                    WebView webView2 = getWebView();
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("<html><head><meta name=\"viewport\" content=\"width=650, target-densitydpi=medium-dpi\"></head><body><pre style=\"font-size:12pt; white-space:pre-wrap\">");
                    sb2.append(str5.replaceAll("\\<", "&lt;").replaceAll("\\>", "&gt;"));
                    sb2.append("</pre></body></html>");
                    webView2.loadDataWithBaseURL(null, sb2.toString(), NanoHTTPD.MIME_HTML, "UTF-8", null);
                }
            } else {
                setResult(0);
                finish();
            }
        }
        if ("android.intent.action.VIEW".equals(intent.getAction())) {
            final Uri data = intent.getData();
            if (data != null) {
                String type2 = intent.getType();
                String type3 = getContentResolver().getType(data);
                if (type2 == null) {
                    type2 = type3;
                }
                findViewById(R.id.url_bar).setVisibility(8);
                findViewById(R.id.button_print).setEnabled(true);
                if (str4.equals(type2)) {
                    AnonymousClass8 r0 = new Thread() {
                        public void run() {
                            AnonymousClass2 r2;
                            ActivityWeb activityWeb;
                            try {
                                ActivityWeb.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityWeb.this.showProgress(ActivityWeb.this.getResources().getString(R.string.label_loading));
                                    }
                                });
                                Thread.sleep(500);
                                FileInputStream fileInputStream = new FileInputStream(ActivityWeb.this.getContentResolver().openFileDescriptor(data, "r").getFileDescriptor());
                                byte[] bArr = new byte[fileInputStream.available()];
                                fileInputStream.read(bArr);
                                fileInputStream.close();
                                WebView webView = ActivityWeb.this.getWebView();
                                StringBuilder sb = new StringBuilder();
                                sb.append("<html><head><meta name=\"viewport\" content=\"width=650, target-densitydpi=medium-dpi\"></head><body><pre style=\"font-size:12pt; white-space:pre-wrap\">");
                                sb.append(new String(bArr, "UTF-8").replaceAll("\\<", "&lt;").replaceAll("\\>", "&gt;"));
                                sb.append("</pre></body></html>");
                                webView.loadDataWithBaseURL(null, sb.toString(), NanoHTTPD.MIME_HTML, "UTF-8", null);
                                activityWeb = ActivityWeb.this;
                                r2 = new Runnable() {
                                    public void run() {
                                        ActivityWeb.this.hideProgress();
                                    }
                                };
                            } catch (Exception e) {
                                e.printStackTrace();
                                App.reportThrowable(e);
                                ActivityWeb.this.setResult(0);
                                ActivityWeb.this.finish();
                                activityWeb = ActivityWeb.this;
                                r2 = new Runnable() {
                                    public void run() {
                                        ActivityWeb.this.hideProgress();
                                    }
                                };
                            } catch (Throwable th) {
                                ActivityWeb.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityWeb.this.hideProgress();
                                    }
                                });
                                ActivityWeb.this.lt = null;
                                throw th;
                            }
                            activityWeb.runOnUiThread(r2);
                            ActivityWeb.this.lt = null;
                        }
                    };
                    this.lt = r0;
                    r0.start();
                    return;
                }
                if ("file".equals(data.getScheme())) {
                    if (Integer.parseInt(VERSION.SDK) < 8) {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(str3);
                        sb3.append(data.getEncodedPath());
                        sb3.append("?");
                        sb3.append(type2);
                        str = sb3.toString();
                    } else {
                        str = data.toString();
                    }
                    getWebView().loadUrl(str);
                    return;
                }
                final String uri = data.toString();
                if ("gmail-ls".equals(data.getHost())) {
                    getWebView().getSettings().setLoadsImagesAutomatically(false);
                    if (!NanoHTTPD.MIME_HTML.equals(type2)) {
                        showProgress(getResources().getString(R.string.label_loading));
                        new Thread() {
                            /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
                            /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x004c */
                            /* JADX WARNING: Removed duplicated region for block: B:16:0x0053 A[Catch:{ all -> 0x007e }, LOOP:0: B:4:0x0037->B:16:0x0053, LOOP_END] */
                            /* JADX WARNING: Removed duplicated region for block: B:28:0x0052 A[SYNTHETIC] */
                            public void run() {
                                int i;
                                try {
                                    String replace = uri.replace("BEST", "SIMPLE");
                                    ContentResolver contentResolver = ActivityWeb.this.getContentResolver();
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(replace);
                                    sb.append("/download");
                                    Cursor query = contentResolver.query(Uri.parse(sb.toString()), new String[]{"status"}, null, null, null);
                                    if (query != null) {
                                        int i2 = 0;
                                        i = 0;
                                        while (true) {
                                            if (i2 >= 1000) {
                                                break;
                                            }
                                            query.moveToFirst();
                                            i = query.getInt(0);
                                            if (i != 192) {
                                                break;
                                            }
                                            Thread.sleep(1000);
                                            if (query.requery()) {
                                                break;
                                            }
                                            i2++;
                                        }
                                        query.close();
                                    } else {
                                        i = 0;
                                    }
                                    if (i == 200) {
                                        ActivityWeb.this.getWebView().loadUrl(replace);
                                    } else {
                                        ActivityWeb.this.setResult(0);
                                        ActivityWeb.this.finish();
                                    }
                                } finally {
                                    ActivityWeb.this.runOnUiThread(new Runnable() {
                                        public void run() {
                                            ActivityWeb.this.hideProgress();
                                        }
                                    });
                                }
                            }
                        }.start();
                        return;
                    }
                    getWebView().loadUrl(uri);
                    return;
                }
                getWebView().loadUrl(uri);
            }
        }
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        if (i == 0) {
            return this.dialogBookmarks.createMenu(getResources().getString(R.string.dialog_bookmarks_title));
        }
        return super.onCreateDialog(i);
    }

    /* access modifiers changed from: protected */
    public void onPrepareDialog(int i, Dialog dialog) {
        if (i == 0) {
            this.dialogBookmarks.refreshMenu();
        }
    }

    public void setWebView(WebView webView2) {
        this.webView = webView2;
    }

    public WebView getWebView() {
        return this.webView;
    }

    public void setButtonGo(Button button) {
        this.buttonGo = button;
    }

    public Button getButtonGo() {
        return this.buttonGo;
    }

    public void setEnterUri(EditText editText) {
        this.enterUri = editText;
    }

    public EditText getEnterUri() {
        return this.enterUri;
    }

    /* access modifiers changed from: private */
    public void goUrl() {
        String obj = getEnterUri().getText().toString();
        if (obj.length() > 0) {
            if (obj.indexOf("://") < 0) {
                StringBuilder sb = new StringBuilder();
                sb.append("http://");
                sb.append(obj);
                obj = sb.toString();
            }
            getWebView().loadUrl(obj);
            findViewById(R.id.button_print).setEnabled(true);
        }
        try {
            View currentFocus = getCurrentFocus();
            if (currentFocus != null) {
                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
                if (inputMethodManager != null) {
                    inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, final int i2, Intent intent) {
        if (i == 10) {
            try {
                if (VERSION.class.getField("SDK_INT").getInt(null) >= 4) {
                    new Object() {
                        {
                            String str = ActivityWeb.this.getIntent().getPackage();
                            if (str != null && str.indexOf(BuildConfig.FLAVOR_base) > 0) {
                                ActivityWeb.this.setResult(i2);
                                ActivityWeb.this.finish();
                            }
                        }
                    };
                }
            } catch (NoSuchFieldException unused) {
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            return;
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onDestroy() {
        super.onDestroy();
        String stringExtra = getIntent().getStringExtra("temp_file");
        if (stringExtra != null && stringExtra.indexOf("printershare_temp_") > 0) {
            new File(stringExtra).delete();
        }
    }
}
