package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.SoapEnvelope;
import com.dynamixsoftware.printershare.data.XmlUtil;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Element;

public class ActivityPrinters extends ActivityCore {
    private static final int DIALOG_OWNER_DETAILS = 2;
    private static final int DIALOG_PRINTER_DETAILS = 1;
    /* access modifiers changed from: private */
    public Thread rt;
    /* access modifiers changed from: private */
    public View view_dialog_owner_details;
    /* access modifiers changed from: private */
    public View view_dialog_printer_details;

    class PrinterAdapter implements ListAdapter {
        public Context mContext;
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getItemViewType(int i) {
            return 1;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        public PrinterAdapter(Context context) {
            this.mContext = context;
        }

        public int getCount() {
            return ActivityCore.remote_printers.size();
        }

        public Object getItem(int i) {
            return ActivityCore.remote_printers.elementAt(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.printer, null);
            Printer printer = (Printer) ActivityCore.remote_printers.elementAt(i);
            ImageView imageView = (ImageView) inflate.findViewById(R.id.printer_status);
            int i2 = printer.online != null ? printer.online.booleanValue() ? R.drawable.printer_on : R.drawable.printer_off : R.drawable.printer;
            imageView.setBackgroundResource(i2);
            TextView textView = (TextView) inflate.findViewById(R.id.printer_owner);
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append(printer.owner.login);
            sb.append("]");
            String sb2 = sb.toString();
            if (printer.owner.nick != null && printer.owner.nick.length() > 0) {
                sb2 = printer.owner.nick;
            }
            if (printer.owner.name != null && printer.owner.name.length() > 0) {
                sb2 = printer.owner.name;
            }
            textView.setText(sb2);
            String str = "";
            ((TextView) inflate.findViewById(R.id.printer_name)).setText((printer == null || printer.title == null) ? str : printer.title);
            TextView textView2 = (TextView) inflate.findViewById(R.id.printer_location);
            String str2 = (printer.owner.country == null || printer.owner.country.length() <= 0) ? str : printer.owner.country;
            String str3 = ", ";
            if (printer.owner.city != null && printer.owner.city.length() > 0) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append(printer.owner.city);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb3.append(str3);
                sb3.append(str2);
                str2 = sb3.toString();
            } else if (printer.owner.state != null && printer.owner.state.length() > 0) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append(printer.owner.state);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb4.append(str3);
                sb4.append(str2);
                str2 = sb4.toString();
            }
            if (printer.location != null && printer.location.length() > 0) {
                str2 = printer.location;
            }
            if (str2 != null) {
                str = str2;
            }
            textView2.setText(str);
            int i3 = 0;
            textView2.setVisibility(str.length() > 0 ? 0 : 8);
            View findViewById = inflate.findViewById(R.id.printer_current);
            if (ActivityCore.printer == null || ActivityCore.printer.id == null || !ActivityCore.printer.id.equals(printer.id)) {
                i3 = 4;
            }
            findViewById.setVisibility(i3);
            inflate.setTag(printer);
            return inflate;
        }

        public boolean isEmpty() {
            return ActivityCore.remote_printers.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    class RemovePrinterThread extends Thread {
        private Printer prn;

        public RemovePrinterThread(int i) {
            this.prn = (Printer) ActivityCore.remote_printers.elementAt(i);
        }

        public void run() {
            ActivityPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrinters.this.showProgress(ActivityPrinters.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityPrinters.this.last_error = null;
            try {
                SoapEnvelope soapEnvelope = new SoapEnvelope("ChangePrinters", "Param", "data");
                Element dataRoot = soapEnvelope.getDataRoot();
                XmlUtil.appendElement(dataRoot, "token", ActivityCore.remote_token);
                dataRoot.setAttribute("action", "dislike");
                XmlUtil.appendElement(XmlUtil.appendElement(dataRoot, "printer"), "public-id", this.prn.id);
                Element dataRoot2 = App.psService.doAction(soapEnvelope).getDataRoot();
                if ("true".equals(dataRoot2.getAttribute("success"))) {
                    ActivityCore.remote_printers.remove(this.prn);
                    if (ActivityCore.printer == this.prn) {
                        ActivityPrinters.this.setPrinter(ActivityCore.remote_printers.size() > 0 ? (Printer) ActivityCore.remote_printers.elementAt(0) : null);
                        ActivityPrinters.this.setResult(-1);
                    }
                } else {
                    ActivityPrinters activityPrinters = ActivityPrinters.this;
                    StringBuilder sb = new StringBuilder();
                    sb.append("Error: ");
                    sb.append(XmlUtil.getFirstNodeValue(dataRoot2, "message"));
                    activityPrinters.last_error = sb.toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityPrinters activityPrinters2 = ActivityPrinters.this;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Internal Error: ");
                sb2.append(e.getMessage());
                activityPrinters2.last_error = sb2.toString();
                App.reportThrowable(e);
            }
            if (ActivityPrinters.this.last_error == null) {
                ActivityPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrinters.this.hideProgress();
                        ((PrinterAdapter) ((ListView) ActivityPrinters.this.findViewById(R.id.list)).getAdapter()).fireOnChanged();
                    }
                });
            } else {
                ActivityPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrinters.this.hideProgress();
                        ActivityPrinters.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
            }
            ActivityPrinters.this.rt = null;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.header_remote_printers);
        LayoutInflater from = LayoutInflater.from(this);
        this.view_dialog_printer_details = from.inflate(R.layout.dialog_printer_details, null);
        this.view_dialog_owner_details = from.inflate(R.layout.dialog_owner_details, null);
        ((TextView) findViewById(R.id.hint1)).setText(R.string.label_favourite_printers);
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.button_add_printer);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityPrinters.this, ActivityFindPrinters.class);
                ActivityPrinters.this.startActivityForResult(intent, 2);
            }
        });
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                int i2 = 0;
                while (true) {
                    if (i2 >= adapterView.getChildCount()) {
                        break;
                    }
                    View childAt = adapterView.getChildAt(i2);
                    if (ActivityCore.printer == childAt.getTag()) {
                        childAt.findViewById(R.id.printer_current).setVisibility(4);
                        break;
                    }
                    i2++;
                }
                view.findViewById(R.id.printer_current).setVisibility(0);
                ActivityPrinters.this.setPrinter((Printer) view.getTag());
                ActivityPrinters.this.setResult(-1);
                ActivityPrinters.this.finish();
            }
        });
        listView.setOnItemLongClickListener(new OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long j) {
                new Builder(ActivityPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.label_options).setItems(new CharSequence[]{ActivityPrinters.this.getString(R.string.label_printer_details), ActivityPrinters.this.getString(R.string.label_owner_details), ActivityPrinters.this.getString(R.string.label_remove_printer)}, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (i == 0) {
                            Printer printer = (Printer) ActivityCore.remote_printers.elementAt(i);
                            ((TextView) ActivityPrinters.this.view_dialog_printer_details.findViewById(R.id.printer_name)).setText(printer.title);
                            ((TextView) ActivityPrinters.this.view_dialog_printer_details.findViewById(R.id.printer_location)).setText(printer.location);
                            TextView textView = (TextView) ActivityPrinters.this.view_dialog_printer_details.findViewById(R.id.printer_status);
                            String str = printer.online != null ? printer.online.booleanValue() ? "Online" : "Offline" : "";
                            textView.setText(str);
                            ActivityPrinters.this.showDialog(1);
                        } else if (i == 1) {
                            Printer printer2 = (Printer) ActivityCore.remote_printers.elementAt(i);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_login)).setText(printer2.owner.login);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_name)).setText(printer2.owner.name);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_nick)).setText(printer2.owner.nick);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_email)).setText(printer2.owner.email);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_phone)).setText(printer2.owner.phone);
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_address)).setText(printer2.owner.address);
                            TextView textView2 = (TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_city_state_zip);
                            StringBuilder sb = new StringBuilder();
                            sb.append(printer2.owner.city);
                            String str2 = " ";
                            sb.append(str2);
                            sb.append(printer2.owner.state);
                            sb.append(str2);
                            sb.append(printer2.owner.zip);
                            textView2.setText(sb.toString());
                            ((TextView) ActivityPrinters.this.view_dialog_owner_details.findViewById(R.id.user_country)).setText(printer2.owner.country);
                            ActivityPrinters.this.showDialog(2);
                        } else if (i == 2) {
                            ActivityPrinters.this.rt = new RemovePrinterThread(i);
                            ActivityPrinters.this.rt.start();
                        }
                    }
                }).show();
                return true;
            }
        });
    }

    /* access modifiers changed from: protected */
    public void init() {
        if (remote_user == null) {
            this.skip_update = true;
            Intent intent = new Intent();
            intent.setClass(this, ActivityStart.class);
            startActivityForResult(intent, 1);
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        super.update();
        if (remote_printers != null) {
            ListView listView = (ListView) findViewById(R.id.list);
            if (listView.getAdapter() == null) {
                listView.setAdapter(new PrinterAdapter(this));
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 11, 0, R.string.menu_profile);
        menu.add(0, 22, 0, R.string.button_logout);
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 11) {
            Intent intent = new Intent();
            intent.setClass(this, ActivityProfile.class);
            startActivity(intent);
            return true;
        } else if (itemId != 22) {
            return super.onMenuItemSelected(i, menuItem);
        } else {
            Editor edit = this.prefs.edit();
            String str = "";
            edit.putString("token", str);
            edit.commit();
            remote_token = str;
            remote_user = null;
            remote_printers = null;
            printer = null;
            finish();
            return true;
        }
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        if (i == 1) {
            return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_printer_details).setView(this.view_dialog_printer_details).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create();
        }
        if (i != 2) {
            return null;
        }
        return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_owner_details).setView(this.view_dialog_owner_details).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).create();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 2) {
            PrinterAdapter printerAdapter = (PrinterAdapter) ((ListView) findViewById(R.id.list)).getAdapter();
            if (printerAdapter != null) {
                printerAdapter.fireOnChanged();
            }
            if (i2 == -1) {
                setResult(-1);
            }
        }
    }
}
