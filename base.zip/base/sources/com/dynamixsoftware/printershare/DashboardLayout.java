package com.dynamixsoftware.printershare;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import com.dynamixsoftware.printershare.smb.ntlmssp.NtlmFlags;

public class DashboardLayout extends ViewGroup {
    private int MAX_CHILD_SIZE = ((int) (getResources().getDisplayMetrics().density * 200.0f));
    private int MIN_CHILD_SIZE = ((int) (getResources().getDisplayMetrics().density * 100.0f));
    private int cols;
    private int rows;
    private int size;

    public DashboardLayout(Context context) {
        super(context, null);
    }

    public DashboardLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    public DashboardLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        int size2 = (MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
        int size3 = (MeasureSpec.getSize(i2) - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        int i4 = 0;
        for (int i5 = 0; i5 < childCount; i5++) {
            if (getChildAt(i5).getVisibility() != 8) {
                i4++;
            }
        }
        int i6 = size2 > 0 ? size2 / this.MIN_CHILD_SIZE : 0;
        int i7 = size3 > 0 ? size3 / this.MIN_CHILD_SIZE : 0;
        this.cols = i6;
        this.rows = i7;
        while (true) {
            int i8 = this.cols;
            int i9 = this.rows;
            if (i8 * i9 >= i4) {
                break;
            }
            this.rows = i9 + 1;
        }
        while (true) {
            int i10 = this.cols;
            int i11 = this.rows;
            if ((i10 * i11) - i4 >= i10 || (i10 < i6 && i11 - 1 < (i10 * i11) - i4)) {
                int i12 = this.cols;
                int i13 = this.rows;
                if (i12 > i13) {
                    this.cols = i12 - 1;
                    while (true) {
                        int i14 = this.cols;
                        int i15 = this.rows;
                        if (i14 * i15 >= i4) {
                            break;
                        }
                        this.rows = i15 + 1;
                    }
                } else {
                    this.rows = i13 - 1;
                }
            }
        }
        int i16 = this.rows;
        if (i16 <= i7) {
            int i17 = this.cols;
            if ((i17 - 1) * i16 == i4) {
                this.cols = i17 - 1;
            }
        }
        int i18 = size2 / this.cols;
        int i19 = size3 / this.rows;
        if (i19 < this.MIN_CHILD_SIZE || i19 >= i18) {
            this.size = i18;
        } else {
            this.size = i19;
        }
        int i20 = this.size;
        int i21 = this.MAX_CHILD_SIZE;
        if (i20 > i21) {
            this.size = i21;
        }
        int i22 = this.size;
        if (i22 % 2 == 1) {
            this.size = i22 - 1;
        }
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(this.size, NtlmFlags.NTLMSSP_NEGOTIATE_KEY_EXCH);
        int makeMeasureSpec2 = MeasureSpec.makeMeasureSpec(this.size, NtlmFlags.NTLMSSP_NEGOTIATE_KEY_EXCH);
        for (int i23 = 0; i23 < childCount; i23++) {
            View childAt = getChildAt(i23);
            if (childAt.getVisibility() != 8) {
                childAt.measure(makeMeasureSpec, makeMeasureSpec2);
            }
        }
        int resolveSize = resolveSize(size2 + getPaddingLeft() + getPaddingRight(), i);
        int i24 = this.size;
        int i25 = this.rows;
        if (i24 * i25 > size3) {
            i3 = i24 * i25;
        } else {
            i3 = getPaddingBottom() + size3 + getPaddingTop();
        }
        setMeasuredDimension(resolveSize, resolveSize(i3, i2));
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                int paddingLeft = getPaddingLeft() + (this.size * i5);
                int paddingTop = getPaddingTop() + (this.size * i6);
                int paddingLeft2 = getPaddingLeft();
                int i8 = this.size;
                int i9 = paddingLeft2 + (i5 * i8) + i8;
                int paddingTop2 = getPaddingTop();
                int i10 = this.size;
                childAt.layout(paddingLeft, paddingTop, i9, paddingTop2 + (i6 * i10) + i10);
                i5++;
                if (i5 == this.cols) {
                    i6++;
                    i5 = 0;
                }
            }
        }
    }
}
