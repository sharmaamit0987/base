package com.dynamixsoftware.printershare;

import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.data.OutputDuplex;
import com.dynamixsoftware.printershare.data.OutputMode;
import com.dynamixsoftware.printershare.data.Paper;
import com.dynamixsoftware.printershare.data.PaperSource;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import java.io.BufferedInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

public class ActivityCloudPrinters extends ActivityCore {
    private static int requesting_credentials;
    /* access modifiers changed from: private */
    public AlertDialog accounts_menu;
    /* access modifiers changed from: private */
    public String[] al;
    private Object[] al_objs;
    /* access modifiers changed from: private */
    public String[] credentials;
    private boolean ftoken;
    private Handler handler;
    boolean new_am;
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    /* access modifiers changed from: private */
    public Thread wt;

    public static class CloudDeviceDescription {
        public PrinterDescriptionSection printer;
    }

    public static class Color {
        public ArrayList<ColorOption> option;
    }

    public static class ColorOption {
        public String custom_display_name;
        public String is_default;
        public String type;
        public String vendor_id;
    }

    public static class Duplex {
        public ArrayList<DuplexOption> option;
    }

    public static class DuplexOption {
        public String is_default;
        public String type;
    }

    public static class GPrinter {
        public CloudDeviceDescription capabilities;
        public String capsFormat;
        public String description;
        public String displayName;
        public String id;
        public String name;
        public String proxy;
        public String status;
        public String type;
    }

    public static class GPrinterList {
        public ArrayList<GPrinter> printers;
        public String success;
    }

    public static class MediaSize {
        public ArrayList<MediaSizeOption> option;
    }

    public static class MediaSizeOption {
        public String custom_display_name;
        public String height_microns;
        public String is_default;
        public String name;
        public String vendor_id;
        public String width_microns;
    }

    class PrinterAdapter implements ListAdapter {
        public Context mContext;
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getItemViewType(int i) {
            return 1;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        public PrinterAdapter(Context context) {
            this.mContext = context;
        }

        public int getCount() {
            if (ActivityCloudPrinters.this.printers != null) {
                return ActivityCloudPrinters.this.printers.size();
            }
            return 0;
        }

        public Object getItem(int i) {
            return ActivityCloudPrinters.this.printers.elementAt(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.printer, null);
            Printer printer = (Printer) ActivityCloudPrinters.this.printers.elementAt(i);
            TextView textView = (TextView) inflate.findViewById(R.id.printer_owner);
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append(printer.owner.login);
            sb.append("]");
            String sb2 = sb.toString();
            if (printer.owner.nick != null && printer.owner.nick.length() > 0) {
                sb2 = printer.owner.nick;
            }
            if (printer.owner.name != null && printer.owner.name.length() > 0) {
                sb2 = printer.owner.name;
            }
            textView.setText(sb2);
            ((TextView) inflate.findViewById(R.id.printer_name)).setText(printer.title);
            TextView textView2 = (TextView) inflate.findViewById(R.id.printer_location);
            String str = "";
            String str2 = (printer.owner.country == null || printer.owner.country.length() <= 0) ? str : printer.owner.country;
            String str3 = ", ";
            if (printer.owner.city != null && printer.owner.city.length() > 0) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append(printer.owner.city);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb3.append(str3);
                sb3.append(str2);
                str2 = sb3.toString();
            } else if (printer.owner.state != null && printer.owner.state.length() > 0) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append(printer.owner.state);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb4.append(str3);
                sb4.append(str2);
                str2 = sb4.toString();
            }
            if (printer.location != null && printer.location.length() > 0) {
                str2 = printer.location;
            }
            if (str2 != null) {
                str = str2;
            }
            textView2.setText(str);
            int length = str.length();
            int i2 = 0;
            textView2.setVisibility(length > 0 ? 0 : 8);
            ImageView imageView = (ImageView) inflate.findViewById(R.id.printer_status);
            int i3 = printer.online != null ? printer.online.booleanValue() ? R.drawable.printer_on : R.drawable.printer_off : R.drawable.printer;
            imageView.setBackgroundResource(i3);
            View findViewById = inflate.findViewById(R.id.printer_current);
            if (ActivityCore.printer == null || ActivityCore.printer.id == null || !ActivityCore.printer.id.equals(printer.id)) {
                i2 = 4;
            }
            findViewById.setVisibility(i2);
            inflate.setTag(printer);
            return inflate;
        }

        public boolean isEmpty() {
            return ActivityCloudPrinters.this.printers == null || ActivityCloudPrinters.this.printers.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    public static class PrinterDescriptionSection {
        public Color color;
        public Duplex duplex;
        public MediaSize media_size;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x008c  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    public void onCreate(Bundle bundle) {
        boolean z;
        String str = "SDK_INT";
        super.onCreate(bundle);
        this.handler = new Handler();
        setContentView(R.layout.list);
        setTitle((int) R.string.header_cloud_printers);
        try {
            if (VERSION.class.getField(str).getInt(null) >= 26) {
                this.new_am = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.menu_accounts);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityCloudPrinters.this.chooseAccount();
            }
        });
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(new PrinterAdapter(this));
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Printer printer = (Printer) view.getTag();
                final String substring = printer.id.substring(0, printer.id.indexOf("@"));
                ActivityCloudPrinters activityCloudPrinters = ActivityCloudPrinters.this;
                activityCloudPrinters.showProgress(activityCloudPrinters.getResources().getString(R.string.label_processing));
                ActivityCloudPrinters.this.wt = new Thread() {
                    public void run() {
                        ActivityCloudPrinters.this.last_error = null;
                        try {
                            StringBuilder sb = new StringBuilder();
                            sb.append("https://www.google.com/cloudprint/printer?output=json&printerid=");
                            sb.append(substring);
                            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
                            httpURLConnection.setConnectTimeout(15000);
                            httpURLConnection.setReadTimeout(15000);
                            httpURLConnection.setDoInput(true);
                            httpURLConnection.setDoOutput(false);
                            httpURLConnection.setUseCaches(false);
                            httpURLConnection.setRequestMethod("GET");
                            httpURLConnection.setRequestProperty("Connection", "close");
                            httpURLConnection.setRequestProperty("User-Agent", App.getUserAgent());
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("GoogleLogin auth=");
                            sb2.append(ActivityCloudPrinters.this.prefs.getString("cloud_token", ""));
                            httpURLConnection.setRequestProperty("Authorization", sb2.toString());
                            httpURLConnection.setRequestProperty("X-CloudPrint-Proxy", SmbConstants.NATIVE_LANMAN);
                            int responseCode = httpURLConnection.getResponseCode();
                            if (responseCode == 200) {
                                GPrinterList gPrinterList = (GPrinterList) Json.read(new BufferedInputStream(httpURLConnection.getInputStream()), GPrinterList.class);
                                if (gPrinterList.printers != null) {
                                    for (int i = 0; i < gPrinterList.printers.size(); i++) {
                                        final Printer loadPrinter = ActivityCloudPrinters.loadPrinter((GPrinter) gPrinterList.printers.get(i));
                                        if (loadPrinter.id.startsWith(substring)) {
                                            ActivityCloudPrinters.this.runOnUiThread(new Runnable() {
                                                public void run() {
                                                    ActivityCloudPrinters.this.hideProgress();
                                                    ActivityCloudPrinters.this.setPrinter(loadPrinter);
                                                    if ("ActivityMain".equals(ActivityCloudPrinters.this.getIntent().getStringExtra("activity_name"))) {
                                                        Builder negativeButton = new Builder(ActivityCloudPrinters.this).setIcon(R.drawable.icon_title).setTitle(SmbConstants.NATIVE_LANMAN).setMessage(R.string.dialog_install_printer_done).setCancelable(false).setPositiveButton(R.string.button_print_test_page, new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                                ActivityCloudPrinters.this.setResult(-1);
                                                                ActivityCloudPrinters.this.finish();
                                                                Intent intent = new Intent();
                                                                intent.setClass(ActivityCloudPrinters.this, ActivityPrintTestPage.class);
                                                                ActivityCloudPrinters.this.startActivity(intent);
                                                            }
                                                        }).setNegativeButton(R.string.button_skip, new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                                ActivityCloudPrinters.this.setResult(-1);
                                                                ActivityCloudPrinters.this.finish();
                                                            }
                                                        });
                                                        ActivityCloudPrinters.this.hideProgress();
                                                        negativeButton.show();
                                                        return;
                                                    }
                                                    ActivityCloudPrinters.this.setResult(-1);
                                                    ActivityCloudPrinters.this.finish();
                                                }
                                            });
                                            return;
                                        }
                                    }
                                }
                            } else {
                                ActivityCloudPrinters activityCloudPrinters = ActivityCloudPrinters.this;
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("Error: ");
                                sb3.append(responseCode);
                                sb3.append(" ");
                                sb3.append(httpURLConnection.getResponseMessage());
                                activityCloudPrinters.last_error = sb3.toString();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                        if (ActivityCloudPrinters.this.last_error == null) {
                            ActivityCloudPrinters.this.last_error = "Error: Unknown error";
                        }
                        ActivityCloudPrinters.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityCloudPrinters.this.hideProgress();
                                ActivityCloudPrinters.this.displayLastError(null);
                            }
                        });
                    }
                };
                ActivityCloudPrinters.this.wt.start();
            }
        });
        this.ftoken = false;
        this.printers = new Vector<>();
        if (!this.new_am) {
            try {
                if (VERSION.class.getField(str).getInt(null) >= 23) {
                    z = true;
                    if (!z) {
                        final boolean[] zArr = new boolean[1];
                        new Object() {
                            {
                                String str = "android.permission.GET_ACCOUNTS";
                                if (ActivityCloudPrinters.this.checkSelfPermission(str) != 0) {
                                    ActivityCloudPrinters.this.al = new String[0];
                                    ActivityCloudPrinters.this.requestPermissions(new String[]{str}, 444555);
                                    zArr[0] = true;
                                }
                            }
                        };
                        if (zArr[0]) {
                        }
                        return;
                    }
                    return;
                }
            } catch (NoSuchFieldException unused2) {
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
            z = false;
            if (!z) {
            }
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.al = null;
        xinit();
    }

    /* access modifiers changed from: private */
    public void chooseAccount() {
        if (this.new_am) {
            new Object() {
                {
                    ActivityCloudPrinters.this.startActivityForResult(AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null), 444555);
                }
            };
        } else {
            this.accounts_menu.show();
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && i == 444555) {
            String stringExtra = intent.getStringExtra("authAccount");
            if (stringExtra != null) {
                Object systemService = getSystemService("account");
                try {
                    Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
                    this.al_objs = objArr;
                    if (objArr != null) {
                        this.al = new String[objArr.length];
                        if (objArr.length > 0) {
                            Field field = objArr[0].getClass().getField("name");
                            for (int i3 = 0; i3 < objArr.length; i3++) {
                                this.al[i3] = (String) field.get(objArr[i3]);
                            }
                        }
                    }
                    showAccount(stringExtra);
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    public void onDestroy() {
        super.onDestroy();
    }

    /* access modifiers changed from: private */
    public void xinit() {
        Object systemService = getSystemService("account");
        if (systemService != null) {
            try {
                Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
                this.al_objs = objArr;
                if (objArr != null) {
                    this.al = new String[objArr.length];
                    if (objArr.length > 0) {
                        Field field = objArr[0].getClass().getField("name");
                        for (int i = 0; i < objArr.length; i++) {
                            this.al[i] = (String) field.get(objArr[i]);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
        xinit_done();
    }

    private void xinit_done() {
        this.wt = null;
        runOnUiThread(new Runnable() {
            public void run() {
                String str = null;
                String string = ActivityCloudPrinters.this.prefs.getString("cloud_account", null);
                int length = (ActivityCloudPrinters.this.al != null ? ActivityCloudPrinters.this.al.length : 0) + 1;
                CharSequence[] charSequenceArr = new CharSequence[length];
                if (ActivityCloudPrinters.this.al != null && ActivityCloudPrinters.this.al.length > 0) {
                    for (int i = 0; i < ActivityCloudPrinters.this.al.length; i++) {
                        charSequenceArr[i] = ActivityCloudPrinters.this.al[i];
                        if (ActivityCloudPrinters.this.al[i].equals(string)) {
                            str = string;
                        }
                    }
                }
                charSequenceArr[length - 1] = ActivityCloudPrinters.this.getResources().getString(R.string.menu_add_account);
                ActivityCloudPrinters.this.accounts_menu = new Builder(ActivityCloudPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.menu_accounts).setItems(charSequenceArr, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ActivityCloudPrinters.this.al == null || i >= ActivityCloudPrinters.this.al.length) {
                            final Object systemService = ActivityCloudPrinters.this.getSystemService("account");
                            if (systemService != null) {
                                ActivityCloudPrinters.this.wt = new Thread() {
                                    public void run() {
                                        Method method;
                                        try {
                                            Method[] methods = systemService.getClass().getMethods();
                                            int i = 0;
                                            while (true) {
                                                if (i >= methods.length) {
                                                    method = null;
                                                    break;
                                                } else if ("addAccount".equals(methods[i].getName())) {
                                                    method = methods[i];
                                                    break;
                                                } else {
                                                    i++;
                                                }
                                            }
                                            Object invoke = method.invoke(systemService, new Object[]{"com.google", null, null, null, ActivityCloudPrinters.this, null, null});
                                            String string = ((Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0])).getString("authAccount");
                                            if (string != null) {
                                                Editor edit = ActivityCloudPrinters.this.prefs.edit();
                                                edit.putString("cloud_account", string);
                                                edit.commit();
                                                ActivityCloudPrinters.this.xinit();
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                        }
                                    }
                                };
                                ActivityCloudPrinters.this.wt.start();
                                return;
                            }
                            return;
                        }
                        ActivityCloudPrinters.this.showAccount(ActivityCloudPrinters.this.al[i]);
                    }
                }).create();
                if (str != null) {
                    ActivityCloudPrinters.this.showAccount(str);
                    return;
                }
                ActivityCloudPrinters.this.hideProgress();
                if (!ActivityCloudPrinters.this.isFinishing()) {
                    ActivityCloudPrinters.this.chooseAccount();
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void showAccount(final String str) {
        showProgress(getResources().getString(R.string.label_processing));
        Editor edit = this.prefs.edit();
        edit.putString("cloud_account", str);
        edit.commit();
        this.printers.clear();
        String str2 = "";
        ((TextView) findViewById(R.id.hint1)).setText(str2);
        ((TextView) findViewById(R.id.hint2)).setText(str2);
        ((PrinterAdapter) ((ListView) findViewById(R.id.list)).getAdapter()).fireOnChanged();
        AnonymousClass6 r0 = new Thread() {
            public void run() {
                ActivityCloudPrinters.this.authorize(str);
            }
        };
        this.wt = r0;
        r0.start();
    }

    /* access modifiers changed from: private */
    public void authorize(String str) {
        Method method;
        String[] strArr = new String[2];
        this.credentials = strArr;
        strArr[0] = str;
        Object systemService = getSystemService("account");
        Object[] objArr = this.al_objs;
        if (objArr != null && objArr.length > 0) {
            int i = 0;
            while (true) {
                try {
                    if (i >= this.al.length) {
                        i = 0;
                        break;
                    } else if (this.al[i].equals(str)) {
                        break;
                    } else {
                        i++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            Method[] methods = systemService.getClass().getMethods();
            int i2 = 0;
            while (true) {
                if (i2 < methods.length) {
                    if ("getAuthToken".equals(methods[i2].getName()) && methods[i2].getParameterTypes().length == 5) {
                        method = methods[i2];
                        break;
                    }
                    i2++;
                } else {
                    method = null;
                    break;
                }
            }
            Object invoke = method.invoke(systemService, new Object[]{this.al_objs[i], "cloudprint", Boolean.valueOf(false), null, this.handler});
            Bundle bundle = (Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0]);
            Intent intent = (Intent) bundle.getParcelable("intent");
            if (intent == null) {
                this.credentials[1] = bundle.getString("authtoken");
            } else if (requesting_credentials == 0) {
                requesting_credentials = 1;
                startActivity(intent);
                this.wt = null;
                return;
            }
        }
        requesting_credentials = 0;
        authorize_done();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.al == null || requesting_credentials != 0) {
            showProgress(getResources().getString(R.string.label_processing));
            AnonymousClass7 r0 = new Thread() {
                public void run() {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException unused) {
                    }
                    ActivityCloudPrinters.this.xinit();
                }
            };
            this.wt = r0;
            r0.start();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:66:0x018c, code lost:
        if ("CUSTOM_COLOR".equals(r11.type) != false) goto L_0x018e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x0241  */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x0256  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x0272  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x0282  */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0042  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:159:0x0276 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0080  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00d4 A[SYNTHETIC, Splitter:B:38:0x00d4] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00e0 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0155  */
    public static Printer loadPrinter(GPrinter gPrinter) {
        boolean z;
        String str;
        String str2;
        String str3;
        String str4;
        int i;
        int i2;
        ArrayList<MediaSizeOption> arrayList;
        String str5;
        GPrinter gPrinter2 = gPrinter;
        Printer printer = new Printer();
        StringBuilder sb = new StringBuilder();
        sb.append(gPrinter2.id);
        sb.append("@cloudprint.google.");
        printer.id = sb.toString();
        String str6 = "";
        if (gPrinter2.status != null && !str6.equals(gPrinter2.status)) {
            if (!"0".equals(gPrinter2.status)) {
                z = false;
                printer.online = Boolean.valueOf(z);
                printer.title = App.fixEncoding(gPrinter2.displayName == null ? gPrinter2.displayName : gPrinter2.name);
                printer.model = App.fixEncoding(gPrinter2.name);
                printer.owner = new User();
                printer.owner.name = "Google Cloud";
                str = "Off";
                str2 = "200x200";
                if (!(gPrinter2.capabilities == null || gPrinter2.capabilities.printer == null)) {
                    String str7 = ", \"vendor_id\": \"";
                    String str8 = "\"";
                    String str9 = "true";
                    String str10 = "CUSTOM_";
                    if (gPrinter2.capabilities.printer.media_size != null) {
                        ArrayList<MediaSizeOption> arrayList2 = gPrinter2.capabilities.printer.media_size.option;
                        printer.paper_list = new Vector<>();
                        if (arrayList2 != null) {
                            int i3 = 0;
                            while (i3 < arrayList2.size()) {
                                MediaSizeOption mediaSizeOption = (MediaSizeOption) arrayList2.get(i3);
                                if (mediaSizeOption.name != null) {
                                    str4 = mediaSizeOption.name;
                                } else if (mediaSizeOption.vendor_id != null) {
                                    StringBuilder sb2 = new StringBuilder();
                                    sb2.append(str10);
                                    sb2.append(mediaSizeOption.vendor_id);
                                    str4 = sb2.toString();
                                } else {
                                    str4 = null;
                                }
                                String fixEncoding = App.fixEncoding(mediaSizeOption.custom_display_name);
                                if (mediaSizeOption.width_microns != null) {
                                    try {
                                        i = Integer.parseInt(mediaSizeOption.width_microns) / 100;
                                    } catch (NumberFormatException unused) {
                                    }
                                    if (mediaSizeOption.height_microns != null) {
                                        try {
                                            i2 = Integer.parseInt(mediaSizeOption.height_microns) / 100;
                                        } catch (NumberFormatException unused2) {
                                        }
                                        if (str4 != null || fixEncoding == null || i <= 0 || i2 <= 0) {
                                            arrayList = arrayList2;
                                        } else {
                                            arrayList = arrayList2;
                                            Paper paper = new Paper(str4, fixEncoding, i, i2);
                                            StringBuilder sb3 = new StringBuilder();
                                            sb3.append("\"media_size\": {\"width_microns\": ");
                                            sb3.append(mediaSizeOption.width_microns);
                                            sb3.append(", \"height_microns\": ");
                                            sb3.append(mediaSizeOption.height_microns);
                                            if (mediaSizeOption.vendor_id != null) {
                                                StringBuilder sb4 = new StringBuilder();
                                                sb4.append(str7);
                                                sb4.append(mediaSizeOption.vendor_id);
                                                sb4.append(str8);
                                                str5 = sb4.toString();
                                            } else {
                                                str5 = str6;
                                            }
                                            sb3.append(str5);
                                            sb3.append("}");
                                            paper.drv_params = sb3.toString();
                                            printer.paper_list.add(paper);
                                            if (str9.equals(mediaSizeOption.is_default)) {
                                                printer.paper_default = paper.id;
                                            }
                                        }
                                        i3++;
                                        arrayList2 = arrayList;
                                    }
                                    i2 = 0;
                                    if (str4 != null) {
                                    }
                                    arrayList = arrayList2;
                                    i3++;
                                    arrayList2 = arrayList;
                                }
                                i = 0;
                                if (mediaSizeOption.height_microns != null) {
                                }
                                i2 = 0;
                                if (str4 != null) {
                                }
                                arrayList = arrayList2;
                                i3++;
                                arrayList2 = arrayList;
                            }
                            Collections.sort(printer.paper_list);
                        }
                    }
                    if (gPrinter2.capabilities.printer.color != null) {
                        ArrayList<ColorOption> arrayList3 = gPrinter2.capabilities.printer.color.option;
                        printer.outputMode_list = new Vector<>();
                        if (arrayList3 != null) {
                            for (int i4 = 0; i4 < arrayList3.size(); i4++) {
                                ColorOption colorOption = (ColorOption) arrayList3.get(i4);
                                OutputMode outputMode = new OutputMode();
                                outputMode.resolution = str2;
                                if (!"STANDARD_COLOR".equals(colorOption.type)) {
                                }
                                outputMode.id = "COLOR";
                                if (colorOption.type.startsWith(str10)) {
                                    StringBuilder sb5 = new StringBuilder();
                                    sb5.append(outputMode.id);
                                    sb5.append(colorOption.vendor_id);
                                    outputMode.id = sb5.toString();
                                }
                                outputMode.name = colorOption.custom_display_name != null ? App.fixEncoding(colorOption.custom_display_name) : "Color";
                                if (!"STANDARD_MONOCHROME".equals(colorOption.type)) {
                                    if (!"CUSTOM_MONOCHROME".equals(colorOption.type)) {
                                        String str11 = "AUTO";
                                        if (str11.equals(colorOption.type)) {
                                            outputMode.id = str11;
                                            outputMode.name = colorOption.custom_display_name != null ? App.fixEncoding(colorOption.custom_display_name) : "Auto";
                                            printer.outputMode_default = outputMode.id;
                                        }
                                        if (!(outputMode.id == null || outputMode.name == null)) {
                                            StringBuilder sb6 = new StringBuilder();
                                            sb6.append("\"color\": {\"type\": \"");
                                            sb6.append(colorOption.type);
                                            sb6.append(str8);
                                            if (colorOption.vendor_id == null) {
                                                StringBuilder sb7 = new StringBuilder();
                                                sb7.append(str7);
                                                sb7.append(colorOption.vendor_id);
                                                sb7.append(str8);
                                                str3 = sb7.toString();
                                            } else {
                                                str3 = str6;
                                            }
                                            sb6.append(str3);
                                            sb6.append("}");
                                            outputMode.drv_params = sb6.toString();
                                            printer.outputMode_list.add(outputMode);
                                            if (!str9.equals(colorOption.is_default)) {
                                                printer.outputMode_default = outputMode.id;
                                            }
                                        }
                                    }
                                }
                                outputMode.id = "MONOCHROME";
                                if (colorOption.type.startsWith(str10)) {
                                    StringBuilder sb8 = new StringBuilder();
                                    sb8.append(outputMode.id);
                                    sb8.append(colorOption.vendor_id);
                                    outputMode.id = sb8.toString();
                                }
                                outputMode.name = colorOption.custom_display_name != null ? App.fixEncoding(colorOption.custom_display_name) : "Grayscale";
                                StringBuilder sb62 = new StringBuilder();
                                sb62.append("\"color\": {\"type\": \"");
                                sb62.append(colorOption.type);
                                sb62.append(str8);
                                if (colorOption.vendor_id == null) {
                                }
                                sb62.append(str3);
                                sb62.append("}");
                                outputMode.drv_params = sb62.toString();
                                printer.outputMode_list.add(outputMode);
                                if (!str9.equals(colorOption.is_default)) {
                                }
                            }
                        }
                    }
                    if (gPrinter2.capabilities.printer.duplex != null) {
                        ArrayList<DuplexOption> arrayList4 = gPrinter2.capabilities.printer.duplex.option;
                        printer.outputDuplex_list = new Vector<>();
                        if (arrayList4 != null) {
                            for (int i5 = 0; i5 < arrayList4.size(); i5++) {
                                DuplexOption duplexOption = (DuplexOption) arrayList4.get(i5);
                                OutputDuplex outputDuplex = new OutputDuplex();
                                if ("LONG_EDGE".equals(duplexOption.type)) {
                                    outputDuplex.id = duplexOption.type;
                                    outputDuplex.name = "Long Edge (Standard)";
                                }
                                if ("SHORT_EDGE".equals(duplexOption.type)) {
                                    outputDuplex.id = duplexOption.type;
                                    outputDuplex.name = "Short Edge (Flip)";
                                } else {
                                    if ("NO_DUPLEX".equals(duplexOption.type)) {
                                        outputDuplex.id = duplexOption.type;
                                        outputDuplex.name = str;
                                        printer.outputDuplex_default = outputDuplex.id;
                                    }
                                }
                                if (!(outputDuplex.id == null || outputDuplex.name == null)) {
                                    StringBuilder sb9 = new StringBuilder();
                                    sb9.append("\"duplex\": {\"type\": \"");
                                    sb9.append(duplexOption.type);
                                    sb9.append("\"}");
                                    outputDuplex.drv_params = sb9.toString();
                                    printer.outputDuplex_list.add(outputDuplex);
                                    if (str9.equals(duplexOption.is_default)) {
                                        printer.outputDuplex_default = outputDuplex.id;
                                    }
                                }
                            }
                        }
                    }
                }
                if (printer.paper_list == null || printer.paper_list.size() == 0) {
                    printer.paper_list = new Vector<>();
                    String str12 = "Letter";
                    printer.paper_default = str12;
                    printer.paper_list.add(new Paper("Photo", "Photo, 4x6 inch", 1016, 1524));
                    printer.paper_list.add(new Paper("L", "L, 3.5x5 inch", 889, 1270));
                    printer.paper_list.add(new Paper(str12, str12, 2159, 2794));
                    String str13 = "A4";
                    printer.paper_list.add(new Paper(str13, str13, 2099, 2970));
                    String str14 = "Legal";
                    printer.paper_list.add(new Paper(str14, str14, 2159, 3556));
                    String str15 = "A3";
                    printer.paper_list.add(new Paper(str15, str15, 2970, 4198));
                    String str16 = "Ledger";
                    printer.paper_list.add(new Paper(str16, str16, 2794, 4318));
                    String str17 = "B4";
                    printer.paper_list.add(new Paper(str17, str17, 2571, 3644));
                    Collections.sort(printer.paper_list);
                }
                String str18 = "Default";
                if (printer.paperSource_list == null || printer.paperSource_list.size() == 0) {
                    printer.paperSource_list = new Vector<>();
                    printer.paperSource_default = str18;
                    PaperSource paperSource = new PaperSource();
                    paperSource.id = str18;
                    paperSource.name = "Default Tray";
                    printer.paperSource_list.add(paperSource);
                }
                if (printer.outputMode_list == null || printer.outputMode_list.size() == 0) {
                    printer.outputMode_list = new Vector<>();
                    printer.outputMode_default = str18;
                    OutputMode outputMode2 = new OutputMode();
                    outputMode2.id = str18;
                    outputMode2.name = str18;
                    outputMode2.resolution = str2;
                    printer.outputMode_list.add(outputMode2);
                }
                if (printer.outputDuplex_list == null || printer.outputDuplex_list.size() == 0) {
                    printer.outputDuplex_list = new Vector<>();
                    String str19 = "None";
                    printer.outputDuplex_default = str19;
                    OutputDuplex outputDuplex2 = new OutputDuplex();
                    outputDuplex2.id = str19;
                    outputDuplex2.name = str;
                    printer.outputDuplex_list.add(outputDuplex2);
                }
                return printer;
            }
        }
        z = true;
        printer.online = Boolean.valueOf(z);
        printer.title = App.fixEncoding(gPrinter2.displayName == null ? gPrinter2.displayName : gPrinter2.name);
        printer.model = App.fixEncoding(gPrinter2.name);
        printer.owner = new User();
        printer.owner.name = "Google Cloud";
        str = "Off";
        str2 = "200x200";
        String str72 = ", \"vendor_id\": \"";
        String str82 = "\"";
        String str92 = "true";
        String str102 = "CUSTOM_";
        if (gPrinter2.capabilities.printer.media_size != null) {
        }
        if (gPrinter2.capabilities.printer.color != null) {
        }
        if (gPrinter2.capabilities.printer.duplex != null) {
        }
        printer.paper_list = new Vector<>();
        String str122 = "Letter";
        printer.paper_default = str122;
        printer.paper_list.add(new Paper("Photo", "Photo, 4x6 inch", 1016, 1524));
        printer.paper_list.add(new Paper("L", "L, 3.5x5 inch", 889, 1270));
        printer.paper_list.add(new Paper(str122, str122, 2159, 2794));
        String str132 = "A4";
        printer.paper_list.add(new Paper(str132, str132, 2099, 2970));
        String str142 = "Legal";
        printer.paper_list.add(new Paper(str142, str142, 2159, 3556));
        String str152 = "A3";
        printer.paper_list.add(new Paper(str152, str152, 2970, 4198));
        String str162 = "Ledger";
        printer.paper_list.add(new Paper(str162, str162, 2794, 4318));
        String str172 = "B4";
        printer.paper_list.add(new Paper(str172, str172, 2571, 3644));
        Collections.sort(printer.paper_list);
        String str182 = "Default";
        printer.paperSource_list = new Vector<>();
        printer.paperSource_default = str182;
        PaperSource paperSource2 = new PaperSource();
        paperSource2.id = str182;
        paperSource2.name = "Default Tray";
        printer.paperSource_list.add(paperSource2);
        printer.outputMode_list = new Vector<>();
        printer.outputMode_default = str182;
        OutputMode outputMode22 = new OutputMode();
        outputMode22.id = str182;
        outputMode22.name = str182;
        outputMode22.resolution = str2;
        printer.outputMode_list.add(outputMode22);
        printer.outputDuplex_list = new Vector<>();
        String str192 = "None";
        printer.outputDuplex_default = str192;
        OutputDuplex outputDuplex22 = new OutputDuplex();
        outputDuplex22.id = str192;
        outputDuplex22.name = str;
        printer.outputDuplex_list.add(outputDuplex22);
        return printer;
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x00e7 A[Catch:{ Exception -> 0x01d8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00ea A[Catch:{ Exception -> 0x01d8 }] */
    private void authorize_done() {
        Method method;
        boolean z;
        this.last_error = null;
        if (this.credentials[1] != null) {
            String str = "cloud_account";
            if (this.prefs.getString(str, null) == null) {
                Editor edit = this.prefs.edit();
                edit.putString(str, this.credentials[0]);
                edit.commit();
            }
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://www.google.com/cloudprint/search?output=json").openConnection();
                httpURLConnection.setConnectTimeout(15000);
                httpURLConnection.setReadTimeout(15000);
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(false);
                httpURLConnection.setUseCaches(false);
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setRequestProperty("Connection", "close");
                httpURLConnection.setRequestProperty("User-Agent", App.getUserAgent());
                StringBuilder sb = new StringBuilder();
                sb.append("GoogleLogin auth=");
                sb.append(this.credentials[1]);
                httpURLConnection.setRequestProperty("Authorization", sb.toString());
                httpURLConnection.setRequestProperty("X-CloudPrint-Proxy", SmbConstants.NATIVE_LANMAN);
                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode == 200) {
                    GPrinterList gPrinterList = (GPrinterList) Json.read(new BufferedInputStream(httpURLConnection.getInputStream()), GPrinterList.class);
                    if (gPrinterList.printers != null) {
                        for (int i = 0; i < gPrinterList.printers.size(); i++) {
                            GPrinter gPrinter = (GPrinter) gPrinterList.printers.get(i);
                            Printer printer = new Printer();
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(gPrinter.id);
                            sb2.append("@cloudprint.google.");
                            printer.id = sb2.toString();
                            if (gPrinter.status != null && !"".equals(gPrinter.status)) {
                                if (!"0".equals(gPrinter.status)) {
                                    z = false;
                                    printer.online = Boolean.valueOf(z);
                                    printer.title = App.fixEncoding(gPrinter.displayName == null ? gPrinter.displayName : gPrinter.name);
                                    printer.model = App.fixEncoding(gPrinter.name);
                                    printer.owner = new User();
                                    printer.owner.name = "Google Cloud";
                                    this.printers.add(printer);
                                }
                            }
                            z = true;
                            printer.online = Boolean.valueOf(z);
                            printer.title = App.fixEncoding(gPrinter.displayName == null ? gPrinter.displayName : gPrinter.name);
                            printer.model = App.fixEncoding(gPrinter.name);
                            printer.owner = new User();
                            printer.owner.name = "Google Cloud";
                            this.printers.add(printer);
                        }
                        Editor edit2 = this.prefs.edit();
                        edit2.putString("cloud_token", this.credentials[1]);
                        edit2.commit();
                    }
                } else if ((responseCode == 403 || responseCode == 401 || "Token expired".equalsIgnoreCase(httpURLConnection.getResponseMessage())) && !this.ftoken) {
                    this.ftoken = true;
                    Object systemService = getSystemService("account");
                    if (systemService != null) {
                        try {
                            Method[] methods = systemService.getClass().getMethods();
                            int i2 = 0;
                            while (true) {
                                if (i2 < methods.length) {
                                    if ("invalidateAuthToken".equals(methods[i2].getName()) && methods[i2].getParameterTypes().length == 2) {
                                        method = methods[i2];
                                        break;
                                    }
                                    i2++;
                                } else {
                                    method = null;
                                    break;
                                }
                            }
                            method.invoke(systemService, new Object[]{"com.google", this.credentials[1]});
                            authorize(this.credentials[0]);
                            return;
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    } else {
                        Editor edit3 = this.prefs.edit();
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("cloud_token_");
                        sb3.append(this.credentials[0]);
                        edit3.remove(sb3.toString());
                        edit3.commit();
                        authorize(this.credentials[0]);
                        return;
                    }
                } else {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("Error: ");
                    sb4.append(responseCode);
                    sb4.append(" ");
                    sb4.append(httpURLConnection.getResponseMessage());
                    this.last_error = sb4.toString();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                StringBuilder sb5 = new StringBuilder();
                sb5.append("Internal Error: ");
                sb5.append(e2.getMessage());
                this.last_error = sb5.toString();
                App.reportThrowable(e2);
            }
        } else {
            this.last_error = "Error: Authorization failed or network error has occured";
        }
        runOnUiThread(new Runnable() {
            public void run() {
                ((PrinterAdapter) ((ListView) ActivityCloudPrinters.this.findViewById(R.id.list)).getAdapter()).fireOnChanged();
                ActivityCloudPrinters.this.hideProgress();
                if (ActivityCloudPrinters.this.isFinishing()) {
                    return;
                }
                if (ActivityCloudPrinters.this.last_error != null) {
                    ActivityCloudPrinters.this.displayLastError(new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCloudPrinters.this.chooseAccount();
                        }
                    });
                    return;
                }
                ((TextView) ActivityCloudPrinters.this.findViewById(R.id.hint1)).setText(String.format(ActivityCloudPrinters.this.getResources().getString(R.string.label_found_printers), new Object[]{Integer.valueOf(ActivityCloudPrinters.this.printers.size())}));
                ((TextView) ActivityCloudPrinters.this.findViewById(R.id.hint2)).setText(ActivityCloudPrinters.this.credentials[0]);
                if (ActivityCloudPrinters.this.printers.size() == 0) {
                    new Builder(ActivityCloudPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_no_printers_title).setMessage(R.string.dialog_no_cloud_printers_text).setPositiveButton(R.string.button_ok, null).setNeutralButton(R.string.button_read_more, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent();
                            intent.setAction("android.intent.action.VIEW");
                            intent.addCategory("android.intent.category.BROWSABLE");
                            intent.setData(Uri.parse("https://www.google.com/support/cloudprint/"));
                            ActivityCloudPrinters.this.startActivity(intent);
                        }
                    }).show();
                }
            }
        });
        this.wt = null;
    }
}
