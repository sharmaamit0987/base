package com.dynamixsoftware.printershare.data;

import org.w3c.dom.Element;

public class User {
    public String address;
    public String city;
    public String country;
    public String email;
    public String id;
    public String login;
    public String name;
    public String nick;
    public String password;
    public String phone;
    public String state;
    public String zip;

    public void readFromXml(Element element) {
        this.id = element.getAttribute("id");
        this.name = XmlUtil.getFirstNodeValue(element, "name");
        this.nick = XmlUtil.getFirstNodeValue(element, "nick");
        this.login = XmlUtil.getFirstNodeValue(element, "login");
        this.email = XmlUtil.getFirstNodeValue(element, "mail");
        this.phone = XmlUtil.getFirstNodeValue(element, "phone");
        this.address = XmlUtil.getFirstNodeValue(element, "address");
        this.city = XmlUtil.getFirstNodeValue(element, "city");
        this.state = XmlUtil.getFirstNodeValue(element, "state");
        this.zip = XmlUtil.getFirstNodeValue(element, "zip");
        this.country = XmlUtil.getFirstNodeValue(element, "country");
    }
}
