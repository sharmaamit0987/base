package com.dynamixsoftware.printershare.data;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public final class XmlUtil {
    private static DocumentBuilderFactory docBuilderFactory;

    class DOMSerializer {
        private String indent = "";
        private String lineSeparator = "\n";

        public DOMSerializer() {
        }

        public void setIndent(String str) {
            this.indent = str;
        }

        public void setLineSeparator(String str) {
            this.lineSeparator = str;
        }

        public void serialize(Document document, OutputStream outputStream) throws IOException {
            serialize(document, (Writer) new OutputStreamWriter(outputStream));
        }

        public void serialize(Document document, File file) throws IOException {
            serialize(document, (Writer) new FileWriter(file));
        }

        public void serialize(Document document, Writer writer) throws IOException {
            serializeNode(document, writer, "");
            writer.flush();
        }

        /* access modifiers changed from: protected */
        public String Normalize(String str) {
            if (str == null) {
                return "";
            }
            return str.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
        }

        public void serializeNode(Node node, Writer writer, String str) throws IOException {
            String str2 = "\"";
            String str3 = " ";
            switch (node.getNodeType()) {
                case 1:
                    String nodeName = node.getNodeName();
                    StringBuilder sb = new StringBuilder();
                    sb.append(str);
                    sb.append("<");
                    sb.append(nodeName);
                    writer.write(sb.toString());
                    NamedNodeMap attributes = node.getAttributes();
                    for (int i = 0; i < attributes.getLength(); i++) {
                        Node item = attributes.item(i);
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(str3);
                        sb2.append(item.getNodeName());
                        sb2.append("=\"");
                        sb2.append(Normalize(item.getNodeValue()));
                        sb2.append(str2);
                        writer.write(sb2.toString());
                    }
                    String str4 = ">";
                    writer.write(str4);
                    NodeList childNodes = node.getChildNodes();
                    if (childNodes != null) {
                        if (childNodes.item(0) != null && childNodes.item(0).getNodeType() == 1) {
                            writer.write(this.lineSeparator);
                        }
                        for (int i2 = 0; i2 < childNodes.getLength(); i2++) {
                            Node item2 = childNodes.item(i2);
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(str);
                            sb3.append(this.indent);
                            serializeNode(item2, writer, sb3.toString());
                        }
                        if (childNodes.item(0) != null && childNodes.item(childNodes.getLength() - 1).getNodeType() == 1) {
                            writer.write(str);
                        }
                    }
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("</");
                    sb4.append(nodeName);
                    sb4.append(str4);
                    writer.write(sb4.toString());
                    writer.write(this.lineSeparator);
                    return;
                case 3:
                    writer.write(Normalize(node.getNodeValue()));
                    return;
                case 4:
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("<![CDATA[");
                    sb5.append(node.getNodeValue());
                    sb5.append("]]>");
                    writer.write(sb5.toString());
                    return;
                case 5:
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append("&");
                    sb6.append(node.getNodeName());
                    sb6.append(";");
                    writer.write(sb6.toString());
                    return;
                case 7:
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append("<?");
                    sb7.append(node.getNodeName());
                    sb7.append(str3);
                    sb7.append(node.getNodeValue());
                    sb7.append("?>");
                    writer.write(sb7.toString());
                    writer.write(this.lineSeparator);
                    return;
                case 8:
                    StringBuilder sb8 = new StringBuilder();
                    sb8.append(str);
                    sb8.append("<!-- ");
                    sb8.append(node.getNodeValue());
                    sb8.append(" -->");
                    writer.write(sb8.toString());
                    writer.write(this.lineSeparator);
                    return;
                case 9:
                    writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                    writer.write(this.lineSeparator);
                    NodeList childNodes2 = node.getChildNodes();
                    if (childNodes2 != null) {
                        for (int i3 = 0; i3 < childNodes2.getLength(); i3++) {
                            serializeNode(childNodes2.item(i3), writer, "");
                        }
                        return;
                    }
                    return;
                case 10:
                    DocumentType documentType = (DocumentType) node;
                    StringBuilder sb9 = new StringBuilder();
                    sb9.append("<!DOCTYPE ");
                    sb9.append(documentType.getName());
                    writer.write(sb9.toString());
                    if (documentType.getPublicId() != null) {
                        PrintStream printStream = System.out;
                        StringBuilder sb10 = new StringBuilder();
                        sb10.append(" PUBLIC \"");
                        sb10.append(documentType.getPublicId());
                        sb10.append("\" ");
                        printStream.print(sb10.toString());
                    } else {
                        writer.write(" SYSTEM ");
                    }
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(str2);
                    sb11.append(documentType.getSystemId());
                    sb11.append("\">");
                    writer.write(sb11.toString());
                    writer.write(this.lineSeparator);
                    return;
                default:
                    return;
            }
        }
    }

    static {
        try {
            DocumentBuilderFactory newInstance = DocumentBuilderFactory.newInstance();
            docBuilderFactory = newInstance;
            newInstance.setValidating(false);
        } catch (Exception e) {
            System.err.println("Cannot initialize XML parser. VERY BAD");
            e.printStackTrace(System.err);
        }
    }

    public static final Element appendElement(Element element, String str, String str2) {
        Element createElement = element.getOwnerDocument().createElement(str);
        if (str2 != null) {
            createTextNode(createElement, str2);
        }
        element.appendChild(createElement);
        return createElement;
    }

    public static final Element appendElement(Element element, String str) {
        return appendElement(element, str, null);
    }

    public static final Element appendCDATA(Element element, String str, String str2) {
        Document ownerDocument = element.getOwnerDocument();
        Element createElement = ownerDocument.createElement(str);
        if (str2 != null) {
            createElement.appendChild(ownerDocument.createCDATASection(str2));
        }
        element.appendChild(createElement);
        return createElement;
    }

    public static final String getFirstCDATAValue(Element element, String str) {
        Element firstElement = getFirstElement(element, str);
        String str2 = "";
        if (firstElement == null) {
            return str2;
        }
        NodeList childNodes = firstElement.getChildNodes();
        int length = childNodes.getLength();
        for (int i = 0; i < length; i++) {
            Node item = childNodes.item(i);
            if (item.getNodeType() == 4) {
                return item.getNodeValue().trim();
            }
        }
        return str2;
    }

    public static final void removeElementsByTagName(Element element, String str) {
        NodeList elementsByTagName = element.getElementsByTagName(str);
        Vector vector = new Vector();
        int length = elementsByTagName.getLength();
        for (int i = 0; i < length; i++) {
            vector.add(elementsByTagName.item(i));
        }
        for (int i2 = 0; i2 < vector.size(); i2++) {
            element.removeChild((Element) vector.elementAt(i2));
        }
    }

    public static final Node getFirstNode(Node node, String str) {
        if (node == null) {
            return null;
        }
        NodeList childNodes = node.getChildNodes();
        if (childNodes != null) {
            int length = childNodes.getLength();
            for (int i = 0; i < length; i++) {
                Node item = childNodes.item(i);
                if (item.getNodeName().equals(str)) {
                    return item;
                }
            }
        }
        return null;
    }

    public static final String getFirstNodeValue(Node node, String str) {
        Element firstElement = getFirstElement(node, str);
        return firstElement != null ? getNodeValue(firstElement) : "";
    }

    public static final String getFirstNodeValue(Element element, String str, String str2) {
        String firstNodeValue = getFirstNodeValue(element, str);
        return firstNodeValue.length() == 0 ? str2 : firstNodeValue;
    }

    public static final int getFirstNodeValueInt(Element element, String str, int i) {
        String firstNodeValue = getFirstNodeValue(element, str);
        if (firstNodeValue.length() == 0) {
            return i;
        }
        try {
            return Integer.parseInt(firstNodeValue);
        } catch (Exception unused) {
            return i;
        }
    }

    public static final String getNodeValue(Node node) {
        String str = "";
        if (node == null) {
            return str;
        }
        if (node.getNodeType() == 1) {
            node = node.getFirstChild();
        }
        if (node == null) {
            return str;
        }
        String nodeValue = node.getNodeValue();
        if (nodeValue != null) {
            str = nodeValue;
        }
        return str;
    }

    public static final void setNodeValue(Node node, String str) {
        if (node != null) {
            if (node.getNodeType() == 1) {
                Node firstChild = node.getFirstChild();
                if (firstChild != null) {
                    node.removeChild(firstChild);
                }
                if (str != null) {
                    createTextNode(node, str);
                }
            }
            if (str == null) {
                str = "";
            }
            node.setNodeValue(str);
        }
    }

    public static final String getFirstNodeAttribute(Node node, String str, String str2) {
        Node firstNode = getFirstNode(node, str);
        Element element = (Element) (firstNode != null ? firstNode.getFirstChild() : null);
        return element != null ? element.getAttribute(str2) : "";
    }

    public static final Node setFirstNodeValue(Element element, String str, String str2) {
        Node firstNode = getFirstNode(element, str);
        if (firstNode == null) {
            return appendElement(element, str, str2);
        }
        Node firstChild = firstNode.getFirstChild();
        if (firstChild == null) {
            createTextNode(firstNode, str2);
        } else {
            firstChild.setNodeValue(str2);
        }
        return firstNode;
    }

    public static final Element getFirstElement(Node node) {
        return getFirstElement(node, null);
    }

    public static final Element getFirstElement(Node node, String str) {
        if (node == null) {
            return null;
        }
        NodeList childNodes = node.getChildNodes();
        if (childNodes != null) {
            int length = childNodes.getLength();
            for (int i = 0; i < length; i++) {
                Node item = childNodes.item(i);
                if (item.getNodeType() == 1 && (str == null || str.equals(item.getNodeName()))) {
                    return (Element) item;
                }
            }
        }
        return null;
    }

    public static final String[] getValues(Element element, String str) {
        String str2;
        Vector vector = new Vector();
        NodeList childNodes = element.getChildNodes();
        if (childNodes != null) {
            int length = childNodes.getLength();
            for (int i = 0; i < length; i++) {
                Node item = childNodes.item(i);
                if (item.getNodeType() == 1 && (str == null || str.equals(item.getNodeName()))) {
                    Node firstChild = item.getFirstChild();
                    if (firstChild == null) {
                        str2 = "";
                    } else {
                        str2 = firstChild.getNodeValue();
                    }
                    vector.addElement(str2);
                }
            }
        }
        String[] strArr = new String[vector.size()];
        vector.copyInto(strArr);
        return strArr;
    }

    public static final Node cloneAndAppend(Node node, Node node2) {
        Document ownerDocument = node2.getOwnerDocument();
        if (node2.getNodeType() == 9) {
            ownerDocument = (Document) node2;
        }
        if (ownerDocument == null) {
            return null;
        }
        Node importNode = ownerDocument.importNode(node, true);
        node2.appendChild(importNode);
        return importNode;
    }

    public static final Element mergeElements(Element element, Element element2) {
        NodeList childNodes = element.getChildNodes();
        int length = childNodes.getLength();
        for (int i = 0; i < length; i++) {
            Node item = childNodes.item(i);
            if (item.getNodeType() == 1) {
                Element element3 = (Element) item;
                Node firstNode = getFirstNode(element2, element3.getNodeName());
                if (firstNode != null) {
                    element2.removeChild(firstNode);
                }
                cloneAndAppend(element3, element2);
            }
        }
        return element2;
    }

    public static final Document getDocument(InputStream inputStream) throws Exception {
        return docBuilderFactory.newDocumentBuilder().parse(inputStream);
    }

    public static final Document getDocument(File file) throws Exception {
        return docBuilderFactory.newDocumentBuilder().parse(file);
    }

    public static final Document getDocument(String str) throws Exception {
        return getDocument(new File(str));
    }

    public static final Document newDocument() throws Exception {
        return docBuilderFactory.newDocumentBuilder().newDocument();
    }

    public static final Element getElementById(Element element, String str, String str2, String str3) {
        NodeList elementsByTagName = element.getElementsByTagName(str3);
        int length = elementsByTagName.getLength();
        for (int i = 0; i < length; i++) {
            Element element2 = (Element) elementsByTagName.item(i);
            if (element2.getAttribute(str).equals(str2)) {
                return element2;
            }
        }
        return null;
    }

    public static final Element getElementById(Document document, String str, String str2, String str3) {
        return getElementById(document.getDocumentElement(), str, str2, str3);
    }

    public static final void writeElement(Element element, Writer writer) throws Exception {
        XmlUtil xmlUtil = new XmlUtil();
        xmlUtil.getClass();
        new DOMSerializer().serializeNode(element, writer, "");
    }

    public static final void writeElement(Element element, OutputStream outputStream) throws Exception {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
        writeElement(element, (Writer) outputStreamWriter);
        outputStreamWriter.flush();
    }

    public static final void writeDocument(Document document, Writer writer) throws Exception {
        XmlUtil xmlUtil = new XmlUtil();
        xmlUtil.getClass();
        new DOMSerializer().serialize(document, writer);
    }

    public static final void writeDocument(Document document, OutputStream outputStream) throws Exception {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
        writeDocument(document, (Writer) outputStreamWriter);
        outputStreamWriter.flush();
    }

    public static final void writeDocument(Document document, File file) throws Exception {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        writeDocument(document, (OutputStream) fileOutputStream);
        fileOutputStream.close();
    }

    public static final void createTextNode(Node node, String str) {
        node.appendChild(node.getOwnerDocument().createTextNode(str));
    }
}
