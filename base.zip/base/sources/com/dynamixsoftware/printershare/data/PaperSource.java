package com.dynamixsoftware.printershare.data;

import org.w3c.dom.Element;

public class PaperSource implements Comparable<PaperSource> {
    public String drv_params;
    public String id;
    public String name;

    public void readFromXml(Element element) {
        this.id = element.getAttribute("bin");
        String str = "name";
        if (element.hasAttribute(str)) {
            this.name = element.getAttribute(str);
        } else {
            this.name = XmlUtil.getNodeValue(element);
        }
    }

    public int compareTo(PaperSource paperSource) {
        return this.name.compareTo(paperSource.name);
    }
}
