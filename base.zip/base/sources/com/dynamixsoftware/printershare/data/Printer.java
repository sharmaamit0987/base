package com.dynamixsoftware.printershare.data;

import com.dynamixsoftware.printershare.App;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Printer implements Comparable<Printer> {
    public Hashtable<String, String> capabilities;
    public HashSet<String> constraint_list;
    public String direct_address;
    public String[] drv_envp;
    public boolean drv_manual;
    public String drv_model;
    public String drv_name;
    public String drv_params;
    public String id;
    public String location;
    public String model;
    public Boolean online;
    public Vector<Printer> otherServices;
    public String outputColor_default;
    public Vector<OutputColor> outputColor_list;
    public String outputDuplex_default;
    public Vector<OutputDuplex> outputDuplex_list;
    public String outputMode_default;
    public Vector<OutputMode> outputMode_list;
    public User owner;
    public String paperSource_default;
    public Vector<PaperSource> paperSource_list;
    public String paperType_default;
    public Vector<PaperType> paperType_list;
    public String paper_default;
    public Vector<Paper> paper_list;
    public String title;

    public void readFromXml(Element element) {
        boolean z;
        this.id = XmlUtil.getFirstNodeValue(element, "public-id");
        this.online = Boolean.valueOf("True".equals(element.getAttribute("online")));
        this.location = XmlUtil.getFirstNodeValue(element, "location");
        this.title = XmlUtil.getFirstNodeValue(element, "title");
        this.model = XmlUtil.getFirstNodeValue(element, "model");
        Element firstElement = XmlUtil.getFirstElement(element, "owner");
        if (firstElement != null) {
            User user = new User();
            this.owner = user;
            user.readFromXml(firstElement);
        }
        Element firstElement2 = XmlUtil.getFirstElement(element, "details");
        this.capabilities = new Hashtable<>();
        Element firstElement3 = XmlUtil.getFirstElement(firstElement2, "capabilities");
        int i = 0;
        if (firstElement3 != null) {
            NamedNodeMap attributes = firstElement3.getAttributes();
            for (int i2 = 0; i2 < attributes.getLength(); i2++) {
                Node item = attributes.item(i2);
                this.capabilities.put(item.getNodeName(), item.getNodeValue());
            }
        }
        this.paper_list = new Vector<>();
        Element firstElement4 = XmlUtil.getFirstElement(firstElement2, "paper-formats");
        String str = "default";
        if (firstElement4 != null) {
            this.paper_default = firstElement4.getAttribute(str);
            NodeList elementsByTagName = firstElement4.getElementsByTagName("paper");
            int length = elementsByTagName.getLength();
            if (length == 0) {
                elementsByTagName = firstElement4.getElementsByTagName("paper-format");
                length = elementsByTagName.getLength();
            }
            z = false;
            for (int i3 = 0; i3 < length; i3++) {
                Paper readFromXml = Paper.readFromXml((Element) elementsByTagName.item(i3));
                this.paper_list.add(readFromXml);
                if (!z && readFromXml.id.equals(this.paper_default)) {
                    z = true;
                }
            }
            Collections.sort(this.paper_list);
        } else {
            z = false;
        }
        String str2 = "";
        if (!z) {
            this.paper_default = str2;
        }
        this.paperSource_list = new Vector<>();
        Element firstElement5 = XmlUtil.getFirstElement(firstElement2, "bins");
        if (firstElement5 != null) {
            this.paperSource_default = firstElement5.getAttribute(str);
            NodeList elementsByTagName2 = firstElement5.getElementsByTagName("bin");
            int length2 = elementsByTagName2.getLength();
            int i4 = 0;
            while (i < length2) {
                Element element2 = (Element) elementsByTagName2.item(i);
                PaperSource paperSource = new PaperSource();
                paperSource.readFromXml(element2);
                this.paperSource_list.add(paperSource);
                if (i4 == 0 && paperSource.id.equals(this.paperSource_default)) {
                    i4 = 1;
                }
                i++;
            }
            Collections.sort(this.paperSource_list);
            i = i4;
        }
        if (i == 0) {
            this.paperSource_default = str2;
        }
        this.outputMode_list = new Vector<>();
        OutputMode outputMode = new OutputMode();
        String str3 = "0";
        outputMode.id = str3;
        outputMode.name = "Default";
        String str4 = "200";
        outputMode.resolution = str4;
        this.outputMode_list.add(outputMode);
        String str5 = "1";
        if (str5.equals(this.capabilities.get("color"))) {
            OutputMode outputMode2 = new OutputMode();
            outputMode2.id = str5;
            outputMode2.name = "Grayscale";
            outputMode2.resolution = str4;
            this.outputMode_list.add(outputMode2);
            OutputMode outputMode3 = new OutputMode();
            outputMode3.id = "2";
            outputMode3.name = "Color";
            outputMode3.resolution = str4;
            this.outputMode_list.add(outputMode3);
        }
        this.outputMode_default = str3;
        this.outputDuplex_list = new Vector<>();
        if (str5.equals(this.capabilities.get("duplex"))) {
            OutputDuplex outputDuplex = new OutputDuplex();
            outputDuplex.id = str5;
            outputDuplex.name = "On";
            this.outputDuplex_list.add(outputDuplex);
        }
        OutputDuplex outputDuplex2 = new OutputDuplex();
        outputDuplex2.id = str3;
        outputDuplex2.name = "Off";
        this.outputDuplex_list.add(outputDuplex2);
        this.outputDuplex_default = str3;
    }

    public int compareTo(Printer printer) {
        return getPriority() - printer.getPriority();
    }

    private int getPriority() {
        int i = (this.id.startsWith("snmp_") || this.id.startsWith("bjnp_")) ? 1 : 0;
        if (this.direct_address.indexOf("://[") > 0) {
            i += 100;
        }
        if (this.id.endsWith("_pdl-datastream._tcp.local.")) {
            return i;
        }
        if (this.id.endsWith("_canon-bjnp1._tcp.local.")) {
            return i + 2;
        }
        if (this.id.endsWith("_ipps._tcp.local.")) {
            return i + 4;
        }
        if (this.id.endsWith("_ipp._tcp.local.")) {
            return i + 6;
        }
        return this.id.endsWith("_printer._tcp.local.") ? i + 8 : i + 10;
    }

    public String getInfoTitle() {
        String str = this.title;
        return str != null ? str : "";
    }

    public String getInfoOwner() {
        if (this.owner == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        sb.append(this.owner.login);
        sb.append("]");
        String sb2 = sb.toString();
        if (this.owner.nick != null && this.owner.nick.length() > 0) {
            sb2 = this.owner.nick;
        }
        if (this.owner.name != null && this.owner.name.length() > 0) {
            sb2 = this.owner.name;
        }
        return sb2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:70:0x0135  */
    /* JADX WARNING: Removed duplicated region for block: B:72:? A[RETURN, SYNTHETIC] */
    public String getInfoLocation() {
        String str;
        String str2;
        String str3 = "";
        try {
            if (this.owner != null) {
                str = (this.owner.country == null || this.owner.country.length() <= 0) ? str3 : this.owner.country;
                try {
                    String str4 = ", ";
                    if (this.owner.city != null) {
                        if (this.owner.city.length() > 0) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(this.owner.city);
                            if (str.length() <= 0) {
                                str4 = str3;
                            }
                            sb.append(str4);
                            sb.append(str);
                            str = sb.toString();
                        }
                    }
                    if (this.owner.state != null && this.owner.state.length() > 0) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(this.owner.state);
                        if (str.length() <= 0) {
                            str4 = str3;
                        }
                        sb2.append(str4);
                        sb2.append(str);
                        str = sb2.toString();
                    }
                } catch (Exception e) {
                    Exception exc = e;
                    str2 = str;
                    e = exc;
                    e.printStackTrace();
                    App.reportThrowable(e);
                    str = str2;
                    if (!str.equals(getInfoOwner())) {
                    }
                }
            } else {
                str = str3;
            }
            if (this.location != null && this.location.length() > 0) {
                str = this.location;
            }
            if ((str == null || str.length() == 0) && this.direct_address != null) {
                if (!this.direct_address.startsWith("pdl://") && !this.direct_address.startsWith("bjnp://") && !this.direct_address.startsWith("lpd://") && !this.direct_address.startsWith("ipp://") && !this.direct_address.startsWith("ipps://") && !this.direct_address.startsWith("wprt://")) {
                    if (!this.direct_address.startsWith("ptp://")) {
                        if (this.direct_address.startsWith("bluetooth://")) {
                            str = this.direct_address.substring(12);
                        }
                    }
                }
                int indexOf = this.direct_address.indexOf("://");
                StringBuilder sb3 = new StringBuilder();
                sb3.append("http");
                sb3.append(this.direct_address.substring(indexOf));
                str = new URL(sb3.toString()).getHost();
            }
            if (str == null) {
                str = str3;
            }
        } catch (Exception e2) {
            e = e2;
            str2 = str3;
            e.printStackTrace();
            App.reportThrowable(e);
            str = str2;
            if (!str.equals(getInfoOwner())) {
            }
        }
        return !str.equals(getInfoOwner()) ? str : str3;
    }

    public void clearDriverInfo() {
        this.drv_model = null;
        this.drv_name = null;
        this.drv_envp = null;
        this.drv_params = null;
        this.paper_default = null;
        this.paper_list = null;
        this.paperType_default = null;
        this.paperType_list = null;
        this.paperSource_default = null;
        this.paperSource_list = null;
        this.outputMode_default = null;
        this.outputMode_list = null;
        this.outputColor_default = null;
        this.outputColor_list = null;
        this.outputDuplex_default = null;
        this.outputDuplex_list = null;
        this.constraint_list = null;
    }
}
