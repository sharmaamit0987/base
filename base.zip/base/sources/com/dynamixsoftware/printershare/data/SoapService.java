package com.dynamixsoftware.printershare.data;

import java.net.HttpURLConnection;
import java.net.URL;

public class SoapService {
    private String service_url;
    private String user_agent;

    public SoapService(String str, String str2) {
        this.service_url = str;
        this.user_agent = str2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x00d5 A[SYNTHETIC, Splitter:B:30:0x00d5] */
    public SoapEnvelope doAction(SoapEnvelope soapEnvelope) throws Exception {
        URL url = new URL(this.service_url);
        HttpURLConnection httpURLConnection = null;
        int i = 0;
        while (true) {
            try {
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) url.openConnection();
                try {
                    httpURLConnection2.setConnectTimeout(15000);
                    httpURLConnection2.setReadTimeout(15000);
                    httpURLConnection2.setDoInput(true);
                    httpURLConnection2.setDoOutput(true);
                    httpURLConnection2.setUseCaches(false);
                    httpURLConnection2.setRequestMethod("POST");
                    httpURLConnection2.setRequestProperty("Connection", "close");
                    httpURLConnection2.setRequestProperty("User-Agent", this.user_agent);
                    httpURLConnection2.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
                    StringBuilder sb = new StringBuilder();
                    sb.append("http://www.printeranywhere.com/");
                    sb.append(soapEnvelope.action_name);
                    httpURLConnection2.setRequestProperty("SOAPAction", sb.toString());
                    XmlUtil.writeDocument(soapEnvelope.doc, httpURLConnection2.getOutputStream());
                    int responseCode = httpURLConnection2.getResponseCode();
                    if (responseCode == 200) {
                        String str = soapEnvelope.action_name;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(soapEnvelope.action_name);
                        sb2.append("Result");
                        SoapEnvelope soapEnvelope2 = new SoapEnvelope(str, sb2.toString(), "response", XmlUtil.getDocument(httpURLConnection2.getInputStream()));
                        if (httpURLConnection2 != null) {
                            try {
                                httpURLConnection2.disconnect();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        return soapEnvelope2;
                    } else if (i < 3) {
                        i++;
                        Thread.sleep((long) (i * 1000));
                        if (httpURLConnection2 != null) {
                            try {
                                httpURLConnection2.disconnect();
                            } catch (Exception e2) {
                                e2.printStackTrace();
                                httpURLConnection = httpURLConnection2;
                            }
                        }
                        httpURLConnection = null;
                    } else {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("Can't connect to ");
                        sb3.append(this.service_url);
                        sb3.append(". HTTP error ");
                        sb3.append(responseCode);
                        throw new Exception(sb3.toString());
                    }
                } catch (Throwable th) {
                    th = th;
                    httpURLConnection = httpURLConnection2;
                    if (httpURLConnection != null) {
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                if (httpURLConnection != null) {
                    try {
                        httpURLConnection.disconnect();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
                throw th;
            }
        }
    }
}
