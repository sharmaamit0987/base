package com.dynamixsoftware.printershare.data;

public class OutputMode implements Comparable<OutputMode> {
    public String drv_params;
    public String id;
    public String name;
    public String resolution;

    public int compareTo(OutputMode outputMode) {
        return this.name.compareTo(outputMode.name);
    }
}
