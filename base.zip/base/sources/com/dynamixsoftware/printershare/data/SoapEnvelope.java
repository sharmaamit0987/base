package com.dynamixsoftware.printershare.data;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class SoapEnvelope {
    static final String namespace = "http://www.printeranywhere.com/";
    static final String template = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body></soap:Body></soap:Envelope>";
    String action_name;
    String action_root;
    Element data;
    String data_root;
    Document doc;

    public SoapEnvelope(String str, String str2, String str3) throws Exception {
        this.action_name = str;
        this.action_root = str2;
        this.data_root = str3;
        Document document = XmlUtil.getDocument((InputStream) new ByteArrayInputStream(template.getBytes()));
        this.doc = document;
        Element appendElement = XmlUtil.appendElement((Element) document.getDocumentElement().getFirstChild(), str);
        String str4 = "xmlns";
        appendElement.setAttribute(str4, namespace);
        Element appendElement2 = XmlUtil.appendElement(appendElement, str2);
        if (str3 != null) {
            Element appendElement3 = XmlUtil.appendElement(appendElement2, str3);
            this.data = appendElement3;
            appendElement3.setAttribute(str4, "");
            return;
        }
        this.data = appendElement2;
    }

    SoapEnvelope(String str, String str2, String str3, Document document) throws Exception {
        this.action_name = str;
        this.action_root = str2;
        this.data_root = str3;
        this.doc = document;
        Element element = (Element) XmlUtil.getFirstNode(((Element) document.getDocumentElement().getFirstChild()).getFirstChild(), str2);
        this.data = element;
        if (str3 != null) {
            this.data = (Element) XmlUtil.getFirstNode(element, str3);
        }
    }

    public Element getDataRoot() {
        return this.data;
    }
}
