package com.dynamixsoftware.printershare.data;

public class PaperType implements Comparable<PaperType> {
    public String drv_params;
    public String id;
    public String name;

    public int compareTo(PaperType paperType) {
        return this.name.compareTo(paperType.name);
    }
}
