package com.dynamixsoftware.printershare.data;

public class OutputColor implements Comparable<OutputMode> {
    public String drv_params;
    public String id;
    public String name;

    public int compareTo(OutputMode outputMode) {
        return this.name.compareTo(outputMode.name);
    }
}
