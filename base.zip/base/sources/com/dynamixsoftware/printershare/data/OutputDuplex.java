package com.dynamixsoftware.printershare.data;

public class OutputDuplex implements Comparable<OutputDuplex> {
    public String drv_params;
    public String id;
    public boolean isBackSideRotated;
    public String name;

    public int compareTo(OutputDuplex outputDuplex) {
        return this.name.compareTo(outputDuplex.name);
    }
}
