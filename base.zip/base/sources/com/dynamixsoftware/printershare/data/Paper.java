package com.dynamixsoftware.printershare.data;

import android.graphics.Rect;
import org.w3c.dom.Element;

public class Paper implements Comparable<Paper> {
    public boolean custom;
    public String drv_params;
    public int height;
    public int height_orig;
    public String id;
    public boolean isLandscape270;
    public int margin_bottom;
    public int margin_left;
    public int margin_right;
    public int margin_top;
    public String name;
    public boolean roll;
    public int width;

    private Paper() {
    }

    public Paper(String str, String str2, int i, int i2) {
        this(str, str2, i, i2, 0, 0, 0, 0);
    }

    public Paper(String str, String str2, int i, int i2, Rect rect) {
        this(str, str2, i, i2, rect.left, i2 - rect.bottom, i - rect.right, rect.top);
    }

    public Paper(String str, String str2, int i, int i2, Rect rect, boolean z) {
        Rect rect2 = rect;
        int i3 = rect2.left;
        int i4 = i2 - rect2.bottom;
        int i5 = i - rect2.right;
        int i6 = rect2.top;
        this(str, str2, i, i2, i3, i4, i5, i6, false, z);
    }

    public Paper(String str, String str2, int i, int i2, int i3, int i4) {
        int i5 = i - i3;
        int i6 = i2 - i4;
        this(str, str2, i, i2, i5 / 2, i6 / 2, (i5 + 1) / 2, (i6 + 1) / 2, false);
    }

    public Paper(String str, String str2, int i, int i2, int i3, int i4, int i5, int i6) {
        this(str, str2, i, i2, i3, i4, i5, i6, false);
    }

    public Paper(String str, String str2, int i, int i2, int i3, int i4, int i5, int i6, boolean z) {
        this(str, str2, i, i2, i3, i4, i5, i6, z, true);
    }

    public Paper(String str, String str2, int i, int i2, int i3, int i4, int i5, int i6, boolean z, boolean z2) {
        this.id = str;
        this.name = str2;
        this.width = i;
        this.height = i2;
        this.height_orig = i2;
        this.margin_left = i3;
        this.margin_top = i4;
        this.margin_right = i5;
        this.margin_bottom = i6;
        this.roll = z;
        this.isLandscape270 = z2;
    }

    public static Paper readFromXml(Element element) {
        Paper paper = new Paper();
        paper.id = element.getAttribute("format");
        paper.width = Integer.parseInt(element.getAttribute("width"));
        int parseInt = Integer.parseInt(element.getAttribute("height"));
        paper.height = parseInt;
        paper.height_orig = parseInt;
        String attribute = element.getAttribute("area-x");
        String attribute2 = element.getAttribute("area-y");
        String attribute3 = element.getAttribute("area-width");
        String attribute4 = element.getAttribute("area-height");
        int i = 0;
        int parseInt2 = (attribute == null || attribute.length() == 0) ? 0 : Integer.parseInt(attribute);
        if (!(attribute2 == null || attribute2.length() == 0)) {
            i = Integer.parseInt(attribute2);
        }
        int parseInt3 = (attribute3 == null || attribute3.length() == 0) ? paper.width : Integer.parseInt(attribute3);
        int parseInt4 = (attribute4 == null || attribute4.length() == 0) ? paper.height : Integer.parseInt(attribute4);
        paper.margin_left = parseInt2;
        paper.margin_top = i;
        paper.margin_right = (paper.width - parseInt3) - parseInt2;
        paper.margin_bottom = (paper.height - parseInt4) - i;
        paper.custom = "true".equals(element.getAttribute("custom"));
        String str = "name";
        if (element.hasAttribute(str)) {
            paper.name = element.getAttribute(str);
        } else {
            paper.name = XmlUtil.getNodeValue(element);
            if ("256".equals(paper.id)) {
                paper.custom = true;
            }
        }
        return paper;
    }

    public int compareTo(Paper paper) {
        return this.name.compareTo(paper.name);
    }
}
