package com.dynamixsoftware.printershare;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Picture;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region.Op;
import android.graphics.drawable.PictureDrawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.SimpleOnScaleGestureListener;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

public class ActivityPreview extends ActivityRoot {
    boolean lst_scroll = false;
    boolean lst_scroll_draw = false;
    private GestureDetector mGestureDetector;
    /* access modifiers changed from: private */
    public PageImageView mPageView;
    private ScaleGestureDetector mScaleDetector;

    private class MyGestureListener extends SimpleOnGestureListener {
        private MyGestureListener() {
        }

        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            if (ActivityPreview.this.mPageView.getScale() > 1.0f) {
                ActivityPreview.this.lst_scroll = true;
                ActivityPreview.this.mPageView.postTranslateCenter(-f, -f2);
            }
            return true;
        }
    }

    class PageImageView extends ImageView {
        Matrix mBaseMatrix = new Matrix();
        private final Matrix mDisplayMatrix = new Matrix();
        private final float[] mMatrixValues = new float[9];
        float mMaxZoom;
        Matrix mSuppMatrix = new Matrix();
        /* access modifiers changed from: private */
        public PictureDrawable pd;

        public PageImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            setBackgroundColor(-16777216);
            setLayerType(1, null);
        }

        public void setPicture(Picture picture) {
            PictureDrawable pictureDrawable = this.pd;
            if (pictureDrawable != null) {
                pictureDrawable.setPicture(null);
            }
            this.pd = null;
            if (picture != null) {
                AnonymousClass1 r0 = new PictureDrawable(null) {
                    public void draw(Canvas canvas) {
                        Picture picture = getPicture();
                        if (picture != null) {
                            Rect bounds = getBounds();
                            canvas.save();
                            canvas.clipRect(bounds, Op.INTERSECT);
                            picture.draw(canvas);
                            canvas.restore();
                            canvas.save();
                            canvas.clipRect(bounds, Op.DIFFERENCE);
                            canvas.drawColor(-16777216);
                            canvas.restore();
                            if (ActivityPreview.this.lst_scroll) {
                                ActivityPreview.this.lst_scroll_draw = true;
                            }
                        }
                    }
                };
                this.pd = r0;
                r0.setPicture(picture);
                getProperBaseMatrix(picture, this.mBaseMatrix);
            } else {
                this.mBaseMatrix.reset();
            }
            this.mSuppMatrix.reset();
            setImageMatrix(getImageViewMatrix());
            this.mMaxZoom = maxZoom();
            setImageDrawable(this.pd);
        }

        /* access modifiers changed from: protected */
        public void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            PictureDrawable pictureDrawable = this.pd;
            if (pictureDrawable != null) {
                getProperBaseMatrix(pictureDrawable.getPicture(), this.mBaseMatrix);
                setImageMatrix(getImageViewMatrix());
                this.mMaxZoom = maxZoom();
            }
        }

        /* access modifiers changed from: protected */
        public void onDraw(Canvas canvas) {
            canvas.save();
            canvas.clipRect(new Rect(0, 0, getWidth(), getHeight()), Op.INTERSECT);
            super.onDraw(canvas);
            canvas.restore();
        }

        /* access modifiers changed from: 0000 */
        public float getScale(Matrix matrix) {
            matrix.getValues(this.mMatrixValues);
            return this.mMatrixValues[0];
        }

        /* access modifiers changed from: 0000 */
        public float getScale() {
            return getScale(this.mSuppMatrix);
        }

        private void getProperBaseMatrix(Picture picture, Matrix matrix) {
            float width = (float) getWidth();
            float height = (float) getHeight();
            float width2 = (float) picture.getWidth();
            float height2 = (float) picture.getHeight();
            matrix.reset();
            float min = Math.min(Math.min(width / width2, 2.0f), Math.min(height / height2, 2.0f));
            matrix.postScale(min, min);
            matrix.postTranslate((width - (width2 * min)) / 2.0f, (height - (height2 * min)) / 2.0f);
        }

        /* access modifiers changed from: 0000 */
        public Matrix getImageViewMatrix() {
            this.mDisplayMatrix.set(this.mBaseMatrix);
            this.mDisplayMatrix.postConcat(this.mSuppMatrix);
            return this.mDisplayMatrix;
        }

        /* access modifiers changed from: protected */
        public void postTranslateCenter(float f, float f2) {
            postTranslate(f, f2);
            center();
        }

        /* access modifiers changed from: 0000 */
        public float maxZoom() {
            if (this.pd == null) {
                return 1.0f;
            }
            float max = Math.max(((float) this.pd.getPicture().getWidth()) / ((float) getWidth()), ((float) this.pd.getPicture().getHeight()) / ((float) getHeight()));
            if (max < 2.0f) {
                max = 2.0f;
            }
            return max;
        }

        /* access modifiers changed from: 0000 */
        public void resetZoom() {
            float scale = 1.0f / getScale();
            this.mSuppMatrix.postScale(scale, scale, ((float) getWidth()) / 2.0f, ((float) getHeight()) / 2.0f);
            setImageMatrix(getImageViewMatrix());
            center();
        }

        /* access modifiers changed from: 0000 */
        public void zoomIn(float f) {
            if (getScale() < this.mMaxZoom && this.pd != null) {
                this.mSuppMatrix.postScale(f, f, ((float) getWidth()) / 2.0f, ((float) getHeight()) / 2.0f);
                setImageMatrix(getImageViewMatrix());
            }
        }

        /* access modifiers changed from: 0000 */
        public void zoomOut(float f) {
            if (this.pd != null) {
                float width = ((float) getWidth()) / 2.0f;
                float height = ((float) getHeight()) / 2.0f;
                Matrix matrix = new Matrix(this.mSuppMatrix);
                float f2 = 1.0f / f;
                matrix.postScale(f2, f2, width, height);
                if (getScale(matrix) < 1.0f) {
                    this.mSuppMatrix.setScale(1.0f, 1.0f, width, height);
                } else {
                    this.mSuppMatrix.postScale(f2, f2, width, height);
                }
                setImageMatrix(getImageViewMatrix());
                center();
            }
        }

        /* access modifiers changed from: 0000 */
        public void postTranslate(float f, float f2) {
            this.mSuppMatrix.postTranslate(f, f2);
        }

        /* access modifiers changed from: 0000 */
        public void center() {
            float f;
            if (this.pd != null) {
                Matrix imageViewMatrix = getImageViewMatrix();
                float f2 = 0.0f;
                RectF rectF = new RectF(0.0f, 0.0f, (float) this.pd.getPicture().getWidth(), (float) this.pd.getPicture().getHeight());
                imageViewMatrix.mapRect(rectF);
                float height = rectF.height();
                float width = rectF.width();
                float height2 = (float) getHeight();
                float f3 = height < height2 ? ((height2 - height) / 2.0f) - rectF.top : rectF.top > 0.0f ? -rectF.top : rectF.bottom < height2 ? ((float) getHeight()) - rectF.bottom : 0.0f;
                float width2 = (float) getWidth();
                if (width < width2) {
                    width2 = (width2 - width) / 2.0f;
                    f = rectF.left;
                } else {
                    if (rectF.left > 0.0f) {
                        f2 = -rectF.left;
                    } else if (rectF.right < width2) {
                        f = rectF.right;
                    }
                    postTranslate(f2, f3);
                    setImageMatrix(getImageViewMatrix());
                }
                f2 = width2 - f;
                postTranslate(f2, f3);
                setImageMatrix(getImageViewMatrix());
            }
        }
    }

    private class ScaleListener extends SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            float scaleFactor = scaleGestureDetector.getScaleFactor();
            if (scaleFactor > 1.0f) {
                ActivityPreview.this.mPageView.zoomIn(scaleFactor);
            } else {
                ActivityPreview.this.mPageView.zoomOut(1.0f / scaleFactor);
            }
            return true;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        this.mScaleDetector = new ScaleGestureDetector(this, new ScaleListener());
        this.mGestureDetector = new GestureDetector(this, new MyGestureListener());
        PageImageView pageImageView = new PageImageView(this);
        this.mPageView = pageImageView;
        setContentView(pageImageView);
        this.mPageView.setPicture(ActivityPrint.pp);
        ActivityPrint.pp = null;
    }

    public void onDestroy() {
        this.mPageView.setPicture(null);
        super.onDestroy();
    }

    public void finish() {
        getWindow().clearFlags(1024);
        super.finish();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.mPageView.pd != null) {
            PageImageView pageImageView = this.mPageView;
            pageImageView.setPicture(pageImageView.pd.getPicture());
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.mPageView.getVisibility() != 0 || i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        if (this.mPageView.getScale() > 1.0f) {
            this.mPageView.resetZoom();
        } else {
            onBackPressed();
        }
        return true;
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if ((motionEvent.getAction() == 1) && this.lst_scroll) {
            this.lst_scroll = false;
            if (this.lst_scroll_draw) {
                this.mPageView.pd.invalidateSelf();
            }
            this.lst_scroll_draw = false;
        }
        if (!super.dispatchTouchEvent(motionEvent)) {
            this.mScaleDetector.onTouchEvent(motionEvent);
            this.mGestureDetector.onTouchEvent(motionEvent);
        }
        return true;
    }
}
