package com.dynamixsoftware.printershare.jbig;

import com.dynamixsoftware.printershare.bjnp.BJNPMain;
import com.dynamixsoftware.printershare.mdns.DnsConstants;
import com.dynamixsoftware.printershare.smb.WinError;
import java.io.IOException;
import java.io.OutputStream;

public final class Jbig85 {
    public static final int JBG_LRLTWO = 64;
    public static final int JBG_TPBON = 8;
    public static final int JBG_VLENGTH = 32;
    static final int MARKER_ABORT = 4;
    static final int MARKER_ATMOVE = 6;
    static final int MARKER_COMMENT = 7;
    static final int MARKER_ESC = 255;
    static final int MARKER_NEWLEN = 5;
    static final int MARKER_RESERVE = 1;
    static final int MARKER_SDNORM = 2;
    static final int MARKER_SDRST = 3;
    static final int MARKER_STUFF = 0;
    static final int[] lsztab = {23069, 9606, 4372, 2059, 984, 474, 229, 111, 54, 26, 13, 6, 3, 1, 23167, 16165, 11506, 8316, 6073, 4482, 3311, 2465, 1839, 1372, 1030, 771, 576, 433, 324, 245, 183, 138, 104, 78, 59, 44, 23265, 18508, 14861, 12017, 9759, 7987, 6568, 5400, 4471, 3700, 3067, 2552, 2145, 1798, 1485, 1246, 1039, 867, 724, 604, 504, 420, 352, 293, 246, 203, 171, 143, 23314, 19716, 16684, 14296, 12264, 10556, 9081, 7903, 6825, 5966, 5156, 4508, 3947, 3409, 2998, 2624, 22578, 19740, 17294, 15325, 13550, 11950, 10650, 9494, 21872, 19625, 17625, 15906, 14372, 12980, 11799, 22184, 20294, 18405, 16847, 15421, 14174, 21041, 19471, 17977, 16734, 22055, 20711, 19333, 21911, 20559, 23056, 21794, 23019};
    static final int[] nlpstab = {BJNPMain.BJNP_RES_PRINT, 14, 16, 18, 20, 23, 25, 28, 30, 33, 35, 9, 10, 12, 143, 36, 38, 39, 40, 42, 43, 45, 46, 48, 49, 51, 52, 54, 56, 57, 59, 60, 62, 63, 32, 33, 165, 64, 65, 67, 68, 69, 70, 72, 73, 74, 75, 77, 78, 79, 48, 50, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 61, 61, 193, 80, 81, 82, 83, 84, 86, 87, 87, 72, 72, 74, 74, 75, 77, 77, 208, 88, 89, 90, 91, 92, 93, 86, 216, 95, 96, 97, 99, 99, 93, 223, DnsConstants.TYPE_UID, DnsConstants.TYPE_GID, DnsConstants.TYPE_UNSPEC, 104, 99, 105, 106, 107, DnsConstants.TYPE_UNSPEC, WinError.ERROR_PIPE_NOT_CONNECTED, 108, 109, 110, 111, 238, 112, 240};
    static final int[] nmpstab = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 13, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 9, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 32, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 48, 81, 82, 83, 84, 85, 86, 87, 71, 89, 90, 91, 92, 93, 94, 86, 96, 97, 98, 99, 100, 93, DnsConstants.TYPE_GID, DnsConstants.TYPE_UNSPEC, 104, 99, 106, 107, DnsConstants.TYPE_UNSPEC, 109, 107, 111, 109, 111};
    long _i;
    long _y;
    long a;
    int buffer;
    long c;
    int ct;
    long l0;
    int newlen;
    int options;
    OutputStream out;
    long sc;
    byte[] st;
    long x0;
    long y0;

    public Jbig85(long j, long j2, OutputStream outputStream) {
        this(j, j2, true, outputStream);
    }

    public Jbig85(long j, long j2, boolean z, OutputStream outputStream) {
        this(j, j2, z, false, outputStream);
    }

    public Jbig85(long j, long j2, boolean z, boolean z2, OutputStream outputStream) {
        this.x0 = j;
        this.y0 = j2;
        this.newlen = 0;
        this.out = outputStream;
        this.l0 = 128;
        if (z) {
            this.options = 96;
        } else {
            this.options = 64;
        }
        if (z2) {
            this.options |= 8;
        }
        this._y = 0;
        this._i = 0;
        this.st = new byte[4096];
        ae_reinit();
    }

    /* access modifiers changed from: 0000 */
    public final void ae_reinit() {
        this.c = 0;
        this.a = 65536;
        this.sc = 0;
        this.ct = 11;
        this.buffer = -1;
    }

    /* access modifiers changed from: 0000 */
    public final void output_newlen() throws IOException {
        byte[] bArr = new byte[6];
        if (this.newlen == 1) {
            bArr[0] = -1;
            bArr[1] = 5;
            long j = this.y0;
            bArr[2] = (byte) ((int) ((j >> 24) & 255));
            bArr[3] = (byte) ((int) ((j >> 16) & 255));
            bArr[4] = (byte) ((int) ((j >> 8) & 255));
            bArr[5] = (byte) ((int) (j & 255));
            this.out.write(bArr, 0, 6);
            this.newlen = 2;
            if (this._y == this.y0) {
                bArr[1] = 2;
                this.out.write(bArr, 0, 2);
            }
        }
    }

    public final void enc_lineout(byte[] bArr, byte[] bArr2) throws IOException {
        enc_lineout(bArr, bArr2, false);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Regions count limit reached
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeEndlessLoop(RegionMaker.java:368)
        	at jadx.core.dex.visitors.regions.RegionMaker.processLoop(RegionMaker.java:172)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:106)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processLoop(RegionMaker.java:225)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:106)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:690)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:695)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
        */
    /* JADX WARNING: Removed duplicated region for block: B:106:0x02d3  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x030b  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0316  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0197  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x02b3  */
    public final void enc_lineout(byte[] r66, byte[] r67, boolean r68) throws java.io.IOException {
        /*
            r65 = this;
            r0 = r65
            java.io.OutputStream r1 = r0.out
            long r2 = r0.x0
            long r4 = r0.y0
            long r6 = r0.l0
            int r8 = r0.options
            long r9 = r0._y
            long r11 = r0._i
            r13 = 20
            byte[] r14 = new byte[r13]
            int r15 = (r9 > r4 ? 1 : (r9 == r4 ? 0 : -1))
            if (r15 < 0) goto L_0x0019
            return
        L_0x0019:
            r16 = 9
            r17 = 7
            r18 = 19
            r19 = 3
            r13 = 2
            r21 = 8
            r22 = 0
            r24 = 1
            r25 = 255(0xff, double:1.26E-321)
            r15 = 0
            int r28 = (r9 > r22 ? 1 : (r9 == r22 ? 0 : -1))
            if (r28 != 0) goto L_0x00c5
            r14[r15] = r15
            r14[r24] = r15
            r14[r13] = r24
            r14[r19] = r15
            r28 = 4
            r29 = 24
            long r30 = r2 >> r29
            r32 = r14
            long r13 = r30 & r25
            int r14 = (int) r13
            byte r13 = (byte) r14
            r32[r28] = r13
            r13 = 5
            r14 = 16
            long r30 = r2 >> r14
            long r14 = r30 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 6
            long r14 = r2 >> r21
            long r14 = r14 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            long r13 = r2 & r25
            int r14 = (int) r13
            byte r13 = (byte) r14
            r32[r17] = r13
            long r13 = r4 >> r29
            long r13 = r13 & r25
            int r14 = (int) r13
            byte r13 = (byte) r14
            r32[r21] = r13
            r13 = 16
            long r14 = r4 >> r13
            long r13 = r14 & r25
            int r14 = (int) r13
            byte r13 = (byte) r14
            r32[r16] = r13
            long r13 = r4 >> r21
            long r13 = r13 & r25
            int r14 = (int) r13
            byte r13 = (byte) r14
            r14 = 10
            r32[r14] = r13
            r13 = 11
            long r14 = r4 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 12
            long r14 = r6 >> r29
            long r14 = r14 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 13
            r14 = 16
            long r29 = r6 >> r14
            long r14 = r29 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 14
            long r14 = r6 >> r21
            long r14 = r14 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 15
            long r14 = r6 & r25
            int r15 = (int) r14
            byte r14 = (byte) r15
            r32[r13] = r14
            r13 = 16
            r14 = 0
            r32[r13] = r14
            r13 = 17
            r32[r13] = r14
            r13 = 18
            r32[r13] = r14
            r8 = r8 & 104(0x68, float:1.46E-43)
            byte r8 = (byte) r8
            r32[r18] = r8
            r8 = r32
            r13 = 20
            r1.write(r8, r14, r13)
            goto L_0x00c6
        L_0x00c5:
            r8 = r14
        L_0x00c6:
            int r13 = (r11 > r22 ? 1 : (r11 == r22 ? 0 : -1))
            if (r13 != 0) goto L_0x00d0
            r65.output_newlen()
            r65.ae_reinit()
        L_0x00d0:
            long r13 = r2 >> r19
            r29 = 7
            long r31 = r2 & r29
            int r15 = (r31 > r22 ? 1 : (r31 == r22 ? 0 : -1))
            r33 = r4
            r20 = r8
            if (r15 == 0) goto L_0x00e0
            r8 = 1
            goto L_0x00e1
        L_0x00e0:
            r8 = 0
        L_0x00e1:
            long r4 = (long) r8
            long r13 = r13 + r4
            r8 = 255(0xff, float:3.57E-43)
            r35 = 1
            if (r15 == 0) goto L_0x0100
            long r4 = r13 - r35
            int r5 = (int) r4
            byte r4 = r66[r5]
            r4 = r4 & r8
            r39 = r9
            r37 = 8
            long r8 = r37 - r31
            int r9 = (int) r8
            int r8 = r24 << r9
            int r8 = r8 + -1
            int r8 = ~r8
            r4 = r4 & r8
            byte r4 = (byte) r4
            r66[r5] = r4
            goto L_0x0102
        L_0x0100:
            r39 = r9
        L_0x0102:
            byte[] r4 = r0.st
            long r8 = r0.a
            r31 = r11
            long r10 = r0.c
            r41 = r6
            long r5 = r0.sc
            int r12 = r0.ct
            int r15 = r0.buffer
            int r7 = r0.options
            r7 = r7 & 8
            r44 = 4294934528(0xffff8000, double:2.1219796014E-314)
            r46 = r5
            r6 = 128(0x80, float:1.794E-43)
            if (r7 == 0) goto L_0x01d5
            r7 = 405(0x195, float:5.68E-43)
            byte r48 = r4[r7]
            r48 = r48 & 127(0x7f, float:1.78E-43)
            int[] r49 = lsztab
            r5 = r49[r48]
            byte r49 = r4[r7]
            r7 = r6 ^ r49
            r7 = r7 & r6
            if (r7 == 0) goto L_0x014e
            long r6 = (long) r5
            long r8 = r8 - r6
            int r5 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r5 < 0) goto L_0x013a
            long r10 = r10 + r8
            goto L_0x013b
        L_0x013a:
            r6 = r8
        L_0x013b:
            r5 = 405(0x195, float:5.68E-43)
            byte r8 = r4[r5]
            r9 = 128(0x80, float:1.794E-43)
            r8 = r8 & r9
            int[] r9 = nlpstab
            r9 = r9[r48]
            r8 = r8 ^ r9
            byte r8 = (byte) r8
            r4[r5] = r8
        L_0x014a:
            r7 = r6
            r5 = r46
            goto L_0x0170
        L_0x014e:
            long r5 = (long) r5
            long r8 = r8 - r5
            long r51 = r8 & r44
            int r7 = (r51 > r22 ? 1 : (r51 == r22 ? 0 : -1))
            if (r7 == 0) goto L_0x0158
            goto L_0x01d5
        L_0x0158:
            int r7 = (r8 > r5 ? 1 : (r8 == r5 ? 0 : -1))
            if (r7 >= 0) goto L_0x015f
            long r10 = r10 + r8
            r6 = r5
            goto L_0x0160
        L_0x015f:
            r6 = r8
        L_0x0160:
            r5 = 405(0x195, float:5.68E-43)
            byte r8 = r4[r5]
            r9 = 128(0x80, float:1.794E-43)
            r8 = r8 & r9
            int[] r9 = nmpstab
            r9 = r9[r48]
            r8 = r8 | r9
            byte r8 = (byte) r8
            r4[r5] = r8
            goto L_0x014a
        L_0x0170:
            long r7 = r7 << r24
            long r46 = r10 << r24
            r9 = -1
            int r12 = r12 + r9
            if (r12 != 0) goto L_0x01ca
            long r11 = r46 >> r18
            r9 = 4294967040(0xffffff00, double:2.1219956645E-314)
            long r9 = r9 & r11
            int r48 = (r9 > r22 ? 1 : (r9 == r22 ? 0 : -1))
            if (r48 == 0) goto L_0x01a2
            if (r15 < 0) goto L_0x019c
            int r15 = r15 + 1
            r1.write(r15)
            r9 = 255(0xff, float:3.57E-43)
            if (r15 != r9) goto L_0x019c
            r9 = 0
            r1.write(r9)
        L_0x0193:
            int r15 = (r5 > r22 ? 1 : (r5 == r22 ? 0 : -1))
            if (r15 == 0) goto L_0x019e
            r1.write(r9)
            long r5 = r5 - r35
        L_0x019c:
            r9 = 0
            goto L_0x0193
        L_0x019e:
            long r11 = r11 & r25
            int r15 = (int) r11
            goto L_0x01c1
        L_0x01a2:
            int r9 = (r11 > r25 ? 1 : (r11 == r25 ? 0 : -1))
            if (r9 != 0) goto L_0x01a9
            long r5 = r5 + r35
            goto L_0x01c1
        L_0x01a9:
            if (r15 < 0) goto L_0x01ae
            r1.write(r15)
        L_0x01ae:
            int r9 = (r5 > r22 ? 1 : (r5 == r22 ? 0 : -1))
            if (r9 == 0) goto L_0x01be
            r9 = 255(0xff, float:3.57E-43)
            r1.write(r9)
            r9 = 0
            r1.write(r9)
            long r5 = r5 - r35
            goto L_0x01ae
        L_0x01be:
            long r9 = r11 & r25
            int r15 = (int) r9
        L_0x01c1:
            r9 = 524287(0x7ffff, double:2.59032E-318)
            long r9 = r46 & r9
            r10 = r9
            r12 = 8
            goto L_0x01cc
        L_0x01ca:
            r10 = r46
        L_0x01cc:
            r46 = 32768(0x8000, double:1.61895E-319)
            int r9 = (r7 > r46 ? 1 : (r7 == r46 ? 0 : -1))
            if (r9 < 0) goto L_0x0170
            r8 = r7
            goto L_0x01d7
        L_0x01d5:
            r5 = r46
        L_0x01d7:
            int r7 = (r39 > r35 ? 1 : (r39 == r35 ? 0 : -1))
            r46 = r5
            r5 = -1
            if (r7 >= 0) goto L_0x01e0
            r7 = -1
            goto L_0x01e1
        L_0x01e0:
            r7 = 0
        L_0x01e1:
            if (r7 == r5) goto L_0x01ee
            byte r5 = r67[r7]
            r6 = 255(0xff, float:3.57E-43)
            r5 = r5 & r6
            r43 = r7
            long r6 = (long) r5
            long r5 = r6 << r21
            goto L_0x01f2
        L_0x01ee:
            r43 = r7
            r5 = r22
        L_0x01f2:
            r50 = r22
            r52 = r50
            r62 = r15
            r15 = r12
            r63 = r10
            r10 = r62
            r11 = r8
            r9 = r43
            r43 = 0
            r7 = r5
            r5 = r63
        L_0x0205:
            int r54 = (r50 > r2 ? 1 : (r50 == r2 ? 0 : -1))
            if (r54 >= 0) goto L_0x033a
            r54 = r10
            byte r10 = r66[r43]
            r55 = r15
            r15 = 255(0xff, float:3.57E-43)
            r10 = r10 & r15
            r56 = r5
            long r5 = (long) r10
            long r5 = r52 | r5
            r37 = 8
            long r52 = r13 * r37
            long r52 = r52 - r37
            int r10 = (r50 > r52 ? 1 : (r50 == r52 ? 0 : -1))
            if (r10 >= 0) goto L_0x0230
            r10 = -1
            if (r9 == r10) goto L_0x0230
            int r10 = r9 + 1
            byte r10 = r67[r10]
            r10 = r10 & r15
            r52 = r5
            r15 = r54
            long r5 = (long) r10
            long r7 = r7 | r5
            goto L_0x0234
        L_0x0230:
            r52 = r5
            r15 = r54
        L_0x0234:
            r10 = r15
            r5 = r52
            r15 = r55
        L_0x0239:
            long r5 = r5 << r24
            long r7 = r7 << r24
            r27 = 10
            long r52 = r7 >> r27
            r54 = 1008(0x3f0, double:4.98E-321)
            long r52 = r52 & r54
            long r54 = r5 >> r16
            r58 = 15
            long r54 = r54 & r58
            r58 = r7
            long r7 = r52 | r54
            int r8 = (int) r7
            long r52 = r5 >> r21
            r60 = r5
            long r5 = r52 & r35
            int r6 = (int) r5
            byte r5 = r4[r8]
            r5 = r5 & 127(0x7f, float:1.78E-43)
            int[] r7 = lsztab
            r7 = r7[r5]
            int r6 = r6 << 7
            byte r52 = r4[r8]
            r6 = r6 ^ r52
            r52 = r10
            r10 = 128(0x80, float:1.794E-43)
            r6 = r6 & r10
            if (r6 == 0) goto L_0x0286
            long r6 = (long) r7
            long r11 = r11 - r6
            int r49 = (r11 > r6 ? 1 : (r11 == r6 ? 0 : -1))
            if (r49 < 0) goto L_0x0275
            long r56 = r56 + r11
            goto L_0x0276
        L_0x0275:
            r6 = r11
        L_0x0276:
            byte r11 = r4[r8]
            r11 = r11 & r10
            int[] r10 = nlpstab
            r5 = r10[r5]
            r5 = r5 ^ r11
            byte r5 = (byte) r5
            r4[r8] = r5
            r5 = r52
        L_0x0283:
            r11 = 128(0x80, float:1.794E-43)
            goto L_0x02ab
        L_0x0286:
            long r6 = (long) r7
            long r11 = r11 - r6
            long r53 = r11 & r44
            int r10 = (r53 > r22 ? 1 : (r53 == r22 ? 0 : -1))
            if (r10 == 0) goto L_0x0294
            r10 = r52
            r8 = 255(0xff, float:3.57E-43)
            goto L_0x0318
        L_0x0294:
            int r10 = (r11 > r6 ? 1 : (r11 == r6 ? 0 : -1))
            if (r10 >= 0) goto L_0x029b
            long r56 = r56 + r11
            goto L_0x029c
        L_0x029b:
            r6 = r11
        L_0x029c:
            byte r10 = r4[r8]
            r11 = 128(0x80, float:1.794E-43)
            r10 = r10 & r11
            int[] r12 = nmpstab
            r5 = r12[r5]
            r5 = r5 | r10
            byte r5 = (byte) r5
            r4[r8] = r5
            r5 = r52
        L_0x02ab:
            long r6 = r6 << r24
            long r52 = r56 << r24
            r8 = -1
            int r15 = r15 + r8
            if (r15 != 0) goto L_0x030b
            long r54 = r52 >> r18
            r56 = 4294967040(0xffffff00, double:2.1219956645E-314)
            long r56 = r54 & r56
            int r8 = (r56 > r22 ? 1 : (r56 == r22 ? 0 : -1))
            if (r8 == 0) goto L_0x02de
            if (r5 < 0) goto L_0x02d8
            int r5 = r5 + 1
            r1.write(r5)
            r8 = 255(0xff, float:3.57E-43)
            if (r5 != r8) goto L_0x02d8
            r5 = 0
            r1.write(r5)
        L_0x02cf:
            int r8 = (r46 > r22 ? 1 : (r46 == r22 ? 0 : -1))
            if (r8 == 0) goto L_0x02da
            r1.write(r5)
            long r46 = r46 - r35
        L_0x02d8:
            r5 = 0
            goto L_0x02cf
        L_0x02da:
            long r10 = r54 & r25
            int r5 = (int) r10
            goto L_0x02e4
        L_0x02de:
            int r8 = (r54 > r25 ? 1 : (r54 == r25 ? 0 : -1))
            if (r8 != 0) goto L_0x02e7
            long r46 = r46 + r35
        L_0x02e4:
            r8 = 255(0xff, float:3.57E-43)
            goto L_0x0301
        L_0x02e7:
            if (r5 < 0) goto L_0x02ec
            r1.write(r5)
        L_0x02ec:
            int r5 = (r46 > r22 ? 1 : (r46 == r22 ? 0 : -1))
            if (r5 == 0) goto L_0x02fc
            r8 = 255(0xff, float:3.57E-43)
            r1.write(r8)
            r5 = 0
            r1.write(r5)
            long r46 = r46 - r35
            goto L_0x02ec
        L_0x02fc:
            r8 = 255(0xff, float:3.57E-43)
            long r10 = r54 & r25
            int r5 = (int) r10
        L_0x0301:
            r10 = 524287(0x7ffff, double:2.59032E-318)
            long r10 = r52 & r10
            r56 = r10
            r15 = 8
            goto L_0x030f
        L_0x030b:
            r8 = 255(0xff, float:3.57E-43)
            r56 = r52
        L_0x030f:
            r10 = 32768(0x8000, double:1.61895E-319)
            int r12 = (r6 > r10 ? 1 : (r6 == r10 ? 0 : -1))
            if (r12 < 0) goto L_0x0283
            r10 = r5
            r11 = r6
        L_0x0318:
            long r50 = r50 + r35
            long r5 = r50 & r29
            int r7 = (r5 > r22 ? 1 : (r5 == r22 ? 0 : -1))
            if (r7 == 0) goto L_0x032b
            int r5 = (r50 > r2 ? 1 : (r50 == r2 ? 0 : -1))
            if (r5 < 0) goto L_0x0325
            goto L_0x032b
        L_0x0325:
            r7 = r58
            r5 = r60
            goto L_0x0239
        L_0x032b:
            int r43 = r43 + 1
            r5 = -1
            if (r9 == r5) goto L_0x0332
            int r9 = r9 + 1
        L_0x0332:
            r5 = r56
            r7 = r58
            r52 = r60
            goto L_0x0205
        L_0x033a:
            r56 = r5
            r55 = r15
            r15 = r10
            r0.a = r11
            r10 = r56
            r0.c = r10
            r2 = r46
            r0.sc = r2
            r12 = r55
            r0.ct = r12
            r0.buffer = r15
            long r11 = r31 + r35
            long r9 = r39 + r35
            int r2 = (r11 > r41 ? 1 : (r11 == r41 ? 0 : -1))
            if (r2 == 0) goto L_0x035d
            int r2 = (r9 > r33 ? 1 : (r9 == r33 ? 0 : -1))
            if (r2 == 0) goto L_0x035d
            if (r68 == 0) goto L_0x0382
        L_0x035d:
            r65.ae_flush()
            r2 = -1
            r3 = 0
            r20[r3] = r2
            if (r68 == 0) goto L_0x0368
            r2 = 3
            goto L_0x0369
        L_0x0368:
            r2 = 2
        L_0x0369:
            byte r2 = (byte) r2
            r20[r24] = r2
            r2 = r20
            r4 = 2
            r1.write(r2, r3, r4)
            if (r68 == 0) goto L_0x037d
            r1 = 4096(0x1000, float:5.74E-42)
            byte[] r1 = new byte[r1]
            r0.st = r1
            r65.ae_reinit()
        L_0x037d:
            r65.output_newlen()
            r11 = r22
        L_0x0382:
            r0._y = r9
            r0._i = r11
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dynamixsoftware.printershare.jbig.Jbig85.enc_lineout(byte[], byte[], boolean):void");
    }

    /* access modifiers changed from: 0000 */
    public final void ae_flush() throws IOException {
        OutputStream outputStream = this.out;
        long j = this.a;
        long j2 = this.c;
        long j3 = this.sc;
        int i = this.ct;
        int i2 = this.buffer;
        long j4 = ((j - 1) + j2) & 4294901760L;
        if (j4 < j2) {
            j4 += 32768;
        }
        long j5 = j4 << i;
        if ((4160749568L & j5) != 0) {
            if (i2 >= 0) {
                int i3 = i2 + 1;
                outputStream.write(i3);
                if (i3 == 255) {
                    outputStream.write(0);
                }
            }
            if ((j5 & 134215680) != 0) {
                while (j3 != 0) {
                    outputStream.write(0);
                    j3--;
                }
            }
        } else {
            if (i2 >= 0) {
                outputStream.write(i2);
            }
            while (j3 != 0) {
                outputStream.write(255);
                outputStream.write(0);
                j3--;
            }
        }
        if ((j5 & 134215680) != 0) {
            long j6 = (j5 >> 19) & 255;
            outputStream.write((int) j6);
            if (j6 == 255) {
                outputStream.write(0);
            }
            if ((522240 & j5) != 0) {
                long j7 = (j5 >> 11) & 255;
                outputStream.write((int) j7);
                if (j7 == 255) {
                    outputStream.write(0);
                }
            }
        }
        this.a = j;
        this.c = j5;
        this.sc = j3;
        this.ct = i;
        this.buffer = i2;
    }

    public final void enc_newlen(long j) throws IOException {
        byte[] bArr = new byte[6];
        if (this.newlen != 2 && j < this.y0 && j >= 1 && (this.options & 32) != 0) {
            long j2 = this._y;
            if (j < j2) {
                j = j2;
            }
            if (this._y > 0 && this.y0 != j) {
                this.newlen = 1;
            }
            this.y0 = j;
            if (this._y == j) {
                if (this._i > 0) {
                    ae_flush();
                    bArr[0] = -1;
                    bArr[1] = 2;
                    this.out.write(bArr, 0, 2);
                    this._i = 0;
                }
                output_newlen();
            }
        }
    }
}
