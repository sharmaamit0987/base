package com.dynamixsoftware.printershare;

import android.graphics.Bitmap;

public class K2render {

    public interface ReadingCallback {
        void on_reading(int i);
    }

    static native int closeFile();

    static native int createViewer(String str, int i);

    static native int deleteViewer();

    static native int drawPage(int i, int i2, int i3, int i4, int i5, int i6, int i7, boolean z, Bitmap bitmap);

    static native int getPageCount();

    static native int getPageSize(int i, int i2, int[] iArr);

    static native int init(String[] strArr);

    static native int openFile(String str, int i, String str2, ReadingCallback readingCallback);

    static native int setDPI(int i);
}
