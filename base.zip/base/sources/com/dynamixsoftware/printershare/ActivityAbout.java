package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActivityAbout extends ActivityRoot {
    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        setContentView(R.layout.about);
        setTitle((int) R.string.header_about);
        String version = App.getVersion();
        StringBuilder sb = new StringBuilder();
        sb.append(version);
        sb.append(getTitleSuffix());
        String sb2 = sb.toString();
        TextView textView = (TextView) findViewById(R.id.about_version);
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getResources().getString(R.string.app_name));
        sb3.append(" ");
        sb3.append(sb2);
        textView.setText(sb3.toString());
        String campaignID = getCampaignID();
        TextView textView2 = (TextView) findViewById(R.id.about_campaign);
        if (campaignID.length() > 0) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append("[");
            sb4.append(campaignID);
            sb4.append("]");
            str = sb4.toString();
        } else {
            str = "";
        }
        textView2.setText(str);
        ((Button) findViewById(R.id.open_printershare_button)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                intent.addCategory("android.intent.category.BROWSABLE");
                intent.setData(Uri.parse("http://www.printershare.com"));
                ActivityAbout.this.startActivity(intent);
            }
        });
        ((Button) findViewById(R.id.open_dynamix_button)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                intent.addCategory("android.intent.category.BROWSABLE");
                intent.setData(Uri.parse("http://www.mobiledynamix.com"));
                ActivityAbout.this.startActivity(intent);
            }
        });
    }
}
