package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences.Editor;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.dynamixsoftware.printershare.ActivityCloudPrinters.GPrinter;
import com.dynamixsoftware.printershare.ActivityCloudPrinters.GPrinterList;
import com.dynamixsoftware.printershare.bjnp.BJNPSocket;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.SoapEnvelope;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.data.XmlUtil;
import com.dynamixsoftware.printershare.ipp.IppAttribute;
import com.dynamixsoftware.printershare.ipp.IppConnection;
import com.dynamixsoftware.printershare.ipp.IppMessage;
import com.dynamixsoftware.printershare.smb.SmbFile;
import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.Collections;
import java.util.Hashtable;
import java.util.UUID;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ActivityStart extends ActivityCore {
    private static final int DIALOG_LOGIN = 2;
    private static final int DIALOG_REGISTER = 1;
    /* access modifiers changed from: private */
    public Vector<Printer> cloud_printers;
    /* access modifiers changed from: private */
    public Vector<Printer> local_printers;
    protected Handler scanHandler = new Handler() {
        public synchronized void handleMessage(Message message) {
            int i = message.what;
            if (i == 3 || i == 4) {
                if (message.arg1 == 0) {
                    if (ActivityStart.this.st_bonjour != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_bonjour.getPrinters());
                    }
                    ActivityStart.this.st_bonjour = null;
                } else if (message.arg1 == 1) {
                    if (ActivityStart.this.st_snmp != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_snmp.getPrinters());
                    }
                    ActivityStart.this.st_snmp = null;
                } else if (message.arg1 == 2) {
                    if (ActivityStart.this.st_bjnp != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_bjnp.getPrinters());
                    }
                    ActivityStart.this.st_bjnp = null;
                } else if (message.arg1 == 3) {
                    if (ActivityStart.this.st_bluetooth != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_bluetooth.getPrinters());
                    }
                    ActivityStart.this.st_bluetooth = null;
                } else if (message.arg1 == 4) {
                    if (ActivityStart.this.st_usb != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_usb.getPrinters());
                    }
                    ActivityStart.this.st_usb = null;
                } else if (message.arg1 == 5) {
                    if (ActivityStart.this.st_wsd != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_wsd.getPrinters());
                    }
                    ActivityStart.this.st_wsd = null;
                } else if (message.arg1 == 6) {
                    if (ActivityStart.this.st_tpl != null) {
                        ActivityStart.this.local_printers.addAll(ActivityStart.this.st_tpl.getPrinters());
                    }
                    ActivityStart.this.st_tpl = null;
                }
                if (ActivityStart.this.st_bonjour == null && ActivityStart.this.st_snmp == null && ActivityStart.this.st_bjnp == null && ActivityStart.this.st_wsd == null && ActivityStart.this.st_tpl == null && ActivityStart.this.st_bluetooth == null && ActivityStart.this.st_usb == null) {
                    ActivityCore.remote_token = ActivityStart.this.prefs.getString("token", "");
                    if (ActivityCore.remote_token.length() <= 0 || message.arg1 != -1) {
                        ActivityStart.this.wt = new LoginThread(4);
                    } else {
                        ActivityStart.this.wt = new LoginThread(3);
                    }
                    ActivityStart.this.wt.start();
                    synchronized (ActivityStart.this) {
                        try {
                            if (ActivityStart.this.wl != null && ActivityStart.this.wl.isHeld()) {
                                ActivityStart.this.wl.release();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                        ActivityStart.this.wl = null;
                    }
                } else {
                    String string = ActivityStart.this.prefs.getString("printer", null);
                    int i2 = 0;
                    if (string != null) {
                        string = string.split("\\|")[0];
                    }
                    while (true) {
                        if (i2 >= ActivityStart.this.local_printers.size()) {
                            break;
                        } else if (((Printer) ActivityStart.this.local_printers.get(i2)).id.equals(string)) {
                            if (ActivityStart.this.st_bonjour != null) {
                                ActivityStart.this.st_bonjour.destroy();
                            }
                            if (ActivityStart.this.st_snmp != null) {
                                ActivityStart.this.st_snmp.destroy();
                            }
                            if (ActivityStart.this.st_bjnp != null) {
                                ActivityStart.this.st_bjnp.destroy();
                            }
                            if (ActivityStart.this.st_wsd != null) {
                                ActivityStart.this.st_wsd.destroy();
                            }
                            if (ActivityStart.this.st_tpl != null) {
                                ActivityStart.this.st_tpl.destroy();
                            }
                            if (ActivityStart.this.st_bluetooth != null) {
                                ActivityStart.this.st_bluetooth.destroy();
                            }
                            if (ActivityStart.this.st_usb != null) {
                                ActivityStart.this.st_usb.destroy();
                            }
                        } else {
                            i2++;
                        }
                    }
                }
            }
            super.handleMessage(message);
        }
    };
    /* access modifiers changed from: private */
    public ScanThreadBJNP st_bjnp;
    /* access modifiers changed from: private */
    public ScanThreadBluetooth st_bluetooth;
    /* access modifiers changed from: private */
    public ScanThreadBonjour st_bonjour;
    /* access modifiers changed from: private */
    public ScanThreadSNMP st_snmp;
    /* access modifiers changed from: private */
    public ScanThreadTPL st_tpl;
    /* access modifiers changed from: private */
    public ScanThreadUSB st_usb;
    /* access modifiers changed from: private */
    public ScanThreadWSD st_wsd;
    /* access modifiers changed from: private */
    public View view_dialog_login;
    /* access modifiers changed from: private */
    public View view_dialog_register;
    /* access modifiers changed from: private */
    public WakeLock wl;
    /* access modifiers changed from: private */
    public Thread wt;

    class CloudThread extends Thread {
        private String pid;

        public CloudThread(String str) {
            this.pid = str;
        }

        public void run() {
            try {
                StringBuilder sb = new StringBuilder();
                sb.append("https://www.google.com/cloudprint/printer?output=json&use_cdd=false&printerid=");
                sb.append(this.pid);
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
                httpURLConnection.setConnectTimeout(15000);
                httpURLConnection.setReadTimeout(15000);
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(false);
                httpURLConnection.setUseCaches(false);
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setRequestProperty("Connection", "close");
                httpURLConnection.setRequestProperty("User-Agent", App.getUserAgent());
                StringBuilder sb2 = new StringBuilder();
                sb2.append("GoogleLogin auth=");
                sb2.append(ActivityStart.this.prefs.getString("cloud_token", ""));
                httpURLConnection.setRequestProperty("Authorization", sb2.toString());
                httpURLConnection.setRequestProperty("X-CloudPrint-Proxy", SmbConstants.NATIVE_LANMAN);
                if (httpURLConnection.getResponseCode() == 200) {
                    GPrinterList gPrinterList = (GPrinterList) Json.read(new BufferedInputStream(httpURLConnection.getInputStream()), GPrinterList.class);
                    if (gPrinterList.printers != null) {
                        for (int i = 0; i < gPrinterList.printers.size(); i++) {
                            ActivityStart.this.cloud_printers.add(ActivityCloudPrinters.loadPrinter((GPrinter) gPrinterList.printers.get(i)));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            Message message = new Message();
            message.what = 4;
            message.arg1 = -1;
            ActivityStart.this.scanHandler.sendMessage(message);
        }
    }

    class LoginThread extends Thread {
        final int type;

        public LoginThread(int i) {
            this.type = i;
        }

        private void login_ok(Element element) {
            String str = "token";
            ActivityCore.remote_token = XmlUtil.getFirstNodeValue(element, str);
            ActivityCore.remote_user = new User();
            ActivityCore.remote_user.readFromXml(XmlUtil.getFirstElement(element, "user"));
            ActivityCore.remote_printers = new Vector<>();
            NodeList elementsByTagName = element.getElementsByTagName("printer");
            int length = elementsByTagName.getLength();
            for (int i = 0; i < length; i++) {
                Printer printer = new Printer();
                printer.readFromXml((Element) elementsByTagName.item(i));
                ActivityCore.remote_printers.add(printer);
            }
            Editor edit = ActivityStart.this.prefs.edit();
            edit.putString(str, ActivityCore.remote_token);
            edit.putString("login", ActivityCore.remote_user.login);
            edit.commit();
        }

        public void run() {
            ActivityCore.remote_user = null;
            ActivityCore.remote_printers = null;
            ActivityStart.this.last_error = null;
            try {
                String str = "favorites";
                String str2 = "echo";
                String str3 = "Login";
                String str4 = "message";
                String str5 = "Error: ";
                String str6 = "success";
                String str7 = "true";
                String str8 = "data";
                String str9 = "Param";
                if (this.type == 3) {
                    SoapEnvelope soapEnvelope = new SoapEnvelope(str3, str9, str8);
                    final Element dataRoot = soapEnvelope.getDataRoot();
                    dataRoot.setAttribute(str2, str);
                    XmlUtil.appendElement(dataRoot, "token", ActivityCore.remote_token);
                    Billing.action.run(null, new Runnable() {
                        public void run() {
                            XmlUtil.appendElement(dataRoot, "premium-key", App.getDeviceID());
                        }
                    });
                    Element dataRoot2 = App.psService.doAction(soapEnvelope).getDataRoot();
                    if (str7.equals(dataRoot2.getAttribute(str6))) {
                        login_ok(dataRoot2);
                    } else {
                        ActivityStart activityStart = ActivityStart.this;
                        StringBuilder sb = new StringBuilder();
                        sb.append(str5);
                        sb.append(XmlUtil.getFirstNodeValue(dataRoot2, str4));
                        activityStart.last_error = sb.toString();
                    }
                } else if (this.type == 2) {
                    EditText editText = (EditText) ActivityStart.this.view_dialog_login.findViewById(R.id.login_edit);
                    EditText editText2 = (EditText) ActivityStart.this.view_dialog_login.findViewById(R.id.password_edit);
                    SoapEnvelope soapEnvelope2 = new SoapEnvelope(str3, str9, str8);
                    final Element dataRoot3 = soapEnvelope2.getDataRoot();
                    dataRoot3.setAttribute(str2, str);
                    XmlUtil.appendElement(dataRoot3, "login", editText.getText().toString());
                    XmlUtil.appendElement(dataRoot3, "password", editText2.getText().toString());
                    Billing.action.run(null, new Runnable() {
                        public void run() {
                            XmlUtil.appendElement(dataRoot3, "premium-key", App.getDeviceID());
                        }
                    });
                    Element dataRoot4 = App.psService.doAction(soapEnvelope2).getDataRoot();
                    if (str7.equals(dataRoot4.getAttribute(str6))) {
                        login_ok(dataRoot4);
                    } else {
                        ActivityStart activityStart2 = ActivityStart.this;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(str5);
                        sb2.append(XmlUtil.getFirstNodeValue(dataRoot4, str4));
                        activityStart2.last_error = sb2.toString();
                    }
                } else if (this.type == 1) {
                    String obj = ((EditText) ActivityStart.this.view_dialog_register.findViewById(R.id.user_name_edit)).getText().toString();
                    String obj2 = ((EditText) ActivityStart.this.view_dialog_register.findViewById(R.id.user_email_edit)).getText().toString();
                    if (obj.length() == 0) {
                        ActivityStart.this.last_error = "Error: Name can't be empty.";
                    } else if (obj2.length() != 0) {
                        int indexOf = obj2.indexOf("@");
                        int i = indexOf + 1;
                        int indexOf2 = obj2.indexOf(".", i);
                        if (indexOf <= 0 || indexOf2 <= i || indexOf2 == obj2.length() - 1) {
                            ActivityStart.this.last_error = "Error: Email is not valid.";
                        } else {
                            SoapEnvelope soapEnvelope3 = new SoapEnvelope("UserRegister", str9, str8);
                            final Element dataRoot5 = soapEnvelope3.getDataRoot();
                            Element appendElement = XmlUtil.appendElement(dataRoot5, "user");
                            XmlUtil.appendElement(appendElement, "name", obj);
                            XmlUtil.appendElement(appendElement, "mail", obj2);
                            Billing.action.run(null, new Runnable() {
                                public void run() {
                                    XmlUtil.appendElement(dataRoot5, "premium-key", App.getDeviceID());
                                }
                            });
                            Element dataRoot6 = App.psService.doAction(soapEnvelope3).getDataRoot();
                            if (str7.equals(dataRoot6.getAttribute(str6))) {
                                login_ok(dataRoot6);
                            } else {
                                ActivityStart activityStart3 = ActivityStart.this;
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append(str5);
                                sb3.append(XmlUtil.getFirstNodeValue(dataRoot6, str4));
                                activityStart3.last_error = sb3.toString();
                            }
                        }
                    } else {
                        ActivityStart.this.last_error = "Error: Email can't be empty.";
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityStart activityStart4 = ActivityStart.this;
                StringBuilder sb4 = new StringBuilder();
                sb4.append("Internal Error: ");
                sb4.append(e.getMessage());
                activityStart4.last_error = sb4.toString();
                App.reportThrowable(e);
            }
            if (ActivityStart.this.last_error != null) {
                ActivityStart.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityStart.this.findViewById(R.id.start_buttons).setVisibility(8);
                        ActivityStart.this.findViewById(R.id.login_buttons).setVisibility(0);
                        ActivityStart.this.findViewById(R.id.status).setVisibility(8);
                        ActivityStart.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if (LoginThread.this.type == 1) {
                                    ActivityStart.this.showDialog(1);
                                } else if (LoginThread.this.type == 2) {
                                    ActivityStart.this.showDialog(2);
                                }
                            }
                        });
                    }
                });
            } else {
                ActivityStart.this.do_finish(-1);
            }
            ActivityStart.this.wt = null;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.start);
        setTitle((int) R.string.app_name);
        ((Button) findViewById(R.id.newuser_button)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityStart.this.showDialog(1);
            }
        });
        ((Button) findViewById(R.id.login_button)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityStart.this.showDialog(2);
            }
        });
        ((Button) findViewById(R.id.continue_button)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Editor edit = ActivityStart.this.prefs.edit();
                edit.putString("version", App.getVersion());
                edit.commit();
                ActivityStart.this.start_init();
            }
        });
        LayoutInflater from = LayoutInflater.from(this);
        this.view_dialog_register = from.inflate(R.layout.dialog_register, null);
        this.view_dialog_login = from.inflate(R.layout.dialog_login, null);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        synchronized (this) {
            try {
                if (this.wl != null && this.wl.isHeld()) {
                    this.wl.release();
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            this.wl = null;
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        super.update();
        StringBuilder sb = new StringBuilder();
        sb.append(getResources().getString(R.string.app_name));
        sb.append(getTitleSuffix());
        setTitle((CharSequence) sb.toString());
    }

    /* access modifiers changed from: protected */
    public void init() {
        String string = this.prefs.getString("version", "");
        if (!App.getVersion().equals(string)) {
            if ("6.5.0".equals(string) || "6.5.1".equals(string) || "6.6.0".equals(string)) {
                Editor edit = this.prefs.edit();
                edit.putBoolean("smb_nearby_hack", true);
                edit.commit();
            }
            findViewById(R.id.start_buttons).setVisibility(0);
            findViewById(R.id.login_buttons).setVisibility(8);
            findViewById(R.id.status).setVisibility(8);
            return;
        }
        start_init();
    }

    /* access modifiers changed from: private */
    public void start_init() {
        findViewById(R.id.start_buttons).setVisibility(8);
        findViewById(R.id.login_buttons).setVisibility(8);
        findViewById(R.id.status).setVisibility(0);
        if (remote_token == null) {
            this.local_printers = new Vector<>();
            this.cloud_printers = new Vector<>();
            synchronized (this) {
                try {
                    if (this.wl == null || !this.wl.isHeld()) {
                        WakeLock newWakeLock = ((PowerManager) getSystemService("power")).newWakeLock(1, "PrinterShare:WakeLock");
                        this.wl = newWakeLock;
                        newWakeLock.acquire();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            String string = this.prefs.getString("printer", null);
            if (string != null) {
                string = string.split("\\|")[0];
            }
            if (string == null || !string.endsWith(".local.")) {
                if (string == null || !string.endsWith("cloudprint.google.")) {
                    Message message = new Message();
                    message.what = 4;
                    message.arg1 = -1;
                    this.scanHandler.sendMessage(message);
                    return;
                }
                CloudThread cloudThread = new CloudThread(string.substring(0, string.indexOf("@")));
                this.wt = cloudThread;
                cloudThread.start();
            } else if (string.indexOf("_usb.") > 0) {
                ScanThreadUSB scanThreadUSB = new ScanThreadUSB(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_usb = scanThreadUSB;
                scanThreadUSB.start();
            } else if (string.indexOf("_bluetooth.") > 0) {
                ScanThreadBluetooth scanThreadBluetooth = new ScanThreadBluetooth(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_bluetooth = scanThreadBluetooth;
                scanThreadBluetooth.start();
            } else if (string.startsWith("snmp_")) {
                ScanThreadSNMP scanThreadSNMP = new ScanThreadSNMP(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_snmp = scanThreadSNMP;
                scanThreadSNMP.start();
            } else if (string.startsWith("bjnp_")) {
                ScanThreadBJNP scanThreadBJNP = new ScanThreadBJNP(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_bjnp = scanThreadBJNP;
                scanThreadBJNP.start();
            } else if (string.indexOf("_wprt.") > 0) {
                ScanThreadWSD scanThreadWSD = new ScanThreadWSD(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_wsd = scanThreadWSD;
                scanThreadWSD.start();
            } else if (string.indexOf("_tpl.") > 0) {
                ScanThreadTPL scanThreadTPL = new ScanThreadTPL(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_tpl = scanThreadTPL;
                scanThreadTPL.start();
            } else {
                ScanThreadBonjour scanThreadBonjour = new ScanThreadBonjour(getApplicationContext(), 10000, string, this.scanHandler);
                this.st_bonjour = scanThreadBonjour;
                scanThreadBonjour.start();
            }
        } else if (remote_token.length() > 0) {
            LoginThread loginThread = new LoginThread(3);
            this.wt = loginThread;
            loginThread.start();
        } else {
            findViewById(R.id.start_buttons).setVisibility(8);
            findViewById(R.id.login_buttons).setVisibility(0);
            findViewById(R.id.status).setVisibility(8);
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || findViewById(R.id.start_buttons).getVisibility() != 8) {
            return super.onKeyDown(i, keyEvent);
        }
        if (findViewById(R.id.status).getVisibility() == 8) {
            do_finish(0);
        }
        return true;
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x026b, code lost:
        if (r0.getResponse().code == 0) goto L_0x01fd;
     */
    public void do_finish(int i) {
        String str;
        String str2;
        String str3;
        String[] strArr;
        boolean z;
        String str4 = "\n";
        if (i == -1) {
            String str5 = "";
            String string = this.prefs.getString("printer", str5);
            String str6 = "\\|";
            int i2 = 0;
            boolean z2 = true;
            if (string != null) {
                String[] split = string.split(str6);
                str2 = split[0];
                str = split.length > 1 ? split[1] : null;
            } else {
                str2 = string;
                str = null;
            }
            String str7 = "internal";
            int i3 = 2;
            if (str2.endsWith(".local.")) {
                if (this.local_printers != null && (printer == null || !str2.equals(printer.id))) {
                    printer = null;
                    Collections.sort(this.local_printers);
                    Printer printer = null;
                    for (int i4 = 0; i4 < this.local_printers.size(); i4++) {
                        printer = (Printer) this.local_printers.get(i4);
                        if (printer.id.equals(str2)) {
                            break;
                        }
                        if (str2.length() > 0) {
                            printer = null;
                        }
                    }
                    if (printer != null) {
                        if (str != null) {
                            printer.model = str;
                            printer.drv_manual = true;
                        }
                        loop1:
                        while (true) {
                            if (!printer.direct_address.startsWith("ipp://")) {
                                if (!printer.direct_address.startsWith("ipps://")) {
                                    String str8 = "http";
                                    if (printer.direct_address.startsWith("bjnp://")) {
                                        URL url = new URL(printer.direct_address.replaceAll("bjnp", str8));
                                        z = new BJNPSocket().check(new InetSocketAddress(url.getHost(), url.getPort()), 15000);
                                    } else {
                                        if (printer.direct_address.startsWith("pdl://")) {
                                            URL url2 = new URL(printer.direct_address.replaceAll("pdl", str8));
                                            Socket socket = new Socket();
                                            socket.connect(new InetSocketAddress(url2.getHost(), url2.getPort()), 15000);
                                            socket.close();
                                        } else if (printer.direct_address.startsWith("wprt://")) {
                                            String replaceAll = printer.direct_address.replaceAll("wprt", str8);
                                            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(replaceAll).openConnection();
                                            httpURLConnection.setConnectTimeout(15000);
                                            httpURLConnection.setReadTimeout(15000);
                                            httpURLConnection.setDoInput(z2);
                                            httpURLConnection.setDoOutput(z2);
                                            httpURLConnection.setUseCaches(false);
                                            httpURLConnection.setRequestMethod("POST");
                                            httpURLConnection.setRequestProperty("Content-Type", "application/soap+xml");
                                            httpURLConnection.setRequestProperty("Connection", "close");
                                            OutputStream outputStream = httpURLConnection.getOutputStream();
                                            StringBuilder sb = new StringBuilder();
                                            sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wsdp=\"http://schemas.xmlsoap.org/ws/2005/05/devprof\" xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" xmlns:wprt=\"http://schemas.microsoft.com/windows/2006/08/wdp/print\"><soap:Header><wsa:To>");
                                            sb.append(replaceAll);
                                            sb.append("</wsa:To><wsa:Action>http://schemas.microsoft.com/windows/2006/08/wdp/print/GetPrinterElements</wsa:Action><wsa:MessageID>urn:uuid:");
                                            sb.append(UUID.randomUUID());
                                            sb.append("</wsa:MessageID><wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo></soap:Header><soap:Body><wprt:GetPrinterElementsRequest><wprt:RequestedElements><wprt:Name>wprt:PrinterStatus</wprt:Name></wprt:RequestedElements></wprt:GetPrinterElementsRequest></soap:Body></soap:Envelope>");
                                            outputStream.write(sb.toString().getBytes());
                                            if (httpURLConnection.getResponseCode() == 200) {
                                            }
                                            z = false;
                                        } else if (printer.direct_address.startsWith("lpd://")) {
                                            URL url3 = new URL(printer.direct_address.replaceAll("lpd", str8));
                                            Socket socket2 = new Socket();
                                            socket2.connect(new InetSocketAddress(url3.getHost(), url3.getPort()), 15000);
                                            socket2.setSoTimeout(15000);
                                            OutputStream outputStream2 = socket2.getOutputStream();
                                            outputStream2.write(i3);
                                            StringBuilder sb2 = new StringBuilder();
                                            sb2.append(url3.getPath().substring(z2));
                                            sb2.append(str4);
                                            outputStream2.write(sb2.toString().getBytes());
                                            outputStream2.flush();
                                            int read = socket2.getInputStream().read();
                                            outputStream2.write(z2);
                                            outputStream2.write(str4.getBytes());
                                            socket2.close();
                                            if (read == 0) {
                                            }
                                            z = false;
                                        } else if (printer.direct_address.startsWith("usb://")) {
                                            final String[] split2 = printer.direct_address.substring(6).split(str6);
                                            final boolean[] zArr = new boolean[(z2 ? 1 : 0)];
                                            new Object() {
                                                {
                                                    if (((UsbDevice) ((UsbManager) ActivityStart.this.getSystemService("usb")).getDeviceList().get(split2[0])) != null) {
                                                        zArr[0] = true;
                                                    }
                                                }
                                            };
                                            z = zArr[0];
                                        }
                                        z = true;
                                    }
                                    if (!z) {
                                        break;
                                    } else if (printer.direct_address.startsWith("ptp://") || (findDriver(printer) != 0 && (printer.drv_name.startsWith(str7) || drvCheck(printer)))) {
                                        printer = printer;
                                    }
                                }
                            }
                            boolean z3 = false;
                            while (true) {
                                try {
                                    IppConnection ippConnection = new IppConnection(printer.direct_address, App.getUserAgent());
                                    if (z3) {
                                        ippConnection.setSecured(z2);
                                    }
                                    printer.owner.login = this.prefs.getString("printer_login", null);
                                    printer.owner.password = this.prefs.getString("printer_password", null);
                                    IppMessage ippMessage = new IppMessage(IppMessage.OP_GET_PRINTER_ATTRIBUTES);
                                    ippMessage.operation_attributes.add(new IppAttribute(71, "attributes-charset", "utf-8"));
                                    ippMessage.operation_attributes.add(new IppAttribute((byte) IppAttribute.TYPE_NATURAL_LANGUAGE, "attributes-natural-language", "en-us"));
                                    ippMessage.operation_attributes.add(new IppAttribute(69, "printer-uri", ippConnection.getUri()));
                                    ippConnection.sendRequest(ippMessage);
                                } catch (Exception e) {
                                    String message = e.getMessage();
                                    String str9 = "/ipp/port1";
                                    if (message != null) {
                                        if (message.indexOf("/duerqxesz5090. HTTP error 404") > 0) {
                                            printer.direct_address = printer.direct_address.replace("/duerqxesz5090", str9);
                                            z2 = true;
                                        }
                                    }
                                    if (message != null && message.indexOf("/ipp/port1. HTTP error 404") > 0) {
                                        printer.direct_address = printer.direct_address.replace(str9, "/ipp/printer");
                                        z2 = true;
                                    } else if (message == null || message.indexOf("HTTP error 426") <= 0 || z3) {
                                        throw e;
                                    } else {
                                        z3 = true;
                                        z2 = true;
                                    }
                                } catch (Exception e2) {
                                    String message2 = e2.getMessage();
                                    if (message2 == null || message2.indexOf("HTTP error 404") == -1 || printer.direct_address.indexOf(":631/ipp") >= 0) {
                                        e2.printStackTrace();
                                        App.reportThrowable(e2);
                                    } else {
                                        int indexOf = printer.direct_address.indexOf(":631");
                                        StringBuilder sb3 = new StringBuilder();
                                        int i5 = indexOf + 4;
                                        sb3.append(printer.direct_address.substring(0, i5));
                                        sb3.append("/ipp");
                                        sb3.append(printer.direct_address.substring(i5));
                                        printer.direct_address = sb3.toString();
                                        z2 = true;
                                        i3 = 2;
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (str2.endsWith("cloudprint.google.")) {
                printer = null;
                if (this.cloud_printers != null) {
                    while (true) {
                        if (i2 >= this.cloud_printers.size()) {
                            break;
                        }
                        Printer printer2 = (Printer) this.cloud_printers.elementAt(i2);
                        if (printer2.id.equals(str2)) {
                            printer = printer2;
                            break;
                        }
                        i2++;
                    }
                }
            } else {
                String str10 = "smb://";
                if (str2.startsWith(str10)) {
                    printer = null;
                    try {
                        String string2 = this.prefs.getString("smb_auth", null);
                        if (string2 != null) {
                            StringBuilder sb4 = new StringBuilder();
                            sb4.append(str10);
                            sb4.append(string2);
                            sb4.append("@");
                            sb4.append(str2.substring(6));
                            str3 = sb4.toString();
                        } else {
                            str3 = str2;
                        }
                        SmbFile smbFile = new SmbFile(str3);
                        try {
                            strArr = smbFile.printerGetInfo();
                        } catch (Exception e3) {
                            Exception exc = e3;
                            exc.printStackTrace();
                            App.reportThrowable(exc);
                            strArr = null;
                        }
                        Printer printer3 = new Printer();
                        printer3.owner = new User();
                        printer3.capabilities = new Hashtable<>();
                        String name = smbFile.getName();
                        if (name.endsWith("/")) {
                            name = name.substring(0, name.length() - 1);
                        }
                        printer3.id = str2;
                        printer3.title = name;
                        printer3.direct_address = str3;
                        printer3.owner.name = smbFile.getServer();
                        if (strArr != null) {
                            printer3.model = strArr[1];
                            printer3.location = strArr[2];
                        } else {
                            printer3.model = App.clearPrinterModelName(name);
                        }
                        if (str != null) {
                            printer3.model = str;
                            printer3.drv_manual = true;
                        }
                        smbFile.print_open(str5);
                        smbFile.print_close();
                        if (findDriver(printer3) != 0 && (printer3.drv_name.startsWith(str7) || drvCheck(printer3))) {
                            printer = printer3;
                        }
                    } catch (Exception e4) {
                        e4.printStackTrace();
                        App.reportThrowable(e4);
                    }
                } else {
                    printer = null;
                    if (remote_printers != null) {
                        for (int size = remote_printers.size() - 1; size >= 0; size--) {
                            Printer printer4 = (Printer) remote_printers.elementAt(size);
                            printer = printer4;
                            if (printer4.id.equals(str2)) {
                                break;
                            }
                        }
                    }
                }
            }
        }
        setPrinter(printer);
        setResult(i);
        finish();
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        if (i == 1) {
            return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_register_title).setView(this.view_dialog_register).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityStart.this.findViewById(R.id.start_buttons).setVisibility(8);
                    ActivityStart.this.findViewById(R.id.login_buttons).setVisibility(8);
                    ActivityStart.this.findViewById(R.id.status).setVisibility(0);
                    new LoginThread(1).start();
                }
            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create();
        }
        if (i != 2) {
            return null;
        }
        ((EditText) this.view_dialog_login.findViewById(R.id.login_edit)).setText(this.prefs.getString("login", ""));
        return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_login_title).setView(this.view_dialog_login).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityStart.this.findViewById(R.id.start_buttons).setVisibility(8);
                ActivityStart.this.findViewById(R.id.login_buttons).setVisibility(8);
                ActivityStart.this.findViewById(R.id.status).setVisibility(0);
                new LoginThread(2).start();
            }
        }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).create();
    }
}
