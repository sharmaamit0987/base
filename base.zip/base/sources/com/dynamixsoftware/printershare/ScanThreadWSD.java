package com.dynamixsoftware.printershare;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.App.NetworkInterfaceData;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;

public class ScanThreadWSD extends Thread {
    private static final String PROBE_PRF = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" xmlns:wsd=\"http://schemas.xmlsoap.org/ws/2005/04/discovery\" xmlns:wsdp=\"http://schemas.xmlsoap.org/ws/2006/02/devprof\"><soap:Header><wsa:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</wsa:To><wsa:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</wsa:Action><wsa:MessageID>urn:uuid:";
    private static final String PROBE_SFX = "</wsa:MessageID></soap:Header><soap:Body><wsd:Probe><wsd:Types>wsdp:Device</wsd:Types></wsd:Probe></soap:Body></soap:Envelope>";
    /* access modifiers changed from: private */
    public static String WSD_GROUP = "239.255.255.250";
    /* access modifiers changed from: private */
    public static String WSD_GROUP_IPV6 = "FF02::C";
    /* access modifiers changed from: private */
    public static int WSD_PORT = 3702;
    /* access modifiers changed from: private */
    public boolean[] destroyed = new boolean[1];
    /* access modifiers changed from: private */
    public ArrayList<DatagramPacket> packets = new ArrayList<>();
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    /* access modifiers changed from: private */
    public String rq_pid;
    private Thread sender = new Thread() {
        /* JADX WARNING: Code restructure failed: missing block: B:12:?, code lost:
            r3 = 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0024, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$300(r8.this$0).size() <= 1) goto L_0x0027;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0027, code lost:
            r3 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0032, code lost:
            if (r3 >= com.dynamixsoftware.printershare.ScanThreadWSD.access$300(r8.this$0).size()) goto L_0x00cd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x0034, code lost:
            r2 = com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r8.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x003a, code lost:
            monitor-enter(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0043, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r8.this$0)[0] == false) goto L_0x0047;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0045, code lost:
            monitor-exit(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x0046, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0047, code lost:
            monitor-exit(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
            r2 = (com.dynamixsoftware.printershare.ScanThreadWSD.SocketThread) com.dynamixsoftware.printershare.ScanThreadWSD.access$300(r8.this$0).get(r3);
            r4 = new java.lang.StringBuilder();
            r4.append(com.dynamixsoftware.printershare.ScanThreadWSD.PROBE_PRF);
            r4.append(java.util.UUID.randomUUID());
            r4.append(com.dynamixsoftware.printershare.ScanThreadWSD.PROBE_SFX);
            r4 = r4.toString().getBytes();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0074, code lost:
            if (r2.ia == null) goto L_0x009c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x007e, code lost:
            if (r2.ia.getAddress().length == 4) goto L_0x009c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x0080, code lost:
            r5 = new java.net.DatagramPacket(r4, r4.length);
            r5.setAddress(java.net.InetAddress.getByName(com.dynamixsoftware.printershare.ScanThreadWSD.access$400()));
            r5.setPort(com.dynamixsoftware.printershare.ScanThreadWSD.access$500());
            r2.send(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x009c, code lost:
            r5 = new java.net.DatagramPacket(r4, r4.length);
            r5.setAddress(java.net.InetAddress.getByName(com.dynamixsoftware.printershare.ScanThreadWSD.access$600()));
            r5.setPort(com.dynamixsoftware.printershare.ScanThreadWSD.access$500());
            r2.send(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x00b8, code lost:
            r2 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x00c6, code lost:
            r2 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:43:0x00c7, code lost:
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:?, code lost:
            r5 = new java.lang.StringBuilder();
            r5.append(com.dynamixsoftware.printershare.ScanThreadWSD.PROBE_PRF);
            r5.append(java.util.UUID.randomUUID());
            r5.append(com.dynamixsoftware.printershare.ScanThreadWSD.PROBE_SFX);
            r5 = r5.toString().getBytes();
            r6 = new java.net.DatagramPacket(r5, r5.length);
            r6.setAddress((java.net.InetAddress) r2.get(r4));
            r6.setPort(com.dynamixsoftware.printershare.ScanThreadWSD.access$500());
            r3.send(r6);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:59:0x012f, code lost:
            r4 = r4 + 1;
         */
        public void run() {
            int i = 0;
            while (i < 3) {
                synchronized (ScanThreadWSD.this.destroyed) {
                    if (ScanThreadWSD.this.destroyed[0]) {
                        return;
                    }
                }
            }
            return;
            try {
                Thread.sleep(1000);
                i++;
            } catch (InterruptedException unused) {
                return;
            }
            Vector broadcastAdrresses = App.getBroadcastAdrresses();
            try {
                SocketThread socketThread = (SocketThread) ScanThreadWSD.this.sockets.get(0);
                int i2 = 0;
                while (i2 < broadcastAdrresses.size()) {
                    synchronized (ScanThreadWSD.this.destroyed) {
                        if (ScanThreadWSD.this.destroyed[0]) {
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            Thread.sleep(1000);
            i++;
            int i3 = i3 + 1;
        }
    };
    /* access modifiers changed from: private */
    public ArrayList<SocketThread> sockets = new ArrayList<>();
    /* access modifiers changed from: private */
    public Handler status;
    /* access modifiers changed from: private */
    public int timeout;
    private ArrayList<DetectThread> workers = new ArrayList<>();

    class DetectThread extends Thread {
        DatagramPacket packet;

        DetectThread(DatagramPacket datagramPacket) {
            this.packet = datagramPacket;
        }

        /* JADX WARNING: type inference failed for: r6v1 */
        /* JADX WARNING: type inference failed for: r6v2, types: [boolean] */
        /* JADX WARNING: type inference failed for: r6v9 */
        /* JADX WARNING: type inference failed for: r6v10 */
        /* JADX WARNING: type inference failed for: r6v11 */
        /* JADX WARNING: Code restructure failed: missing block: B:113:?, code lost:
            r0 = (java.net.HttpURLConnection) r0.openConnection();
            r0.setConnectTimeout(3000);
            r0.setReadTimeout(3000);
            r0.setDoInput(r5);
            r0.setDoOutput(r5);
            r0.setUseCaches(r6);
            r0.setRequestMethod("POST");
            r0.setRequestProperty("Connection", "close");
            r0.setRequestProperty("User-Agent", com.dynamixsoftware.printershare.App.getUserAgent());
            r0.setRequestProperty("Content-Type", "application/soap+xml");
            r9 = new java.lang.StringBuilder();
            r9.append("<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\"><soap:Header><wsa:To>");
            r9.append(r7);
            r9.append("</wsa:To><wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</wsa:Action><wsa:MessageID>urn:uuid:");
            r9.append(java.util.UUID.randomUUID());
            r9.append("</wsa:MessageID><wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo></soap:Header><soap:Body></soap:Body></soap:Envelope>");
            r0.getOutputStream().write(r9.toString().getBytes());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:114:0x0274, code lost:
            if (r0.getResponseCode() != 200) goto L_0x0184;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:115:0x0276, code lost:
            r9 = com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r1.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:116:0x027c, code lost:
            monitor-enter(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:119:0x0285, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r1.this$0)[r6] == false) goto L_0x0289;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:120:0x0287, code lost:
            monitor-exit(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:121:0x0288, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:122:0x0289, code lost:
            monitor-exit(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:124:?, code lost:
            r9 = new java.lang.StringBuffer();
            r13 = new java.io.DataInputStream(r0.getInputStream());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:125:0x0298, code lost:
            r0 = r13.readLine();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:126:0x029c, code lost:
            if (r0 == null) goto L_0x02a2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:127:0x029e, code lost:
            r9.append(r0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:128:0x02a2, code lost:
            r0 = r9.toString();
            r9 = r0.indexOf(":Manufacturer");
            r13 = r0.indexOf("</", r9 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:129:0x02b4, code lost:
            if (r13 <= r9) goto L_0x02c8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:130:0x02b6, code lost:
            if (r9 < 0) goto L_0x02c8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:131:0x02b8, code lost:
            r9 = r0.substring(r0.indexOf(">", r9) + r5, r13).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:132:0x02c8, code lost:
            r9 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:133:0x02c9, code lost:
            r13 = r0.indexOf(":ModelName");
            r6 = r0.indexOf("</", r13 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:134:0x02d7, code lost:
            if (r6 <= r13) goto L_0x02eb;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:135:0x02d9, code lost:
            if (r13 < 0) goto L_0x02eb;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:136:0x02db, code lost:
            r6 = r0.substring(r0.indexOf(">", r13) + r5, r6).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:137:0x02eb, code lost:
            r6 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:138:0x02ec, code lost:
            r13 = r0.indexOf(":FriendlyName");
            r14 = r0.indexOf("</", r13 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:139:0x02fa, code lost:
            if (r14 <= r13) goto L_0x030e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:140:0x02fc, code lost:
            if (r13 < 0) goto L_0x030e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:141:0x02fe, code lost:
            r13 = r0.substring(r0.indexOf(">", r13) + r5, r14).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:142:0x030e, code lost:
            r13 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:143:0x030f, code lost:
            r14 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:144:0x0310, code lost:
            r14 = r0.indexOf(":Hosted", r14 + r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:145:0x0318, code lost:
            if (r14 == -1) goto L_0x0184;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:146:0x031a, code lost:
            r5 = r0.indexOf(":Hosted", r14 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:147:0x0323, code lost:
            if (r5 == -1) goto L_0x0184;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:148:0x0325, code lost:
            r15 = r0.indexOf(":Address", r14);
            r17 = r2;
            r18 = r4;
            r2 = r0.indexOf("</", r15 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:149:0x0337, code lost:
            if (r2 <= r15) goto L_0x034e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x005e, code lost:
            r5 = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:150:0x0339, code lost:
            if (r15 < 0) goto L_0x034e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:151:0x033b, code lost:
            if (r15 >= r5) goto L_0x034e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:152:0x033d, code lost:
            r2 = r0.substring(r0.indexOf(">", r15) + 1, r2).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:153:0x034e, code lost:
            r2 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:154:0x034f, code lost:
            r4 = r0.indexOf(":ServiceId", r14);
            r19 = r7;
            r7 = r0.indexOf("</", r4 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:155:0x035f, code lost:
            if (r7 <= r4) goto L_0x0376;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:156:0x0361, code lost:
            if (r4 < 0) goto L_0x0376;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:157:0x0363, code lost:
            if (r4 >= r5) goto L_0x0376;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:158:0x0365, code lost:
            r4 = r0.substring(r0.indexOf(">", r4) + 1, r7).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:159:0x0376, code lost:
            r4 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:160:0x0377, code lost:
            r7 = r0.indexOf(":Types", r14);
            r14 = r0.indexOf("</", r7 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:161:0x0385, code lost:
            if (r14 <= r7) goto L_0x039c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:162:0x0387, code lost:
            if (r7 < 0) goto L_0x039c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:163:0x0389, code lost:
            if (r7 >= r5) goto L_0x039c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:164:0x038b, code lost:
            r7 = r0.substring(r0.indexOf(">", r7) + 1, r14).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:165:0x039c, code lost:
            r7 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:166:0x039d, code lost:
            if (r4 == null) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:167:0x039f, code lost:
            if (r7 == null) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:168:0x03a1, code lost:
            if (r2 == null) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
            r0 = r2.indexOf(":ProbeMatch", r0 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:170:0x03a9, code lost:
            if (r7.indexOf("PrinterServiceType") < 0) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:172:0x03b5, code lost:
            if (r4.toLowerCase().indexOf("fax") >= 0) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:174:0x03c1, code lost:
            if (r2.toLowerCase().indexOf("fax") >= 0) goto L_0x0571;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:175:0x03c3, code lost:
            r4 = r2.indexOf("://");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:176:0x03c9, code lost:
            if (r4 >= 0) goto L_0x03cd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:177:0x03cb, code lost:
            r4 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:178:0x03cd, code lost:
            r4 = r4 + 3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:179:0x03cf, code lost:
            r7 = r2.lastIndexOf(":");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0066, code lost:
            if (r0 >= 0) goto L_0x006a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:180:0x03d5, code lost:
            if (r7 <= r4) goto L_0x03e0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:182:?, code lost:
            java.net.InetAddress.getByName(r2.substring(r4, r7));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:183:0x03df, code lost:
            r7 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x006a, code lost:
            r4 = r2.indexOf(":ProbeMatch", r0 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x0072, code lost:
            if (r4 >= 0) goto L_0x0076;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0076, code lost:
            r0 = r2.substring(r0, r4);
            r7 = r0.indexOf(":Address");
            r8 = r0.indexOf("</", r7 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0088, code lost:
            if (r8 <= r7) goto L_0x009c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:248:?, code lost:
            r2 = com.dynamixsoftware.printershare.ScanThreadWSD.access$800(r1.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:249:0x053d, code lost:
            monitor-enter(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x008a, code lost:
            if (r7 < 0) goto L_0x009c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:251:?, code lost:
            com.dynamixsoftware.printershare.ScanThreadWSD.access$800(r1.this$0).add(r14);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:252:0x0547, code lost:
            monitor-exit(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:254:?, code lost:
            r2 = new android.os.Message();
            r2.what = 2;
            r2.arg1 = 5;
            com.dynamixsoftware.printershare.ScanThreadWSD.access$900(r1.this$0).sendMessage(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:255:0x0562, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$700(r1.this$0) == null) goto L_0x0569;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:256:0x0564, code lost:
            r1.this$0.destroy();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:257:0x0569, code lost:
            r13 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x008c, code lost:
            r7 = r0.substring(r0.indexOf(">", r7) + 1, r8).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:269:0x0572, code lost:
            r14 = r5;
            r2 = r17;
            r4 = r18;
            r7 = r19;
            r5 = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x009c, code lost:
            r7 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x009d, code lost:
            r8 = r0.indexOf(":XAddrs");
            r10 = r0.indexOf("</", r8 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x00ab, code lost:
            if (r10 <= r8) goto L_0x00bf;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x00ad, code lost:
            if (r8 < 0) goto L_0x00bf;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:305:0x0591, code lost:
            continue;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:306:0x0591, code lost:
            continue;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:307:0x0591, code lost:
            continue;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:308:0x0591, code lost:
            continue;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x00af, code lost:
            r8 = r0.substring(r0.indexOf(">", r8) + 1, r10).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x00bf, code lost:
            r8 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x00c0, code lost:
            r10 = r0.indexOf(":Types");
            r11 = r0.indexOf("</", r10 + 1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x00ce, code lost:
            if (r11 <= r10) goto L_0x00e2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x00d0, code lost:
            if (r10 < 0) goto L_0x00e2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x00d2, code lost:
            r0 = r0.substring(r0.indexOf(">", r10) + 1, r11).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x00e2, code lost:
            r0 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x00e3, code lost:
            if (r7 == null) goto L_0x0591;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x00e5, code lost:
            if (r8 == null) goto L_0x0591;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:39:0x00e7, code lost:
            if (r0 == null) goto L_0x0591;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x00ef, code lost:
            if (r0.indexOf("PrintDevice") < 0) goto L_0x0591;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x00f1, code lost:
            r0 = new java.lang.StringBuilder();
            r0.append(r7);
            r0.append("._wprt._tcp.local.");
            r10 = r0.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:43:0x0108, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$700(r1.this$0) == null) goto L_0x0117;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0114, code lost:
            if (r10.equals(com.dynamixsoftware.printershare.ScanThreadWSD.access$700(r1.this$0)) != false) goto L_0x0117;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x0116, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x0117, code lost:
            r0 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:49:0x0122, code lost:
            if (r0 >= com.dynamixsoftware.printershare.ScanThreadWSD.access$800(r1.this$0).size()) goto L_0x0151;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:51:0x0136, code lost:
            if (((com.dynamixsoftware.printershare.data.Printer) com.dynamixsoftware.printershare.ScanThreadWSD.access$800(r1.this$0).get(r0)).direct_address.indexOf(r3) <= 0) goto L_0x014e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:53:0x014a, code lost:
            if (r10.equals(((com.dynamixsoftware.printershare.data.Printer) com.dynamixsoftware.printershare.ScanThreadWSD.access$800(r1.this$0).get(r0)).id) == false) goto L_0x014e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x014c, code lost:
            r0 = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:0x014e, code lost:
            r0 = r0 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x0151, code lost:
            r0 = false;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x0152, code lost:
            if (r0 == false) goto L_0x0155;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:0x0154, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:59:0x0155, code lost:
            r8 = r8.split(" ");
            r11 = new java.util.HashSet();
            r12 = 0;
            r6 = r6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:61:0x0162, code lost:
            if (r12 >= r8.length) goto L_0x0591;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:62:0x0164, code lost:
            r13 = com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r1.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:63:0x016a, code lost:
            monitor-enter(r13);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:66:0x0173, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadWSD.access$000(r1.this$0)[r6] == false) goto L_0x0177;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:67:0x0175, code lost:
            monitor-exit(r13);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:68:0x0176, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:69:0x0177, code lost:
            monitor-exit(r13);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:71:?, code lost:
            r0 = r8[r12].trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:72:0x0182, code lost:
            if (r0.length() != 0) goto L_0x018d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:74:0x018d, code lost:
            r13 = r0.indexOf("://");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:75:0x0193, code lost:
            if (r13 >= 0) goto L_0x0197;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:76:0x0195, code lost:
            r13 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:77:0x0197, code lost:
            r13 = r13 + 3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:78:0x0199, code lost:
            r14 = r0.lastIndexOf(":");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:79:0x019f, code lost:
            if (r14 <= r13) goto L_0x01aa;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:81:?, code lost:
            java.net.InetAddress.getByName(r0.substring(r13, r14));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:82:0x01a9, code lost:
            r14 = -1;
         */
        /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r6v2, types: [boolean]
  assigns: []
  uses: [?[int, short, byte, char], boolean]
  mth insns count: 568
        	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$0(DepthTraversal.java:13)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:13)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
        	at jadx.core.ProcessClass.process(ProcessClass.java:35)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
         */
        /* JADX WARNING: Removed duplicated region for block: B:103:0x01f9 A[Catch:{ Exception -> 0x059e }] */
        /* JADX WARNING: Removed duplicated region for block: B:104:0x01fa A[Catch:{ Exception -> 0x059e }] */
        /* JADX WARNING: Unknown variable types count: 3 */
        public void run() {
            int indexOf;
            String sb;
            HashSet hashSet;
            ? r6;
            String trim;
            int i;
            int lastIndexOf;
            URL url;
            String str;
            String str2;
            String str3;
            String str4;
            int i2;
            int lastIndexOf2;
            String str5;
            String str6;
            InetAddress address = this.packet.getAddress();
            try {
                String str7 = new String(this.packet.getData(), this.packet.getOffset(), this.packet.getLength(), "UTF-8");
                String hostAddress = address.getHostAddress();
                if (address.getAddress().length != 4) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("[");
                    sb2.append(hostAddress);
                    sb2.append("]");
                    hostAddress = sb2.toString();
                }
                int indexOf2 = str7.indexOf(":ProbeMatches");
                while (true) {
                    synchronized (ScanThreadWSD.this.destroyed) {
                        ? r62 = 0;
                        if (ScanThreadWSD.this.destroyed[0]) {
                            return;
                        }
                    }
                    str7 = str7;
                    indexOf2 = indexOf;
                }
                while (true) {
                }
                if (lastIndexOf2 < i2) {
                    lastIndexOf2 = str4.indexOf("/", i2);
                    if (lastIndexOf2 < 0) {
                        lastIndexOf2 = str4.length();
                    }
                }
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str4.startsWith("https") ? "https" : "http");
                sb3.append("://");
                sb3.append(hostAddress);
                sb3.append(str4.substring(lastIndexOf2));
                String sb4 = sb3.toString();
                int indexOf3 = str3.indexOf("(");
                if (indexOf3 < 0 || !str3.endsWith(")")) {
                    int indexOf4 = str3.indexOf("[");
                    if (indexOf4 < 0 || !str3.endsWith("]")) {
                        int indexOf5 = str3.indexOf(" _");
                        if (indexOf5 >= 0) {
                            str6 = str3.substring(indexOf5 + 2).trim();
                            str5 = str3.substring(0, indexOf5).trim();
                        } else {
                            int indexOf6 = str3.indexOf(" - ");
                            if (indexOf6 >= 0) {
                                str6 = str3.substring(indexOf6 + 3).trim();
                                str5 = str3.substring(0, indexOf6).trim();
                            } else {
                                str5 = null;
                            }
                        }
                    } else {
                        str6 = str3.substring(indexOf4 + 1, str3.length() - 1).trim();
                        str5 = str3.substring(0, indexOf4).trim();
                    }
                    str3 = str6;
                } else {
                    String trim2 = str3.substring(0, indexOf3).trim();
                    str5 = str3.substring(indexOf3 + 1, str3.length() - 1).trim();
                    str3 = trim2;
                }
                if (str5 != null && str5.indexOf(" ") < 0 && str3 != null && str3.indexOf(" ") > 0) {
                    String str8 = str3;
                    str3 = str5;
                    str5 = str8;
                }
                String fullModelName = App.getFullModelName(str, str2);
                if (str5 == null) {
                    str5 = fullModelName;
                }
                int indexOf7 = sb4.indexOf("://");
                if (indexOf7 > 0) {
                    sb4 = sb4.substring(indexOf7 + 3);
                }
                StringBuilder sb5 = new StringBuilder();
                sb5.append("wprt://");
                sb5.append(sb4);
                String sb6 = sb5.toString();
                Printer printer = new Printer();
                printer.owner = new User();
                printer.owner.name = str3;
                printer.id = sb;
                printer.direct_address = sb6;
                printer.title = str5 != null ? str5 : "Network Printer";
                if (fullModelName == null) {
                    fullModelName = "";
                }
                printer.model = fullModelName;
                printer.capabilities = new Hashtable<>();
                if (str != null) {
                    printer.capabilities.put("usb_MFG", str);
                }
                if (str2 != null) {
                    printer.capabilities.put("usb_MDL", str2);
                }
                synchronized (ScanThreadWSD.this.destroyed) {
                    if (ScanThreadWSD.this.destroyed[0]) {
                        return;
                    }
                }
                return;
                if (url == null) {
                    synchronized (ScanThreadWSD.this.destroyed) {
                        if (ScanThreadWSD.this.destroyed[r6]) {
                            return;
                        }
                    }
                }
                int i3 = i3 + 1;
                str7 = str7;
                indexOf = indexOf;
                String str9 = str9;
                boolean z = true;
                r6 = 0;
                if (lastIndexOf < i) {
                    lastIndexOf = trim.indexOf("/", i);
                    if (lastIndexOf < 0) {
                        lastIndexOf = trim.length();
                    }
                }
                StringBuilder sb7 = new StringBuilder();
                sb7.append(trim.startsWith("https") ? "https" : "http");
                sb7.append("://");
                sb7.append(hostAddress);
                sb7.append(trim.substring(lastIndexOf));
                String sb8 = sb7.toString();
                if (!hashSet.contains(sb8)) {
                    hashSet.add(sb8);
                    try {
                        url = new URL(sb8);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        App.reportThrowable(e, sb8);
                        url = null;
                    }
                    if (url == null) {
                    }
                }
                int i32 = i32 + 1;
                str7 = str7;
                indexOf = indexOf;
                String str92 = str92;
                boolean z2 = true;
                r6 = 0;
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }
    }

    class SocketThread extends Thread {
        InetAddress ia;
        NetworkInterface ni;
        MulticastSocket socket;

        SocketThread(InetAddress inetAddress, NetworkInterface networkInterface) throws IOException {
            this.ia = inetAddress;
            this.ni = networkInterface;
            MulticastSocket multicastSocket = new MulticastSocket(new InetSocketAddress(inetAddress, 0));
            this.socket = multicastSocket;
            if (networkInterface != null) {
                multicastSocket.setNetworkInterface(networkInterface);
            }
            try {
                this.socket.setTimeToLive(255);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            try {
                this.socket.setLoopbackMode(true);
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }

        public void run() {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                while (true) {
                    synchronized (ScanThreadWSD.this.destroyed) {
                        if (ScanThreadWSD.this.destroyed[0]) {
                            break;
                        }
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        if (currentTimeMillis2 >= ((long) ScanThreadWSD.this.timeout)) {
                            break;
                        }
                        this.socket.setSoTimeout((int) (((long) ScanThreadWSD.this.timeout) - currentTimeMillis2));
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[4096], 4096);
                        try {
                            this.socket.receive(datagramPacket);
                            synchronized (ScanThreadWSD.this.packets) {
                                ScanThreadWSD.this.packets.add(datagramPacket);
                                ScanThreadWSD.this.packets.notifyAll();
                            }
                        } catch (SocketTimeoutException unused) {
                        } catch (IOException e) {
                            synchronized (ScanThreadWSD.this.destroyed) {
                                if (!ScanThreadWSD.this.destroyed[0]) {
                                    throw e;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                } catch (Throwable th) {
                    this.socket.close();
                    throw th;
                }
            }
            this.socket.close();
            synchronized (ScanThreadWSD.this.packets) {
                ScanThreadWSD.this.packets.notifyAll();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
            if (r3.socket.isClosed() == false) goto L_0x0021;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0020, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r3.socket.send(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
            java.lang.Thread.sleep(100);
         */
        public synchronized void send(DatagramPacket datagramPacket) {
            try {
                synchronized (ScanThreadWSD.this.destroyed) {
                    if (ScanThreadWSD.this.destroyed[0]) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("src: ");
                sb.append(this.socket.getLocalAddress());
                sb.append(" dst: ");
                sb.append(datagramPacket.getAddress());
                sb.append(" | ");
                sb.append(this.ia);
                sb.append(" | ");
                sb.append(this.ni);
                App.reportThrowable(e, sb.toString());
            }
            return;
        }

        public void interrupt() {
            super.interrupt();
            this.socket.close();
        }
    }

    public ScanThreadWSD(Context context, int i, String str, Handler handler) {
        this.timeout = i;
        this.status = handler;
        this.rq_pid = str;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        int i;
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        for (int i2 = 0; i2 < this.workers.size(); i2++) {
            DetectThread detectThread = (DetectThread) this.workers.get(i2);
            if (detectThread.isAlive()) {
                detectThread.interrupt();
            }
        }
        for (i = 0; i < this.sockets.size(); i++) {
            ((SocketThread) this.sockets.get(i)).interrupt();
        }
        interrupt();
    }

    /* JADX WARNING: Removed duplicated region for block: B:149:0x0174 A[EDGE_INSN: B:149:0x0174->B:120:0x0174 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0129  */
    public void run() {
        String str;
        Object[] array;
        Message message = new Message();
        message.what = 1;
        message.arg1 = 5;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            str = null;
            try {
                Vector activeNetworkInterfaces = App.getActiveNetworkInterfaces();
                if (activeNetworkInterfaces == null || activeNetworkInterfaces.size() != 0) {
                    SocketThread socketThread = new SocketThread(null, null);
                    socketThread.start();
                    this.sockets.add(socketThread);
                    if (activeNetworkInterfaces != null) {
                        for (int i = 0; i < activeNetworkInterfaces.size(); i++) {
                            NetworkInterfaceData networkInterfaceData = (NetworkInterfaceData) activeNetworkInterfaces.get(i);
                            if (networkInterfaceData.is_multicast) {
                                if (networkInterfaceData.ipv4_addresses != null) {
                                    for (int i2 = 0; i2 < networkInterfaceData.ipv4_addresses.size(); i2++) {
                                        try {
                                            SocketThread socketThread2 = new SocketThread((InetAddress) networkInterfaceData.ipv4_addresses.get(i2), networkInterfaceData.iface);
                                            socketThread2.start();
                                            this.sockets.add(socketThread2);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                        }
                                    }
                                }
                                if (networkInterfaceData.ipv6_linklocal_address != null) {
                                    try {
                                        SocketThread socketThread3 = new SocketThread(networkInterfaceData.ipv6_linklocal_address, networkInterfaceData.iface);
                                        socketThread3.start();
                                        this.sockets.add(socketThread3);
                                    } catch (Exception e2) {
                                        e2.printStackTrace();
                                        App.reportThrowable(e2);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Message message2 = new Message();
                    message2.what = 4;
                    message2.arg1 = 5;
                    this.status.sendMessage(message2);
                    return;
                }
            } catch (Exception e3) {
                e3.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e3.getMessage());
                String sb2 = sb.toString();
                App.reportThrowable(e3);
                str = sb2;
            }
        }
        if (str == null) {
            this.sender.start();
            HashSet hashSet = new HashSet();
            while (true) {
                synchronized (this.destroyed) {
                    if (!this.destroyed[0]) {
                        while (true) {
                            synchronized (this.packets) {
                                if (this.packets.size() != 0) {
                                    break;
                                }
                                int i3 = 0;
                                for (int i4 = 0; i4 < this.sockets.size(); i4++) {
                                    if (((SocketThread) this.sockets.get(i4)).isAlive()) {
                                        i3++;
                                    }
                                }
                                if (i3 != this.sockets.size()) {
                                    if (i3 <= 0) {
                                        break;
                                    }
                                    Thread.yield();
                                } else {
                                    try {
                                        this.packets.wait();
                                        break;
                                    } catch (InterruptedException unused) {
                                    }
                                }
                            }
                        }
                        array = this.packets.toArray();
                        this.packets.clear();
                        if (array.length == 0) {
                            int i5 = 0;
                            while (true) {
                                if (i5 >= array.length) {
                                    break;
                                }
                                synchronized (this.destroyed) {
                                    if (this.destroyed[0]) {
                                        break;
                                    }
                                    DatagramPacket datagramPacket = (DatagramPacket) array[i5];
                                    InetAddress address = datagramPacket.getAddress();
                                    if (!hashSet.contains(address)) {
                                        hashSet.add(address);
                                        DetectThread detectThread = new DetectThread(datagramPacket);
                                        synchronized (this.destroyed) {
                                            if (!this.destroyed[0]) {
                                                this.workers.add(detectThread);
                                                detectThread.start();
                                            }
                                        }
                                    }
                                    i5++;
                                }
                            }
                        } else {
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
        }
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        if (str != null) {
            Message message3 = new Message();
            message3.what = 3;
            message3.arg1 = 5;
            Bundle bundle = new Bundle();
            bundle.putString("message", str);
            message3.setData(bundle);
            this.status.sendMessage(message3);
        } else {
            Message message4 = new Message();
            message4.what = 4;
            message4.arg1 = 5;
            this.status.sendMessage(message4);
        }
        return;
        array = this.packets.toArray();
        this.packets.clear();
        if (array.length == 0) {
        }
    }
}
