package com.dynamixsoftware.printershare;

public final class R {

    public static final class color {
        public static final int bottom_panel_bg = 2130771968;

        private color() {
        }
    }

    public static final class drawable {
        public static final int btn_bg = 2130837504;
        public static final int btn_bg_disabled = 2130837505;
        public static final int btn_bg_selected = 2130837506;
        public static final int btn_circle_normal = 2130837507;
        public static final int btn_ic_calendar = 2130837508;
        public static final int btn_ic_calllog = 2130837509;
        public static final int btn_ic_contacts = 2130837510;
        public static final int btn_ic_docs = 2130837511;
        public static final int btn_ic_gdocs = 2130837512;
        public static final int btn_ic_gmail = 2130837513;
        public static final int btn_ic_messages = 2130837514;
        public static final int btn_ic_pictures = 2130837515;
        public static final int btn_ic_web = 2130837516;
        public static final int btn_main = 2130837517;
        public static final int call_log_incoming_call = 2130837518;
        public static final int call_log_missed_call = 2130837519;
        public static final int call_log_outgoing_call = 2130837520;
        public static final int check = 2130837521;
        public static final int check_off = 2130837522;
        public static final int check_on = 2130837523;
        public static final int contact = 2130837524;
        public static final int dlg_ic_bluetooth = 2130837525;
        public static final int dlg_ic_cloud = 2130837526;
        public static final int dlg_ic_network = 2130837527;
        public static final int dlg_ic_usb = 2130837528;
        public static final int dlg_ic_wifi = 2130837529;
        public static final int ic_btn_round_more_normal = 2130837530;
        public static final int ic_print_notification = 2130837531;
        public static final int icn_doc = 2130837532;
        public static final int icn_empty = 2130837533;
        public static final int icn_folder = 2130837534;
        public static final int icn_hwp = 2130837535;
        public static final int icn_img = 2130837536;
        public static final int icn_pdf = 2130837537;
        public static final int icn_ppt = 2130837538;
        public static final int icn_txt = 2130837539;
        public static final int icn_up = 2130837540;
        public static final int icn_xls = 2130837541;
        public static final int icon = 2130837542;
        public static final int icon_title = 2130837543;
        public static final int light_header = 2130837544;
        public static final int logo_about = 2130837545;
        public static final int paper_auto = 2130837546;
        public static final int paper_landscape = 2130837547;
        public static final int paper_portrait = 2130837548;
        public static final int paperclip = 2130837549;
        public static final int printer = 2130837550;
        public static final int printer_about = 2130837551;
        public static final int printer_off = 2130837552;
        public static final int printer_on = 2130837553;
        public static final int schema = 2130837554;
        public static final int selected = 2130837555;
        public static final int smb_domain = 2130837556;
        public static final int smb_server = 2130837557;
        public static final int smb_up = 2130837558;
        public static final int sms_unread = 2130837559;
        public static final int star_off = 2130837560;
        public static final int star_on = 2130837561;

        private drawable() {
        }
    }

    public static final class id {
        public static final int about_campaign = 2130903040;
        public static final int about_version = 2130903041;
        public static final int arrow = 2130903042;
        public static final int bookmark_favicon = 2130903043;
        public static final int bookmark_title = 2130903044;
        public static final int bookmark_url = 2130903045;
        public static final int bottom = 2130903046;
        public static final int button_favbookmarks = 2130903047;
        public static final int button_go = 2130903048;
        public static final int button_print = 2130903049;
        public static final int continue_button = 2130903050;
        public static final int date = 2130903051;
        public static final int empty = 2130903052;
        public static final int enter_url = 2130903053;
        public static final int from = 2130903054;
        public static final int header = 2130903055;
        public static final int header_text = 2130903056;
        public static final int help_view = 2130903057;
        public static final int hint1 = 2130903058;
        public static final int hint2 = 2130903059;
        public static final int image = 2130903060;
        public static final int labels = 2130903061;
        public static final int list = 2130903062;
        public static final int login_button = 2130903063;
        public static final int login_buttons = 2130903064;
        public static final int login_edit = 2130903065;
        public static final int login_label = 2130903066;
        public static final int main_layout = 2130903067;
        public static final int name = 2130903068;
        public static final int newuser_button = 2130903069;
        public static final int noQuickContactPhoto = 2130903070;
        public static final int note = 2130903071;
        public static final int open_dynamix_button = 2130903072;
        public static final int open_printershare_button = 2130903073;
        public static final int options_button = 2130903074;
        public static final int page_preview_container = 2130903075;
        public static final int page_preview_scroll = 2130903076;
        public static final int paper_info = 2130903077;
        public static final int paper_mode = 2130903078;
        public static final int paper_orientation = 2130903079;
        public static final int paper_size = 2130903080;
        public static final int paper_tray = 2130903081;
        public static final int paperclip = 2130903082;
        public static final int password_edit = 2130903083;
        public static final int password_label = 2130903084;
        public static final int print_all = 2130903085;
        public static final int print_button = 2130903086;
        public static final int print_calendar = 2130903087;
        public static final int print_call_log = 2130903088;
        public static final int print_contacts = 2130903089;
        public static final int print_copies = 2130903090;
        public static final int print_copies_minus = 2130903091;
        public static final int print_copies_plus = 2130903092;
        public static final int print_docs = 2130903093;
        public static final int print_gdocs = 2130903094;
        public static final int print_gmail = 2130903095;
        public static final int print_messages = 2130903096;
        public static final int print_pages = 2130903097;
        public static final int print_pictures = 2130903098;
        public static final int print_range = 2130903099;
        public static final int print_selected = 2130903100;
        public static final int print_web_pages = 2130903101;
        public static final int printer_current = 2130903102;
        public static final int printer_info = 2130903103;
        public static final int printer_keyword = 2130903104;
        public static final int printer_location = 2130903105;
        public static final int printer_name = 2130903106;
        public static final int printer_owner = 2130903107;
        public static final int printer_status = 2130903108;
        public static final int root_layout = 2130903109;
        public static final int schema = 2130903110;
        public static final int schema_title = 2130903111;
        public static final int select_button = 2130903112;
        public static final int selected = 2130903113;
        public static final int snippet = 2130903114;
        public static final int star = 2130903115;
        public static final int start_buttons = 2130903116;
        public static final int status = 2130903117;
        public static final int subject = 2130903118;
        public static final int unread_indicator = 2130903119;
        public static final int upgrade_banner = 2130903120;
        public static final int url_bar = 2130903121;
        public static final int user_address = 2130903122;
        public static final int user_city = 2130903123;
        public static final int user_city_state_zip = 2130903124;
        public static final int user_country = 2130903125;
        public static final int user_email = 2130903126;
        public static final int user_email_edit = 2130903127;
        public static final int user_email_label = 2130903128;
        public static final int user_login = 2130903129;
        public static final int user_name = 2130903130;
        public static final int user_name_edit = 2130903131;
        public static final int user_name_label = 2130903132;
        public static final int user_nick = 2130903133;
        public static final int user_phone = 2130903134;
        public static final int user_state = 2130903135;
        public static final int user_zip = 2130903136;
        public static final int web_view = 2130903137;

        private id() {
        }
    }

    public static final class layout {
        public static final int about = 2130968576;
        public static final int bottom = 2130968577;
        public static final int dialog_authorization = 2130968578;
        public static final int dialog_bookmarks = 2130968579;
        public static final int dialog_login = 2130968580;
        public static final int dialog_owner_details = 2130968581;
        public static final int dialog_pages = 2130968582;
        public static final int dialog_printer_details = 2130968583;
        public static final int dialog_register = 2130968584;
        public static final int dialog_search = 2130968585;
        public static final int gmail_conversation = 2130968586;
        public static final int help = 2130968587;
        public static final int list = 2130968588;
        public static final int list_item_calendar = 2130968589;
        public static final int list_item_contacts = 2130968590;
        public static final int list_item_docs = 2130968591;
        public static final int list_item_gmail = 2130968592;
        public static final int list_item_messages = 2130968593;
        public static final int main = 2130968594;
        public static final int paper = 2130968595;
        public static final int print = 2130968596;
        public static final int printer = 2130968597;
        public static final int profile = 2130968598;
        public static final int profile_edit = 2130968599;
        public static final int start = 2130968600;
        public static final int web = 2130968601;

        private layout() {
        }
    }

    public static final class raw {
        public static final int btn_ic_calendar = 2131034112;
        public static final int btn_ic_calllog = 2131034113;
        public static final int btn_ic_contacts = 2131034114;
        public static final int btn_ic_docs = 2131034115;
        public static final int btn_ic_gdocs = 2131034116;
        public static final int btn_ic_gmail = 2131034117;
        public static final int btn_ic_messages = 2131034118;
        public static final int btn_ic_pictures = 2131034119;
        public static final int btn_ic_web = 2131034120;
        public static final int schema = 2131034121;
        public static final int test_page = 2131034122;

        private raw() {
        }
    }

    public static final class string {
        public static final int about_text = 2131099648;
        public static final int about_text_company = 2131099649;
        public static final int app_name = 2131099650;
        public static final int banner_upgrade_action = 2131099651;
        public static final int banner_upgrade_text = 2131099652;
        public static final int button_add_printer = 2131099653;
        public static final int button_buynow_market_google = 2131099654;
        public static final int button_buynow_market_huawei = 2131099655;
        public static final int button_buynow_online = 2131099656;
        public static final int button_cancel = 2131099657;
        public static final int button_continue = 2131099658;
        public static final int button_edit = 2131099659;
        public static final int button_go = 2131099660;
        public static final int button_login = 2131099661;
        public static final int button_logout = 2131099662;
        public static final int button_main_calendar = 2131099663;
        public static final int button_main_call_log = 2131099664;
        public static final int button_main_contacts = 2131099665;
        public static final int button_main_docs = 2131099666;
        public static final int button_main_gdocs = 2131099667;
        public static final int button_main_gmail = 2131099668;
        public static final int button_main_messages = 2131099669;
        public static final int button_main_pictures = 2131099670;
        public static final int button_main_web_pages = 2131099671;
        public static final int button_new_search = 2131099672;
        public static final int button_new_user = 2131099673;
        public static final int button_no = 2131099674;
        public static final int button_ok = 2131099675;
        public static final int button_open_site_dynamix = 2131099676;
        public static final int button_open_site_printershare = 2131099677;
        public static final int button_options = 2131099678;
        public static final int button_print = 2131099679;
        public static final int button_print_test_page = 2131099680;
        public static final int button_read_more = 2131099681;
        public static final int button_review = 2131099682;
        public static final int button_save = 2131099683;
        public static final int button_scan = 2131099684;
        public static final int button_search = 2131099685;
        public static final int button_select = 2131099686;
        public static final int button_select_manually = 2131099687;
        public static final int button_send_feedback = 2131099688;
        public static final int button_skip = 2131099689;
        public static final int button_storages = 2131099690;
        public static final int button_troubleshooting = 2131099691;
        public static final int button_use_generic = 2131099692;
        public static final int button_yes = 2131099693;
        public static final int dialog_authorization_label_2step_note = 2131099694;
        public static final int dialog_authorization_label_domain = 2131099695;
        public static final int dialog_authorization_label_login = 2131099696;
        public static final int dialog_authorization_label_password = 2131099697;
        public static final int dialog_authorization_title = 2131099698;
        public static final int dialog_bookmarks_title = 2131099699;
        public static final int dialog_driver_not_found_text = 2131099700;
        public static final int dialog_driver_note = 2131099701;
        public static final int dialog_generic_driver_found_text = 2131099702;
        public static final int dialog_incompatible_settings_text = 2131099703;
        public static final int dialog_incompatible_settings_title = 2131099704;
        public static final int dialog_install_docs_render_text = 2131099705;
        public static final int dialog_install_drivers_text = 2131099706;
        public static final int dialog_install_pdf_render_text = 2131099707;
        public static final int dialog_install_printer_done = 2131099708;
        public static final int dialog_key_activation_error_text = 2131099709;
        public static final int dialog_key_activation_error_title = 2131099710;
        public static final int dialog_login_label_login = 2131099711;
        public static final int dialog_login_label_password = 2131099712;
        public static final int dialog_login_title = 2131099713;
        public static final int dialog_no_bt_printers_text = 2131099714;
        public static final int dialog_no_cloud_printers_text = 2131099715;
        public static final int dialog_no_printers_title = 2131099716;
        public static final int dialog_no_usb_printers_text = 2131099717;
        public static final int dialog_no_wifi_printers_text = 2131099718;
        public static final int dialog_payment_options_label_annual_subscription = 2131099719;
        public static final int dialog_payment_options_label_monthly_subscription = 2131099720;
        public static final int dialog_payment_options_label_onetime_payment = 2131099721;
        public static final int dialog_payment_options_title = 2131099722;
        public static final int dialog_premium_upgrade_text = 2131099723;
        public static final int dialog_premium_upgrade_title = 2131099724;
        public static final int dialog_register_label_password_note = 2131099725;
        public static final int dialog_register_label_user_email = 2131099726;
        public static final int dialog_register_label_user_name = 2131099727;
        public static final int dialog_register_title = 2131099728;
        public static final int dialog_search_hint = 2131099729;
        public static final int dialog_search_label_online_printers_only = 2131099730;
        public static final int dialog_search_text = 2131099731;
        public static final int dialog_search_title = 2131099732;
        public static final int dialog_user_action_title = 2131099733;
        public static final int fast_scroll_alphabet = 2131099734;
        public static final int fast_scroll_numeric_alphabet = 2131099735;
        public static final int header_about = 2131099736;
        public static final int header_cloud_printers = 2131099737;
        public static final int header_edit_profile = 2131099738;
        public static final int header_find_printers = 2131099739;
        public static final int header_help = 2131099740;
        public static final int header_info = 2131099741;
        public static final int header_local_printers = 2131099742;
        public static final int header_print_preview = 2131099743;
        public static final int header_profile = 2131099744;
        public static final int header_remote_printers = 2131099745;
        public static final int label_30days = 2131099746;
        public static final int label_7days = 2131099747;
        public static final int label_all = 2131099748;
        public static final int label_chat_addresses = 2131099749;
        public static final int label_chats = 2131099750;
        public static final int label_copies = 2131099751;
        public static final int label_custom = 2131099752;
        public static final int label_drafts = 2131099753;
        public static final int label_email_addresses = 2131099754;
        public static final int label_favourite_printers = 2131099755;
        public static final int label_font_size = 2131099756;
        public static final int label_font_size_large = 2131099757;
        public static final int label_font_size_normal = 2131099758;
        public static final int label_font_size_small = 2131099759;
        public static final int label_found_printers = 2131099760;
        public static final int label_from = 2131099761;
        public static final int label_inbox = 2131099762;
        public static final int label_loading = 2131099763;
        public static final int label_loading_progress = 2131099764;
        public static final int label_more_then = 2131099765;
        public static final int label_no_contacts = 2131099766;
        public static final int label_no_conversations = 2131099767;
        public static final int label_no_messages = 2131099768;
        public static final int label_not_selected = 2131099769;
        public static final int label_notes = 2131099770;
        public static final int label_options = 2131099771;
        public static final int label_organizations = 2131099772;
        public static final int label_output_color = 2131099773;
        public static final int label_output_duplex = 2131099774;
        public static final int label_output_mode = 2131099775;
        public static final int label_owner_details = 2131099776;
        public static final int label_page_margins = 2131099777;
        public static final int label_page_margins_no = 2131099778;
        public static final int label_page_orientation = 2131099779;
        public static final int label_page_orientation_auto = 2131099780;
        public static final int label_page_orientation_landscape = 2131099781;
        public static final int label_page_orientation_portrait = 2131099782;
        public static final int label_page_scaling = 2131099783;
        public static final int label_page_scaling_fit_paper = 2131099784;
        public static final int label_page_scaling_fit_printable_area = 2131099785;
        public static final int label_page_scaling_original = 2131099786;
        public static final int label_pages = 2131099787;
        public static final int label_paper_size = 2131099788;
        public static final int label_paper_source = 2131099789;
        public static final int label_paper_type = 2131099790;
        public static final int label_password_required = 2131099791;
        public static final int label_phone_numbers = 2131099792;
        public static final int label_picture_align = 2131099793;
        public static final int label_picture_align_bottom_left = 2131099794;
        public static final int label_picture_align_bottom_right = 2131099795;
        public static final int label_picture_align_center = 2131099796;
        public static final int label_picture_align_top_left = 2131099797;
        public static final int label_picture_align_top_right = 2131099798;
        public static final int label_picture_scaling = 2131099799;
        public static final int label_picture_scaling_crop = 2131099800;
        public static final int label_picture_scaling_inside = 2131099801;
        public static final int label_picture_size = 2131099802;
        public static final int label_picture_size_fit = 2131099803;
        public static final int label_picture_size_original = 2131099804;
        public static final int label_postal_addresses = 2131099805;
        public static final int label_premium = 2131099806;
        public static final int label_print_options = 2131099807;
        public static final int label_print_range = 2131099808;
        public static final int label_print_range_all = 2131099809;
        public static final int label_print_range_hint = 2131099810;
        public static final int label_print_range_selected = 2131099811;
        public static final int label_printer = 2131099812;
        public static final int label_printer_details = 2131099813;
        public static final int label_printer_location = 2131099814;
        public static final int label_printer_name = 2131099815;
        public static final int label_printer_status = 2131099816;
        public static final int label_printing_completed = 2131099817;
        public static final int label_printing_solution = 2131099818;
        public static final int label_processing = 2131099819;
        public static final int label_processing_progress = 2131099820;
        public static final int label_remove_printer = 2131099821;
        public static final int label_rendering = 2131099822;
        public static final int label_review = 2131099823;
        public static final int label_scanning = 2131099824;
        public static final int label_searching = 2131099825;
        public static final int label_select_date_range = 2131099826;
        public static final int label_sent = 2131099827;
        public static final int label_spam = 2131099828;
        public static final int label_starred = 2131099829;
        public static final int label_to = 2131099830;
        public static final int label_today = 2131099831;
        public static final int label_tomorrow = 2131099832;
        public static final int label_trash = 2131099833;
        public static final int menu_about = 2131099834;
        public static final int menu_accounts = 2131099835;
        public static final int menu_add_account = 2131099836;
        public static final int menu_display_group = 2131099837;
        public static final int menu_google_cloud_printer = 2131099838;
        public static final int menu_help = 2131099839;
        public static final int menu_labels = 2131099840;
        public static final int menu_nearby_bt = 2131099841;
        public static final int menu_nearby_usb = 2131099842;
        public static final int menu_nearby_wifi = 2131099843;
        public static final int menu_profile = 2131099844;
        public static final int menu_refresh = 2131099845;
        public static final int menu_remote_printer = 2131099846;
        public static final int menu_select_all = 2131099847;
        public static final int menu_select_printer = 2131099848;
        public static final int menu_unselect_all = 2131099849;
        public static final int message_finishing_print_job = 2131099850;
        public static final int message_sending_page = 2131099851;
        public static final int message_sending_page_progress = 2131099852;
        public static final int message_starting_print_job = 2131099853;
        public static final int mgr_pid_descr = 2131099854;
        public static final int mgr_pid_title = 2131099855;
        public static final int print_notification_channel = 2131099856;
        public static final int print_notification_content_text = 2131099857;
        public static final int print_notification_content_title = 2131099858;
        public static final int print_problem_bad_colors = 2131099859;
        public static final int print_problem_bad_printouts = 2131099860;
        public static final int print_problem_blank_pages = 2131099861;
        public static final int print_problem_get_error = 2131099862;
        public static final int print_problem_no_duplex = 2131099863;
        public static final int print_problem_not_printed = 2131099864;
        public static final int print_problem_other = 2131099865;
        public static final int print_problem_partially_printed = 2131099866;
        public static final int profile_label_address = 2131099867;
        public static final int profile_label_city = 2131099868;
        public static final int profile_label_country = 2131099869;
        public static final int profile_label_details = 2131099870;
        public static final int profile_label_email = 2131099871;
        public static final int profile_label_name = 2131099872;
        public static final int profile_label_nickname = 2131099873;
        public static final int profile_label_phone = 2131099874;
        public static final int profile_label_state = 2131099875;
        public static final int profile_label_user_id = 2131099876;
        public static final int profile_label_zip = 2131099877;
        public static final int sent_on = 2131099878;
        public static final int title_choose_printer_model = 2131099879;
        public static final int title_select_contact = 2131099880;
        public static final int title_select_conversation = 2131099881;
        public static final int toast_empty_agenda = 2131099882;
        public static final int toast_empty_call_log = 2131099883;
        public static final int toast_incorrect_date_range = 2131099884;
        public static final int toast_incorrect_print_range = 2131099885;
        public static final int toast_nothing_selected = 2131099886;
        public static final int toast_profile_updated = 2131099887;
        public static final int toast_select_printer_first = 2131099888;

        private string() {
        }
    }

    public static final class style {
        public static final int AppTheme = 2131165184;
        public static final int AppThemeBase = 2131165185;
        public static final int Theme_PlayCore_Transparent = 2131165186;
        public static final int Widget_ActionBar = 2131165187;
        public static final int Widget_Holo_Light_Button = 2131165188;

        private style() {
        }
    }

    public static final class xml {
        public static final int app_restrictions = 2131230720;
        public static final int network_security_config = 2131230721;
        public static final int usb_device_filter = 2131230722;
        /* added by JADX */
        public static final int splits0 = 2131230723;

        private xml() {
        }
    }

    private R() {
    }
}
