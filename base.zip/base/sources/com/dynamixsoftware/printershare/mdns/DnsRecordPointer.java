package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;

public class DnsRecordPointer extends DnsRecord {
    String alias;

    public DnsRecordPointer(String str, int i, int i2, int i3, String str2) {
        super(str, i, i2, i3);
        this.alias = str2;
    }

    /* access modifiers changed from: 0000 */
    public void write(DnsPacketOut dnsPacketOut) throws IOException {
        dnsPacketOut.writeName(this.alias);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameValue(DnsRecord dnsRecord) {
        return this.alias.equals(((DnsRecordPointer) dnsRecord).alias);
    }

    public String getAlias() {
        return this.alias;
    }
}
