package com.dynamixsoftware.printershare.mdns;

import com.flurry.android.Constants;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class DnsPacketIn {
    List<DnsRecord> answers = Collections.emptyList();
    private byte[] data;
    int flags = readUnsignedShort();
    int id = readUnsignedShort();
    private int len;
    int numAdditionals = readUnsignedShort();
    int numAnswers = readUnsignedShort();
    int numAuthorities = readUnsignedShort();
    int numQuestions = readUnsignedShort();
    private int off;
    List<DnsQuestion> questions = Collections.emptyList();
    long receivedTime = System.currentTimeMillis();

    /* JADX WARNING: type inference failed for: r7v1 */
    /* JADX WARNING: type inference failed for: r7v2, types: [com.dynamixsoftware.printershare.mdns.DnsRecord, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r8v1 */
    /* JADX WARNING: type inference failed for: r7v3 */
    /* JADX WARNING: type inference failed for: r2v12, types: [com.dynamixsoftware.printershare.mdns.DnsRecordAddress] */
    /* JADX WARNING: type inference failed for: r2v13, types: [com.dynamixsoftware.printershare.mdns.DnsRecordPointer] */
    /* JADX WARNING: type inference failed for: r2v16, types: [com.dynamixsoftware.printershare.mdns.DnsRecordText] */
    /* JADX WARNING: type inference failed for: r2v18, types: [com.dynamixsoftware.printershare.mdns.DnsRecordService] */
    /* JADX WARNING: type inference failed for: r7v12 */
    /* JADX WARNING: type inference failed for: r2v24, types: [com.dynamixsoftware.printershare.mdns.DnsRecordAddress] */
    /* JADX WARNING: type inference failed for: r2v25, types: [com.dynamixsoftware.printershare.mdns.DnsRecordPointer] */
    /* JADX WARNING: type inference failed for: r2v26, types: [com.dynamixsoftware.printershare.mdns.DnsRecordText] */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r2v24, types: [com.dynamixsoftware.printershare.mdns.DnsRecordAddress]
  assigns: [com.dynamixsoftware.printershare.mdns.DnsRecordAddress, com.dynamixsoftware.printershare.mdns.DnsRecordPointer, com.dynamixsoftware.printershare.mdns.DnsRecordText]
  uses: [com.dynamixsoftware.printershare.mdns.DnsRecordAddress, ?[OBJECT, ARRAY], com.dynamixsoftware.printershare.mdns.DnsRecordPointer, com.dynamixsoftware.printershare.mdns.DnsRecordText]
  mth insns count: 129
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0117  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0120  */
    /* JADX WARNING: Unknown variable types count: 6 */
    public DnsPacketIn(DatagramPacket datagramPacket) throws IOException {
        ? r8;
        String str;
        String str2;
        InetAddress address = datagramPacket.getAddress();
        this.data = datagramPacket.getData();
        this.len = datagramPacket.getLength();
        this.off = datagramPacket.getOffset();
        if (this.numQuestions > 0) {
            this.questions = Collections.synchronizedList(new ArrayList(this.numQuestions));
            for (int i = 0; i < this.numQuestions; i++) {
                this.questions.add(new DnsQuestion(readName(), readUnsignedShort(), readUnsignedShort()));
            }
        }
        int i2 = this.numAnswers + this.numAuthorities + this.numAdditionals;
        if (i2 > 0) {
            this.answers = Collections.synchronizedList(new ArrayList(i2));
            for (int i3 = 0; i3 < i2; i3++) {
                String readName = readName();
                int readUnsignedShort = readUnsignedShort();
                int readUnsignedShort2 = readUnsignedShort();
                int readInt = readInt();
                int readUnsignedShort3 = readUnsignedShort();
                int i4 = this.off + readUnsignedShort3;
                ? r7 = 0;
                if (readUnsignedShort != 1) {
                    String str3 = "";
                    if (readUnsignedShort == 5 || readUnsignedShort == 12) {
                        try {
                            str = readName();
                        } catch (IOException e) {
                            e.printStackTrace();
                            str = str3;
                        }
                        ? dnsRecordPointer = new DnsRecordPointer(readName, readUnsignedShort, readUnsignedShort2, readInt, str);
                        r8 = dnsRecordPointer;
                        r7 = r8;
                        if (r7 == 0) {
                            r7.setRecordSource(address);
                            this.answers.add(r7);
                        } else {
                            int size = this.answers.size();
                            int i5 = this.numAnswers;
                            if (size < i5) {
                                this.numAnswers = i5 - 1;
                            } else {
                                int size2 = this.answers.size();
                                int i6 = this.numAnswers;
                                int i7 = this.numAuthorities;
                                if (size2 < i6 + i7) {
                                    this.numAuthorities = i7 - 1;
                                } else {
                                    int size3 = this.answers.size();
                                    int i8 = this.numAnswers + this.numAuthorities;
                                    int i9 = this.numAdditionals;
                                    if (size3 < i8 + i9) {
                                        this.numAdditionals = i9 - 1;
                                    }
                                }
                            }
                        }
                        this.off = i4;
                    } else if (readUnsignedShort == 16) {
                        ? dnsRecordText = new DnsRecordText(readName, readUnsignedShort, readUnsignedShort2, readInt, readBytes(this.off, readUnsignedShort3));
                        r8 = dnsRecordText;
                        r7 = r8;
                        if (r7 == 0) {
                        }
                        this.off = i4;
                    } else if (readUnsignedShort != 28) {
                        if (readUnsignedShort == 33) {
                            int readUnsignedShort4 = readUnsignedShort();
                            int readUnsignedShort5 = readUnsignedShort();
                            int readUnsignedShort6 = readUnsignedShort();
                            try {
                                str2 = readName();
                            } catch (IOException e2) {
                                e2.printStackTrace();
                                str2 = str3;
                            }
                            ? dnsRecordService = new DnsRecordService(readName, readUnsignedShort, readUnsignedShort2, readInt, readUnsignedShort4, readUnsignedShort5, readUnsignedShort6, str2);
                            r7 = dnsRecordService;
                        }
                        if (r7 == 0) {
                        }
                        this.off = i4;
                    }
                }
                ? dnsRecordAddress = new DnsRecordAddress(readName, readUnsignedShort, readUnsignedShort2, readInt, readBytes(this.off, readUnsignedShort3));
                r8 = dnsRecordAddress;
                r7 = r8;
                if (r7 == 0) {
                }
                this.off = i4;
            }
        }
    }

    public boolean isQuery() {
        return (this.flags & 32768) == 0;
    }

    public boolean isTruncated() {
        return (this.flags & 512) != 0;
    }

    public boolean isResponse() {
        return (this.flags & 32768) == 32768;
    }

    private int get(int i) throws IOException {
        if (i >= 0 && i < this.len) {
            return this.data[i] & Constants.UNKNOWN;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("parser error: offset=");
        sb.append(i);
        throw new IOException(sb.toString());
    }

    private int readUnsignedShort() throws IOException {
        int i = this.off;
        this.off = i + 1;
        int i2 = get(i) << 8;
        int i3 = this.off;
        this.off = i3 + 1;
        return i2 + get(i3);
    }

    private int readInt() throws IOException {
        return (readUnsignedShort() << 16) + readUnsignedShort();
    }

    private byte[] readBytes(int i, int i2) throws IOException {
        byte[] bArr = new byte[i2];
        System.arraycopy(this.data, i, bArr, 0, i2);
        return bArr;
    }

    private void readUTF(StringBuffer stringBuffer, int i, int i2) throws IOException {
        stringBuffer.append(new String(readBytes(i, i2), "UTF-8"));
    }

    private String readName() throws IOException {
        StringBuffer stringBuffer = new StringBuffer();
        int i = this.off;
        int i2 = i;
        int i3 = -1;
        while (true) {
            int i4 = i + 1;
            int i5 = get(i);
            if (i5 == 0) {
                if (i3 < 0) {
                    i3 = i4;
                }
                this.off = i3;
                return stringBuffer.toString();
            }
            int i6 = i5 & 192;
            if (i6 == 0) {
                readUTF(stringBuffer, i4, i5);
                i4 += i5;
                stringBuffer.append('.');
            } else if (i6 == 192) {
                if (i3 < 0) {
                    i3 = i4 + 1;
                }
                i = ((i5 & 63) << 8) | get(i4);
                if (i < i2) {
                    i2 = i;
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("bad domain name: possible circular name detected. name start: ");
                    sb.append(i2);
                    sb.append(" bad offset: 0x");
                    sb.append(Integer.toHexString(i));
                    throw new IOException(sb.toString());
                }
            }
            i = i4;
        }
    }

    /* access modifiers changed from: 0000 */
    public void append(DnsPacketIn dnsPacketIn) {
        if (!isQuery() || !isTruncated() || !dnsPacketIn.isQuery()) {
            throw new IllegalArgumentException();
        }
        if (dnsPacketIn.numQuestions > 0) {
            if (Collections.EMPTY_LIST.equals(this.questions)) {
                this.questions = Collections.synchronizedList(new ArrayList(dnsPacketIn.numQuestions));
            }
            this.questions.addAll(dnsPacketIn.questions);
            this.numQuestions += dnsPacketIn.numQuestions;
        }
        if (Collections.EMPTY_LIST.equals(this.answers)) {
            this.answers = Collections.synchronizedList(new ArrayList());
        }
        int i = dnsPacketIn.numAnswers;
        if (i > 0) {
            this.answers.addAll(this.numAnswers, dnsPacketIn.answers.subList(0, i));
            this.numAnswers += dnsPacketIn.numAnswers;
        }
        int i2 = dnsPacketIn.numAuthorities;
        if (i2 > 0) {
            List<DnsRecord> list = this.answers;
            int i3 = this.numAnswers + this.numAuthorities;
            List<DnsRecord> list2 = dnsPacketIn.answers;
            int i4 = dnsPacketIn.numAnswers;
            list.addAll(i3, list2.subList(i4, i2 + i4));
            this.numAuthorities += dnsPacketIn.numAuthorities;
        }
        int i5 = dnsPacketIn.numAdditionals;
        if (i5 > 0) {
            List<DnsRecord> list3 = this.answers;
            List<DnsRecord> list4 = dnsPacketIn.answers;
            int i6 = dnsPacketIn.numAnswers;
            int i7 = dnsPacketIn.numAuthorities;
            list3.addAll(list4.subList(i6 + i7, i6 + i7 + i5));
            this.numAdditionals += dnsPacketIn.numAdditionals;
        }
    }

    public int elapseSinceArrival() {
        return (int) (System.currentTimeMillis() - this.receivedTime);
    }

    public List<DnsQuestion> getQuestions() {
        return this.questions;
    }

    public List<DnsRecord> getAnswers() {
        return this.answers;
    }

    public DnsRecord getAnswer(int i, String str) {
        for (int i2 = 0; i2 < this.answers.size(); i2++) {
            DnsRecord dnsRecord = (DnsRecord) this.answers.get(i2);
            if (dnsRecord.type == i && dnsRecord.name.equals(str)) {
                return dnsRecord;
            }
        }
        return null;
    }
}
