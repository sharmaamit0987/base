package com.dynamixsoftware.printershare.mdns;

public class DnsEntity {
    int clazz;
    String key;
    String name;
    int type;
    boolean unique;

    DnsEntity(String str, int i, int i2) {
        this.key = str.toLowerCase();
        this.name = str;
        this.type = i;
        this.clazz = i2 & DnsConstants.CLASS_MASK;
        this.unique = (32768 & i2) != 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof DnsEntity)) {
            return false;
        }
        DnsEntity dnsEntity = (DnsEntity) obj;
        if (this.name.equals(dnsEntity.name) && this.type == dnsEntity.type && this.clazz == dnsEntity.clazz) {
            return true;
        }
        return false;
    }

    public String getName() {
        return this.name;
    }

    public int getType() {
        return this.type;
    }

    public int hashCode() {
        return this.name.hashCode() + this.type + this.clazz;
    }
}
