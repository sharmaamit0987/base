package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;

public class DnsRecordText extends DnsRecord {
    byte[] text;

    public DnsRecordText(String str, int i, int i2, int i3, byte[] bArr) {
        super(str, i, i2, i3);
        this.text = bArr;
    }

    /* access modifiers changed from: 0000 */
    public void write(DnsPacketOut dnsPacketOut) throws IOException {
        byte[] bArr = this.text;
        dnsPacketOut.writeBytes(bArr, 0, bArr.length);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameValue(DnsRecord dnsRecord) {
        DnsRecordText dnsRecordText = (DnsRecordText) dnsRecord;
        int length = dnsRecordText.text.length;
        byte[] bArr = this.text;
        if (length != bArr.length) {
            return false;
        }
        int length2 = bArr.length;
        while (true) {
            int i = length2 - 1;
            if (length2 <= 0) {
                return true;
            }
            if (dnsRecordText.text[i] != this.text[i]) {
                return false;
            }
            length2 = i;
        }
    }

    public byte[] getText() {
        return this.text;
    }
}
