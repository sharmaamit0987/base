package com.dynamixsoftware.printershare.mdns;

public final class DnsQuestion extends DnsEntity {
    public DnsQuestion(String str, int i, int i2) {
        super(str, i, i2);
    }

    /* access modifiers changed from: 0000 */
    public boolean answeredBy(DnsRecord dnsRecord) {
        return this.clazz == dnsRecord.clazz && (this.type == dnsRecord.type || this.type == 255) && this.name.equals(dnsRecord.name);
    }
}
