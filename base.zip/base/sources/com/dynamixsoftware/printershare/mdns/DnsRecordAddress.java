package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class DnsRecordAddress extends DnsRecord {
    InetAddress addr;

    DnsRecordAddress(String str, int i, int i2, int i3, InetAddress inetAddress) {
        super(str, i, i2, i3);
        this.addr = inetAddress;
    }

    DnsRecordAddress(String str, int i, int i2, int i3, byte[] bArr) throws UnknownHostException {
        super(str, i, i2, i3);
        this.addr = InetAddress.getByAddress(bArr);
    }

    /* access modifiers changed from: 0000 */
    public void write(DnsPacketOut dnsPacketOut) throws IOException {
        byte[] bArr;
        InetAddress inetAddress = this.addr;
        if (inetAddress != null) {
            byte[] address = inetAddress.getAddress();
            if (1 == this.type) {
                if (!(this.addr instanceof Inet4Address)) {
                    bArr = new byte[4];
                    System.arraycopy(address, 12, bArr, 0, 4);
                }
                dnsPacketOut.writeBytes(address);
            }
            if (this.addr instanceof Inet4Address) {
                bArr = new byte[16];
                for (int i = 0; i < 16; i++) {
                    if (i < 11) {
                        bArr[i] = address[i - 12];
                    } else {
                        bArr[i] = 0;
                    }
                }
            }
            dnsPacketOut.writeBytes(address);
            address = bArr;
            dnsPacketOut.writeBytes(address);
        }
    }

    /* access modifiers changed from: 0000 */
    public boolean same(DnsRecord dnsRecord) {
        return sameName(dnsRecord) && sameValue(dnsRecord);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameName(DnsRecord dnsRecord) {
        return this.name.equalsIgnoreCase(((DnsRecordAddress) dnsRecord).name);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameValue(DnsRecord dnsRecord) {
        return this.addr.equals(((DnsRecordAddress) dnsRecord).getAddress());
    }

    public InetAddress getAddress() {
        return this.addr;
    }
}
