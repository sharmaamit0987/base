package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;
import java.net.InetAddress;

public abstract class DnsRecord extends DnsEntity {
    long created = System.currentTimeMillis();
    InetAddress source;
    int ttl;

    /* access modifiers changed from: 0000 */
    public abstract boolean sameValue(DnsRecord dnsRecord);

    /* access modifiers changed from: 0000 */
    public abstract void write(DnsPacketOut dnsPacketOut) throws IOException;

    DnsRecord(String str, int i, int i2, int i3) {
        super(str, i, i2);
        this.ttl = i3;
    }

    public boolean equals(Object obj) {
        return (obj instanceof DnsRecord) && sameAs((DnsRecord) obj);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameAs(DnsRecord dnsRecord) {
        return super.equals(dnsRecord) && sameValue(dnsRecord);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameType(DnsRecord dnsRecord) {
        return this.type == dnsRecord.type;
    }

    /* access modifiers changed from: 0000 */
    public boolean suppressedBy(DnsPacketIn dnsPacketIn) {
        int i = dnsPacketIn.numAnswers;
        while (true) {
            int i2 = i - 1;
            if (i <= 0) {
                return false;
            }
            if (suppressedBy((DnsRecord) dnsPacketIn.answers.get(i2))) {
                return true;
            }
            i = i2;
        }
    }

    /* access modifiers changed from: 0000 */
    public boolean suppressedBy(DnsRecord dnsRecord) {
        return sameAs(dnsRecord) && dnsRecord.ttl > this.ttl / 2;
    }

    /* access modifiers changed from: 0000 */
    public long getExpirationTime(int i) {
        return this.created + (((long) (i * this.ttl)) * 10);
    }

    /* access modifiers changed from: 0000 */
    public int getRemainingTTL(long j) {
        return (int) Math.max(0, (getExpirationTime(100) - j) / 1000);
    }

    public boolean isExpired(long j) {
        return getExpirationTime(100) <= j;
    }

    /* access modifiers changed from: 0000 */
    public boolean isStale(long j) {
        return getExpirationTime(50) <= j;
    }

    /* access modifiers changed from: 0000 */
    public void resetTTL(DnsRecord dnsRecord) {
        this.created = dnsRecord.created;
        this.ttl = dnsRecord.ttl;
    }

    public void setRecordSource(InetAddress inetAddress) {
        this.source = inetAddress;
    }

    public InetAddress getRecordSource() {
        return this.source;
    }

    public void setTtl(int i) {
        this.ttl = i;
    }

    public int getTtl() {
        return this.ttl;
    }
}
