package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;

public class DnsRecordService extends DnsRecord {
    int port;
    int priority;
    String server;
    int weight;

    public DnsRecordService(String str, int i, int i2, int i3, int i4, int i5, int i6, String str2) {
        super(str, i, i2, i3);
        this.priority = i4;
        this.weight = i5;
        this.port = i6;
        this.server = str2;
    }

    /* access modifiers changed from: 0000 */
    public void write(DnsPacketOut dnsPacketOut) throws IOException {
        dnsPacketOut.writeShort(this.priority);
        dnsPacketOut.writeShort(this.weight);
        dnsPacketOut.writeShort(this.port);
        dnsPacketOut.writeName(this.server, false);
    }

    /* access modifiers changed from: 0000 */
    public boolean sameValue(DnsRecord dnsRecord) {
        DnsRecordService dnsRecordService = (DnsRecordService) dnsRecord;
        return this.priority == dnsRecordService.priority && this.weight == dnsRecordService.weight && this.port == dnsRecordService.port && this.server.equals(dnsRecordService.server);
    }

    public String getServer() {
        return this.server;
    }

    public int getPort() {
        return this.port;
    }
}
