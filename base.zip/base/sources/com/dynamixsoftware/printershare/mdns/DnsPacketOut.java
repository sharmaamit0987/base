package com.dynamixsoftware.printershare.mdns;

import java.io.IOException;
import java.net.DatagramPacket;
import java.util.Hashtable;
import java.util.LinkedList;

public final class DnsPacketOut {
    private static int[] pid = {1};
    private LinkedList<DnsRecord> authorativeAnswers;
    private byte[] data;
    int flags;
    private int len;
    boolean multicast;
    Hashtable<String, Integer> names;
    int numAdditionals;
    int numAnswers;
    int numAuthorities;
    int numQuestions;
    private int off;

    public DnsPacketOut(int i) {
        this(i, true);
    }

    public DnsPacketOut(int i, boolean z) {
        this.authorativeAnswers = new LinkedList<>();
        this.flags = i;
        this.multicast = z;
        this.names = new Hashtable<>();
        this.data = new byte[DnsConstants.MAX_MSG_TYPICAL];
        this.off = 12;
    }

    public void addQuestion(DnsQuestion dnsQuestion) throws IOException {
        if (this.numAnswers > 0 || this.numAuthorities > 0 || this.numAdditionals > 0) {
            throw new IllegalStateException("Questions must be added before answers");
        }
        this.numQuestions++;
        writeQuestion(dnsQuestion);
    }

    public void addAnswer(DnsPacketIn dnsPacketIn, DnsRecord dnsRecord) throws IOException {
        if (this.numAuthorities > 0 || this.numAdditionals > 0) {
            throw new IllegalStateException("Answers must be added before authorities and additionals");
        } else if (!dnsRecord.suppressedBy(dnsPacketIn)) {
            addAnswer(dnsRecord, 0);
        }
    }

    public void addAdditionalAnswer(DnsPacketIn dnsPacketIn, DnsRecord dnsRecord) throws IOException {
        if (this.off < 1260 && !dnsRecord.suppressedBy(dnsPacketIn)) {
            writeRecord(dnsRecord, 0);
            this.numAdditionals++;
        }
    }

    public void addAnswer(DnsRecord dnsRecord, long j) throws IOException {
        if (this.numAuthorities > 0 || this.numAdditionals > 0) {
            throw new IllegalStateException("Questions must be added before answers");
        } else if (dnsRecord == null) {
        } else {
            if (j == 0 || !dnsRecord.isExpired(j)) {
                writeRecord(dnsRecord, j);
                this.numAnswers++;
            }
        }
    }

    public void addAuthorativeAnswer(DnsRecord dnsRecord) throws IOException {
        if (this.numAdditionals <= 0) {
            this.authorativeAnswers.add(dnsRecord);
            writeRecord(dnsRecord, 0);
            this.numAuthorities++;
            return;
        }
        throw new IllegalStateException("Authorative answers must be added before additional answers");
    }

    /* access modifiers changed from: 0000 */
    public void writeByte(int i) throws IOException {
        int i2 = this.off;
        byte[] bArr = this.data;
        if (i2 < bArr.length) {
            this.off = i2 + 1;
            bArr[i2] = (byte) i;
            return;
        }
        throw new IOException("buffer full");
    }

    /* access modifiers changed from: 0000 */
    public void writeBytes(String str, int i, int i2) throws IOException {
        for (int i3 = 0; i3 < i2; i3++) {
            writeByte(str.charAt(i + i3));
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeBytes(byte[] bArr) throws IOException {
        if (bArr != null) {
            writeBytes(bArr, 0, bArr.length);
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeBytes(byte[] bArr, int i, int i2) throws IOException {
        for (int i3 = 0; i3 < i2; i3++) {
            writeByte(bArr[i + i3]);
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeShort(int i) throws IOException {
        writeByte(i >> 8);
        writeByte(i);
    }

    /* access modifiers changed from: 0000 */
    public void writeInt(int i) throws IOException {
        writeShort(i >> 16);
        writeShort(i);
    }

    /* access modifiers changed from: 0000 */
    public void writeUTF(String str, int i, int i2) throws IOException {
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            char charAt = str.charAt(i + i4);
            i3 = (charAt < 1 || charAt > 127) ? charAt > 2047 ? i3 + 3 : i3 + 2 : i3 + 1;
        }
        writeByte(i3);
        for (int i5 = 0; i5 < i2; i5++) {
            char charAt2 = str.charAt(i + i5);
            if (charAt2 >= 1 && charAt2 <= 127) {
                writeByte(charAt2);
            } else if (charAt2 > 2047) {
                writeByte(((charAt2 >> 12) & 15) | 224);
                writeByte(((charAt2 >> 6) & 63) | 128);
                writeByte(((charAt2 >> 0) & 63) | 128);
            } else {
                writeByte(((charAt2 >> 6) & 31) | 192);
                writeByte(((charAt2 >> 0) & 63) | 128);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeName(String str) throws IOException {
        writeName(str, true);
    }

    /* access modifiers changed from: 0000 */
    public void writeName(String str, boolean z) throws IOException {
        while (true) {
            int indexOf = str.indexOf(46);
            if (indexOf < 0) {
                indexOf = str.length();
            }
            if (indexOf <= 0) {
                writeByte(0);
                return;
            }
            if (z) {
                Integer num = (Integer) this.names.get(str);
                if (num != null) {
                    int intValue = num.intValue();
                    writeByte((intValue >> 8) | 192);
                    writeByte(intValue & 255);
                    return;
                }
                this.names.put(str, Integer.valueOf(this.off));
            }
            writeUTF(str, 0, indexOf);
            str = str.substring(indexOf);
            if (str.startsWith(".")) {
                str = str.substring(1);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeQuestion(DnsQuestion dnsQuestion) throws IOException {
        writeName(dnsQuestion.name);
        writeShort(dnsQuestion.type);
        writeShort(((!dnsQuestion.unique || !this.multicast) ? 0 : 32768) | dnsQuestion.clazz);
    }

    /* access modifiers changed from: 0000 */
    public void writeRecord(DnsRecord dnsRecord, long j) throws IOException {
        int i = this.off;
        try {
            writeName(dnsRecord.name);
            writeShort(dnsRecord.type);
            writeShort(dnsRecord.clazz | ((!dnsRecord.unique || !this.multicast) ? 0 : 32768));
            writeInt(j == 0 ? dnsRecord.getTtl() : dnsRecord.getRemainingTTL(j));
            writeShort(0);
            int i2 = this.off;
            dnsRecord.write(this);
            int i3 = this.off - i2;
            this.data[i2 - 2] = (byte) (i3 >> 8);
            this.data[i2 - 1] = (byte) (i3 & 255);
        } catch (IOException e) {
            this.off = i;
            throw e;
        }
    }

    /* access modifiers changed from: 0000 */
    public void finish() throws IOException {
        int i = this.off;
        this.off = 0;
        if (this.multicast) {
            writeShort(0);
        } else {
            synchronized (pid) {
                int[] iArr = pid;
                int i2 = iArr[0];
                iArr[0] = i2 + 1;
                writeShort(i2);
            }
        }
        writeShort(this.flags);
        writeShort(this.numQuestions);
        writeShort(this.numAnswers);
        writeShort(this.numAuthorities);
        writeShort(this.numAdditionals);
        this.off = i;
        this.len = i;
    }

    public DatagramPacket createPacket() throws IOException {
        finish();
        return new DatagramPacket(this.data, 0, this.len);
    }

    /* access modifiers changed from: 0000 */
    public boolean isQuery() {
        return (this.flags & 32768) == 0;
    }

    public boolean isEmpty() {
        return this.numQuestions == 0 && this.numAuthorities == 0 && this.numAdditionals == 0 && this.numAnswers == 0;
    }
}
