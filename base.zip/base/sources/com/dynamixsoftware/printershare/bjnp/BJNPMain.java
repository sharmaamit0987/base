package com.dynamixsoftware.printershare.bjnp;

import com.flurry.android.Constants;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;

public class BJNPMain {
    public static final int BJNP_CMD_PRINT = 1;
    public static final int BJNP_CMD_SCAN = 2;
    public static final int BJNP_PORT_3 = 8613;
    public static final int BJNP_PORT_4 = 8614;
    public static final int BJNP_PORT_PRINT = 8611;
    public static final int BJNP_PORT_SCAN = 8612;
    public static final int BJNP_RES_PRINT = 129;
    public static final int BJNP_RES_SCAN = 130;
    public static final int CMD_TCP_CLOSE = 17;
    public static final int CMD_TCP_READ = 32;
    public static final int CMD_TCP_UNKNOWN = 20;
    public static final int CMD_TCP_WRITE = 33;
    public static final int CMD_UDP_DISCOVER = 1;
    public static final int CMD_UDP_GET_ID = 48;
    public static final int CMD_UDP_OPEN = 16;
    private static int packet_id;

    public static synchronized int get_packet_id() {
        int i;
        synchronized (BJNPMain.class) {
            int i2 = packet_id + 1;
            packet_id = i2;
            if (i2 > 65535) {
                packet_id = 1;
            }
            i = packet_id;
        }
        return i;
    }

    public static BJNPCommand sendUDPCommand(BJNPCommand bJNPCommand, InetSocketAddress inetSocketAddress, int i) throws Exception {
        BJNPCommand bJNPCommand2;
        DatagramSocket datagramSocket = new DatagramSocket();
        datagramSocket.setSoTimeout(i);
        bJNPCommand.seq_no = get_packet_id();
        byte[] packet = bJNPCommand.toPacket();
        datagramSocket.send(new DatagramPacket(packet, packet.length, inetSocketAddress.getAddress(), inetSocketAddress.getPort()));
        byte[] bArr = new byte[4096];
        long currentTimeMillis = System.currentTimeMillis();
        while (true) {
            bJNPCommand2 = null;
            if (System.currentTimeMillis() - currentTimeMillis >= ((long) i)) {
                break;
            }
            try {
                DatagramPacket datagramPacket = new DatagramPacket(bArr, 4096);
                datagramPacket.setLength(4096);
                datagramSocket.receive(datagramPacket);
                bJNPCommand2 = BJNPCommand.fromPacket(datagramPacket.getData(), 0);
                if (bJNPCommand2 != null && (bJNPCommand2.dev_type & Constants.UNKNOWN) == (bJNPCommand.dev_type & Constants.UNKNOWN) + 128 && bJNPCommand2.seq_no == bJNPCommand.seq_no) {
                    break;
                }
            } catch (SocketTimeoutException unused) {
            }
        }
        datagramSocket.close();
        return bJNPCommand2;
    }
}
