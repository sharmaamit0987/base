package com.dynamixsoftware.printershare.bjnp;

import com.flurry.android.Constants;
import java.io.IOException;
import java.io.InputStream;

public class BJNPCommand {
    public byte cmd_code;
    public byte[] data;
    public byte dev_type;
    public int dlen = -1;
    public int error_code;
    public int seq_no = 1;
    public int session_id;

    public byte[] toPacket() {
        if (this.dlen == -1) {
            byte[] bArr = this.data;
            this.dlen = bArr != null ? bArr.length : 0;
        }
        int i = this.dlen;
        byte[] bArr2 = new byte[(i + 16)];
        bArr2[0] = 66;
        bArr2[1] = 74;
        bArr2[2] = 78;
        bArr2[3] = 80;
        bArr2[4] = this.dev_type;
        bArr2[5] = this.cmd_code;
        int i2 = this.error_code;
        bArr2[6] = (byte) ((i2 >> 8) & 255);
        bArr2[7] = (byte) (i2 & 255);
        int i3 = this.seq_no;
        bArr2[8] = (byte) ((i3 >> 8) & 255);
        bArr2[9] = (byte) (i3 & 255);
        int i4 = this.session_id;
        bArr2[10] = (byte) ((i4 >> 8) & 255);
        bArr2[11] = (byte) (i4 & 255);
        bArr2[12] = (byte) ((i >> 24) & 255);
        bArr2[13] = (byte) ((i >> 16) & 255);
        bArr2[14] = (byte) ((i >> 8) & 255);
        bArr2[15] = (byte) (i & 255);
        if (i > 0) {
            System.arraycopy(this.data, 0, bArr2, 16, i);
        }
        return bArr2;
    }

    public static BJNPCommand fromPacket(byte[] bArr, int i) {
        if (bArr[i] != 66 || bArr[i + 1] != 74 || bArr[i + 2] != 78 || bArr[i + 3] != 80) {
            return null;
        }
        BJNPCommand bJNPCommand = new BJNPCommand();
        bJNPCommand.dev_type = bArr[i + 4];
        bJNPCommand.cmd_code = bArr[i + 5];
        bJNPCommand.error_code = ((bArr[i + 6] & Constants.UNKNOWN) << 8) + (bArr[i + 7] & Constants.UNKNOWN);
        bJNPCommand.seq_no = ((bArr[i + 8] & Constants.UNKNOWN) << 8) + (bArr[i + 9] & Constants.UNKNOWN);
        bJNPCommand.session_id = ((bArr[i + 10] & Constants.UNKNOWN) << 8) + (bArr[i + 11] & Constants.UNKNOWN);
        int i2 = ((bArr[i + 12] & Constants.UNKNOWN) << 24) + ((bArr[i + 13] & Constants.UNKNOWN) << 16) + ((bArr[i + 14] & Constants.UNKNOWN) << 8) + (bArr[i + 15] & Constants.UNKNOWN);
        bJNPCommand.dlen = i2;
        if (i2 > 0) {
            byte[] bArr2 = new byte[i2];
            bJNPCommand.data = bArr2;
            System.arraycopy(bArr, i + 16, bArr2, 0, i2);
        } else {
            bJNPCommand.data = null;
        }
        return bJNPCommand;
    }

    public static BJNPCommand fromStream(InputStream inputStream) throws IOException {
        if (inputStream.read() != 66 || inputStream.read() != 74 || inputStream.read() != 78 || inputStream.read() != 80) {
            return null;
        }
        byte[] bArr = new byte[16];
        int i = 4;
        while (true) {
            String str = "Unexpected end of stream";
            if (i < 16) {
                int read = inputStream.read(bArr, i, 16 - i);
                if (read != -1) {
                    i += read;
                } else {
                    throw new IOException(str);
                }
            } else {
                BJNPCommand bJNPCommand = new BJNPCommand();
                bJNPCommand.dev_type = bArr[4];
                bJNPCommand.cmd_code = bArr[5];
                bJNPCommand.error_code = ((bArr[6] & Constants.UNKNOWN) << 8) + (bArr[7] & Constants.UNKNOWN);
                bJNPCommand.seq_no = ((bArr[8] & Constants.UNKNOWN) << 8) + (bArr[9] & Constants.UNKNOWN);
                bJNPCommand.session_id = ((bArr[10] & Constants.UNKNOWN) << 8) + (bArr[11] & Constants.UNKNOWN);
                int i2 = ((bArr[12] & Constants.UNKNOWN) << 24) + ((bArr[13] & Constants.UNKNOWN) << 16) + ((bArr[14] & Constants.UNKNOWN) << 8) + (bArr[15] & Constants.UNKNOWN);
                bJNPCommand.dlen = i2;
                if (i2 > 0) {
                    bJNPCommand.data = new byte[i2];
                    int i3 = 0;
                    while (true) {
                        byte[] bArr2 = bJNPCommand.data;
                        if (i3 >= bArr2.length) {
                            break;
                        }
                        int read2 = inputStream.read(bArr2, i3, bArr2.length - i3);
                        if (read2 != -1) {
                            i3 += read2;
                        } else {
                            throw new IOException(str);
                        }
                    }
                } else {
                    bJNPCommand.data = null;
                }
                return bJNPCommand;
            }
        }
    }
}
