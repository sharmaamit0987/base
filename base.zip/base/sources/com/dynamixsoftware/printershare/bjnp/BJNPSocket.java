package com.dynamixsoftware.printershare.bjnp;

import com.dynamixsoftware.printershare.ipp.IppAttribute;
import com.flurry.android.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class BJNPSocket {
    private InputStream bjnp_is = new InputStream() {
        private int len;

        public void close() throws IOException {
        }

        public int read() throws IOException {
            if (this.len == 0) {
                xread();
            }
            int i = -1;
            if (this.len != 0) {
                i = BJNPSocket.this.sis.read();
                if (i > 0) {
                    this.len -= i;
                }
            }
            return i;
        }

        public int read(byte[] bArr) throws IOException {
            return read(bArr, 0, bArr.length);
        }

        public int read(byte[] bArr, int i, int i2) throws IOException {
            if (this.len == 0) {
                xread();
            }
            int i3 = -1;
            if (this.len != 0) {
                InputStream access$000 = BJNPSocket.this.sis;
                int i4 = this.len;
                if (i2 >= i4) {
                    i2 = i4;
                }
                i3 = access$000.read(bArr, i, i2);
                if (i3 > 0) {
                    this.len -= i3;
                }
            }
            return i3;
        }

        private void xread() throws IOException {
            int read;
            BJNPCommand bJNPCommand = new BJNPCommand();
            bJNPCommand.dev_type = 1;
            bJNPCommand.cmd_code = 32;
            bJNPCommand.seq_no = BJNPMain.get_packet_id();
            bJNPCommand.session_id = BJNPSocket.this.session_id;
            BJNPSocket.this.sos.write(bJNPCommand.toPacket());
            BJNPSocket.this.sos.flush();
            byte[] bArr = new byte[16];
            int i = 0;
            while (true) {
                read = BJNPSocket.this.sis.read(bArr, i, 16 - i);
                if (read != -1 && i < 16) {
                    i += read;
                } else if (read != -1 && i >= 16 && bArr[0] == 66 && bArr[1] == 74 && bArr[2] == 78 && bArr[3] == 80) {
                    this.len = ((bArr[12] & Constants.UNKNOWN) << 24) + ((bArr[13] & Constants.UNKNOWN) << 16) + ((bArr[14] & Constants.UNKNOWN) << 8) + (bArr[15] & Constants.UNKNOWN);
                    return;
                } else {
                    return;
                }
            }
            if (read != -1) {
            }
        }
    };
    private OutputStream bjnp_os = new OutputStream() {
        private byte[] buf = new byte[4096];
        private int pos;

        public void write(int i) throws IOException {
            byte[] bArr = this.buf;
            int i2 = this.pos;
            int i3 = i2 + 1;
            this.pos = i3;
            bArr[i2] = (byte) i;
            if (i3 >= bArr.length) {
                flush();
            }
        }

        public void write(byte[] bArr) throws IOException {
            write(bArr, 0, bArr.length);
        }

        public void write(byte[] bArr, int i, int i2) throws IOException {
            while (i2 > 0) {
                int length = this.buf.length - this.pos;
                if (length > i2) {
                    length = i2;
                }
                System.arraycopy(bArr, i, this.buf, this.pos, length);
                i2 -= length;
                i += length;
                int i3 = this.pos + length;
                this.pos = i3;
                if (i3 >= this.buf.length) {
                    flush();
                }
            }
        }

        public void flush() throws IOException {
            if (this.pos != 0) {
                long currentTimeMillis = System.currentTimeMillis();
                int i = 0;
                while (System.currentTimeMillis() - currentTimeMillis < 180000) {
                    BJNPCommand bJNPCommand = new BJNPCommand();
                    bJNPCommand.dev_type = 1;
                    bJNPCommand.cmd_code = IppAttribute.TYPE_INTEGER;
                    bJNPCommand.seq_no = BJNPMain.get_packet_id();
                    bJNPCommand.session_id = BJNPSocket.this.session_id;
                    if (i == 0) {
                        bJNPCommand.dlen = this.pos;
                        bJNPCommand.data = this.buf;
                    } else {
                        bJNPCommand.dlen = this.pos - i;
                        bJNPCommand.data = new byte[bJNPCommand.dlen];
                        System.arraycopy(this.buf, i, bJNPCommand.data, 0, bJNPCommand.dlen);
                    }
                    BJNPSocket.this.sos.write(bJNPCommand.toPacket());
                    BJNPSocket.this.sos.flush();
                    BJNPCommand fromStream = BJNPCommand.fromStream(BJNPSocket.this.sis);
                    if (fromStream == null) {
                        break;
                    } else if (fromStream.error_code == 0) {
                        i += ((fromStream.data[0] & Constants.UNKNOWN) << 24) + ((fromStream.data[1] & Constants.UNKNOWN) << 16) + ((fromStream.data[2] & Constants.UNKNOWN) << 8) + (fromStream.data[3] & Constants.UNKNOWN);
                        if (i == this.pos) {
                            this.pos = 0;
                            return;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException unused) {
                        }
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Protocol error ");
                        sb.append(fromStream.error_code);
                        sb.append(".");
                        throw new IOException(sb.toString());
                    }
                }
                throw new IOException("Network or printer error.");
            }
        }

        public void close() throws IOException {
            flush();
        }
    };
    /* access modifiers changed from: private */
    public int session_id;
    /* access modifiers changed from: private */
    public InputStream sis;
    private Socket socket;
    /* access modifiers changed from: private */
    public OutputStream sos;

    public boolean check(InetSocketAddress inetSocketAddress, int i) throws Exception {
        return connect(inetSocketAddress, i, true);
    }

    public void connect(InetSocketAddress inetSocketAddress, int i) throws Exception {
        if (!connect(inetSocketAddress, i, false)) {
            throw new IOException("Network or printer error.");
        }
    }

    private boolean connect(InetSocketAddress inetSocketAddress, int i, boolean z) throws Exception {
        int i2;
        int i3;
        int i4;
        int i5;
        InetSocketAddress inetSocketAddress2 = inetSocketAddress;
        int i6 = i;
        long currentTimeMillis = System.currentTimeMillis();
        char c = 0;
        int i7 = 0;
        int i8 = 0;
        while (System.currentTimeMillis() - currentTimeMillis < ((long) i6)) {
            BJNPCommand bJNPCommand = new BJNPCommand();
            bJNPCommand.dev_type = 1;
            bJNPCommand.cmd_code = 16;
            String str = SmbConstants.UNI_ENCODING;
            byte[] bytes = "android ".getBytes(str);
            byte[] bytes2 = "android_user".getBytes(str);
            byte[] bytes3 = "android_document".getBytes(str);
            bJNPCommand.data = new byte[392];
            bJNPCommand.data[c] = (byte) ((i7 >> 24) & 255);
            bJNPCommand.data[1] = (byte) ((i7 >> 16) & 255);
            bJNPCommand.data[2] = (byte) ((i7 >> 8) & 255);
            bJNPCommand.data[3] = (byte) (i7 & 255);
            bJNPCommand.data[4] = (byte) ((i8 >> 24) & 255);
            bJNPCommand.data[5] = (byte) ((i8 >> 16) & 255);
            bJNPCommand.data[6] = (byte) ((i8 >> 8) & 255);
            bJNPCommand.data[7] = (byte) (i8 & 255);
            byte[] bArr = bJNPCommand.data;
            if (bytes.length > 64) {
                i3 = 0;
                i2 = 63;
            } else {
                i2 = bytes.length - 1;
                i3 = 0;
            }
            System.arraycopy(bytes, i3, bArr, 9, i2);
            byte[] bArr2 = bJNPCommand.data;
            if (bytes2.length > 64) {
                i5 = 63;
                i4 = 1;
            } else {
                i4 = 1;
                i5 = bytes2.length - 1;
            }
            System.arraycopy(bytes2, i3, bArr2, 73, i5);
            System.arraycopy(bytes3, i3, bJNPCommand.data, 137, bytes3.length > 256 ? 255 : bytes3.length - i4);
            BJNPCommand sendUDPCommand = BJNPMain.sendUDPCommand(bJNPCommand, inetSocketAddress2, 1000);
            if (sendUDPCommand != null) {
                if (sendUDPCommand.error_code == 0 && sendUDPCommand.session_id != 0) {
                    if (!z) {
                        this.session_id = sendUDPCommand.session_id;
                        Socket socket2 = new Socket();
                        this.socket = socket2;
                        socket2.connect(inetSocketAddress2, i6);
                        this.sis = this.socket.getInputStream();
                        this.sos = this.socket.getOutputStream();
                    }
                    return true;
                } else if (sendUDPCommand.error_code != 34050) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Protocol error ");
                    sb.append(sendUDPCommand.error_code);
                    sb.append(".");
                    throw new IOException(sb.toString());
                } else if (z) {
                    return true;
                } else {
                    i7++;
                    i8 = ((sendUDPCommand.data[0] & Constants.UNKNOWN) << 24) + ((sendUDPCommand.data[1] & Constants.UNKNOWN) << 16) + ((sendUDPCommand.data[2] & Constants.UNKNOWN) << 8) + (sendUDPCommand.data[3] & Constants.UNKNOWN);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException unused) {
                    }
                }
            }
            c = 0;
        }
        return false;
    }

    public void setSoTimeout(int i) throws IOException {
        Socket socket2 = this.socket;
        if (socket2 != null) {
            socket2.setSoTimeout(i);
        }
    }

    public void close() throws Exception {
        if (this.socket != null) {
            this.bjnp_os.close();
            BJNPCommand bJNPCommand = new BJNPCommand();
            bJNPCommand.dev_type = 1;
            bJNPCommand.cmd_code = 17;
            bJNPCommand.seq_no = BJNPMain.get_packet_id();
            bJNPCommand.session_id = this.session_id;
            this.sos.write(bJNPCommand.toPacket());
            this.sos.flush();
            this.socket.close();
            this.socket = null;
            this.sis = null;
            this.sos = null;
        }
    }

    public InputStream getInputStream() {
        return this.bjnp_is;
    }

    public OutputStream getOutputStream() {
        return this.bjnp_os;
    }
}
