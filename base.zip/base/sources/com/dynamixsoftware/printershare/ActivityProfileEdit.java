package com.dynamixsoftware.printershare;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.dynamixsoftware.printershare.data.SoapEnvelope;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.data.XmlUtil;
import org.w3c.dom.Element;

public class ActivityProfileEdit extends ActivityCore {

    class EditProfileThread extends Thread {
        EditProfileThread() {
        }

        public void run() {
            ActivityProfileEdit.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityProfileEdit.this.showProgress(ActivityProfileEdit.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityProfileEdit.this.last_error = null;
            try {
                SoapEnvelope soapEnvelope = new SoapEnvelope("UpdateProfile", "Param", "data");
                Element dataRoot = soapEnvelope.getDataRoot();
                XmlUtil.appendElement(dataRoot, "token", ActivityCore.remote_token);
                Element appendElement = XmlUtil.appendElement(dataRoot, "user");
                XmlUtil.appendElement(appendElement, "name", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_name)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "nick", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_nick)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "mail", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_email)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "phone", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_phone)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "address", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_address)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "city", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_city)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "state", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_state)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "zip", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_zip)).getEditableText().toString());
                XmlUtil.appendElement(appendElement, "country", ((EditText) ActivityProfileEdit.this.findViewById(R.id.user_country)).getEditableText().toString());
                Element dataRoot2 = App.psService.doAction(soapEnvelope).getDataRoot();
                if ("true".equals(dataRoot2.getAttribute("success"))) {
                    User user = new User();
                    user.readFromXml(appendElement);
                    ActivityCore.remote_user = user;
                } else {
                    ActivityProfileEdit activityProfileEdit = ActivityProfileEdit.this;
                    StringBuilder sb = new StringBuilder();
                    sb.append("Error: ");
                    sb.append(XmlUtil.getFirstNodeValue(dataRoot2, "message"));
                    activityProfileEdit.last_error = sb.toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityProfileEdit activityProfileEdit2 = ActivityProfileEdit.this;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Internal Error: ");
                sb2.append(e.getMessage());
                activityProfileEdit2.last_error = sb2.toString();
                App.reportThrowable(e);
            }
            if (ActivityProfileEdit.this.last_error == null) {
                ActivityProfileEdit.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityProfileEdit.this.hideProgress();
                        ActivityProfileEdit.this.setResult(-1);
                        ActivityProfileEdit.this.finish();
                        Toast.makeText(ActivityProfileEdit.this.getApplication(), R.string.toast_profile_updated, 1).show();
                    }
                });
            } else {
                ActivityProfileEdit.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityProfileEdit.this.hideProgress();
                        ActivityProfileEdit.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.profile_edit);
        setTitle((int) R.string.header_edit_profile);
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new EditProfileThread().start();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void init() {
        if (remote_user == null) {
            this.skip_update = true;
            Intent intent = new Intent();
            intent.setClass(this, ActivityStart.class);
            startActivityForResult(intent, 1);
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        if (remote_user != null) {
            ((EditText) findViewById(R.id.user_name)).setText(remote_user.name);
            ((EditText) findViewById(R.id.user_nick)).setText(remote_user.nick);
            ((EditText) findViewById(R.id.user_email)).setText(remote_user.email);
            ((EditText) findViewById(R.id.user_phone)).setText(remote_user.phone);
            ((EditText) findViewById(R.id.user_address)).setText(remote_user.address);
            ((EditText) findViewById(R.id.user_city)).setText(remote_user.city);
            ((EditText) findViewById(R.id.user_state)).setText(remote_user.state);
            ((EditText) findViewById(R.id.user_zip)).setText(remote_user.zip);
            ((EditText) findViewById(R.id.user_country)).setText(remote_user.country);
        }
    }
}
