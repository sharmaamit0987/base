package com.dynamixsoftware.printershare;

import android.graphics.Bitmap;

public class PDFrender5 {
    public static native synchronized int create(String str, String str2);

    public static native synchronized int destroy();

    public static native synchronized int drawPage(int i, int[] iArr, float[] fArr, int i2, Bitmap bitmap);

    public static native synchronized int getPageCount();

    public static native synchronized int getPageSize(int i, double[] dArr);
}
