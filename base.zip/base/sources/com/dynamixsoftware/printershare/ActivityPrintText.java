package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Picture;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import com.dynamixsoftware.printershare.ActivityPrint.Page;
import java.util.Vector;

public class ActivityPrintText extends ActivityPrint {
    protected Canvas canvas;
    protected float fontSizeCoef;
    /* access modifiers changed from: private */
    public float[] fontSizeCoefValues;
    private CharSequence[] fontSizeNames;
    protected int mb;
    protected int ml;
    protected int mr;
    protected int mt;
    protected boolean need_new;
    protected int p_height;
    protected int p_width;
    protected Picture page;
    /* access modifiers changed from: private */
    public int selectedFontSize = 1;
    protected int th;

    /* access modifiers changed from: protected */
    public void createPages() {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Resources resources = getResources();
        CharSequence[] charSequenceArr = new CharSequence[3];
        this.fontSizeNames = charSequenceArr;
        charSequenceArr[0] = resources.getString(R.string.label_font_size_small);
        this.fontSizeNames[1] = resources.getString(R.string.label_font_size_normal);
        this.fontSizeNames[2] = resources.getString(R.string.label_font_size_large);
        float[] fArr = new float[3];
        this.fontSizeCoefValues = fArr;
        fArr[0] = 0.5f;
        fArr[1] = 0.7f;
        fArr[2] = 1.0f;
        this.fontSizeCoef = fArr[this.selectedFontSize];
    }

    /* access modifiers changed from: protected */
    public void initPage() {
        this.page = null;
        this.canvas = null;
        boolean z = true;
        this.need_new = true;
        this.th = 0;
        this.p_width = this.paper.width;
        this.p_height = this.paper.height;
        int i = (this.paper.width < this.paper.height ? this.paper.width : this.paper.height) / 15;
        if (this.margins == 0) {
            i = 0;
        } else if (this.margins == 1) {
            i /= 2;
        } else if (this.margins == 3) {
            i = (i * 3) / 2;
        }
        this.ml = this.paper.margin_left > i ? this.paper.margin_left : i;
        this.mr = this.paper.margin_right > i ? this.paper.margin_right : i;
        this.mt = this.paper.margin_top > i ? this.paper.margin_top : i;
        if (this.paper.margin_bottom > i) {
            i = this.paper.margin_bottom;
        }
        this.mb = i;
        boolean z2 = this.orientation == 2;
        if (this.paper.width <= this.paper.height) {
            z = false;
        }
        if (z ^ z2) {
            int i2 = this.p_width;
            this.p_width = this.p_height;
            this.p_height = i2;
            if (this.paper.isLandscape270) {
                if (this.paper.width > this.paper.height) {
                    int i3 = this.ml;
                    this.ml = this.mt;
                    this.mt = this.mr;
                    this.mr = this.mb;
                    this.mb = i3;
                } else {
                    int i4 = this.ml;
                    this.ml = this.mb;
                    this.mb = this.mr;
                    this.mr = this.mt;
                    this.mt = i4;
                }
            } else if (this.paper.width > this.paper.height) {
                int i5 = this.ml;
                this.ml = this.mb;
                this.mb = this.mr;
                this.mr = this.mt;
                this.mt = i5;
            } else {
                int i6 = this.ml;
                this.ml = this.mt;
                this.mt = this.mr;
                this.mr = this.mb;
                this.mb = i6;
            }
        }
        while (true) {
            if (this.p_width < 500 || this.p_height < 500) {
                this.p_width *= 2;
                this.p_height *= 2;
                this.ml *= 2;
                this.mr *= 2;
                this.mt *= 2;
                this.mb *= 2;
            } else {
                this.pages = new Vector();
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void newPage() {
        if (this.need_new) {
            this.need_new = false;
            Picture picture = this.page;
            if (picture != null) {
                picture.endRecording();
                this.pages.add(new Page(this.page));
            }
            Picture picture2 = new Picture();
            this.page = picture2;
            Canvas beginRecording = picture2.beginRecording(this.p_width, this.p_height);
            this.canvas = beginRecording;
            beginRecording.drawColor(-1);
            this.canvas.translate((float) this.ml, (float) this.mt);
            this.th = 0;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x001f  */
    public boolean checkPermission(final String str) {
        boolean z;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                z = true;
                if (z) {
                    final boolean[] zArr = new boolean[1];
                    new Object() {
                        {
                            if (ActivityPrintText.this.checkSelfPermission(str) != 0) {
                                ActivityPrintText.this.requestPermissions(new String[]{str}, 444555);
                                zArr[0] = true;
                            }
                        }
                    };
                    if (zArr[0]) {
                        return false;
                    }
                }
                return true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        z = false;
        if (z) {
        }
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.need_update_pages = true;
        update();
    }

    /* access modifiers changed from: protected */
    public void addPage() {
        Picture picture = this.page;
        if (picture != null) {
            picture.endRecording();
            this.pages.add(new Page(this.page));
        }
    }

    /* access modifiers changed from: protected */
    public void printRect(int i, int i2, int i3, int i4, int i5) {
        Paint newPaint = App.newPaint();
        newPaint.setStyle(Style.FILL);
        newPaint.setColor(i);
        this.canvas.drawRect(new Rect(i2, i3, i4, i5), newPaint);
    }

    /* access modifiers changed from: protected */
    public int testTextSize(String str, int i, boolean z, float f, int i2) {
        int i3 = i;
        String replace = str.replace("\r\n", "\n").replace("\t", " ");
        Paint newPaint = App.newPaint();
        newPaint.setStyle(Style.FILL);
        newPaint.setColor(-16777216);
        newPaint.setTypeface(z ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        newPaint.setTextSize(((float) i3) * this.fontSizeCoef);
        int length = replace.length();
        float[] fArr = new float[length];
        int i4 = 0;
        newPaint.getTextWidths(replace, 0, replace.length(), fArr);
        float f2 = this.fontSizeCoef;
        float f3 = f * f2;
        float f4 = f2 * f;
        int i5 = 0;
        int i6 = 0;
        while (i4 < length) {
            f3 += fArr[i4];
            char charAt = replace.charAt(i4);
            if (charAt == ' ' || charAt == 10 || i4 == length - 1) {
                float width = (float) (this.page.getWidth() - (this.ml + this.mr));
                float f5 = (float) i2;
                float f6 = this.fontSizeCoef;
                float f7 = (width - (f5 * f6)) - (i6 == 0 ? f6 * f : 0.0f);
                if (f3 < f7) {
                    int i7 = i4 + 1;
                    if (charAt == 10 || i4 == length - 1) {
                        i5 += i3;
                        i6 = i7;
                        f4 = 0.0f;
                        f3 = 0.0f;
                    } else {
                        i6 = i7;
                        f4 = f3;
                    }
                } else {
                    f3 = 0.0f;
                    if (f4 == 0.0f) {
                        float f8 = 0.0f;
                        do {
                            f8 += fArr[i6];
                            i6++;
                            if (i6 >= length) {
                                break;
                            }
                        } while (f8 < f7);
                        if (i6 < length - 1) {
                            i6--;
                            f8 -= fArr[i6];
                        }
                        i5 += i3;
                        i4 = i6 - 1;
                        i6 = i4;
                        f3 = f8;
                    } else {
                        i5 += i3;
                        i4 = i6 - 1;
                        f4 = 0.0f;
                    }
                }
            } else {
                int i8 = i2;
            }
            i4++;
        }
        return i5;
    }

    /* access modifiers changed from: protected */
    public void printText(String str, int i, boolean z, float f, int i2, int i3, int i4, Paint paint) {
        int i5;
        int i6 = i;
        int i7 = i3;
        int i8 = i4;
        Paint paint2 = paint;
        String replace = str.replace("\r\n", "\n").replace("\t", " ");
        paint2.setTypeface(z ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        paint2.setTextSize(((float) i6) * this.fontSizeCoef);
        int length = replace.length();
        float[] fArr = new float[length];
        paint2.getTextWidths(replace, 0, replace.length(), fArr);
        float f2 = this.fontSizeCoef;
        float f3 = f * f2;
        float f4 = f2 * f;
        if (needNew(0, i6)) {
            newPage();
        }
        float f5 = f4;
        int i9 = 0;
        int i10 = 0;
        int i11 = 0;
        while (i5 < length) {
            float f6 = f3 + fArr[i5];
            char charAt = replace.charAt(i5);
            if (charAt == ' ' || charAt == 10 || i5 == length - 1) {
                float width = (float) (this.page.getWidth() - (this.ml + this.mr));
                float f7 = (float) i2;
                float f8 = this.fontSizeCoef;
                float f9 = (width - (f7 * f8)) - (i9 == 0 ? f8 * f : 0.0f);
                if (f6 < f9) {
                    Canvas canvas2 = this.canvas;
                    int i12 = i5 + (charAt == 10 ? 0 : 1);
                    float f10 = this.fontSizeCoef;
                    char c = charAt;
                    int i13 = i10;
                    int i14 = i5;
                    canvas2.drawText(replace, i9, i12, (f7 * f10) + f5, ((float) i7) * f10, paint);
                    i9 = i14 + 1;
                    if (c == 10 || i14 == length - 1) {
                        translate(i6);
                        i10 = i13 + i6;
                        i5 = i14;
                        f3 = 0.0f;
                    } else {
                        i5 = i14;
                        f3 = f6;
                        f5 = f3;
                        i10 = i13;
                    }
                } else {
                    int i15 = i10;
                    f3 = 0.0f;
                    if (f5 == 0.0f) {
                        int i16 = i9;
                        do {
                            f3 += fArr[i16];
                            i16++;
                            if (i16 >= length) {
                                break;
                            }
                        } while (f3 < f9);
                        if (i16 < length - 1) {
                            i16--;
                            f3 -= fArr[i16];
                        }
                        float f11 = f3;
                        int i17 = i16;
                        Canvas canvas3 = this.canvas;
                        float f12 = this.fontSizeCoef;
                        canvas3.drawText(replace, i9, i17, (f7 * f12) + f5, ((float) i7) * f12, paint);
                        translate(i6);
                        i10 = i15 + i6;
                        i9 = i17 - 1;
                        i5 = i9;
                        f3 = f11;
                    } else {
                        translate(i6);
                        i10 = i15 + i6;
                        i5 = i9 - 1;
                    }
                }
                f5 = 0.0f;
            } else {
                f3 = f6;
            }
            i11 = i5 + 1;
            Paint paint3 = paint;
        }
        int i18 = i10;
        if (i18 <= i8) {
            float f13 = (float) (i8 - i18);
            this.canvas.translate(0.0f, this.fontSizeCoef * f13);
            this.th = (int) (((float) this.th) + (f13 * this.fontSizeCoef) + 1.0f);
            return;
        }
        this.canvas.translate(0.0f, this.fontSizeCoef * 10.0f);
        this.th = (int) (((float) this.th) + (this.fontSizeCoef * 10.0f) + 1.0f);
    }

    /* access modifiers changed from: protected */
    public boolean needNew(int i, int i2) {
        if (this.th > 0) {
            float f = (float) i;
            this.canvas.translate(0.0f, this.fontSizeCoef * f);
            this.th = (int) (((float) this.th) + (f * this.fontSizeCoef));
        }
        if (((float) this.th) + (((float) i2) * this.fontSizeCoef) <= ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
            return false;
        }
        this.need_new = true;
        return true;
    }

    /* access modifiers changed from: protected */
    public void translate(int i) {
        float f = (float) i;
        if (((float) this.th) + (this.fontSizeCoef * f) > ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
            this.need_new = true;
            newPage();
            return;
        }
        this.canvas.translate(0.0f, this.fontSizeCoef * f);
        this.th = (int) (((float) this.th) + (f * this.fontSizeCoef));
    }

    public void onCreateOptionsMenu(ContextMenu contextMenu) {
        contextMenu.add(0, 40, 0, R.string.label_font_size);
        super.onCreateOptionsMenu(contextMenu);
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (menuItem.getItemId() != 40) {
            return super.onMenuItemSelected(i, menuItem);
        }
        new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_font_size).setPositiveButton(R.string.button_ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityPrintText activityPrintText = ActivityPrintText.this;
                activityPrintText.fontSizeCoef = activityPrintText.fontSizeCoefValues[ActivityPrintText.this.selectedFontSize];
                ActivityPrintText.this.need_update_pages = true;
                ActivityPrintText.this.update();
            }
        }).setNegativeButton(R.string.button_cancel, null).setSingleChoiceItems(this.fontSizeNames, this.selectedFontSize, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityPrintText.this.selectedFontSize = i;
            }
        }).show();
        return true;
    }
}
