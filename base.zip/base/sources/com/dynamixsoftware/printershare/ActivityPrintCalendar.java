package com.dynamixsoftware.printershare;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Instances;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import android.text.format.Time;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.TreeMap;

public class ActivityPrintCalendar extends ActivityPrintText {
    private static final int TYPE_DAY = 0;
    private static final int TYPE_MEETING = 1;

    static abstract class Impl {
        /* access modifiers changed from: 0000 */
        public abstract Cursor createCursor(Context context, long j, long j2);

        /* access modifiers changed from: 0000 */
        public abstract int getColor(Context context, Cursor cursor);

        Impl() {
        }

        static Impl getImpl() {
            if (Integer.parseInt(VERSION.SDK) < 14) {
                return new ImplOld();
            }
            return new ImplNew();
        }
    }

    private static class ImplNew extends Impl {
        private ImplNew() {
        }

        /* access modifiers changed from: 0000 */
        public Cursor createCursor(Context context, long j, long j2) {
            long j3 = j;
            long j4 = j2;
            int offset = TimeZone.getDefault().getOffset(j4) / 1000;
            int julianDay = Time.getJulianDay(j3, (long) (TimeZone.getDefault().getOffset(j3) / 1000));
            int julianDay2 = Time.getJulianDay(j4, (long) offset);
            ContentResolver contentResolver = context.getContentResolver();
            Uri uri = Instances.CONTENT_BY_DAY_URI;
            StringBuilder sb = new StringBuilder();
            String str = "//";
            sb.append(str);
            sb.append(julianDay);
            sb.append(str);
            sb.append(julianDay2);
            return contentResolver.query(Uri.withAppendedPath(uri, sb.toString()), new String[]{"title", "eventLocation", "allDay", "hasAlarm", "eventColor", "rrule", "begin", "end", "event_id", "startDay", "endDay", "selfAttendeeStatus", "description", "eventColor", "calendar_id"}, "selfAttendeeStatus!=2", null, "startDay ASC, begin ASC, title ASC");
        }

        /* access modifiers changed from: 0000 */
        public int getColor(Context context, Cursor cursor) {
            int i;
            if (!cursor.isNull(13)) {
                i = cursor.getInt(13);
            } else {
                ContentResolver contentResolver = context.getContentResolver();
                Uri uri = Calendars.CONTENT_URI;
                String[] strArr = {"calendar_color"};
                StringBuilder sb = new StringBuilder();
                sb.append("_id= ");
                sb.append(cursor.getInt(14));
                Cursor query = contentResolver.query(uri, strArr, sb.toString(), null, null);
                if (query == null || !query.moveToFirst()) {
                    return -16777216;
                }
                i = query.getInt(0);
            }
            return i | -16777216;
        }
    }

    private static class ImplOld extends Impl {
        private ImplOld() {
        }

        /* access modifiers changed from: 0000 */
        public Cursor createCursor(Context context, long j, long j2) {
            long j3 = j;
            long j4 = j2;
            StringBuilder sb = new StringBuilder();
            sb.append("content://com.android.calendar/instances/when/");
            sb.append(j3);
            String str = "/";
            sb.append(str);
            sb.append(j4);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("content://calendar/instances/when/");
            sb2.append(j3);
            sb2.append(str);
            sb2.append(j4);
            Uri[] uriArr = {Uri.parse(sb.toString()), Uri.parse(sb2.toString())};
            Cursor cursor = null;
            for (int i = 0; i < 2; i++) {
                cursor = context.getContentResolver().query(uriArr[i], new String[]{"title", "eventLocation", "allDay", "hasAlarm", "color", "rrule", "begin", "end", "event_id", "startDay", "endDay", "selfAttendeeStatus", "description"}, "selected=1 AND selfAttendeeStatus!=2", null, "startDay ASC, begin ASC, title ASC");
                if (cursor != null) {
                    break;
                }
            }
            return cursor;
        }

        /* access modifiers changed from: 0000 */
        public int getColor(Context context, Cursor cursor) {
            return cursor.getInt(4) | -16777216;
        }
    }

    private static class RowInfo {
        final int mData;
        final int mType;

        RowInfo(int i, int i2) {
            this.mType = i;
            this.mData = i2;
        }
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        Paint paint;
        int i;
        int i2;
        String str;
        if (checkPermission("android.permission.READ_CALENDAR")) {
            initPage();
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                long j = extras.getLong("start");
                long j2 = extras.getLong("end");
                int offset = TimeZone.getDefault().getOffset(j2) / 1000;
                int julianDay = Time.getJulianDay(j, (long) (TimeZone.getDefault().getOffset(j) / 1000));
                int julianDay2 = Time.getJulianDay(j2, (long) offset);
                Cursor createCursor = Impl.getImpl().createCursor(this, j, j2);
                ArrayList calculateDays = createCursor != null ? calculateDays(createCursor, julianDay, julianDay2) : new ArrayList();
                int i3 = -1;
                int i4 = -1;
                while (i4 < calculateDays.size()) {
                    newPage();
                    if (i4 != i3) {
                        RowInfo rowInfo = (RowInfo) calculateDays.get(i4);
                        if (rowInfo.mType == 0) {
                            Time time = new Time();
                            time.set(new Date().getTime());
                            long julianDay3 = time.setJulianDay(rowInfo.mData);
                            if (rowInfo.mData == Time.getJulianDay(System.currentTimeMillis(), time.gmtoff)) {
                                StringBuilder sb = new StringBuilder();
                                sb.append("Today, ");
                                sb.append(DateUtils.formatDateTime(this, julianDay3, 20));
                                str = sb.toString();
                            } else {
                                str = DateUtils.formatDateTime(this, julianDay3, 22);
                            }
                            String str2 = str;
                            Paint newPaint = App.newPaint();
                            newPaint.setStyle(Style.FILL);
                            newPaint.setColor(-16777216);
                            int testTextSize = testTextSize(str2, 70, true, 0.0f, 20);
                            if (needNew(10, testTextSize + 65)) {
                                i4--;
                            } else {
                                int i5 = (int) (((float) (testTextSize + 20)) * this.fontSizeCoef);
                                printRect(-2565928, 0, 0, this.page.getWidth() - (this.ml + this.mr), i5);
                                printText(str2, 70, true, 0.0f, 20, 70, 90, newPaint);
                            }
                        } else {
                            createCursor.moveToPosition(rowInfo.mData);
                            String string = createCursor.getString(0);
                            String string2 = createCursor.getString(12);
                            long j3 = createCursor.getLong(6);
                            long j4 = createCursor.getLong(7);
                            int i6 = createCursor.getInt(2) != 0 ? 8192 : 1;
                            if (DateFormat.is24HourFormat(this)) {
                                i6 |= 128;
                            }
                            String formatDateRange = DateUtils.formatDateRange(this, j3, j4, i6);
                            String string3 = createCursor.getString(1);
                            int color = Impl.getImpl().getColor(this, createCursor);
                            Paint newPaint2 = App.newPaint();
                            newPaint2.setStyle(Style.FILL);
                            newPaint2.setColor(color);
                            int i7 = this.th;
                            float f = this.fontSizeCoef;
                            String str3 = "";
                            int i8 = i7;
                            Paint paint2 = newPaint2;
                            int i9 = color;
                            if (((float) this.th) + (((float) testTextSize(string != null ? string : str3, 45, true, 0.0f, 30)) * this.fontSizeCoef) > ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
                                if (!needNew(0, 45)) {
                                    float f2 = this.fontSizeCoef;
                                    if ((string2 == null || string2.length() <= 0) && ((formatDateRange == null || formatDateRange.length() <= 0) && string3 != null)) {
                                        int length = string3.length();
                                    }
                                    printRect(-16777216, 0, 0, (int) (this.fontSizeCoef * 8.0f), (this.page.getHeight() - (this.mt + this.mb)) - this.th);
                                }
                                i8 = 0;
                            }
                            int i10 = 0;
                            printText(string != null ? string : str3, 45, true, 0.0f, 30, 45, 55, paint2);
                            printRect(-16777216, 0, (int) (((float) (-(this.th - i8))) + (this.fontSizeCoef * 10.0f)), (int) (this.fontSizeCoef * 8.0f), ((string2 == null || string2.length() <= 0) && (formatDateRange == null || formatDateRange.length() <= 0) && (string3 == null || string3.length() <= 0)) ? (int) (this.fontSizeCoef * -5.0f) : 0);
                            int i11 = this.th;
                            Paint paint3 = paint2;
                            paint3.setColor(-16777216);
                            if (string2 == null || string2.length() <= 0) {
                                paint = paint3;
                            } else {
                                if (((float) this.th) + (((float) testTextSize(string2, 25, true, 0.0f, 30)) * this.fontSizeCoef) > ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
                                    if (!needNew(0, 25)) {
                                        float f3 = this.fontSizeCoef;
                                        if ((formatDateRange == null || formatDateRange.length() <= 0) && string3 != null) {
                                            int length2 = string3.length();
                                        }
                                        printRect(-16777216, 0, 0, (int) (this.fontSizeCoef * 8.0f), (this.page.getHeight() - (this.mt + this.mb)) - this.th);
                                    }
                                    i2 = 0;
                                } else {
                                    i2 = i11;
                                }
                                String str4 = string2;
                                paint = paint3;
                                printText(str4, 25, true, 0.0f, 30, 25, 35, paint3);
                                printRect(-16777216, 0, (-(this.th - i2)) - 1, (int) (this.fontSizeCoef * 8.0f), ((formatDateRange == null || formatDateRange.length() <= 0) && (string3 == null || string3.length() <= 0)) ? (int) (this.fontSizeCoef * -5.0f) : 0);
                            }
                            int i12 = this.th;
                            if (formatDateRange != null && formatDateRange.length() > 0) {
                                if (((float) this.th) + (((float) testTextSize(formatDateRange, 35, true, 0.0f, 30)) * this.fontSizeCoef) > ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
                                    if (!needNew(0, 35)) {
                                        float f4 = this.fontSizeCoef;
                                        if ((formatDateRange == null || formatDateRange.length() <= 0) && string3 != null) {
                                            int length3 = string3.length();
                                        }
                                        printRect(-16777216, 0, 0, (int) (this.fontSizeCoef * 8.0f), (this.page.getHeight() - (this.mt + this.mb)) - this.th);
                                    }
                                    i = 0;
                                } else {
                                    i = i12;
                                }
                                printText(formatDateRange, 35, true, 0.0f, 30, 35, 45, paint);
                                printRect(-16777216, 0, (-(this.th - i)) - 1, (int) (this.fontSizeCoef * 8.0f), (string3 == null || string3.length() <= 0) ? (int) (this.fontSizeCoef * -5.0f) : 0);
                            }
                            int i13 = this.th;
                            if (string3 != null && string3.length() > 0) {
                                if (((float) this.th) + (((float) testTextSize(string3, 30, false, 0.0f, 30)) * this.fontSizeCoef) <= ((float) ((this.page.getHeight() - (this.mt + this.mb)) - 10))) {
                                    i10 = i13;
                                } else if (!needNew(0, 30)) {
                                    float f5 = this.fontSizeCoef;
                                    if ((formatDateRange == null || formatDateRange.length() <= 0) && string3 != null) {
                                        int length4 = string3.length();
                                    }
                                    printRect(-16777216, 0, 0, (int) (this.fontSizeCoef * 8.0f), (this.page.getHeight() - (this.mt + this.mb)) - this.th);
                                }
                                printText(string3, 30, false, 0.0f, 30, 30, 40, paint);
                                printRect(-16777216, 0, (-(this.th - i10)) - 1, (int) (this.fontSizeCoef * 8.0f), (int) (this.fontSizeCoef * -5.0f));
                            }
                            Paint newPaint3 = App.newPaint();
                            newPaint3.setStyle(Style.FILL);
                            newPaint3.setColor(i9);
                        }
                    }
                    i4++;
                    i3 = -1;
                }
                addPage();
                if (createCursor != null) {
                    createCursor.close();
                }
                if (calculateDays.size() == 0) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(ActivityPrintCalendar.this, R.string.toast_empty_agenda, 1).show();
                        }
                    });
                }
            }
        }
    }

    private ArrayList<RowInfo> calculateDays(Cursor cursor, int i, int i2) {
        TreeMap treeMap = new TreeMap();
        int i3 = 0;
        while (cursor.moveToNext()) {
            int i4 = cursor.getInt(9);
            int i5 = cursor.getInt(10);
            int max = Math.max(i4, i);
            while (max <= i5 && max <= i2) {
                LinkedList linkedList = (LinkedList) treeMap.get(Integer.valueOf(max));
                if (linkedList == null) {
                    linkedList = new LinkedList();
                    treeMap.put(Integer.valueOf(max), linkedList);
                }
                linkedList.add(Integer.valueOf(i3));
                max++;
            }
            i3++;
        }
        ArrayList<RowInfo> arrayList = new ArrayList<>();
        for (Entry entry : treeMap.entrySet()) {
            arrayList.add(new RowInfo(0, ((Integer) entry.getKey()).intValue()));
            Iterator it = ((LinkedList) entry.getValue()).iterator();
            while (it.hasNext()) {
                arrayList.add(new RowInfo(1, ((Integer) it.next()).intValue()));
            }
        }
        return arrayList;
    }
}
