package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActivityProfile extends ActivityCore {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.profile);
        setTitle((int) R.string.header_profile);
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.button_edit);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityProfile.this, ActivityProfileEdit.class);
                ActivityProfile.this.startActivity(intent);
            }
        });
    }

    /* access modifiers changed from: protected */
    public void init() {
        if (remote_user == null) {
            this.skip_update = true;
            Intent intent = new Intent();
            intent.setClass(this, ActivityStart.class);
            startActivityForResult(intent, 1);
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        if (remote_user != null) {
            ((TextView) findViewById(R.id.user_login)).setText(remote_user.login);
            ((TextView) findViewById(R.id.user_name)).setText(remote_user.name);
            ((TextView) findViewById(R.id.user_nick)).setText(remote_user.nick);
            ((TextView) findViewById(R.id.user_email)).setText(remote_user.email);
            ((TextView) findViewById(R.id.user_phone)).setText(remote_user.phone);
            ((TextView) findViewById(R.id.user_address)).setText(remote_user.address);
            TextView textView = (TextView) findViewById(R.id.user_city_state_zip);
            StringBuilder sb = new StringBuilder();
            sb.append(remote_user.city);
            String str = " ";
            sb.append(str);
            sb.append(remote_user.state);
            sb.append(str);
            sb.append(remote_user.zip);
            textView.setText(sb.toString());
            ((TextView) findViewById(R.id.user_country)).setText(remote_user.country);
        }
    }
}
