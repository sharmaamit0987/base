package com.dynamixsoftware.printershare.ijs;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;

public class IjsDriver {
    private static final int IJS_CMD_ACK = 0;
    private static final int IJS_CMD_BEGIN_JOB = 6;
    private static final int IJS_CMD_BEGIN_PAGE = 14;
    private static final int IJS_CMD_CANCEL_JOB = 8;
    private static final int IJS_CMD_CLOSE = 5;
    private static final int IJS_CMD_END_JOB = 7;
    private static final int IJS_CMD_END_PAGE = 16;
    private static final int IJS_CMD_EXIT = 17;
    private static final int IJS_CMD_GET_PARAM = 13;
    private static final int IJS_CMD_OPEN = 4;
    private static final int IJS_CMD_PING = 2;
    private static final int IJS_CMD_PONG = 3;
    private static final int IJS_CMD_SEND_DATA_BLOCK = 15;
    private static final int IJS_CMD_SET_PARAM = 12;
    private Process proc;
    public InputStream proc_es = this.proc.getErrorStream();
    private DataInputStream proc_is = new DataInputStream(this.proc.getInputStream());
    private DataOutputStream proc_os = new DataOutputStream(this.proc.getOutputStream());

    public IjsDriver(File file, String[] strArr) throws Exception {
        this.proc = Runtime.getRuntime().exec(file.getAbsolutePath(), strArr, file.getParentFile());
    }

    public boolean connect() throws Exception {
        this.proc_os.writeBytes("IJS\nüv1\n");
        this.proc_os.flush();
        if ("IJS".equals(this.proc_is.readLine()) && this.proc_is.read() == 171) {
            if ("v1".equals(this.proc_is.readLine())) {
                sendCmdInt(2, 30);
                int[] readCmdInt = readCmdInt();
                if (readCmdInt[0] == 3 && readCmdInt[1] >= 30) {
                    return true;
                }
            }
        }
        terminate();
        return false;
    }

    public void terminate() throws Exception {
        Process process = this.proc;
        if (process != null) {
            process.destroy();
            this.proc = null;
        }
    }

    public int disconnect() throws Exception {
        sendCmd(17);
        return this.proc.waitFor();
    }

    public boolean open() throws Exception {
        sendCmd(4);
        return readCmd() == 0;
    }

    public boolean close() throws Exception {
        sendCmd(5);
        return readCmd() == 0;
    }

    public boolean beginJob(int i) throws Exception {
        sendCmdInt(6, i);
        return readCmd() == 0;
    }

    public boolean cancelJob(int i) throws Exception {
        sendCmdInt(8, i);
        return readCmd() == 0;
    }

    public boolean endJob(int i) throws Exception {
        sendCmdInt(7, i);
        return readCmd() == 0;
    }

    public boolean setParam(int i, String str, String str2) throws Exception {
        sendCmdIntStrStr(12, i, str, str2);
        return readCmd() == 0;
    }

    public String getParam(int i, String str) throws Exception {
        sendCmdIntStr(13, i, str);
        return readCmdStr();
    }

    public boolean beginPage() throws Exception {
        sendCmd(14);
        return readCmd() == 0;
    }

    public boolean sendDataBlock(int i, byte[] bArr, int i2, int i3) throws Exception {
        sendCmdIntInt(15, i, i3);
        this.proc_os.write(bArr, i2, i3);
        this.proc_os.flush();
        return readCmd() == 0;
    }

    public boolean endPage() throws Exception {
        sendCmd(16);
        return readCmd() == 0;
    }

    private void sendCmd(int i) throws Exception {
        this.proc_os.writeInt(i);
        this.proc_os.writeInt(8);
        this.proc_os.flush();
    }

    private void sendCmdInt(int i, int i2) throws Exception {
        this.proc_os.writeInt(i);
        this.proc_os.writeInt(12);
        this.proc_os.writeInt(i2);
        this.proc_os.flush();
    }

    private void sendCmdIntInt(int i, int i2, int i3) throws Exception {
        this.proc_os.writeInt(i);
        this.proc_os.writeInt(16);
        this.proc_os.writeInt(i2);
        this.proc_os.writeInt(i3);
        this.proc_os.flush();
    }

    private void sendCmdIntStr(int i, int i2, String str) throws Exception {
        this.proc_os.writeInt(i);
        this.proc_os.writeInt(str.length() + 12 + 1);
        this.proc_os.writeInt(i2);
        this.proc_os.writeBytes(str);
        this.proc_os.write(0);
        this.proc_os.flush();
    }

    private void sendCmdIntStrStr(int i, int i2, String str, String str2) throws Exception {
        this.proc_os.writeInt(i);
        this.proc_os.writeInt(str.length() + 16 + str2.length() + 1);
        this.proc_os.writeInt(i2);
        this.proc_os.writeInt(str.length() + str2.length() + 1);
        this.proc_os.writeBytes(str);
        this.proc_os.write(0);
        this.proc_os.writeBytes(str2);
        this.proc_os.flush();
    }

    private int readCmd() throws Exception {
        int readInt = this.proc_is.readInt();
        int readInt2 = this.proc_is.readInt() - 8;
        if (readInt2 > 0) {
            this.proc_is.readFully(new byte[readInt2]);
        }
        return readInt;
    }

    private int[] readCmdInt() throws Exception {
        int readInt = this.proc_is.readInt();
        int readInt2 = this.proc_is.readInt() - 12;
        int readInt3 = this.proc_is.readInt();
        if (readInt2 > 0) {
            this.proc_is.readFully(new byte[readInt2]);
        }
        return new int[]{readInt, readInt3};
    }

    private String readCmdStr() throws Exception {
        int readInt = this.proc_is.readInt();
        int readInt2 = this.proc_is.readInt() - 8;
        byte[] bArr = new byte[readInt2];
        if (readInt2 > 0) {
            this.proc_is.readFully(bArr);
        }
        if (readInt == 0) {
            return new String(bArr);
        }
        return null;
    }
}
