package com.dynamixsoftware.printershare.cups;

import com.dynamixsoftware.printershare.App;
import com.dynamixsoftware.printershare.bjnp.BJNPMain;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.zip.GZIPInputStream;

public class RasterFile {
    public static final int[][] cluster_template_3x = {new int[]{6, 3, 7}, new int[]{2, 0, 4}, new int[]{5, 1, 8}};
    public static final int[][] cluster_template_4x = {new int[]{12, 5, 6, 13}, new int[]{4, 0, 1, 7}, new int[]{11, 3, 2, 8}, new int[]{15, 10, 9, 14}};
    public static final int[][] cluster_template_8x = {new int[]{60, 53, 42, 27, 28, 43, 54, 61}, new int[]{52, 41, 26, 14, 15, 29, 44, 55}, new int[]{40, 25, 13, 5, 6, 16, 30, 45}, new int[]{24, 12, 4, 0, 1, 7, 17, 31}, new int[]{39, 23, 11, 3, 2, 8, 18, 32}, new int[]{51, 38, 22, 10, 9, 19, 33, 46}, new int[]{59, 50, 37, 21, 20, 34, 47, 56}, new int[]{63, 58, 49, 36, 35, 48, 57, 62}};
    private int AdvanceDistance;
    private int AdvanceMedia;
    private int Collate;
    private int CutMedia;
    private int Duplex;
    private int[] HWResolution = new int[2];
    private int[] ImagingBBox;
    private int InsertSheet;
    private int Jog;
    private int LeadingEdge;
    private int ManualFeed;
    private int[] Margins;
    private String MediaClass;
    private String MediaColor;
    private int MediaPosition;
    private String MediaType;
    private int MediaWeight;
    private int MirrorPrint;
    private int NegativePrint;
    private int NumCopies;
    private int Orientation;
    private int OutputFaceUp;
    private String OutputType;
    private int[] PageSize;
    private int Separations;
    private int TraySwitch;
    private int Tumble;
    private byte[] buf;
    private int cupsBitsPerColor;
    private int cupsBitsPerPixel;
    private float cupsBorderlessScalingFactor;
    private int cupsBytesPerLine;
    private int cupsColorOrder;
    private int cupsColorSpace;
    private int cupsCompression;
    private int cupsHeight;
    private float[] cupsImagingBBox;
    private int cupsInteger0;
    private int cupsInteger1;
    private int cupsInteger10;
    private int cupsInteger11;
    private int cupsInteger12;
    private int cupsInteger13;
    private int cupsInteger14;
    private int cupsInteger15;
    private int cupsInteger2;
    private int cupsInteger3;
    private int cupsInteger4;
    private int cupsInteger5;
    private int cupsInteger6;
    private int cupsInteger7;
    private int cupsInteger8;
    private int cupsInteger9;
    private String cupsMarkerType;
    private int cupsMediaType;
    private int cupsNumColors;
    private float[] cupsPageSize;
    private String cupsPageSizeName;
    private float cupsReal0;
    private float cupsReal1;
    private float cupsReal10;
    private float cupsReal11;
    private float cupsReal12;
    private float cupsReal13;
    private float cupsReal14;
    private float cupsReal15;
    private float cupsReal2;
    private float cupsReal3;
    private float cupsReal4;
    private float cupsReal5;
    private float cupsReal6;
    private float cupsReal7;
    private float cupsReal8;
    private float cupsReal9;
    private String cupsRenderingIntent;
    private int cupsRowCount;
    private int cupsRowFeed;
    private int cupsRowStep;
    private String cupsString0;
    private String cupsString1;
    private String cupsString10;
    private String cupsString11;
    private String cupsString12;
    private String cupsString13;
    private String cupsString14;
    private String cupsString15;
    private String cupsString2;
    private String cupsString3;
    private String cupsString4;
    private String cupsString5;
    private String cupsString6;
    private String cupsString7;
    private String cupsString8;
    private String cupsString9;
    private int cupsWidth;
    private int[][] dm;
    private int dmz;
    private byte[] zbuf;

    public RasterFile(File file, String str) throws IOException {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        String str2;
        String str3;
        String str4;
        File file2 = file;
        String str5 = str;
        Class<int> cls = int.class;
        int i6 = 2;
        int i7 = 4;
        this.ImagingBBox = new int[4];
        this.Margins = new int[2];
        this.PageSize = new int[2];
        this.cupsPageSize = new float[2];
        this.cupsImagingBBox = new float[4];
        int indexOf = str5.indexOf("PageSize=");
        String str6 = " ";
        int indexOf2 = str5.indexOf(str6, indexOf + 1);
        if (indexOf >= 0) {
            int i8 = indexOf + 9;
            if (indexOf2 < 0) {
                indexOf2 = str.length();
            }
            String substring = str5.substring(i8, indexOf2);
            StringBuilder sb = new StringBuilder();
            sb.append(str5);
            sb.append(" PageRegion=");
            sb.append(substring);
            sb.append(" ImageableArea=");
            sb.append(substring);
            sb.append(" PaperDimension=");
            sb.append(substring);
            str5 = sb.toString();
        }
        String str7 = str5;
        int i9 = 0;
        int i10 = 0;
        while (true) {
            int i11 = 8;
            int i12 = 1;
            if (i10 >= i6) {
                break;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file.getName().endsWith(".gz") ? new GZIPInputStream(new FileInputStream(file2)) : new FileInputStream(file2)));
            Hashtable hashtable = new Hashtable();
            if (i10 == 1) {
                String[] split = str7.split(str6);
                for (String trim : split) {
                    String trim2 = trim.trim();
                    if (trim2.length() != 0) {
                        String[] split2 = trim2.split("=");
                        hashtable.put(split2[i9].trim(), split2[1].trim());
                    }
                }
            }
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                } else if (!readLine.startsWith("*%")) {
                    String str8 = ":";
                    if (readLine.startsWith("*Default")) {
                        int indexOf3 = readLine.indexOf(str8);
                        String substring2 = readLine.substring(i11, indexOf3);
                        String trim3 = readLine.substring(indexOf3 + i12).trim();
                        if (i10 == 0) {
                            hashtable.put(substring2, trim3);
                        }
                    } else {
                        String str9 = "/";
                        if (readLine.startsWith("*ImageableArea")) {
                            int indexOf4 = readLine.indexOf(str6);
                            if (!readLine.substring(indexOf4 + i12, readLine.indexOf(str9)).trim().equals(hashtable.get(readLine.substring(i12, indexOf4)))) {
                                i11 = 8;
                            } else {
                                String[] split3 = readLine.substring(readLine.indexOf(str8) + i12).trim().replaceAll("\\\"", "").trim().split("\\ ");
                                int[] iArr = new int[i];
                                this.ImagingBBox = iArr;
                                iArr[i9] = (int) Math.round(Double.parseDouble(split3[i9]));
                                this.ImagingBBox[i12] = (int) Math.round(Double.parseDouble(split3[i12]));
                                str2 = str7;
                                this.ImagingBBox[2] = (int) Math.round(Double.parseDouble(split3[2]));
                                this.ImagingBBox[3] = (int) Math.round(Double.parseDouble(split3[3]));
                                int[] iArr2 = this.Margins;
                                int[] iArr3 = this.ImagingBBox;
                                iArr2[i9] = iArr3[i9];
                                iArr2[1] = iArr3[1];
                            }
                        } else {
                            str2 = str7;
                            if (readLine.indexOf("setpagedevice") >= 0) {
                                int indexOf5 = readLine.indexOf(str6);
                                if (readLine.substring(indexOf5 + 1, readLine.indexOf(str9)).trim().equals(hashtable.get(readLine.substring(1, indexOf5)))) {
                                    int indexOf6 = readLine.indexOf("<<");
                                    int indexOf7 = readLine.indexOf(">>", indexOf6 + 1);
                                    if (indexOf6 >= 0 && indexOf7 > indexOf6) {
                                        String[] split4 = readLine.substring(indexOf6 + 2, indexOf7).split("\\/");
                                        int i13 = 0;
                                        while (i13 < split4.length) {
                                            String trim4 = split4[i13].trim();
                                            if (trim4.length() != 0) {
                                                String str10 = "(";
                                                int indexOf8 = trim4.indexOf(str10);
                                                if (indexOf8 < 0) {
                                                    indexOf8 = trim4.indexOf("[");
                                                }
                                                if (indexOf8 < 0) {
                                                    indexOf8 = trim4.indexOf(str6);
                                                }
                                                if (indexOf8 < 0) {
                                                    str3 = trim4;
                                                } else {
                                                    str3 = trim4.substring(i9, indexOf8).trim();
                                                }
                                                if (!str3.equals("PageSize") || !readLine.contains("PageRegion")) {
                                                    if (indexOf8 < 0) {
                                                        str4 = null;
                                                    } else {
                                                        str4 = trim4.substring(indexOf8).trim();
                                                    }
                                                    if ("false".equalsIgnoreCase(str4)) {
                                                        str4 = "0";
                                                    }
                                                    if ("true".equalsIgnoreCase(str4)) {
                                                        str4 = "1";
                                                    }
                                                    if ("null".equalsIgnoreCase(str4)) {
                                                        str4 = null;
                                                    }
                                                    try {
                                                        Field declaredField = RasterFile.class.getDeclaredField(str3);
                                                        declaredField.setAccessible(true);
                                                        if (Integer.TYPE.equals(declaredField.getType())) {
                                                            declaredField.setInt(this, Integer.parseInt(str4));
                                                        } else if (Float.TYPE.equals(declaredField.getType())) {
                                                            declaredField.setFloat(this, Float.parseFloat(str4));
                                                        } else if (int[].class.equals(declaredField.getType())) {
                                                            if (str4 == null) {
                                                                declaredField.set(this, null);
                                                            } else {
                                                                String[] split5 = str4.substring(1, str4.length() - 1).split(str6);
                                                                declaredField.set(this, new int[]{(int) Math.round(Double.parseDouble(split5[0])), (int) Math.round(Double.parseDouble(split5[1]))});
                                                            }
                                                        } else if (!float[].class.equals(declaredField.getType())) {
                                                            if (str4 != null && str4.startsWith(str10)) {
                                                                str4 = str4.substring(1, str4.length() - 1);
                                                            }
                                                            declaredField.set(this, str4);
                                                        } else if (str4 == null) {
                                                            declaredField.set(this, null);
                                                        } else {
                                                            String[] split6 = str4.substring(1, str4.length() - 1).split(str6);
                                                            declaredField.set(this, new float[]{Float.parseFloat(split6[0]), Float.parseFloat(split6[1])});
                                                        }
                                                    } catch (NoSuchFieldException e) {
                                                        e.printStackTrace();
                                                        App.reportThrowable(e);
                                                    } catch (IllegalAccessException e2) {
                                                        e2.printStackTrace();
                                                        App.reportThrowable(e2);
                                                    }
                                                }
                                            }
                                            i13++;
                                            i9 = 0;
                                        }
                                    }
                                    str7 = str2;
                                    i = 4;
                                    i9 = 0;
                                    i11 = 8;
                                    i12 = 1;
                                }
                            }
                        }
                        str7 = str2;
                        i = 4;
                        i11 = 8;
                        i12 = 1;
                    }
                }
            }
            String str11 = str7;
            bufferedReader.close();
            i10++;
            i6 = 2;
            i7 = 4;
            i9 = 0;
        }
        int[] iArr4 = this.HWResolution;
        if (iArr4[0] <= 600 || iArr4[1] <= 600) {
            int[] iArr5 = this.HWResolution;
            if (iArr5[0] <= 300 || iArr5[1] <= 300) {
                int[] iArr6 = this.HWResolution;
                if (iArr6[0] <= 150 || iArr6[1] <= 150) {
                    this.dmz = 4;
                    int[] iArr7 = new int[2];
                    iArr7[1] = 4;
                    iArr7[0] = 4;
                    this.dm = (int[][]) Array.newInstance(cls, iArr7);
                    for (int i14 = 0; i14 < 4; i14++) {
                        for (int i15 = 0; i15 < 4; i15++) {
                            int[] iArr8 = this.dm[i14];
                            int i16 = (cluster_template_4x[i14][i15] + 1) * 255;
                            int i17 = this.dmz;
                            iArr8[i15] = 254 - (i16 / ((i17 * i17) + 1));
                        }
                    }
                    return;
                }
                this.dmz = 6;
                int[] iArr9 = new int[2];
                iArr9[1] = 6;
                iArr9[0] = 6;
                this.dm = (int[][]) Array.newInstance(cls, iArr9);
                int i18 = 3;
                int i19 = 0;
                while (i19 < i18) {
                    int i20 = 0;
                    while (i20 < i18) {
                        int[] iArr10 = this.dm[i19];
                        int i21 = ((cluster_template_3x[i19][i20] * 2) + 1) * 255;
                        int i22 = this.dmz;
                        iArr10[i20] = 254 - (i21 / ((i22 * i22) + 1));
                        i20++;
                        i18 = 3;
                    }
                    i19++;
                    i18 = 3;
                }
                int i23 = 0;
                while (i23 < i18) {
                    int i24 = 0;
                    while (i24 < i18) {
                        int[] iArr11 = this.dm[i23 + 3];
                        int i25 = i24 + 3;
                        int i26 = ((cluster_template_3x[i23][i24] * 2) + 1 + 1) * 255;
                        int i27 = this.dmz;
                        iArr11[i25] = 254 - (i26 / ((i27 * i27) + 1));
                        i24++;
                        i18 = 3;
                    }
                    i23++;
                    i18 = 3;
                }
                int i28 = 0;
                while (i28 < i18) {
                    int i29 = 0;
                    while (i29 < i18) {
                        int[] iArr12 = this.dm[i28 + 3];
                        int i30 = (((8 - cluster_template_3x[2 - i29][2 - i28]) * 2) + 1 + 18) * 255;
                        int i31 = this.dmz;
                        iArr12[i29] = 254 - (i30 / ((i31 * i31) + 1));
                        i29++;
                        i18 = 3;
                    }
                    i28++;
                    i18 = 3;
                }
                for (int i32 = 0; i32 < i18; i32++) {
                    for (int i33 = 0; i33 < i18; i33++) {
                        int[] iArr13 = this.dm[i32];
                        int i34 = i33 + 3;
                        int i35 = (((8 - cluster_template_3x[2 - i33][2 - i32]) * 2) + 1 + 19) * 255;
                        int i36 = this.dmz;
                        iArr13[i34] = 254 - (i35 / ((i36 * i36) + 1));
                    }
                }
                return;
            }
            this.dmz = 8;
            int[] iArr14 = new int[2];
            iArr14[1] = 8;
            iArr14[0] = 8;
            this.dm = (int[][]) Array.newInstance(cls, iArr14);
            int i37 = 0;
            while (true) {
                i2 = 4;
                if (i37 >= 4) {
                    break;
                }
                int i38 = 0;
                while (i38 < i2) {
                    int[] iArr15 = this.dm[i37];
                    int i39 = ((cluster_template_4x[i37][i38] * 2) + 1) * 255;
                    int i40 = this.dmz;
                    iArr15[i38] = 254 - (i39 / ((i40 * i40) + 1));
                    i38++;
                    i2 = 4;
                }
                i37++;
            }
            int i41 = 0;
            while (i41 < i2) {
                int i42 = 0;
                while (i42 < i2) {
                    int[] iArr16 = this.dm[i41 + 4];
                    int i43 = i42 + 4;
                    int i44 = ((cluster_template_4x[i41][i42] * 2) + 1 + 1) * 255;
                    int i45 = this.dmz;
                    iArr16[i43] = 254 - (i44 / ((i45 * i45) + 1));
                    i42++;
                    i2 = 4;
                }
                i41++;
                i2 = 4;
            }
            int i46 = 0;
            while (true) {
                i3 = 4;
                if (i46 >= 4) {
                    break;
                }
                int i47 = 0;
                while (i47 < i3) {
                    int[] iArr17 = this.dm[i46 + 4];
                    int i48 = (((15 - cluster_template_4x[3 - i47][3 - i46]) * 2) + 1 + 32) * 255;
                    int i49 = this.dmz;
                    iArr17[i47] = 254 - (i48 / ((i49 * i49) + 1));
                    i47++;
                    i3 = 4;
                }
                i46++;
            }
            int i50 = 0;
            while (i50 < i3) {
                int i51 = 0;
                while (i51 < i3) {
                    int[] iArr18 = this.dm[i50];
                    int i52 = i51 + 4;
                    int i53 = (((15 - cluster_template_4x[3 - i51][3 - i50]) * 2) + 1 + 33) * 255;
                    int i54 = this.dmz;
                    iArr18[i52] = 254 - (i53 / ((i54 * i54) + 1));
                    i51++;
                    i3 = 4;
                }
                i50++;
                i3 = 4;
            }
            return;
        }
        this.dmz = 16;
        int[] iArr19 = new int[2];
        iArr19[1] = 16;
        iArr19[0] = 16;
        this.dm = (int[][]) Array.newInstance(cls, iArr19);
        int i55 = 0;
        while (true) {
            i4 = 8;
            if (i55 >= 8) {
                break;
            }
            int i56 = 0;
            while (i56 < i4) {
                int[] iArr20 = this.dm[i55];
                int i57 = ((cluster_template_8x[i55][i56] * 2) + 1) * 255;
                int i58 = this.dmz;
                iArr20[i56] = 254 - (i57 / ((i58 * i58) + 1));
                i56++;
                i4 = 8;
            }
            i55++;
        }
        int i59 = 0;
        while (i59 < i4) {
            int i60 = 0;
            while (i60 < i4) {
                int[] iArr21 = this.dm[i59 + 8];
                int i61 = i60 + 8;
                int i62 = ((cluster_template_8x[i59][i60] * 2) + 1 + 1) * 255;
                int i63 = this.dmz;
                iArr21[i61] = 254 - (i62 / ((i63 * i63) + 1));
                i60++;
                i4 = 8;
            }
            i59++;
            i4 = 8;
        }
        int i64 = 0;
        while (true) {
            i5 = 8;
            if (i64 >= 8) {
                break;
            }
            int i65 = 0;
            while (i65 < i5) {
                int[] iArr22 = this.dm[i64 + 8];
                int i66 = (((63 - cluster_template_8x[7 - i65][7 - i64]) * 2) + 1 + 128) * 255;
                int i67 = this.dmz;
                iArr22[i65] = 254 - (i66 / ((i67 * i67) + 1));
                i65++;
                i5 = 8;
            }
            i64++;
        }
        int i68 = 0;
        while (i68 < i5) {
            int i69 = 0;
            while (i69 < i5) {
                int[] iArr23 = this.dm[i68];
                int i70 = i69 + 8;
                int i71 = (((63 - cluster_template_8x[7 - i69][7 - i68]) * 2) + 1 + BJNPMain.BJNP_RES_PRINT) * 255;
                int i72 = this.dmz;
                iArr23[i70] = 254 - (i71 / ((i72 * i72) + 1));
                i69++;
                i5 = 8;
            }
            i68++;
            i5 = 8;
        }
    }

    public void writeFileHeader(OutputStream outputStream) throws IOException {
        writeInteger(outputStream, 1382110003);
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00a8  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0146  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x01a6  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x01b3  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x01bd  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x01d8  */
    public void writePageHeader(OutputStream outputStream, int i, int i2) throws IOException {
        int i3;
        int[] iArr;
        int[] iArr2;
        int[] iArr3;
        int[] iArr4;
        float[] fArr;
        float[] fArr2;
        this.cupsWidth = i;
        this.cupsHeight = i2;
        int i4 = this.cupsBitsPerColor;
        String str = "Unsuppported parameter";
        if (i4 == 1 || i4 == 8) {
            int i5 = this.cupsColorSpace;
            int i6 = 4;
            if (i5 != 0) {
                if (i5 == 1) {
                    int i7 = this.cupsBitsPerColor;
                    if (i7 != 1) {
                        i6 = i7 * 3;
                    }
                    this.cupsBitsPerPixel = i6;
                    i6 = 3;
                } else if (i5 != 3) {
                    if (i5 == 6 || i5 == 17) {
                        this.cupsBitsPerPixel = this.cupsBitsPerColor * 4;
                    } else {
                        throw new RuntimeException(str);
                    }
                }
                i3 = this.cupsColorOrder;
                if (i3 != 0) {
                    int i8 = ((i * this.cupsBitsPerPixel) + 7) / 8;
                    this.cupsBytesPerLine = i8;
                    this.zbuf = new byte[i8];
                    this.buf = new byte[i8];
                } else if (i3 == 1) {
                    int i9 = (((i * this.cupsBitsPerColor) + 7) / 8) * i6;
                    this.cupsBytesPerLine = i9;
                    this.buf = new byte[i9];
                    this.zbuf = new byte[i9];
                } else {
                    throw new RuntimeException(str);
                }
                writeString(outputStream, this.MediaClass);
                writeString(outputStream, this.MediaColor);
                writeString(outputStream, this.MediaType);
                writeString(outputStream, this.OutputType);
                writeInteger(outputStream, this.AdvanceDistance);
                writeInteger(outputStream, this.AdvanceMedia);
                writeInteger(outputStream, this.Collate);
                writeInteger(outputStream, this.CutMedia);
                writeInteger(outputStream, this.Duplex);
                iArr = this.HWResolution;
                if (iArr == null) {
                    writeInteger(outputStream, iArr[0]);
                    writeInteger(outputStream, this.HWResolution[1]);
                } else {
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                }
                iArr2 = this.ImagingBBox;
                if (iArr2 == null) {
                    writeInteger(outputStream, iArr2[0]);
                    writeInteger(outputStream, this.ImagingBBox[1]);
                    writeInteger(outputStream, this.ImagingBBox[2]);
                    writeInteger(outputStream, this.ImagingBBox[3]);
                } else {
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                }
                writeInteger(outputStream, this.InsertSheet);
                writeInteger(outputStream, this.Jog);
                writeInteger(outputStream, this.LeadingEdge);
                iArr3 = this.Margins;
                if (iArr3 == null) {
                    writeInteger(outputStream, iArr3[0]);
                    writeInteger(outputStream, this.Margins[1]);
                } else {
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                }
                writeInteger(outputStream, this.ManualFeed);
                writeInteger(outputStream, this.MediaPosition);
                writeInteger(outputStream, this.MediaWeight);
                writeInteger(outputStream, this.MirrorPrint);
                writeInteger(outputStream, this.NegativePrint);
                writeInteger(outputStream, this.NumCopies);
                writeInteger(outputStream, this.Orientation);
                writeInteger(outputStream, this.OutputFaceUp);
                iArr4 = this.PageSize;
                if (iArr4 == null) {
                    writeInteger(outputStream, iArr4[0]);
                    writeInteger(outputStream, this.PageSize[1]);
                } else {
                    writeInteger(outputStream, 0);
                    writeInteger(outputStream, 0);
                }
                writeInteger(outputStream, this.Separations);
                writeInteger(outputStream, this.TraySwitch);
                writeInteger(outputStream, this.Tumble);
                writeInteger(outputStream, this.cupsWidth);
                writeInteger(outputStream, this.cupsHeight);
                writeInteger(outputStream, this.cupsMediaType);
                writeInteger(outputStream, this.cupsBitsPerColor);
                writeInteger(outputStream, this.cupsBitsPerPixel);
                writeInteger(outputStream, this.cupsBytesPerLine);
                writeInteger(outputStream, this.cupsColorOrder);
                writeInteger(outputStream, this.cupsColorSpace);
                writeInteger(outputStream, this.cupsCompression);
                writeInteger(outputStream, this.cupsRowCount);
                writeInteger(outputStream, this.cupsRowFeed);
                writeInteger(outputStream, this.cupsRowStep);
                writeInteger(outputStream, this.cupsNumColors);
                writeFloat(outputStream, this.cupsBorderlessScalingFactor);
                fArr = this.cupsPageSize;
                if (fArr == null) {
                    writeFloat(outputStream, fArr[0]);
                    writeFloat(outputStream, this.cupsPageSize[1]);
                } else {
                    writeFloat(outputStream, 0.0f);
                    writeFloat(outputStream, 0.0f);
                }
                fArr2 = this.cupsImagingBBox;
                if (fArr2 == null) {
                    writeFloat(outputStream, fArr2[0]);
                    writeFloat(outputStream, this.cupsImagingBBox[1]);
                    writeFloat(outputStream, this.cupsImagingBBox[2]);
                    writeFloat(outputStream, this.cupsImagingBBox[3]);
                } else {
                    writeFloat(outputStream, 0.0f);
                    writeFloat(outputStream, 0.0f);
                    writeFloat(outputStream, 0.0f);
                    writeFloat(outputStream, 0.0f);
                }
                writeInteger(outputStream, this.cupsInteger0);
                writeInteger(outputStream, this.cupsInteger1);
                writeInteger(outputStream, this.cupsInteger2);
                writeInteger(outputStream, this.cupsInteger3);
                writeInteger(outputStream, this.cupsInteger4);
                writeInteger(outputStream, this.cupsInteger5);
                writeInteger(outputStream, this.cupsInteger6);
                writeInteger(outputStream, this.cupsInteger7);
                writeInteger(outputStream, this.cupsInteger8);
                writeInteger(outputStream, this.cupsInteger9);
                writeInteger(outputStream, this.cupsInteger10);
                writeInteger(outputStream, this.cupsInteger11);
                writeInteger(outputStream, this.cupsInteger12);
                writeInteger(outputStream, this.cupsInteger13);
                writeInteger(outputStream, this.cupsInteger14);
                writeInteger(outputStream, this.cupsInteger15);
                writeFloat(outputStream, this.cupsReal0);
                writeFloat(outputStream, this.cupsReal1);
                writeFloat(outputStream, this.cupsReal2);
                writeFloat(outputStream, this.cupsReal3);
                writeFloat(outputStream, this.cupsReal4);
                writeFloat(outputStream, this.cupsReal5);
                writeFloat(outputStream, this.cupsReal6);
                writeFloat(outputStream, this.cupsReal7);
                writeFloat(outputStream, this.cupsReal8);
                writeFloat(outputStream, this.cupsReal9);
                writeFloat(outputStream, this.cupsReal10);
                writeFloat(outputStream, this.cupsReal11);
                writeFloat(outputStream, this.cupsReal12);
                writeFloat(outputStream, this.cupsReal13);
                writeFloat(outputStream, this.cupsReal14);
                writeFloat(outputStream, this.cupsReal15);
                writeString(outputStream, this.cupsString0);
                writeString(outputStream, this.cupsString1);
                writeString(outputStream, this.cupsString2);
                writeString(outputStream, this.cupsString3);
                writeString(outputStream, this.cupsString4);
                writeString(outputStream, this.cupsString5);
                writeString(outputStream, this.cupsString6);
                writeString(outputStream, this.cupsString7);
                writeString(outputStream, this.cupsString8);
                writeString(outputStream, this.cupsString9);
                writeString(outputStream, this.cupsString10);
                writeString(outputStream, this.cupsString11);
                writeString(outputStream, this.cupsString12);
                writeString(outputStream, this.cupsString13);
                writeString(outputStream, this.cupsString14);
                writeString(outputStream, this.cupsString15);
                writeString(outputStream, this.cupsMarkerType);
                writeString(outputStream, this.cupsRenderingIntent);
                writeString(outputStream, this.cupsPageSizeName);
                return;
            }
            this.cupsBitsPerPixel = this.cupsBitsPerColor;
            i6 = 1;
            i3 = this.cupsColorOrder;
            if (i3 != 0) {
            }
            writeString(outputStream, this.MediaClass);
            writeString(outputStream, this.MediaColor);
            writeString(outputStream, this.MediaType);
            writeString(outputStream, this.OutputType);
            writeInteger(outputStream, this.AdvanceDistance);
            writeInteger(outputStream, this.AdvanceMedia);
            writeInteger(outputStream, this.Collate);
            writeInteger(outputStream, this.CutMedia);
            writeInteger(outputStream, this.Duplex);
            iArr = this.HWResolution;
            if (iArr == null) {
            }
            iArr2 = this.ImagingBBox;
            if (iArr2 == null) {
            }
            writeInteger(outputStream, this.InsertSheet);
            writeInteger(outputStream, this.Jog);
            writeInteger(outputStream, this.LeadingEdge);
            iArr3 = this.Margins;
            if (iArr3 == null) {
            }
            writeInteger(outputStream, this.ManualFeed);
            writeInteger(outputStream, this.MediaPosition);
            writeInteger(outputStream, this.MediaWeight);
            writeInteger(outputStream, this.MirrorPrint);
            writeInteger(outputStream, this.NegativePrint);
            writeInteger(outputStream, this.NumCopies);
            writeInteger(outputStream, this.Orientation);
            writeInteger(outputStream, this.OutputFaceUp);
            iArr4 = this.PageSize;
            if (iArr4 == null) {
            }
            writeInteger(outputStream, this.Separations);
            writeInteger(outputStream, this.TraySwitch);
            writeInteger(outputStream, this.Tumble);
            writeInteger(outputStream, this.cupsWidth);
            writeInteger(outputStream, this.cupsHeight);
            writeInteger(outputStream, this.cupsMediaType);
            writeInteger(outputStream, this.cupsBitsPerColor);
            writeInteger(outputStream, this.cupsBitsPerPixel);
            writeInteger(outputStream, this.cupsBytesPerLine);
            writeInteger(outputStream, this.cupsColorOrder);
            writeInteger(outputStream, this.cupsColorSpace);
            writeInteger(outputStream, this.cupsCompression);
            writeInteger(outputStream, this.cupsRowCount);
            writeInteger(outputStream, this.cupsRowFeed);
            writeInteger(outputStream, this.cupsRowStep);
            writeInteger(outputStream, this.cupsNumColors);
            writeFloat(outputStream, this.cupsBorderlessScalingFactor);
            fArr = this.cupsPageSize;
            if (fArr == null) {
            }
            fArr2 = this.cupsImagingBBox;
            if (fArr2 == null) {
            }
            writeInteger(outputStream, this.cupsInteger0);
            writeInteger(outputStream, this.cupsInteger1);
            writeInteger(outputStream, this.cupsInteger2);
            writeInteger(outputStream, this.cupsInteger3);
            writeInteger(outputStream, this.cupsInteger4);
            writeInteger(outputStream, this.cupsInteger5);
            writeInteger(outputStream, this.cupsInteger6);
            writeInteger(outputStream, this.cupsInteger7);
            writeInteger(outputStream, this.cupsInteger8);
            writeInteger(outputStream, this.cupsInteger9);
            writeInteger(outputStream, this.cupsInteger10);
            writeInteger(outputStream, this.cupsInteger11);
            writeInteger(outputStream, this.cupsInteger12);
            writeInteger(outputStream, this.cupsInteger13);
            writeInteger(outputStream, this.cupsInteger14);
            writeInteger(outputStream, this.cupsInteger15);
            writeFloat(outputStream, this.cupsReal0);
            writeFloat(outputStream, this.cupsReal1);
            writeFloat(outputStream, this.cupsReal2);
            writeFloat(outputStream, this.cupsReal3);
            writeFloat(outputStream, this.cupsReal4);
            writeFloat(outputStream, this.cupsReal5);
            writeFloat(outputStream, this.cupsReal6);
            writeFloat(outputStream, this.cupsReal7);
            writeFloat(outputStream, this.cupsReal8);
            writeFloat(outputStream, this.cupsReal9);
            writeFloat(outputStream, this.cupsReal10);
            writeFloat(outputStream, this.cupsReal11);
            writeFloat(outputStream, this.cupsReal12);
            writeFloat(outputStream, this.cupsReal13);
            writeFloat(outputStream, this.cupsReal14);
            writeFloat(outputStream, this.cupsReal15);
            writeString(outputStream, this.cupsString0);
            writeString(outputStream, this.cupsString1);
            writeString(outputStream, this.cupsString2);
            writeString(outputStream, this.cupsString3);
            writeString(outputStream, this.cupsString4);
            writeString(outputStream, this.cupsString5);
            writeString(outputStream, this.cupsString6);
            writeString(outputStream, this.cupsString7);
            writeString(outputStream, this.cupsString8);
            writeString(outputStream, this.cupsString9);
            writeString(outputStream, this.cupsString10);
            writeString(outputStream, this.cupsString11);
            writeString(outputStream, this.cupsString12);
            writeString(outputStream, this.cupsString13);
            writeString(outputStream, this.cupsString14);
            writeString(outputStream, this.cupsString15);
            writeString(outputStream, this.cupsMarkerType);
            writeString(outputStream, this.cupsRenderingIntent);
            writeString(outputStream, this.cupsPageSizeName);
            return;
        }
        throw new RuntimeException(str);
    }

    public void writePageStripe(OutputStream outputStream, int[] iArr, int i, int i2, int i3) throws IOException {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        RasterFile rasterFile;
        int i13;
        OutputStream outputStream2;
        int i14;
        int i15;
        int i16;
        RasterFile rasterFile2;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        RasterFile rasterFile3;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        int i30;
        int i31;
        RasterFile rasterFile4 = this;
        int i32 = i3;
        byte[] bArr = rasterFile4.buf;
        int i33 = rasterFile4.cupsWidth;
        int i34 = rasterFile4.cupsBitsPerColor;
        int i35 = rasterFile4.cupsColorSpace;
        int i36 = rasterFile4.cupsColorOrder;
        int i37 = ((i33 * i34) + 7) / 8;
        int i38 = i37 * 2;
        int i39 = i37 * 3;
        int i40 = i * i32;
        int i41 = i2;
        int i42 = 0;
        while (i42 < i41) {
            int i43 = 0;
            while (i43 < i32) {
                int i44 = i33 / i32;
                int i45 = i42 * i44;
                if (i34 == 8) {
                    int i46 = 0;
                    int i47 = 0;
                    while (i46 < i44) {
                        int i48 = i45 + 1;
                        int i49 = i33;
                        int i50 = iArr[i45];
                        int i51 = i34;
                        int i52 = (i50 >> 16) & 255;
                        int i53 = i42;
                        int i54 = (i50 >> 8) & 255;
                        int i55 = i50 & 255;
                        if (i35 != 0) {
                            if (i35 == 1) {
                                i28 = i37;
                                i29 = i38;
                                i30 = i39;
                                i31 = i43;
                                for (int i56 = 0; i56 < i32; i56++) {
                                    int i57 = i47 + 1;
                                    bArr[i47] = (byte) i52;
                                    int i58 = i57 + 1;
                                    bArr[i57] = (byte) i54;
                                    i47 = i58 + 1;
                                    bArr[i58] = (byte) i55;
                                }
                            } else if (i35 != 3) {
                                if (i35 == 6) {
                                    i28 = i37;
                                    i29 = i38;
                                    i30 = i39;
                                    i31 = i43;
                                    int i59 = i54 > i52 ? i54 : i52;
                                    if (i55 > i59) {
                                        i59 = i55;
                                    }
                                    int i60 = i59 > 0 ? 255 - ((i52 * 255) / i59) : 0;
                                    int i61 = i59 > 0 ? 255 - ((i54 * 255) / i59) : 0;
                                    int i62 = i59 > 0 ? 255 - ((i55 * 255) / i59) : 0;
                                    int i63 = 255 - i59;
                                    for (int i64 = 0; i64 < i32; i64++) {
                                        int i65 = i47 + 1;
                                        bArr[i47] = (byte) i60;
                                        int i66 = i65 + 1;
                                        bArr[i65] = (byte) i61;
                                        int i67 = i66 + 1;
                                        bArr[i66] = (byte) i62;
                                        i47 = i67 + 1;
                                        bArr[i67] = (byte) i63;
                                    }
                                } else if (i35 != 17) {
                                    i28 = i37;
                                    i29 = i38;
                                    i30 = i39;
                                    i31 = i43;
                                } else {
                                    int i68 = (i52 == 0 && i54 == 0 && i55 == 0) ? 0 : 255;
                                    i31 = i43;
                                    int i69 = 0;
                                    while (i69 < i32) {
                                        int i70 = i47 + 1;
                                        int i71 = i39;
                                        bArr[i47] = (byte) i52;
                                        int i72 = i70 + 1;
                                        int i73 = i38;
                                        bArr[i70] = (byte) i54;
                                        int i74 = i72 + 1;
                                        int i75 = i37;
                                        bArr[i72] = (byte) i55;
                                        i47 = i74 + 1;
                                        bArr[i74] = (byte) i68;
                                        i69++;
                                        i39 = i71;
                                        i38 = i73;
                                        i37 = i75;
                                    }
                                    i28 = i37;
                                    i29 = i38;
                                    i30 = i39;
                                }
                            }
                            i46++;
                            int i76 = i2;
                            i45 = i48;
                            i33 = i49;
                            i34 = i51;
                            i42 = i53;
                            i43 = i31;
                            i39 = i30;
                            i38 = i29;
                            i37 = i28;
                        }
                        i28 = i37;
                        i29 = i38;
                        i30 = i39;
                        i31 = i43;
                        int i77 = (((i55 * 117) + (i54 * 601)) + (i52 * 306)) >> 10;
                        if (i35 == 3) {
                            i77 = 255 - i77;
                        }
                        int i78 = 0;
                        while (i78 < i32) {
                            int i79 = i47 + 1;
                            bArr[i47] = (byte) i77;
                            i78++;
                            i47 = i79;
                        }
                        i46++;
                        int i762 = i2;
                        i45 = i48;
                        i33 = i49;
                        i34 = i51;
                        i42 = i53;
                        i43 = i31;
                        i39 = i30;
                        i38 = i29;
                        i37 = i28;
                    }
                    i12 = i33;
                    i11 = i34;
                    i6 = i37;
                    i7 = i38;
                    i8 = i39;
                    i10 = i42;
                    i9 = i43;
                    rasterFile = rasterFile4;
                    i5 = i36;
                    i4 = i40;
                    outputStream2 = outputStream;
                    i13 = i32;
                } else {
                    i12 = i33;
                    i11 = i34;
                    i6 = i37;
                    i7 = i38;
                    i8 = i39;
                    i10 = i42;
                    i9 = i43;
                    int i80 = rasterFile4.dmz;
                    int[] iArr2 = rasterFile4.dm[i40 % i80];
                    int i81 = 0;
                    int i82 = 128;
                    int i83 = 0;
                    int i84 = 0;
                    int i85 = 0;
                    int i86 = 0;
                    int i87 = 0;
                    int i88 = 0;
                    while (i81 < i44) {
                        int i89 = i45 + 1;
                        int i90 = iArr[i45];
                        int i91 = i82;
                        int i92 = i83;
                        int i93 = (i90 >> 16) & 255;
                        int i94 = i44;
                        int i95 = (i90 >> 8) & 255;
                        int i96 = i90 & 255;
                        if (i35 != 0) {
                            if (i35 != 1) {
                                if (i35 != 3) {
                                    if (i35 == 6) {
                                        int i97 = i95 > i93 ? i95 : i93;
                                        if (i96 > i97) {
                                            i97 = i96;
                                        }
                                        if (i97 > 0) {
                                            i24 = i84;
                                            i25 = 255 - ((i93 * 255) / i97);
                                        } else {
                                            i24 = i84;
                                            i25 = 0;
                                        }
                                        int i98 = i97 > 0 ? 255 - ((i95 * 255) / i97) : 0;
                                        int i99 = i97 > 0 ? 255 - ((i96 * 255) / i97) : 0;
                                        int i100 = 255 - i97;
                                        int i101 = 0;
                                        while (i101 < i32) {
                                            if (i36 == 0) {
                                                int i102 = i24 % i80;
                                                i27 = i40;
                                                if (i25 > iArr2[i102]) {
                                                    i92 |= i91;
                                                }
                                                int i103 = i92;
                                                int i104 = i91 >> 1;
                                                if (i104 == 0) {
                                                    int i105 = i85 + 1;
                                                    bArr[i85] = (byte) i103;
                                                    i26 = i81;
                                                    i85 = i105;
                                                    i103 = 0;
                                                    i104 = 128;
                                                } else {
                                                    i26 = i81;
                                                }
                                                if (i98 > iArr2[i102]) {
                                                    i103 |= i104;
                                                }
                                                int i106 = i104 >> 1;
                                                if (i106 == 0) {
                                                    int i107 = i85 + 1;
                                                    bArr[i85] = (byte) i103;
                                                    i85 = i107;
                                                    i106 = 128;
                                                    i103 = 0;
                                                }
                                                if (i99 > iArr2[i102]) {
                                                    i103 |= i106;
                                                }
                                                int i108 = i106 >> 1;
                                                if (i108 == 0) {
                                                    int i109 = i85 + 1;
                                                    bArr[i85] = (byte) i103;
                                                    i85 = i109;
                                                    i108 = 128;
                                                    i103 = 0;
                                                }
                                                if (i100 > iArr2[i102]) {
                                                    i103 |= i108;
                                                }
                                                int i110 = i108 >> 1;
                                                if (i110 == 0) {
                                                    int i111 = i85 + 1;
                                                    bArr[i85] = (byte) i103;
                                                    i85 = i111;
                                                    i91 = 128;
                                                } else {
                                                    i91 = i110;
                                                    i92 = i103;
                                                    i101++;
                                                    i24++;
                                                    i40 = i27;
                                                    i81 = i26;
                                                }
                                            } else {
                                                i26 = i81;
                                                i27 = i40;
                                                int i112 = i24 % i80;
                                                if (i25 > iArr2[i112]) {
                                                    i92 |= i91;
                                                }
                                                int i113 = i92;
                                                if (i98 > iArr2[i112]) {
                                                    i86 |= i91;
                                                }
                                                if (i99 > iArr2[i112]) {
                                                    i87 |= i91;
                                                }
                                                int i114 = i87;
                                                if (i100 > iArr2[i112]) {
                                                    i88 |= i91;
                                                }
                                                int i115 = i88;
                                                i91 >>= 1;
                                                if (i91 == 0) {
                                                    bArr[i85] = (byte) i113;
                                                    bArr[i6 + i85] = (byte) i86;
                                                    bArr[i7 + i85] = (byte) i114;
                                                    bArr[i8 + i85] = (byte) i115;
                                                    i85++;
                                                    i86 = 0;
                                                    i91 = 128;
                                                    i87 = 0;
                                                    i88 = 0;
                                                } else {
                                                    i88 = i115;
                                                    i92 = i113;
                                                    i87 = i114;
                                                    i101++;
                                                    i24++;
                                                    i40 = i27;
                                                    i81 = i26;
                                                }
                                            }
                                            i92 = 0;
                                            i101++;
                                            i24++;
                                            i40 = i27;
                                            i81 = i26;
                                        }
                                        i14 = i81;
                                        i15 = i40;
                                        rasterFile2 = this;
                                        i16 = i36;
                                        i82 = i91;
                                        i83 = i92;
                                        i84 = i24;
                                    } else if (i35 != 17) {
                                        i16 = i36;
                                        i14 = i81;
                                        i15 = i40;
                                        i82 = i91;
                                        i83 = i92;
                                        rasterFile2 = rasterFile4;
                                    }
                                    i17 = i32;
                                    i32 = i17;
                                    i45 = i89;
                                    i44 = i94;
                                    i36 = i16;
                                    i40 = i15;
                                    RasterFile rasterFile5 = rasterFile2;
                                    i81 = i14 + 1;
                                    rasterFile4 = rasterFile5;
                                } else {
                                    i20 = i81;
                                    i21 = i40;
                                    i18 = i84;
                                    rasterFile3 = this;
                                    i19 = i36;
                                }
                            }
                            i14 = i81;
                            i15 = i40;
                            int i116 = i84;
                            char c = (i93 == 0 && i95 == 0 && i96 == 0) ? (char) 0 : 255;
                            i83 = i92;
                            int i117 = 0;
                            while (i117 < i32) {
                                if (i36 == 0) {
                                    if (i35 == 1) {
                                        i91 >>= 1;
                                        if (i91 == 0) {
                                            int i118 = i85 + 1;
                                            bArr[i85] = (byte) i83;
                                            i85 = i118;
                                            i83 = 0;
                                            i91 = 128;
                                        }
                                    }
                                    int i119 = i116 % i80;
                                    if (i93 > iArr2[i119]) {
                                        i83 |= i91;
                                    }
                                    int i120 = i91 >> 1;
                                    if (i120 == 0) {
                                        int i121 = i85 + 1;
                                        bArr[i85] = (byte) i83;
                                        i22 = i36;
                                        i85 = i121;
                                        i120 = 128;
                                        i83 = 0;
                                    } else {
                                        i22 = i36;
                                    }
                                    if (i95 > iArr2[i119]) {
                                        i83 |= i120;
                                    }
                                    int i122 = i120 >> 1;
                                    if (i122 == 0) {
                                        int i123 = i85 + 1;
                                        bArr[i85] = (byte) i83;
                                        i85 = i123;
                                        i122 = 128;
                                        i83 = 0;
                                    }
                                    if (i96 > iArr2[i119]) {
                                        i83 |= i122;
                                    }
                                    int i124 = i122 >> 1;
                                    if (i124 == 0) {
                                        int i125 = i85 + 1;
                                        bArr[i85] = (byte) i83;
                                        i85 = i125;
                                        i124 = 128;
                                        i83 = 0;
                                    }
                                    if (this.cupsColorSpace == 17) {
                                        if (c != 0) {
                                            i83 |= i124;
                                        }
                                        int i126 = i124 >> 1;
                                        if (i126 == 0) {
                                            int i127 = i85 + 1;
                                            this.buf[i85] = (byte) i83;
                                            i85 = i127;
                                            i83 = 0;
                                            i23 = 128;
                                        } else {
                                            i23 = i126;
                                        }
                                    } else {
                                        i23 = i124;
                                    }
                                } else {
                                    i22 = i36;
                                    int i128 = i116 % i80;
                                    if (i93 > iArr2[i128]) {
                                        i83 |= i91;
                                    }
                                    if (i95 > iArr2[i128]) {
                                        i86 |= i91;
                                    }
                                    if (i96 > iArr2[i128]) {
                                        i87 |= i91;
                                    }
                                    int i129 = i87;
                                    if (i35 == 17 && c != 0) {
                                        i88 |= i91;
                                    }
                                    int i130 = i88;
                                    int i131 = i91 >> 1;
                                    if (i131 == 0) {
                                        bArr[i85] = (byte) i83;
                                        bArr[i6 + i85] = (byte) i86;
                                        bArr[i7 + i85] = (byte) i129;
                                        if (i35 == 17) {
                                            bArr[i8 + i85] = (byte) i130;
                                            i130 = 0;
                                        }
                                        i85++;
                                        i88 = i130;
                                        i83 = 0;
                                        i86 = 0;
                                        i23 = 128;
                                        i87 = 0;
                                    } else {
                                        i87 = i129;
                                        i88 = i130;
                                        i23 = i131;
                                    }
                                }
                                i117++;
                                i116++;
                                i32 = i3;
                                i36 = i22;
                            }
                            rasterFile2 = this;
                            i16 = i36;
                            i17 = i3;
                            i82 = i91;
                            i84 = i116;
                            i32 = i17;
                            i45 = i89;
                            i44 = i94;
                            i36 = i16;
                            i40 = i15;
                            RasterFile rasterFile52 = rasterFile2;
                            i81 = i14 + 1;
                            rasterFile4 = rasterFile52;
                        } else {
                            i19 = i36;
                            i20 = i81;
                            i21 = i40;
                            i18 = i84;
                            rasterFile3 = rasterFile4;
                        }
                        int i132 = (((i96 * 117) + (i95 * 601)) + (i93 * 306)) >> 10;
                        if (i35 == 3) {
                            i132 = 255 - i132;
                        }
                        i17 = i3;
                        int i133 = i91;
                        i83 = i92;
                        i84 = i18;
                        int i134 = 0;
                        while (i134 < i17) {
                            if (i132 > iArr2[i84 % i80]) {
                                i83 |= i82;
                            }
                            i133 = i82 >> 1;
                            if (i133 == 0) {
                                int i135 = i85 + 1;
                                bArr[i85] = (byte) i83;
                                i85 = i135;
                                i133 = 128;
                                i83 = 0;
                            }
                            i134++;
                            i84++;
                        }
                        i32 = i17;
                        i45 = i89;
                        i44 = i94;
                        i36 = i16;
                        i40 = i15;
                        RasterFile rasterFile522 = rasterFile2;
                        i81 = i14 + 1;
                        rasterFile4 = rasterFile522;
                    }
                    rasterFile = rasterFile4;
                    i5 = i36;
                    i4 = i40;
                    i13 = i32;
                    outputStream2 = outputStream;
                }
                outputStream2.write(bArr);
                byte[] bArr2 = rasterFile.zbuf;
                System.arraycopy(bArr2, 0, bArr, 0, bArr2.length);
                i43 = i9 + 1;
                i40 = i4 + 1;
                int i136 = i2;
                i32 = i13;
                rasterFile4 = rasterFile;
                i33 = i12;
                i34 = i11;
                i42 = i10;
                i39 = i8;
                i38 = i7;
                i37 = i6;
                i36 = i5;
            }
            RasterFile rasterFile6 = rasterFile4;
            int i137 = i33;
            int i138 = i36;
            int i139 = i37;
            int i140 = i38;
            int i141 = i39;
            int i142 = i40;
            OutputStream outputStream3 = outputStream;
            int i143 = i32;
            i42++;
            i41 = i2;
            rasterFile4 = rasterFile6;
            i34 = i34;
            i36 = i138;
        }
        RasterFile rasterFile7 = rasterFile4;
    }

    private void writeString(OutputStream outputStream, String str) throws IOException {
        byte[] bArr = new byte[64];
        byte[] bytes = str != null ? str.getBytes() : null;
        if (bytes != null) {
            System.arraycopy(bytes, 0, bArr, 0, bytes.length < 64 ? bytes.length : 63);
        }
        outputStream.write(bArr);
    }

    private void writeInteger(OutputStream outputStream, int i) throws IOException {
        outputStream.write((i >> 24) & 255);
        outputStream.write((i >> 16) & 255);
        outputStream.write((i >> 8) & 255);
        outputStream.write(i & 255);
    }

    private void writeFloat(OutputStream outputStream, float f) throws IOException {
        writeInteger(outputStream, Float.floatToRawIntBits(f));
    }
}
