package com.dynamixsoftware.printershare;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.preference.PreferenceManager;
import android.print.PrintAttributes.Margins;
import android.print.PrintAttributes.MediaSize;
import android.print.PrintAttributes.Resolution;
import android.print.PrinterCapabilitiesInfo.Builder;
import android.print.PrinterId;
import android.print.PrinterInfo;
import android.printservice.PrintJob;
import android.printservice.PrintService;
import android.printservice.PrinterDiscoverySession;
import com.dynamixsoftware.printershare.data.Paper;
import com.dynamixsoftware.printershare.data.Printer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class AndroidPrintService extends PrintService {
    /* access modifiers changed from: protected */
    public void onConnected() {
        super.onConnected();
        try {
            List activePrintJobs = getActivePrintJobs();
            for (int i = 0; i < activePrintJobs.size(); i++) {
                ((PrintJob) activePrintJobs.get(i)).cancel();
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }

    /* access modifiers changed from: protected */
    public void onDisconnected() {
        super.onDisconnected();
    }

    /* access modifiers changed from: protected */
    public PrinterDiscoverySession onCreatePrinterDiscoverySession() {
        return new PrinterDiscoverySession() {
            public void onDestroy() {
            }

            public void onStartPrinterStateTracking(PrinterId printerId) {
            }

            public void onStopPrinterDiscovery() {
            }

            public void onStopPrinterStateTracking(PrinterId printerId) {
            }

            public void onValidatePrinters(List<PrinterId> list) {
            }

            /* JADX WARNING: Removed duplicated region for block: B:55:0x0160  */
            public void onStartPrinterDiscovery(List<PrinterId> list) {
                ArrayList arrayList;
                PrinterInfo printerInfo;
                HashSet hashSet;
                String sb;
                ArrayList arrayList2 = new ArrayList();
                String str = "default";
                PrinterId generatePrinterId = AndroidPrintService.this.generatePrinterId(str);
                Printer printer = ActivityCore.getPrinter();
                String str2 = "Default";
                String str3 = "A4";
                String str4 = "Letter";
                if (printer != null) {
                    try {
                        String string = PreferenceManager.getDefaultSharedPreferences(App.self.getApplicationContext()).getString("activity_print_android#paper", null);
                        if (string == null) {
                            Locale locale = Locale.getDefault();
                            if (!locale.equals(Locale.CANADA) && !locale.equals(Locale.CANADA_FRENCH)) {
                                if (!locale.equals(Locale.US)) {
                                    string = str3;
                                }
                            }
                            string = str4;
                        }
                        boolean z = false;
                        for (int i = 0; i < printer.paper_list.size(); i++) {
                            if (((Paper) printer.paper_list.get(i)).id.equals(string)) {
                                z = true;
                            }
                        }
                        if (!z) {
                            string = printer.paper_default;
                        }
                        Builder builder = new Builder(generatePrinterId);
                        HashSet hashSet2 = new HashSet();
                        int i2 = 0;
                        boolean z2 = false;
                        while (i2 < printer.paper_list.size()) {
                            Paper paper = (Paper) printer.paper_list.get(i2);
                            if (!(paper.id == null || paper.id.length() == 0 || paper.name == null)) {
                                if (paper.name.length() != 0) {
                                    int i3 = 0;
                                    while (true) {
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append(((paper.width * 1000) / 254) + i3);
                                        sb2.append(" ");
                                        sb2.append(((paper.height * 1000) / 254) + i3);
                                        sb = sb2.toString();
                                        if (!hashSet2.contains(sb)) {
                                            break;
                                        }
                                        i3++;
                                    }
                                    hashSet2.add(sb);
                                    hashSet = hashSet2;
                                    arrayList = arrayList2;
                                    try {
                                        builder.addMediaSize(new MediaSize(paper.id, paper.name, ((paper.width * 1000) / 254) + i3, ((paper.height * 1000) / 254) + i3), paper.id.equals(string));
                                        z2 = true;
                                        i2++;
                                        hashSet2 = hashSet;
                                        arrayList2 = arrayList;
                                    } catch (Exception e) {
                                        e = e;
                                        e.printStackTrace();
                                        StringBuilder sb3 = new StringBuilder();
                                        sb3.append(printer.model);
                                        sb3.append(" | ");
                                        sb3.append(printer.drv_name);
                                        App.reportThrowable(e, sb3.toString());
                                        printerInfo = null;
                                        if (printerInfo == null) {
                                        }
                                        ArrayList arrayList3 = arrayList;
                                        arrayList3.add(printerInfo);
                                        addPrinters(arrayList3);
                                    }
                                }
                            }
                            arrayList = arrayList2;
                            hashSet = hashSet2;
                            i2++;
                            hashSet2 = hashSet;
                            arrayList2 = arrayList;
                        }
                        arrayList = arrayList2;
                        if (z2) {
                            builder.addResolution(new Resolution(str, str2, 300, 300), true);
                            builder.setColorModes(2, 2);
                            builder.setMinMargins(Margins.NO_MARGINS);
                            printerInfo = new PrinterInfo.Builder(generatePrinterId, printer.title, 1).setCapabilities(builder.build()).build();
                            if (printerInfo == null) {
                                printerInfo = new PrinterInfo.Builder(generatePrinterId, "Default Printer", 1).setCapabilities(new Builder(generatePrinterId).addMediaSize(new MediaSize(str4, str4, MediaSize.NA_LETTER.getWidthMils(), MediaSize.NA_LETTER.getHeightMils()), true).addMediaSize(new MediaSize(str3, str3, MediaSize.ISO_A4.getWidthMils(), MediaSize.ISO_A4.getHeightMils()), false).addResolution(new Resolution(str, str2, 300, 300), true).setColorModes(2, 2).setMinMargins(Margins.NO_MARGINS).build()).build();
                            }
                            ArrayList arrayList32 = arrayList;
                            arrayList32.add(printerInfo);
                            addPrinters(arrayList32);
                        }
                    } catch (Exception e2) {
                        e = e2;
                        arrayList = arrayList2;
                        e.printStackTrace();
                        StringBuilder sb32 = new StringBuilder();
                        sb32.append(printer.model);
                        sb32.append(" | ");
                        sb32.append(printer.drv_name);
                        App.reportThrowable(e, sb32.toString());
                        printerInfo = null;
                        if (printerInfo == null) {
                        }
                        ArrayList arrayList322 = arrayList;
                        arrayList322.add(printerInfo);
                        addPrinters(arrayList322);
                    }
                } else {
                    arrayList = arrayList2;
                }
                printerInfo = null;
                if (printerInfo == null) {
                }
                ArrayList arrayList3222 = arrayList;
                arrayList3222.add(printerInfo);
                addPrinters(arrayList3222);
            }
        };
    }

    /* access modifiers changed from: protected */
    public void onRequestCancelPrintJob(PrintJob printJob) {
        printJob.cancel();
    }

    /* access modifiers changed from: protected */
    public void onPrintJobQueued(PrintJob printJob) {
        printJob.start();
        try {
            File file = new File(App.getTempDir(), "printershare_temp_print.pdf");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            FileInputStream fileInputStream = new FileInputStream(printJob.getDocument().getData().getFileDescriptor());
            byte[] bArr = new byte[4096];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            fileOutputStream.close();
            fileInputStream.close();
            final Intent intent = new Intent("android.intent.action.VIEW");
            intent.putExtra("temp_file", file.getAbsolutePath());
            intent.putExtra("job_info", printJob.getInfo());
            intent.setFlags(268435456);
            intent.setClass(getApplicationContext(), ActivityPrintAndroid.class);
            intent.setDataAndType(Uri.fromFile(file), "application/pdf");
            if (VERSION.SDK_INT >= 29) {
                new Object() {
                    {
                        NotificationManager notificationManager = (NotificationManager) AndroidPrintService.this.getSystemService("notification");
                        String str = "default";
                        if (notificationManager.getNotificationChannel(str) == null) {
                            notificationManager.createNotificationChannel(new NotificationChannel(str, AndroidPrintService.this.getResources().getString(R.string.print_notification_channel), 4));
                        }
                        notificationManager.notify(1, new Notification.Builder(AndroidPrintService.this.getApplicationContext(), str).setCategory("service").setSmallIcon(R.drawable.ic_print_notification).setContentTitle(AndroidPrintService.this.getResources().getString(R.string.print_notification_content_title)).setContentText(AndroidPrintService.this.getResources().getString(R.string.print_notification_content_text)).setLocalOnly(true).setAutoCancel(true).setOngoing(true).setFullScreenIntent(PendingIntent.getActivity(AndroidPrintService.this.getApplicationContext(), 0, intent, 134217728), true).build());
                    }
                };
            } else {
                startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        printJob.complete();
    }
}
