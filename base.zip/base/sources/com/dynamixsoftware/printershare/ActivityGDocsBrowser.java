package com.dynamixsoftware.printershare;

import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.zip.GZIPInputStream;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class ActivityGDocsBrowser extends ActivityRoot {
    private static int requesting_credentials;
    /* access modifiers changed from: private */
    public AlertDialog accounts_menu;
    /* access modifiers changed from: private */
    public FolderAdapter adapter;
    /* access modifiers changed from: private */
    public String[] al;
    private Object[] al_objs;
    /* access modifiers changed from: private */
    public String[] credentials;
    /* access modifiers changed from: private */
    public volatile Vector<Entry> data;
    boolean ftoken;
    private Handler handler;
    private ListView list;
    boolean new_am;
    /* access modifiers changed from: private */
    public Thread wt;

    static class Entry {
        public String id;
        public boolean loaded;
        public String parent_id;
        public String title;
        public String type;
        public int type_rid;

        public Entry(String str, String str2, String str3, String str4) {
            this.id = str2;
            this.type = str3;
            this.title = str4;
            String str5 = "application/vnd.google-apps.folder";
            this.type_rid = str5.equals(str3) ? R.drawable.icn_folder : R.drawable.icn_empty;
            if (str5.equals(str3) && "".equals(str2)) {
                this.type_rid = R.drawable.icn_up;
            }
        }

        public Entry(String str, GFile gFile) {
            this.parent_id = str;
            this.id = gFile.id;
            this.title = App.fixEncoding(gFile.name);
            String str2 = gFile.mimeType;
            this.type = str2;
            if ("application/vnd.google-apps.folder".equals(str2)) {
                this.type_rid = R.drawable.icn_folder;
            } else if (this.type.indexOf("image/jpeg") >= 0 || this.type.indexOf("image/png") >= 0) {
                this.type_rid = R.drawable.icn_img;
            } else if (this.type.indexOf(NanoHTTPD.MIME_PLAINTEXT) >= 0) {
                this.type_rid = R.drawable.icn_txt;
            } else if (this.type.indexOf("application/pdf") >= 0) {
                this.type_rid = R.drawable.icn_pdf;
            } else if (this.type.indexOf("application/msword") >= 0 || this.type.indexOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document") >= 0) {
                this.type_rid = R.drawable.icn_doc;
            } else if (this.type.indexOf("application/vnd.ms-excel") >= 0 || this.type.indexOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") >= 0) {
                this.type_rid = R.drawable.icn_xls;
            } else if (this.type.indexOf("application/vnd.ms-powerpoint") >= 0 || this.type.indexOf("application/vnd.openxmlformats-officedocument.presentationml.presentation") >= 0) {
                this.type_rid = R.drawable.icn_ppt;
            } else {
                this.type_rid = R.drawable.icn_empty;
            }
        }
    }

    class FolderAdapter implements ListAdapter {
        /* access modifiers changed from: private */
        public Vector<Entry> chain = new Vector<>();
        private Vector<Entry> entries = new Vector<>();
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        public FolderAdapter() {
            changeFolder(null);
        }

        public void changeFolder(final Entry entry) {
            String str;
            if (entry == null || entry.loaded) {
                if (entry != null) {
                    if (this.chain.size() > 1) {
                        Vector<Entry> vector = this.chain;
                        if (vector.get(vector.size() - 2) == entry) {
                            Vector<Entry> vector2 = this.chain;
                            vector2.remove(vector2.size() - 1);
                        }
                    }
                    if (this.chain.size() == 0 || entry != this.chain.lastElement()) {
                        this.chain.add(entry);
                    }
                } else {
                    this.chain.clear();
                }
                String str2 = entry != null ? entry.id : "root";
                Vector vector3 = new Vector();
                Vector vector4 = new Vector();
                int i = 0;
                while (true) {
                    str = "application/vnd.google-apps.folder";
                    if (i >= ActivityGDocsBrowser.this.data.size()) {
                        break;
                    }
                    Entry entry2 = (Entry) ActivityGDocsBrowser.this.data.get(i);
                    if (str2.equals(entry2.parent_id)) {
                        if (str.equals(entry2.type)) {
                            vector3.add(entry2);
                        } else {
                            vector4.add(entry2);
                        }
                    }
                    i++;
                }
                AnonymousClass2 r0 = new Comparator<Entry>() {
                    public int compare(Entry entry, Entry entry2) {
                        return entry.title.compareToIgnoreCase(entry2.title);
                    }
                };
                Collections.sort(vector3, r0);
                Collections.sort(vector4, r0);
                this.entries.clear();
                if (entry != null) {
                    this.entries.add(new Entry(entry.id, "", str, ".."));
                }
                this.entries.addAll(vector3);
                this.entries.addAll(vector4);
                fireOnChanged();
                return;
            }
            ActivityGDocsBrowser activityGDocsBrowser = ActivityGDocsBrowser.this;
            activityGDocsBrowser.showProgress(activityGDocsBrowser.getResources().getString(R.string.label_loading));
            ActivityGDocsBrowser.this.wt = new Thread() {
                public void run() {
                    if (ActivityGDocsBrowser.this.loadFolder(entry.id)) {
                        entry.loaded = true;
                    } else if (ActivityGDocsBrowser.this.last_error == null) {
                        return;
                    }
                    ActivityGDocsBrowser.this.wt = null;
                    ActivityGDocsBrowser.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityGDocsBrowser.this.hideProgress();
                            if (ActivityGDocsBrowser.this.last_error == null) {
                                ActivityGDocsBrowser.this.adapter.changeFolder(entry);
                            } else {
                                ActivityGDocsBrowser.this.displayLastError(new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                });
                            }
                        }
                    });
                }
            };
            ActivityGDocsBrowser.this.wt.start();
        }

        public boolean isEnabled(int i) {
            return "application/vnd.google-apps.folder".equals(((Entry) this.entries.get(i)).type) || ((Entry) this.entries.get(i)).type_rid != 2130837533;
        }

        public int getCount() {
            return this.entries.size();
        }

        public Object getItem(int i) {
            return this.entries.get(i);
        }

        public long getItemId(int i) {
            return (long) (((Entry) this.entries.get(i)).id.hashCode() << (i + 16));
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            LinearLayout linearLayout = (LinearLayout) view;
            if (linearLayout == null) {
                linearLayout = (LinearLayout) ActivityGDocsBrowser.this.getLayoutInflater().inflate(R.layout.list_item_docs, viewGroup, false);
            }
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.image);
            TextView textView = (TextView) linearLayout.findViewById(R.id.name);
            int i2 = ((Entry) this.entries.get(i)).type_rid;
            if (imageView.getTag() == null || i2 != ((Integer) imageView.getTag()).intValue()) {
                imageView.setTag(Integer.valueOf(i2));
                imageView.setImageResource(i2);
            }
            linearLayout.setTag(Integer.valueOf(i));
            textView.setText(((Entry) this.entries.get(i)).title);
            textView.setEnabled(isEnabled(i));
            return linearLayout;
        }

        public boolean isEmpty() {
            return this.entries.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    public static class GFile {
        public String id;
        public String kind;
        public String mimeType;
        public String name;
    }

    public static class GFileList {
        public ArrayList<GFile> files;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0092  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    public void onCreate(Bundle bundle) {
        boolean z;
        String str = "SDK_INT";
        super.onCreate(bundle);
        this.data = new Vector<>();
        this.handler = new Handler();
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_gdocs);
        try {
            if (VERSION.class.getField(str).getInt(null) >= 26) {
                this.new_am = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.menu_accounts);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityGDocsBrowser.this.chooseAccount();
            }
        });
        ListView listView = (ListView) findViewById(R.id.list);
        this.list = listView;
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                final Entry entry = (Entry) ActivityGDocsBrowser.this.adapter.getItem(((Integer) view.getTag()).intValue());
                if ("application/vnd.google-apps.folder".equals(entry.type)) {
                    if (!"".equals(entry.id)) {
                        ActivityGDocsBrowser.this.adapter.changeFolder(entry);
                    } else {
                        ActivityGDocsBrowser.this.adapter.changeFolder(ActivityGDocsBrowser.this.adapter.chain.size() > 1 ? (Entry) ActivityGDocsBrowser.this.adapter.chain.get(ActivityGDocsBrowser.this.adapter.chain.size() - 2) : null);
                    }
                } else {
                    ActivityGDocsBrowser activityGDocsBrowser = ActivityGDocsBrowser.this;
                    activityGDocsBrowser.showProgress(activityGDocsBrowser.getResources().getString(R.string.label_loading));
                    ActivityGDocsBrowser.this.wt = new Thread() {
                        public void run() {
                            ActivityGDocsBrowser.this.last_error = null;
                            try {
                                StringBuilder sb = new StringBuilder();
                                sb.append("https://www.googleapis.com/drive/v3/files/");
                                sb.append(entry.id);
                                sb.append("?alt=media");
                                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
                                httpURLConnection.setConnectTimeout(15000);
                                httpURLConnection.setReadTimeout(15000);
                                httpURLConnection.setDoInput(true);
                                httpURLConnection.setDoOutput(false);
                                httpURLConnection.setUseCaches(false);
                                httpURLConnection.setRequestMethod("GET");
                                httpURLConnection.setRequestProperty("Connection", "close");
                                httpURLConnection.setRequestProperty("User-Agent", App.getUserAgent());
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append("Bearer ");
                                sb2.append(ActivityGDocsBrowser.this.credentials[1]);
                                httpURLConnection.setRequestProperty("Authorization", sb2.toString());
                                int responseCode = httpURLConnection.getResponseCode();
                                if (responseCode == 200) {
                                    String contentType = httpURLConnection.getContentType();
                                    if (contentType == null) {
                                        contentType = App.getMimeTypeByName(entry.title);
                                    }
                                    int indexOf = contentType.indexOf(";");
                                    if (indexOf > 0) {
                                        contentType = contentType.substring(0, indexOf);
                                    }
                                    int contentLength = httpURLConnection.getContentLength();
                                    File tempDir = App.getTempDir();
                                    StringBuilder sb3 = new StringBuilder();
                                    sb3.append("printershare_temp_file");
                                    sb3.append(App.getExtByMimeType(contentType));
                                    File file = new File(tempDir, sb3.toString());
                                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                                    InputStream inputStream = httpURLConnection.getInputStream();
                                    byte[] bArr = new byte[4096];
                                    int i = 0;
                                    int i2 = 0;
                                    while (true) {
                                        int read = inputStream.read(bArr);
                                        if (read == -1) {
                                            break;
                                        }
                                        fileOutputStream.write(bArr, 0, read);
                                        i += read;
                                        if (contentLength > 0) {
                                            final int i3 = (i * 100) / contentLength;
                                            if (i3 > i2) {
                                                ActivityGDocsBrowser.this.runOnUiThread(new Runnable() {
                                                    public void run() {
                                                        ActivityGDocsBrowser activityGDocsBrowser = ActivityGDocsBrowser.this;
                                                        String string = ActivityGDocsBrowser.this.getResources().getString(R.string.label_loading_progress);
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append(i3);
                                                        sb.append("%");
                                                        activityGDocsBrowser.showProgress(String.format(string, new Object[]{sb.toString()}));
                                                    }
                                                });
                                                i2 = i3;
                                            }
                                        }
                                    }
                                    fileOutputStream.close();
                                    if (file.length() > 0) {
                                        Intent intent = new Intent("android.intent.action.VIEW");
                                        intent.putExtra("temp_file", file.getAbsolutePath());
                                        if (contentType.startsWith("image/")) {
                                            intent.setClass(ActivityGDocsBrowser.this, ActivityPrintPictures.class);
                                        } else if (contentType.equals(NanoHTTPD.MIME_HTML)) {
                                            intent.setClass(ActivityGDocsBrowser.this, ActivityPrintWeb.class);
                                        } else if (contentType.equals("application/pdf")) {
                                            intent.setClass(ActivityGDocsBrowser.this, ActivityPrintPDF.class);
                                        } else {
                                            intent.setClass(ActivityGDocsBrowser.this, ActivityPrintDocuments.class);
                                        }
                                        intent.setDataAndType(Uri.fromFile(file), contentType);
                                        ActivityGDocsBrowser.this.startActivity(intent);
                                    } else {
                                        ActivityGDocsBrowser.this.last_error = "Error: Can't load document. Content-Length=0.";
                                        file.delete();
                                    }
                                } else {
                                    ActivityGDocsBrowser activityGDocsBrowser = ActivityGDocsBrowser.this;
                                    StringBuilder sb4 = new StringBuilder();
                                    sb4.append("Error: HTTP error ");
                                    sb4.append(responseCode);
                                    sb4.append(" ");
                                    sb4.append(httpURLConnection.getResponseMessage());
                                    activityGDocsBrowser.last_error = sb4.toString();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                ActivityGDocsBrowser activityGDocsBrowser2 = ActivityGDocsBrowser.this;
                                StringBuilder sb5 = new StringBuilder();
                                sb5.append("Internal Error: ");
                                sb5.append(e.getMessage());
                                activityGDocsBrowser2.last_error = sb5.toString();
                                App.reportThrowable(e);
                            }
                            ActivityGDocsBrowser.this.wt = null;
                            ActivityGDocsBrowser.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    ActivityGDocsBrowser.this.hideProgress();
                                    if (ActivityGDocsBrowser.this.last_error != null) {
                                        ActivityGDocsBrowser.this.displayLastError(new OnClickListener() {
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    };
                    ActivityGDocsBrowser.this.wt.start();
                }
            }
        });
        FolderAdapter folderAdapter = new FolderAdapter();
        this.adapter = folderAdapter;
        this.list.setAdapter(folderAdapter);
        this.ftoken = false;
        if (!this.new_am) {
            try {
                if (VERSION.class.getField(str).getInt(null) >= 23) {
                    z = true;
                    if (!z) {
                        final boolean[] zArr = new boolean[1];
                        new Object() {
                            {
                                String str = "android.permission.GET_ACCOUNTS";
                                if (ActivityGDocsBrowser.this.checkSelfPermission(str) != 0) {
                                    ActivityGDocsBrowser.this.al = new String[0];
                                    ActivityGDocsBrowser.this.requestPermissions(new String[]{str}, 444555);
                                    zArr[0] = true;
                                }
                            }
                        };
                        if (zArr[0]) {
                        }
                        return;
                    }
                    return;
                }
            } catch (NoSuchFieldException unused2) {
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
            z = false;
            if (!z) {
            }
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.al = null;
        xinit();
    }

    /* access modifiers changed from: private */
    public void chooseAccount() {
        if (this.new_am) {
            new Object() {
                {
                    ActivityGDocsBrowser.this.startActivityForResult(AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null), 444555);
                }
            };
        } else {
            this.accounts_menu.show();
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && i == 444555) {
            String stringExtra = intent.getStringExtra("authAccount");
            if (stringExtra != null) {
                Object systemService = getSystemService("account");
                try {
                    Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
                    this.al_objs = objArr;
                    if (objArr != null) {
                        this.al = new String[objArr.length];
                        if (objArr.length > 0) {
                            Field field = objArr[0].getClass().getField("name");
                            for (int i3 = 0; i3 < objArr.length; i3++) {
                                this.al[i3] = (String) field.get(objArr[i3]);
                            }
                        }
                    }
                    showAccount(stringExtra);
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    /* access modifiers changed from: private */
    public void xinit() {
        Object systemService = getSystemService("account");
        try {
            Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
            this.al_objs = objArr;
            if (objArr != null) {
                this.al = new String[objArr.length];
                if (objArr.length > 0) {
                    Field field = objArr[0].getClass().getField("name");
                    for (int i = 0; i < objArr.length; i++) {
                        this.al[i] = (String) field.get(objArr[i]);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        xinit_done();
    }

    private void xinit_done() {
        this.wt = null;
        runOnUiThread(new Runnable() {
            public void run() {
                String str = null;
                String string = ActivityGDocsBrowser.this.prefs.getString("gdocs_account", null);
                int length = (ActivityGDocsBrowser.this.al != null ? ActivityGDocsBrowser.this.al.length : 0) + 1;
                CharSequence[] charSequenceArr = new CharSequence[length];
                if (ActivityGDocsBrowser.this.al != null && ActivityGDocsBrowser.this.al.length > 0) {
                    for (int i = 0; i < ActivityGDocsBrowser.this.al.length; i++) {
                        charSequenceArr[i] = ActivityGDocsBrowser.this.al[i];
                        if (ActivityGDocsBrowser.this.al[i].equals(string)) {
                            str = string;
                        }
                    }
                }
                charSequenceArr[length - 1] = ActivityGDocsBrowser.this.getResources().getString(R.string.menu_add_account);
                ActivityGDocsBrowser.this.accounts_menu = new Builder(ActivityGDocsBrowser.this).setIcon(R.drawable.icon_title).setTitle(R.string.menu_accounts).setItems(charSequenceArr, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ActivityGDocsBrowser.this.al == null || i >= ActivityGDocsBrowser.this.al.length) {
                            final Object systemService = ActivityGDocsBrowser.this.getSystemService("account");
                            ActivityGDocsBrowser.this.wt = new Thread() {
                                public void run() {
                                    Method method;
                                    try {
                                        Method[] methods = systemService.getClass().getMethods();
                                        int i = 0;
                                        while (true) {
                                            if (i >= methods.length) {
                                                method = null;
                                                break;
                                            } else if ("addAccount".equals(methods[i].getName())) {
                                                method = methods[i];
                                                break;
                                            } else {
                                                i++;
                                            }
                                        }
                                        Object invoke = method.invoke(systemService, new Object[]{"com.google", null, null, null, ActivityGDocsBrowser.this, null, null});
                                        String string = ((Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0])).getString("authAccount");
                                        if (string != null) {
                                            Editor edit = ActivityGDocsBrowser.this.prefs.edit();
                                            edit.putString("gdocs_account", string);
                                            edit.commit();
                                            ActivityGDocsBrowser.this.xinit();
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                }
                            };
                            ActivityGDocsBrowser.this.wt.start();
                            return;
                        }
                        ActivityGDocsBrowser.this.showAccount(ActivityGDocsBrowser.this.al[i]);
                    }
                }).create();
                if (str != null) {
                    ActivityGDocsBrowser.this.showAccount(str);
                    return;
                }
                ActivityGDocsBrowser.this.hideProgress();
                if (!ActivityGDocsBrowser.this.isFinishing()) {
                    ActivityGDocsBrowser.this.chooseAccount();
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void showAccount(final String str) {
        showProgress(getResources().getString(R.string.label_processing));
        Editor edit = this.prefs.edit();
        edit.putString("gdocs_account", str);
        edit.commit();
        ((TextView) findViewById(R.id.hint1)).setText("My Drive");
        ((TextView) findViewById(R.id.hint2)).setText("");
        AnonymousClass6 r0 = new Thread() {
            public void run() {
                ActivityGDocsBrowser.this.authorize(str);
            }
        };
        this.wt = r0;
        r0.start();
    }

    /* access modifiers changed from: private */
    public void authorize(String str) {
        Method method;
        String[] strArr = new String[2];
        this.credentials = strArr;
        strArr[0] = str;
        this.data.clear();
        runOnUiThread(new Runnable() {
            public void run() {
                ActivityGDocsBrowser.this.adapter.changeFolder(null);
            }
        });
        Object systemService = getSystemService("account");
        Object[] objArr = this.al_objs;
        if (objArr != null && objArr.length > 0) {
            int i = 0;
            while (true) {
                try {
                    if (i >= this.al.length) {
                        i = 0;
                        break;
                    } else if (this.al[i].equals(str)) {
                        break;
                    } else {
                        i++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            Method[] methods = systemService.getClass().getMethods();
            int i2 = 0;
            while (true) {
                if (i2 < methods.length) {
                    if ("getAuthToken".equals(methods[i2].getName()) && methods[i2].getParameterTypes().length == 5) {
                        method = methods[i2];
                        break;
                    }
                    i2++;
                } else {
                    method = null;
                    break;
                }
            }
            Object invoke = method.invoke(systemService, new Object[]{this.al_objs[i], "oauth2:https://www.googleapis.com/auth/drive.readonly", Boolean.valueOf(false), null, this.handler});
            Bundle bundle = (Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0]);
            Intent intent = (Intent) bundle.getParcelable("intent");
            if (intent == null) {
                this.credentials[1] = bundle.getString("authtoken");
                if (requesting_credentials == 1) {
                    requesting_credentials = 0;
                }
            } else if (requesting_credentials == 0) {
                requesting_credentials = 1;
                startActivity(intent);
                this.wt = null;
                return;
            }
        }
        requesting_credentials = 0;
        authorize_done();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.al == null || requesting_credentials != 0) {
            showProgress(getResources().getString(R.string.label_processing));
            AnonymousClass8 r0 = new Thread() {
                public void run() {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException unused) {
                    }
                    ActivityGDocsBrowser.this.xinit();
                }
            };
            this.wt = r0;
            r0.start();
        }
    }

    /* access modifiers changed from: private */
    public boolean loadFolder(String str) {
        String str2 = "gzip";
        Method method = null;
        this.last_error = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("https://www.googleapis.com/drive/v3/files?spaces=drive&maxResults=1000&q='");
            sb.append(str);
            sb.append("'+in+parents");
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(false);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setRequestProperty("Connection", "close");
            StringBuilder sb2 = new StringBuilder();
            sb2.append(App.getUserAgent());
            sb2.append(" (gzip)");
            httpURLConnection.setRequestProperty("User-Agent", sb2.toString());
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Bearer ");
            sb3.append(this.credentials[1]);
            httpURLConnection.setRequestProperty("Authorization", sb3.toString());
            httpURLConnection.setRequestProperty("Accept-Encoding", str2);
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == 200) {
                GFileList gFileList = (GFileList) Json.read(new BufferedInputStream(str2.equals(httpURLConnection.getContentEncoding()) ? new GZIPInputStream(httpURLConnection.getInputStream()) : httpURLConnection.getInputStream()), GFileList.class);
                if (gFileList.files != null) {
                    for (int i = 0; i < gFileList.files.size(); i++) {
                        this.data.add(new Entry(str, (GFile) gFileList.files.get(i)));
                    }
                }
                return true;
            } else if ((responseCode == 403 || responseCode == 401 || "Token expired".equalsIgnoreCase(httpURLConnection.getResponseMessage())) && !this.ftoken) {
                this.ftoken = true;
                Object systemService = getSystemService("account");
                try {
                    Method[] methods = systemService.getClass().getMethods();
                    int i2 = 0;
                    while (true) {
                        if (i2 < methods.length) {
                            if ("invalidateAuthToken".equals(methods[i2].getName()) && methods[i2].getParameterTypes().length == 2) {
                                method = methods[i2];
                                break;
                            }
                            i2++;
                        } else {
                            break;
                        }
                    }
                    method.invoke(systemService, new Object[]{"com.google", this.credentials[1]});
                    authorize(this.credentials[0]);
                    return false;
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            } else {
                StringBuilder sb4 = new StringBuilder();
                sb4.append("Error: HTTP error ");
                sb4.append(responseCode);
                sb4.append(" ");
                sb4.append(httpURLConnection.getResponseMessage());
                this.last_error = sb4.toString();
                return false;
            }
        } catch (Exception e2) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append("Internal Error: ");
            sb5.append(e2.getMessage());
            this.last_error = sb5.toString();
            e2.printStackTrace();
            App.reportThrowable(e2);
        }
    }

    private void authorize_done() {
        this.last_error = null;
        if (this.credentials[1] != null) {
            String str = "gdocs_account";
            if (this.prefs.getString(str, null) == null) {
                Editor edit = this.prefs.edit();
                edit.putString(str, this.credentials[0]);
                edit.commit();
            }
            if (!loadFolder("root") && this.last_error == null) {
                return;
            }
        } else {
            this.last_error = "Error: Authorization failed or network error has occured";
        }
        this.wt = null;
        runOnUiThread(new Runnable() {
            public void run() {
                ActivityGDocsBrowser.this.adapter.changeFolder(null);
                ActivityGDocsBrowser.this.hideProgress();
                if (ActivityGDocsBrowser.this.last_error == null) {
                    ((TextView) ActivityGDocsBrowser.this.findViewById(R.id.hint2)).setText(ActivityGDocsBrowser.this.credentials[0]);
                } else {
                    ActivityGDocsBrowser.this.displayLastError(new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (!ActivityGDocsBrowser.this.isFinishing()) {
                                ActivityGDocsBrowser.this.chooseAccount();
                            }
                        }
                    });
                }
            }
        });
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || this.adapter.chain.size() <= 0) {
            return super.onKeyDown(i, keyEvent);
        }
        FolderAdapter folderAdapter = this.adapter;
        folderAdapter.changeFolder(folderAdapter.chain.size() > 1 ? (Entry) this.adapter.chain.get(this.adapter.chain.size() - 2) : null);
        return true;
    }
}
