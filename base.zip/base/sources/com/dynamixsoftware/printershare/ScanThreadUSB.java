package com.dynamixsoftware.printershare;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

public class ScanThreadUSB extends Thread {
    public static final String ACTION_USB_PERMISSION = "PRINTERSHARE_USB_PERMISSION";
    private Context context;
    private boolean[] destroyed = new boolean[1];
    private Vector<Printer> printers;
    private String rq_pid;
    private Handler status;

    public ScanThreadUSB(Context context2, int i, String str, Handler handler) {
        this.context = context2;
        this.rq_pid = str;
        this.status = handler;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
            interrupt();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:243:0x042f, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
        r10 = (android.hardware.usb.UsbDevice) r9.next();
        r11 = 2;
        r12 = new com.dynamixsoftware.printershare.data.Printer[2];
        r13 = 0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0053 A[SYNTHETIC, Splitter:B:18:0x0053] */
    /* JADX WARNING: Removed duplicated region for block: B:253:0x0470  */
    /* JADX WARNING: Removed duplicated region for block: B:254:0x048e  */
    /* JADX WARNING: Removed duplicated region for block: B:255:0x0450 A[EDGE_INSN: B:255:0x0450->B:250:0x0450 ?: BREAK  
EDGE_INSN: B:255:0x0450->B:250:0x0450 ?: BREAK  
EDGE_INSN: B:255:0x0450->B:250:0x0450 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:255:0x0450 A[EDGE_INSN: B:255:0x0450->B:250:0x0450 ?: BREAK  
EDGE_INSN: B:255:0x0450->B:250:0x0450 ?: BREAK  , SYNTHETIC] */
    public void run() {
        String str;
        ScanThreadUSB scanThreadUSB;
        boolean z;
        UsbManager usbManager;
        Iterator it;
        Iterator it2;
        UsbManager usbManager2;
        boolean z2;
        final UsbDevice usbDevice;
        int i;
        Printer[] printerArr;
        int i2;
        Printer printer;
        String str2;
        String str3;
        UsbDeviceConnection usbDeviceConnection;
        UsbDeviceConnection usbDeviceConnection2;
        String str4;
        String str5;
        int controlTransfer;
        int i3;
        ScanThreadUSB scanThreadUSB2 = this;
        Message message = new Message();
        message.what = 1;
        message.arg1 = 4;
        scanThreadUSB2.status.sendMessage(message);
        char c = 0;
        try {
            z = VERSION.class.getField("SDK_INT").getInt(null) >= 21;
        } catch (NoSuchFieldException unused) {
            z = false;
            usbManager = (UsbManager) scanThreadUSB2.context.getSystemService("usb");
            it = usbManager.getDeviceList().values().iterator();
            while (true) {
                if (!it.hasNext()) {
                }
                scanThreadUSB2 = scanThreadUSB;
                z = z2;
                usbManager = usbManager2;
                it = it2;
                c = 0;
            }
            scanThreadUSB = scanThreadUSB2;
            str = null;
            if (str == null) {
            }
        } catch (Exception e) {
            try {
                e.printStackTrace();
                App.reportThrowable(e);
                z = false;
                usbManager = (UsbManager) scanThreadUSB2.context.getSystemService("usb");
                it = usbManager.getDeviceList().values().iterator();
                while (true) {
                    if (!it.hasNext()) {
                    }
                    scanThreadUSB2 = scanThreadUSB;
                    z = z2;
                    usbManager = usbManager2;
                    it = it2;
                    c = 0;
                }
                scanThreadUSB = scanThreadUSB2;
                str = null;
            } catch (Exception e2) {
                e = e2;
                scanThreadUSB = scanThreadUSB2;
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e.getMessage());
                str = sb.toString();
                e.printStackTrace();
                App.reportThrowable(e);
                if (str == null) {
                }
            }
            if (str == null) {
            }
        }
        usbManager = (UsbManager) scanThreadUSB2.context.getSystemService("usb");
        it = usbManager.getDeviceList().values().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            try {
                synchronized (scanThreadUSB2.destroyed) {
                    try {
                        if (scanThreadUSB2.destroyed[c]) {
                        }
                    } catch (Exception e3) {
                        e = e3;
                    } catch (Throwable th) {
                        th = th;
                        scanThreadUSB = scanThreadUSB2;
                        z2 = z;
                        usbManager2 = usbManager;
                        it2 = it;
                        while (true) {
                            break;
                        }
                        throw th;
                    }
                }
            } catch (Exception e4) {
                e = e4;
                scanThreadUSB = scanThreadUSB2;
                z2 = z;
                usbManager2 = usbManager;
                it2 = it;
                try {
                    e.printStackTrace();
                    App.reportThrowable(e);
                    scanThreadUSB2 = scanThreadUSB;
                    z = z2;
                    usbManager = usbManager2;
                    it = it2;
                    c = 0;
                } catch (Exception e5) {
                    e = e5;
                }
            }
            scanThreadUSB2 = scanThreadUSB;
            z = z2;
            usbManager = usbManager2;
            it = it2;
            c = 0;
        }
        scanThreadUSB = scanThreadUSB2;
        str = null;
        if (str == null) {
            Message message2 = new Message();
            message2.what = 3;
            message2.arg1 = 4;
            Bundle bundle = new Bundle();
            bundle.putString("message", str);
            message2.setData(bundle);
            scanThreadUSB.status.sendMessage(message2);
            return;
        }
        Message message3 = new Message();
        message3.what = 4;
        message3.arg1 = 4;
        scanThreadUSB.status.sendMessage(message3);
        return;
        while (i2 < usbDevice.getInterfaceCount()) {
            try {
                UsbInterface usbInterface = usbDevice.getInterface(i2);
                int i4 = -1;
                int i5 = -1;
                for (int i6 = 0; i6 < usbInterface.getEndpointCount(); i6++) {
                    UsbEndpoint endpoint = usbInterface.getEndpoint(i6);
                    if (i4 == -1 && endpoint.getType() == i && endpoint.getDirection() == 128) {
                        i4 = i6;
                    }
                    if (i5 == -1 && endpoint.getType() == i && endpoint.getDirection() == 0) {
                        i5 = i6;
                    }
                }
                if (i5 != -1 && ((usbInterface.getInterfaceClass() == 7 && usbInterface.getInterfaceProtocol() < 3) || !(usbInterface.getInterfaceClass() != 10 || usbDevice.getVendorId() == 5401 || usbDevice.getVendorId() == 1228))) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(usbDevice.getDeviceId());
                    sb2.append("_");
                    sb2.append(usbDevice.getVendorId());
                    sb2.append("_");
                    sb2.append(usbDevice.getProductId());
                    String sb3 = sb2.toString();
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(sb3);
                    sb4.append("._pdl-datastream._usb.local.");
                    String sb5 = sb4.toString();
                    if (scanThreadUSB2.rq_pid == null || sb5.equals(scanThreadUSB2.rq_pid)) {
                        if (!usbManager.hasPermission(usbDevice)) {
                            AnonymousClass1 r4 = new BroadcastReceiver() {
                                public void onReceive(Context context, Intent intent) {
                                    if (ScanThreadUSB.ACTION_USB_PERMISSION.equals(intent.getAction())) {
                                        synchronized (this) {
                                            notifyAll();
                                        }
                                    }
                                }
                            };
                            scanThreadUSB2.context.registerReceiver(r4, new IntentFilter(ACTION_USB_PERMISSION));
                            synchronized (r4) {
                                usbManager.requestPermission(usbDevice, PendingIntent.getBroadcast(scanThreadUSB2.context, 0, new Intent(ACTION_USB_PERMISSION), 0));
                                r4.wait();
                            }
                            scanThreadUSB2.context.unregisterReceiver(r4);
                        }
                        if (usbManager.hasPermission(usbDevice)) {
                            UsbDeviceConnection openDevice = usbManager.openDevice(usbDevice);
                            if (openDevice != null) {
                                openDevice.claimInterface(usbInterface, true);
                                final String[] strArr = new String[3];
                                if (z) {
                                    new Object() {
                                        {
                                            strArr[0] = usbDevice.getManufacturerName();
                                            strArr[1] = usbDevice.getProductName();
                                            strArr[2] = usbDevice.getSerialNumber();
                                        }
                                    };
                                }
                                byte[] bArr = new byte[1024];
                                int i7 = 4;
                                int i8 = 1;
                                while (i8 < i7) {
                                    int i9 = i8 | 768;
                                    z2 = z;
                                    try {
                                        controlTransfer = openDevice.controlTransfer(128, 6, i9, 1033, bArr, 1024, 3000);
                                        usbManager2 = usbManager;
                                        i3 = 2;
                                        if (controlTransfer < 2) {
                                            try {
                                                controlTransfer = openDevice.controlTransfer(128, 6, i9, 0, bArr, 1024, 3000);
                                                i3 = 2;
                                                if (controlTransfer < 2) {
                                                    it2 = it;
                                                    i8++;
                                                    i7 = 4;
                                                    z = z2;
                                                    usbManager = usbManager2;
                                                    it = it2;
                                                }
                                            } catch (Exception e6) {
                                                e = e6;
                                                it2 = it;
                                                try {
                                                    e.printStackTrace();
                                                    App.reportThrowable(e);
                                                    i2++;
                                                    z = z2;
                                                    usbManager = usbManager2;
                                                    it = it2;
                                                    i = 2;
                                                    scanThreadUSB2 = this;
                                                } catch (Exception e7) {
                                                    e = e7;
                                                }
                                            }
                                        }
                                        it2 = it;
                                    } catch (Exception e8) {
                                        e = e8;
                                        usbManager2 = usbManager;
                                        it2 = it;
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                        i2++;
                                        z = z2;
                                        usbManager = usbManager2;
                                        it = it2;
                                        i = 2;
                                        scanThreadUSB2 = this;
                                    }
                                    try {
                                        strArr[i8 - 1] = new String(bArr, i3, controlTransfer - i3, SmbConstants.UNI_ENCODING);
                                        i8++;
                                        i7 = 4;
                                        z = z2;
                                        usbManager = usbManager2;
                                        it = it2;
                                    } catch (Exception e9) {
                                        e = e9;
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                        i2++;
                                        z = z2;
                                        usbManager = usbManager2;
                                        it = it2;
                                        i = 2;
                                        scanThreadUSB2 = this;
                                    }
                                }
                                z2 = z;
                                usbManager2 = usbManager;
                                it2 = it;
                                String str6 = strArr[0];
                                String str7 = strArr[1];
                                String str8 = strArr[2];
                                int controlTransfer2 = openDevice.controlTransfer(161, 0, 0, usbInterface.getId() << 8, bArr, 1024, 3000);
                                String str9 = controlTransfer2 > 2 ? new String(bArr, 2, controlTransfer2 - 2) : null;
                                if (str9 != null) {
                                    String[] split = str9.split(";");
                                    str3 = null;
                                    str2 = null;
                                    int i10 = 0;
                                    while (i10 < split.length) {
                                        String[] strArr2 = split;
                                        String[] split2 = split[i10].split(":");
                                        String str10 = str3;
                                        if (split2.length < 2) {
                                            str5 = str6;
                                        } else {
                                            str5 = str6;
                                            if (!"MFG".equals(split2[0]) && !"MFR".equals(split2[0])) {
                                                if (!"MANUFACTURER".equals(split2[0])) {
                                                    if (!"MDL".equals(split2[0])) {
                                                        if (!"MODEL".equals(split2[0])) {
                                                            if (!"CMD".equals(split2[0])) {
                                                                if (!"COMMAND SET".equals(split2[0])) {
                                                                    if ("URF".equals(split2[0])) {
                                                                        str2 = split2[1];
                                                                    }
                                                                }
                                                            }
                                                            str3 = split2[1];
                                                            str6 = str5;
                                                            i10++;
                                                            split = strArr2;
                                                        }
                                                    }
                                                    str7 = split2[1];
                                                }
                                            }
                                            str6 = split2[1];
                                            str3 = str10;
                                            i10++;
                                            split = strArr2;
                                        }
                                        str3 = str10;
                                        str6 = str5;
                                        i10++;
                                        split = strArr2;
                                    }
                                    String str11 = str3;
                                    String str12 = str6;
                                } else {
                                    str3 = null;
                                    str2 = null;
                                }
                                String fullModelName = App.getFullModelName(str6, str7);
                                if (fullModelName != null && fullModelName.indexOf("lific Technology Inc. IEEE-1284 Controller") > 0) {
                                    fullModelName = "GWP-80 Mini Printer";
                                }
                                if (usbDevice.getVendorId() == 1155 && usbDevice.getProductId() == 41043) {
                                    fullModelName = "Able Ap1400";
                                }
                                if (fullModelName == null && usbDevice.getVendorId() == 1008 && usbDevice.getProductId() == 15127) {
                                    fullModelName = "HP LaserJet M1005";
                                }
                                char c2 = usbInterface.getInterfaceProtocol() == 2 ? (char) 1 : 0;
                                if (printerArr[c2] == null) {
                                    printerArr[c2] = new Printer();
                                    printerArr[c2].id = sb5;
                                    printerArr[c2].owner = new User();
                                    User user = printerArr[c2].owner;
                                    StringBuilder sb6 = new StringBuilder();
                                    UsbInterface usbInterface2 = usbInterface;
                                    sb6.append("USB");
                                    if (str8 != null) {
                                        StringBuilder sb7 = new StringBuilder();
                                        usbDeviceConnection2 = openDevice;
                                        sb7.append(" [");
                                        sb7.append(str8);
                                        sb7.append("]");
                                        str4 = sb7.toString();
                                    } else {
                                        usbDeviceConnection2 = openDevice;
                                        str4 = "";
                                    }
                                    sb6.append(str4);
                                    user.name = sb6.toString();
                                    Printer printer2 = printerArr[c2];
                                    StringBuilder sb8 = new StringBuilder();
                                    sb8.append("usb://");
                                    sb8.append(usbDevice.getDeviceName());
                                    sb8.append("|");
                                    sb8.append(i2);
                                    sb8.append("|");
                                    sb8.append(i5);
                                    sb8.append("|");
                                    sb8.append(i4);
                                    printer2.direct_address = sb8.toString();
                                    printerArr[c2].title = fullModelName != null ? fullModelName : "USB Printer";
                                    Printer printer3 = printerArr[c2];
                                    if (fullModelName == null) {
                                        fullModelName = "";
                                    }
                                    printer3.model = fullModelName;
                                    printerArr[c2].capabilities = new Hashtable<>();
                                    if (str6 != null) {
                                        printerArr[c2].capabilities.put("usb_MFG", str6);
                                    }
                                    if (str7 != null) {
                                        printerArr[c2].capabilities.put("usb_MDL", str7);
                                    }
                                    if (str3 != null) {
                                        printerArr[c2].capabilities.put("usb_CMD", str3);
                                    }
                                    if (str2 != null) {
                                        printerArr[c2].capabilities.put("URF", str2);
                                    }
                                    usbInterface = usbInterface2;
                                    usbDeviceConnection = usbDeviceConnection2;
                                } else {
                                    usbDeviceConnection = openDevice;
                                }
                                usbDeviceConnection.releaseInterface(usbInterface);
                                usbDeviceConnection.close();
                                i2++;
                                z = z2;
                                usbManager = usbManager2;
                                it = it2;
                                i = 2;
                                scanThreadUSB2 = this;
                            }
                        }
                    }
                }
                z2 = z;
                usbManager2 = usbManager;
                it2 = it;
            } catch (Exception e10) {
                e = e10;
                z2 = z;
            }
            i2++;
            z = z2;
            usbManager = usbManager2;
            it = it2;
            i = 2;
            scanThreadUSB2 = this;
        }
        z2 = z;
        usbManager2 = usbManager;
        it2 = it;
        try {
            if (printerArr[1] != null) {
                printer = printerArr[1];
            } else {
                try {
                    printer = printerArr[0];
                } catch (Exception e11) {
                    e = e11;
                    scanThreadUSB = this;
                    e.printStackTrace();
                    App.reportThrowable(e);
                    scanThreadUSB2 = scanThreadUSB;
                    z = z2;
                    usbManager = usbManager2;
                    it = it2;
                    c = 0;
                }
            }
            if (printer != null) {
                scanThreadUSB = this;
                synchronized (scanThreadUSB.printers) {
                    scanThreadUSB.printers.add(printer);
                }
                Message message4 = new Message();
                message4.what = 2;
                message4.arg1 = 4;
                scanThreadUSB.status.sendMessage(message4);
                if (scanThreadUSB.rq_pid != null && scanThreadUSB.rq_pid.equals(printer.id)) {
                    destroy();
                }
            } else {
                scanThreadUSB = this;
            }
        } catch (Exception e12) {
            e = e12;
            scanThreadUSB = this;
            e.printStackTrace();
            App.reportThrowable(e);
            scanThreadUSB2 = scanThreadUSB;
            z = z2;
            usbManager = usbManager2;
            it = it2;
            c = 0;
        }
        scanThreadUSB2 = scanThreadUSB;
        z = z2;
        usbManager = usbManager2;
        it = it2;
        c = 0;
    }
}
