package com.dynamixsoftware.printershare.gmail;

import com.flurry.android.Constants;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

public class ProtoBuf {
    public static final Boolean FALSE = new Boolean(false);
    private static final String MSG_EOF = "Unexp.EOF";
    private static final String MSG_MISMATCH = "Type mismatch";
    private static final String MSG_UNSUPPORTED = "Unsupp.Type";
    private static Long[] SMALL_NUMBERS = {new Long(0), new Long(1), new Long(2), new Long(3), new Long(4), new Long(5), new Long(6), new Long(7), new Long(8), new Long(9), new Long(10), new Long(11), new Long(12), new Long(13), new Long(14), new Long(15)};
    public static final Boolean TRUE = new Boolean(true);
    private static final int VARINT_MAX_BYTES = 10;
    static final int WIRETYPE_END_GROUP = 4;
    static final int WIRETYPE_FIXED32 = 5;
    static final int WIRETYPE_FIXED64 = 1;
    static final int WIRETYPE_LENGTH_DELIMITED = 2;
    static final int WIRETYPE_START_GROUP = 3;
    static final int WIRETYPE_VARINT = 0;
    private ProtoBufType msgType;
    private final Vector values = new Vector();
    private final StringBuffer wireTypes = new StringBuffer();

    private static int getVarIntSize(long j) {
        if (j < 0) {
            return 10;
        }
        int i = 1;
        while (j >= 128) {
            i++;
            j >>= 7;
        }
        return i;
    }

    private static long zigZagDecode(long j) {
        return (-(j & 1)) ^ (j >>> 1);
    }

    private static long zigZagEncode(long j) {
        return (-(j >>> 63)) ^ (j << 1);
    }

    public ProtoBuf(ProtoBufType protoBufType) {
        this.msgType = protoBufType;
    }

    public void clear() {
        this.values.setSize(0);
        this.wireTypes.setLength(0);
    }

    public ProtoBuf newProtoBufForTag(int i) {
        return new ProtoBuf((ProtoBufType) this.msgType.getData(i));
    }

    public ProtoBuf setNewProtoBuf(int i) {
        ProtoBuf newProtoBufForTag = newProtoBufForTag(i);
        addProtoBuf(i, newProtoBufForTag);
        return newProtoBufForTag;
    }

    public ProtoBuf createGroup(int i) {
        return new ProtoBuf((ProtoBufType) getType().getData(i));
    }

    public void addBool(int i, boolean z) {
        insertBool(i, getCount(i), z);
    }

    public void addBytes(int i, byte[] bArr) {
        insertBytes(i, getCount(i), bArr);
    }

    public void addInt(int i, int i2) {
        insertInt(i, getCount(i), i2);
    }

    public void addLong(int i, long j) {
        insertLong(i, getCount(i), j);
    }

    public void addFloat(int i, float f) {
        insertFloat(i, getCount(i), f);
    }

    public void addDouble(int i, double d) {
        insertDouble(i, getCount(i), d);
    }

    public void addProtoBuf(int i, ProtoBuf protoBuf) {
        insertProtoBuf(i, getCount(i), protoBuf);
    }

    public void addString(int i, String str) {
        insertString(i, getCount(i), str);
    }

    public boolean getBool(int i) {
        Object object = getObject(i, 24);
        if (object != null) {
            return ((Boolean) object).booleanValue();
        }
        return false;
    }

    public boolean getBool(int i, int i2) {
        return ((Boolean) getObject(i, i2, 24)).booleanValue();
    }

    public byte[] getBytes(int i) {
        return (byte[]) getObject(i, 25);
    }

    public byte[] getBytes(int i, int i2) {
        return (byte[]) getObject(i, i2, 25);
    }

    public int getInt(int i) {
        return (int) ((Long) getObject(i, 21)).longValue();
    }

    public int getInt(int i, int i2) {
        return (int) ((Long) getObject(i, i2, 21)).longValue();
    }

    public long getLong(int i) {
        return ((Long) getObject(i, 19)).longValue();
    }

    public long getLong(int i, int i2) {
        return ((Long) getObject(i, i2, 19)).longValue();
    }

    public float getFloat(int i) {
        return Float.intBitsToFloat(getInt(i));
    }

    public float getFloat(int i, int i2) {
        return Float.intBitsToFloat(getInt(i, i2));
    }

    public double getDouble(int i) {
        return Double.longBitsToDouble(getLong(i));
    }

    public double getDouble(int i, int i2) {
        return Double.longBitsToDouble(getLong(i, i2));
    }

    public ProtoBuf getProtoBuf(int i) {
        return (ProtoBuf) getObject(i, 26);
    }

    public ProtoBuf getProtoBuf(int i, int i2) {
        return (ProtoBuf) getObject(i, i2, 26);
    }

    public String getString(int i) {
        return (String) getObject(i, 28);
    }

    public String getString(int i, int i2) {
        return (String) getObject(i, i2, 28);
    }

    public ProtoBufType getType() {
        return this.msgType;
    }

    /* access modifiers changed from: 0000 */
    public void setType(ProtoBufType protoBufType) {
        if (this.values.size() == 0) {
            ProtoBufType protoBufType2 = this.msgType;
            if (protoBufType2 == null || protoBufType == null || protoBufType == protoBufType2) {
                this.msgType = protoBufType;
                return;
            }
        }
        throw new IllegalArgumentException();
    }

    public boolean has(int i) {
        return getCount(i) > 0 || getDefault(i) != null;
    }

    public ProtoBuf parse(byte[] bArr) throws IOException {
        parse(new ByteArrayInputStream(bArr), bArr.length);
        return this;
    }

    public ProtoBuf parse(InputStream inputStream) throws IOException {
        parse(inputStream, Integer.MAX_VALUE);
        return this;
    }

    public int parse(InputStream inputStream, int i) throws IOException {
        Object obj;
        Object obj2;
        ProtoBufType protoBufType;
        clear();
        while (i > 0) {
            long readVarInt = readVarInt(inputStream, true);
            if (readVarInt == -1) {
                break;
            }
            i -= getVarIntSize(readVarInt);
            int i2 = ((int) readVarInt) & 7;
            int i3 = 4;
            if (i2 == 4) {
                break;
            }
            int i4 = (int) (readVarInt >>> 3);
            while (this.wireTypes.length() <= i4) {
                this.wireTypes.append(16);
            }
            this.wireTypes.setCharAt(i4, (char) i2);
            int i5 = 0;
            if (i2 != 0) {
                if (i2 != 1) {
                    if (i2 == 2) {
                        int readVarInt2 = (int) readVarInt(inputStream, false);
                        i = (i - getVarIntSize((long) readVarInt2)) - readVarInt2;
                        if (getType(i4) == 27) {
                            ProtoBuf protoBuf = new ProtoBuf((ProtoBufType) this.msgType.getData(i4));
                            protoBuf.parse(inputStream, readVarInt2);
                            obj = protoBuf;
                        } else {
                            byte[] bArr = new byte[readVarInt2];
                            while (i5 < readVarInt2) {
                                int read = inputStream.read(bArr, i5, readVarInt2 - i5);
                                if (read > 0) {
                                    i5 += read;
                                } else {
                                    throw new IOException(MSG_EOF);
                                }
                            }
                            obj2 = bArr;
                        }
                    } else if (i2 == 3) {
                        ProtoBufType protoBufType2 = this.msgType;
                        if (protoBufType2 == null) {
                            protoBufType = null;
                        } else {
                            protoBufType = (ProtoBufType) protoBufType2.getData(i4);
                        }
                        ProtoBuf protoBuf2 = new ProtoBuf(protoBufType);
                        i = protoBuf2.parse(inputStream, i);
                        obj = protoBuf2;
                    } else if (i2 != 5) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(MSG_UNSUPPORTED);
                        sb.append(i2);
                        throw new RuntimeException(sb.toString());
                    }
                    insertObject(i4, getCount(i4), obj);
                }
                if (i2 != 5) {
                    i3 = 8;
                }
                i -= i3;
                long j = 0;
                while (true) {
                    int i6 = i3 - 1;
                    if (i3 <= 0) {
                        break;
                    }
                    j |= ((long) inputStream.read()) << i5;
                    i5 += 8;
                    i3 = i6;
                }
                if (j >= 0) {
                    Object[] objArr = SMALL_NUMBERS;
                    if (j < ((long) objArr.length)) {
                        obj = objArr[(int) j];
                        insertObject(i4, getCount(i4), obj);
                    }
                }
                obj = new Long(j);
                insertObject(i4, getCount(i4), obj);
            } else {
                long readVarInt3 = readVarInt(inputStream, false);
                i -= getVarIntSize(readVarInt3);
                if (isZigZagEncodedType(i4)) {
                    readVarInt3 = zigZagDecode(readVarInt3);
                }
                if (readVarInt3 >= 0) {
                    Object[] objArr2 = SMALL_NUMBERS;
                    if (readVarInt3 < ((long) objArr2.length)) {
                        obj = objArr2[(int) readVarInt3];
                        insertObject(i4, getCount(i4), obj);
                    }
                }
                obj2 = new Long(readVarInt3);
            }
            obj = obj2;
            insertObject(i4, getCount(i4), obj);
        }
        if (i >= 0) {
            return i;
        }
        throw new IOException();
    }

    public void remove(int i, int i2) {
        int count = getCount(i);
        if (i2 >= count) {
            throw new ArrayIndexOutOfBoundsException();
        } else if (count == 1) {
            this.values.setElementAt(null, i);
        } else {
            ((Vector) this.values.elementAt(i)).removeElementAt(i2);
        }
    }

    public int getCount(int i) {
        if (i >= this.values.size()) {
            return 0;
        }
        Object elementAt = this.values.elementAt(i);
        if (elementAt == null) {
            return 0;
        }
        return elementAt instanceof Vector ? ((Vector) elementAt).size() : 1;
    }

    public int getType(int i) {
        ProtoBufType protoBufType = this.msgType;
        int type = protoBufType != null ? protoBufType.getType(i) : 16;
        if (type == 16 && i < this.wireTypes.length()) {
            type = this.wireTypes.charAt(i);
        }
        if (type != 16 || getCount(i) <= 0) {
            return type;
        }
        Object object = getObject(i, 0, 16);
        if ((object instanceof Long) || (object instanceof Boolean)) {
            return 0;
        }
        return 2;
    }

    public int getDataSize() {
        int i = 0;
        for (int i2 = 0; i2 <= maxTag(); i2++) {
            for (int i3 = 0; i3 < getCount(i2); i3++) {
                i += getDataSize(i2, i3);
            }
        }
        return i;
    }

    private int getDataSize(int i, int i2) {
        int i3;
        int varIntSize = getVarIntSize((long) (i << 3));
        int wireType = getWireType(i);
        if (wireType == 0) {
            long j = getLong(i, i2);
            if (isZigZagEncodedType(i)) {
                j = zigZagEncode(j);
            }
            return varIntSize + getVarIntSize(j);
        } else if (wireType == 1) {
            return varIntSize + 8;
        } else {
            if (wireType == 3) {
                return getProtoBuf(i, i2).getDataSize() + varIntSize + varIntSize;
            }
            if (wireType == 5) {
                return varIntSize + 4;
            }
            Object object = getObject(i, i2, 16);
            if (object instanceof byte[]) {
                i3 = ((byte[]) object).length;
            } else if (object instanceof String) {
                i3 = encodeUtf8((String) object, null, 0);
            } else {
                i3 = ((ProtoBuf) object).getDataSize();
            }
            return varIntSize + getVarIntSize((long) i3) + i3;
        }
    }

    public void outputTo(OutputStream outputStream) throws IOException {
        for (int i = 0; i <= maxTag(); i++) {
            int count = getCount(i);
            int wireType = getWireType(i);
            for (int i2 = 0; i2 < count; i2++) {
                int i3 = i << 3;
                writeVarInt(outputStream, (long) (i3 | wireType));
                if (wireType != 0) {
                    if (wireType != 1) {
                        if (wireType == 2) {
                            Object object = getObject(i, i2, getType(i) == 27 ? 16 : 25);
                            if (object instanceof byte[]) {
                                byte[] bArr = (byte[]) object;
                                writeVarInt(outputStream, (long) bArr.length);
                                outputStream.write(bArr);
                            } else {
                                ProtoBuf protoBuf = (ProtoBuf) object;
                                writeVarInt(outputStream, (long) protoBuf.getDataSize());
                                protoBuf.outputTo(outputStream);
                            }
                        } else if (wireType == 3) {
                            ((ProtoBuf) getObject(i, i2, 26)).outputTo(outputStream);
                            writeVarInt(outputStream, (long) (i3 | 4));
                        } else if (wireType != 5) {
                            throw new IllegalArgumentException();
                        }
                    }
                    long longValue = ((Long) getObject(i, i2, 19)).longValue();
                    int i4 = wireType == 5 ? 4 : 8;
                    for (int i5 = 0; i5 < i4; i5++) {
                        outputStream.write((int) (255 & longValue));
                        longValue >>= 8;
                    }
                } else {
                    long longValue2 = ((Long) getObject(i, i2, 19)).longValue();
                    if (isZigZagEncodedType(i)) {
                        longValue2 = zigZagEncode(longValue2);
                    }
                    writeVarInt(outputStream, longValue2);
                }
            }
        }
    }

    private boolean isZigZagEncodedType(int i) {
        int type = getType(i);
        return type == 33 || type == 34;
    }

    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        outputTo(byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public int maxTag() {
        return this.values.size() - 1;
    }

    public void setBool(int i, boolean z) {
        setObject(i, z ? TRUE : FALSE);
    }

    public void setBytes(int i, byte[] bArr) {
        setObject(i, bArr);
    }

    public void setInt(int i, int i2) {
        setLong(i, (long) i2);
    }

    public void setLong(int i, long j) {
        Long l;
        if (j >= 0) {
            Long[] lArr = SMALL_NUMBERS;
            if (j < ((long) lArr.length)) {
                l = lArr[(int) j];
                setObject(i, l);
            }
        }
        l = new Long(j);
        setObject(i, l);
    }

    public void setDouble(int i, double d) {
        setLong(i, Double.doubleToLongBits(d));
    }

    public void setFloat(int i, float f) {
        setInt(i, Float.floatToIntBits(f));
    }

    public void setProtoBuf(int i, ProtoBuf protoBuf) {
        setObject(i, protoBuf);
    }

    public void setString(int i, String str) {
        setObject(i, str);
    }

    public void insertBool(int i, int i2, boolean z) {
        insertObject(i, i2, z ? TRUE : FALSE);
    }

    public void insertBytes(int i, int i2, byte[] bArr) {
        insertObject(i, i2, bArr);
    }

    public void insertInt(int i, int i2, int i3) {
        insertLong(i, i2, (long) i3);
    }

    public void insertLong(int i, int i2, long j) {
        Long l;
        if (j >= 0) {
            Long[] lArr = SMALL_NUMBERS;
            if (j < ((long) lArr.length)) {
                l = lArr[(int) j];
                insertObject(i, i2, l);
            }
        }
        l = new Long(j);
        insertObject(i, i2, l);
    }

    public void insertFloat(int i, int i2, float f) {
        insertInt(i, i2, Float.floatToIntBits(f));
    }

    public void insertDouble(int i, int i2, double d) {
        insertLong(i, i2, Double.doubleToLongBits(d));
    }

    public void insertProtoBuf(int i, int i2, ProtoBuf protoBuf) {
        insertObject(i, i2, protoBuf);
    }

    public void insertString(int i, int i2, String str) {
        insertObject(i, i2, str);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:44:0x0067, code lost:
        if (r7 != r5.msgType.getData(r6)) goto L_0x0079;
     */
    private void assertTypeMatch(int i, Object obj) {
        int type = getType(i);
        if (type != 16 || this.msgType != null) {
            if (obj instanceof Boolean) {
                if (type == 24 || type == 0) {
                    return;
                }
            } else if (obj instanceof Long) {
                if (!(type == 0 || type == 1 || type == 5)) {
                    switch (type) {
                        case 17:
                        case 18:
                        case 19:
                        case 20:
                        case 21:
                        case 22:
                        case 23:
                        case 24:
                            break;
                        default:
                            switch (type) {
                                case 29:
                                case 30:
                                case 31:
                                case 32:
                                case 33:
                                case 34:
                                    break;
                            }
                    }
                }
                return;
            } else if (obj instanceof byte[]) {
                if (type == 2 || type == 25 || type == 35 || type == 27 || type == 28) {
                    return;
                }
            } else if (obj instanceof ProtoBuf) {
                if (!(type == 2 || type == 3)) {
                    switch (type) {
                        case 25:
                        case 26:
                        case 27:
                            break;
                    }
                }
                ProtoBufType protoBufType = this.msgType;
                if (!(protoBufType == null || protoBufType.getData(i) == null)) {
                    ProtoBufType protoBufType2 = ((ProtoBuf) obj).msgType;
                    if (protoBufType2 != null) {
                    }
                }
                return;
            } else if ((obj instanceof String) && (type == 2 || type == 25 || type == 28 || type == 36)) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Type mismatch type:");
            sb.append(this.msgType);
            sb.append(" tag:");
            sb.append(i);
            throw new IllegalArgumentException(sb.toString());
        }
    }

    private Object getDefault(int i) {
        int type = getType(i);
        if (type == 16 || type == 26 || type == 27) {
            return null;
        }
        return this.msgType.getData(i);
    }

    private Object getObject(int i, int i2) {
        int count = getCount(i);
        if (count == 0) {
            return getDefault(i);
        }
        if (count <= 1) {
            return getObject(i, 0, i2);
        }
        throw new IllegalArgumentException();
    }

    private Object getObject(int i, int i2, int i3) {
        if (i2 < getCount(i)) {
            Object elementAt = this.values.elementAt(i);
            Vector vector = null;
            if (elementAt instanceof Vector) {
                vector = (Vector) elementAt;
                elementAt = vector.elementAt(i2);
            }
            Object convert = convert(elementAt, i3);
            if (!(convert == elementAt || elementAt == null)) {
                if (vector == null) {
                    setObject(i, convert);
                } else {
                    vector.setElementAt(convert, i2);
                }
            }
            return convert;
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    private final int getWireType(int i) {
        int type = getType(i);
        if (!(type == 0 || type == 1 || type == 2 || type == 3 || type == 5)) {
            switch (type) {
                case 16:
                    break;
                case 17:
                case 22:
                case 32:
                    return 1;
                case 18:
                case 23:
                case 31:
                    return 5;
                case 19:
                case 20:
                case 21:
                case 24:
                case 29:
                case 30:
                case 33:
                case 34:
                    return 0;
                case 25:
                case 27:
                case 28:
                case 35:
                case 36:
                    return 2;
                case 26:
                    return 3;
                default:
                    StringBuilder sb = new StringBuilder();
                    sb.append("Unsupp.Type:");
                    sb.append(this.msgType);
                    sb.append('/');
                    sb.append(i);
                    sb.append('/');
                    sb.append(type);
                    throw new RuntimeException(sb.toString());
            }
        }
        return type;
    }

    private void insertObject(int i, int i2, Object obj) {
        Vector vector;
        assertTypeMatch(i, obj);
        if (getCount(i) == 0) {
            setObject(i, obj);
            return;
        }
        Object elementAt = this.values.elementAt(i);
        if (elementAt instanceof Vector) {
            vector = (Vector) elementAt;
        } else {
            Vector vector2 = new Vector();
            vector2.addElement(elementAt);
            this.values.setElementAt(vector2, i);
            vector = vector2;
        }
        vector.insertElementAt(obj, i2);
    }

    private Object convert(Object obj, int i) {
        switch (i) {
            case 16:
                break;
            case 19:
            case 21:
            case 22:
            case 23:
            case 31:
            case 32:
            case 33:
            case 34:
                if (obj instanceof Boolean) {
                    obj = SMALL_NUMBERS[((Boolean) obj).booleanValue()];
                    break;
                }
                break;
            case 24:
                if (obj instanceof Boolean) {
                    return obj;
                }
                int longValue = (int) ((Long) obj).longValue();
                if (longValue == 0) {
                    return FALSE;
                }
                if (longValue == 1) {
                    return TRUE;
                }
                throw new IllegalArgumentException(MSG_MISMATCH);
            case 25:
            case 35:
                if (obj instanceof String) {
                    return encodeUtf8((String) obj);
                }
                if (!(obj instanceof ProtoBuf)) {
                    return obj;
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    ((ProtoBuf) obj).outputTo(byteArrayOutputStream);
                    return byteArrayOutputStream.toByteArray();
                } catch (IOException e) {
                    throw new RuntimeException(e.toString());
                }
            case 26:
            case 27:
                if (!(obj instanceof byte[])) {
                    return obj;
                }
                try {
                    return new ProtoBuf(null).parse((byte[]) obj);
                } catch (IOException e2) {
                    throw new RuntimeException(e2.toString());
                }
            case 28:
            case 36:
                if (obj instanceof byte[]) {
                    byte[] bArr = (byte[]) obj;
                    obj = decodeUtf8(bArr, 0, bArr.length, true);
                }
                return obj;
            default:
                throw new RuntimeException(MSG_UNSUPPORTED);
        }
        return obj;
    }

    static long readVarInt(InputStream inputStream, boolean z) throws IOException {
        int i = 0;
        long j = 0;
        int i2 = 0;
        while (i < 10) {
            int read = inputStream.read();
            if (read != -1) {
                j |= ((long) (read & 127)) << i2;
                if ((read & 128) == 0) {
                    break;
                }
                i2 += 7;
                i++;
            } else if (i == 0 && z) {
                return -1;
            } else {
                throw new IOException("EOF");
            }
        }
        return j;
    }

    private void setObject(int i, Object obj) {
        if (this.values.size() <= i) {
            this.values.setSize(i + 1);
        }
        if (obj != null) {
            assertTypeMatch(i, obj);
        }
        this.values.setElementAt(obj, i);
    }

    static void writeVarInt(OutputStream outputStream, long j) throws IOException {
        int i = 0;
        while (i < 10) {
            int i2 = (int) (127 & j);
            j >>>= 7;
            if (j == 0) {
                outputStream.write(i2);
                return;
            } else {
                outputStream.write(i2 | 128);
                i++;
            }
        }
    }

    static byte[] encodeUtf8(String str) {
        byte[] bArr = new byte[encodeUtf8(str, null, 0)];
        encodeUtf8(str, bArr, 0);
        return bArr;
    }

    static int encodeUtf8(String str, byte[] bArr, int i) {
        int length = str.length();
        int i2 = 0;
        while (i2 < length) {
            int charAt = str.charAt(i2);
            if (charAt >= 55296 && charAt <= 57343) {
                int i3 = i2 + 1;
                if (i3 < length) {
                    int charAt2 = str.charAt(i3);
                    int i4 = charAt2 & 64512;
                    if (((64512 & charAt) ^ i4) == 1024) {
                        if (i4 == 55296) {
                            int i5 = charAt2;
                            charAt2 = charAt;
                            charAt = i5;
                        }
                        charAt = 65536 + (((charAt & 1023) << 10) | (charAt2 & 1023));
                        i2 = i3;
                    }
                }
            }
            if (charAt <= 127) {
                if (bArr != null) {
                    bArr[i] = (byte) charAt;
                }
                i++;
            } else if (charAt <= 2047) {
                if (bArr != null) {
                    bArr[i] = (byte) ((charAt >> 6) | 192);
                    bArr[i + 1] = (byte) ((charAt & 63) | 128);
                }
                i += 2;
            } else if (charAt <= 65535) {
                if (bArr != null) {
                    bArr[i] = (byte) ((charAt >> 12) | 224);
                    bArr[i + 1] = (byte) (((charAt >> 6) & 63) | 128);
                    bArr[i + 2] = (byte) ((charAt & 63) | 128);
                }
                i += 3;
            } else {
                if (bArr != null) {
                    bArr[i] = (byte) ((charAt >> 18) | 240);
                    bArr[i + 1] = (byte) (((charAt >> 12) & 63) | 128);
                    bArr[i + 2] = (byte) (((charAt >> 6) & 63) | 128);
                    bArr[i + 3] = (byte) ((charAt & 63) | 128);
                }
                i += 4;
            }
            i2++;
        }
        return i;
    }

    /* JADX WARNING: type inference failed for: r11v6, types: [int] */
    /* JADX WARNING: type inference failed for: r11v12, types: [int] */
    /* JADX WARNING: type inference failed for: r11v13 */
    /* JADX WARNING: type inference failed for: r11v14 */
    /* JADX WARNING: type inference failed for: r11v17 */
    /* JADX WARNING: type inference failed for: r11v18 */
    /* JADX WARNING: type inference failed for: r11v19 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r11v13
  assigns: []
  uses: []
  mth insns count: 73
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 3 */
    static String decodeUtf8(byte[] bArr, int i, int i2, boolean z) {
        ? r11;
        StringBuffer stringBuffer = new StringBuffer(i2 - i);
        while (i < i2) {
            int i3 = i + 1;
            byte b = bArr[i] & Constants.UNKNOWN;
            if (b <= Byte.MAX_VALUE) {
                stringBuffer.append((char) b);
            } else {
                String str = "Invalid UTF8";
                if (b < 245) {
                    byte b2 = 224;
                    int i4 = 31;
                    int i5 = 128;
                    int i6 = 1;
                    while (b >= b2) {
                        b2 = (b2 >> 1) | 128;
                        i5 <<= i6 == 1 ? 4 : 5;
                        i6++;
                        i4 >>= 1;
                    }
                    ? r112 = b & i4;
                    int i7 = 0;
                    while (i7 < i6) {
                        byte b3 = r112 << 6;
                        if (i3 >= i2) {
                            if (z) {
                                r11 = b3;
                            } else {
                                throw new IllegalArgumentException(str);
                            }
                        } else if (z || (bArr[i3] & 192) == 128) {
                            ? r113 = b3 | (bArr[i3] & 63);
                            i3++;
                            r11 = r113;
                        } else {
                            throw new IllegalArgumentException(str);
                        }
                        i7++;
                        r112 = r11;
                    }
                    if ((!z && r112 < i5) || (r112 >= 55296 && r112 <= 57343)) {
                        throw new IllegalArgumentException(str);
                    } else if (r112 <= 65535) {
                        stringBuffer.append((char) r112);
                    } else {
                        int i8 = r112 - 65536;
                        stringBuffer.append((char) (55296 | (i8 >> 10)));
                        stringBuffer.append((char) ((i8 & 1023) | 56320));
                    }
                } else if (z) {
                    stringBuffer.append((char) b);
                } else {
                    throw new IllegalArgumentException(str);
                }
            }
            i = i3;
        }
        return stringBuffer.toString();
    }
}
