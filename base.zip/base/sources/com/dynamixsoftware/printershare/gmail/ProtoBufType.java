package com.dynamixsoftware.printershare.gmail;

import com.dynamixsoftware.printershare.smb.SmbNamedPipe;
import java.util.Vector;

public class ProtoBufType {
    public static final int MASK_MODIFIER = 65280;
    public static final int MASK_TYPE = 255;
    public static final int OPTIONAL = 512;
    public static final int REPEATED = 1024;
    public static final int REQUIRED = 256;
    public static final int TYPE_BOOL = 24;
    public static final int TYPE_BYTES = 35;
    public static final int TYPE_DATA = 25;
    public static final int TYPE_DOUBLE = 17;
    public static final int TYPE_ENUM = 30;
    public static final int TYPE_FIXED32 = 23;
    public static final int TYPE_FIXED64 = 22;
    public static final int TYPE_FLOAT = 18;
    public static final int TYPE_GROUP = 26;
    public static final int TYPE_INT32 = 21;
    public static final int TYPE_INT64 = 19;
    public static final int TYPE_MESSAGE = 27;
    public static final int TYPE_SFIXED32 = 31;
    public static final int TYPE_SFIXED64 = 32;
    public static final int TYPE_SINT32 = 33;
    public static final int TYPE_SINT64 = 34;
    public static final int TYPE_STRING = 36;
    public static final int TYPE_TEXT = 28;
    public static final int TYPE_UINT32 = 29;
    public static final int TYPE_UINT64 = 20;
    public static final int TYPE_UNDEFINED = 16;
    private final Vector data;
    private final String typeName;
    private final StringBuffer types;

    public ProtoBufType() {
        this.types = new StringBuffer();
        this.data = new Vector();
        this.typeName = null;
    }

    public ProtoBufType(String str) {
        this.types = new StringBuffer();
        this.data = new Vector();
        this.typeName = str;
    }

    public ProtoBufType addElement(int i, int i2, Object obj) {
        while (this.types.length() <= i2) {
            this.types.append(16);
            this.data.addElement(null);
        }
        this.types.setCharAt(i2, (char) i);
        this.data.setElementAt(obj, i2);
        return this;
    }

    public int getType(int i) {
        if (i < 0 || i >= this.types.length()) {
            return 16;
        }
        return this.types.charAt(i) & 255;
    }

    public int getModifiers(int i) {
        return (i < 0 || i >= this.types.length()) ? SmbNamedPipe.PIPE_TYPE_DCE_TRANSACT : this.types.charAt(i) & 65280;
    }

    public Object getData(int i) {
        if (i < 0 || i >= this.data.size()) {
            return null;
        }
        return this.data.elementAt(i);
    }

    public String toString() {
        return this.typeName;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        return stringEquals(this.types, ((ProtoBufType) obj).types);
    }

    public int hashCode() {
        StringBuffer stringBuffer = this.types;
        if (stringBuffer != null) {
            return stringBuffer.hashCode();
        }
        return super.hashCode();
    }

    public static boolean stringEquals(CharSequence charSequence, CharSequence charSequence2) {
        if (charSequence == charSequence2) {
            return true;
        }
        if (!(charSequence == null || charSequence2 == null)) {
            int length = charSequence.length();
            if (length == charSequence2.length()) {
                if ((charSequence instanceof String) && (charSequence2 instanceof String)) {
                    return charSequence.equals(charSequence2);
                }
                for (int i = 0; i < length; i++) {
                    if (charSequence.charAt(i) != charSequence2.charAt(i)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
}
