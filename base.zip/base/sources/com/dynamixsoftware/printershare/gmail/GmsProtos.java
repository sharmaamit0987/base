package com.dynamixsoftware.printershare.gmail;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

public class GmsProtos {
    public static final ProtoBufType EMAIL_ADDRESS = new ProtoBufType();
    public static final String LABEL_ALL = "^all";
    public static final String LABEL_CHATS = "^b";
    public static final String LABEL_DRAFTS = "^r";
    public static final String LABEL_INBOX = "^i";
    public static final String LABEL_SENT = "^f";
    public static final String LABEL_SPAM = "^s";
    public static final String LABEL_STARRED = "^t";
    public static final String LABEL_TRASH = "^k";
    public static final String LABEL_UNREAD = "^u";
    public static final ProtoBufType REQUEST = new ProtoBufType();
    public static final ProtoBufType RESPONSE_CHUNK = new ProtoBufType();
    static final ProtoBufType RESPONSE_MESSAGE = new ProtoBufType();
    public static final ProtoBufType RESPONSE_PREAMBLE = new ProtoBufType();
    public static final ProtoBufType RESPONSE_QUERY = new ProtoBufType();
    public static final ProtoBufType RESPONSE_START_SYNC = new ProtoBufType();
    public static final ProtoBufType SENDER_INSTRUCTIONS = new ProtoBufType();

    static {
        REQUEST.addElement(531, 1, null);
        ProtoBufType protoBufType = new ProtoBufType("CONFIG");
        protoBufType.addElement(533, 1, null);
        protoBufType.addElement(1052, 2, null);
        protoBufType.addElement(1052, 3, null);
        REQUEST.addElement(538, 2, protoBufType);
        ProtoBufType protoBufType2 = new ProtoBufType("CONVERSATION_SYNC");
        ProtoBufType protoBufType3 = new ProtoBufType("CONVERSATION_SYNC_CONVERSATION");
        protoBufType3.addElement(531, 1, null);
        protoBufType3.addElement(531, 2, null);
        protoBufType3.addElement(1043, 3, null);
        protoBufType2.addElement(1050, 1, protoBufType3);
        protoBufType2.addElement(1043, 2, null);
        protoBufType2.addElement(536, 3, null);
        protoBufType2.addElement(1043, 4, null);
        REQUEST.addElement(538, 3, protoBufType2);
        ProtoBufType protoBufType4 = new ProtoBufType("MAIN_SYNC");
        protoBufType4.addElement(531, 1, null);
        protoBufType4.addElement(531, 2, null);
        protoBufType4.addElement(533, 3, null);
        protoBufType4.addElement(533, 4, null);
        protoBufType4.addElement(533, 5, null);
        protoBufType4.addElement(536, 6, ProtoBuf.FALSE);
        protoBufType4.addElement(536, 7, new Long(0));
        protoBufType4.addElement(536, 8, ProtoBuf.FALSE);
        protoBufType4.addElement(536, 9, ProtoBuf.FALSE);
        REQUEST.addElement(538, 4, protoBufType4);
        ProtoBufType protoBufType5 = new ProtoBufType("QUERY");
        protoBufType5.addElement(540, 1, null);
        protoBufType5.addElement(531, 2, null);
        protoBufType5.addElement(533, 3, null);
        protoBufType5.addElement(533, 4, null);
        REQUEST.addElement(538, 5, protoBufType5);
        ProtoBufType protoBufType6 = new ProtoBufType("START_SYNC");
        protoBufType6.addElement(531, 1, null);
        protoBufType6.addElement(531, 2, null);
        protoBufType6.addElement(531, 3, null);
        protoBufType6.addElement(531, 4, null);
        protoBufType6.addElement(536, 5, ProtoBuf.FALSE);
        protoBufType6.addElement(536, 6, ProtoBuf.FALSE);
        protoBufType6.addElement(536, 7, ProtoBuf.FALSE);
        REQUEST.addElement(538, 6, protoBufType6);
        new ProtoBufType("UPHILL_SYNC").addElement(531, 2, null);
        REQUEST.addElement(538, 7, protoBufType6);
        RESPONSE_CHUNK.addElement(539, 1, RESPONSE_PREAMBLE);
        RESPONSE_CHUNK.addElement(539, 4, RESPONSE_START_SYNC);
        RESPONSE_CHUNK.addElement(539, 11, RESPONSE_MESSAGE);
        RESPONSE_CHUNK.addElement(539, 15, RESPONSE_QUERY);
        RESPONSE_PREAMBLE.addElement(533, 1, null);
        RESPONSE_PREAMBLE.addElement(533, 2, null);
        RESPONSE_PREAMBLE.addElement(536, 3, ProtoBuf.FALSE);
        RESPONSE_PREAMBLE.addElement(536, 4, ProtoBuf.FALSE);
        RESPONSE_PREAMBLE.addElement(540, 5, "");
        RESPONSE_PREAMBLE.addElement(540, 6, new Long(0));
        RESPONSE_QUERY.addElement(533, 1, null);
        RESPONSE_QUERY.addElement(531, 2, null);
        SENDER_INSTRUCTIONS.addElement(533, 1, null);
        SENDER_INSTRUCTIONS.addElement(533, 2, null);
        ProtoBufType protoBufType7 = new ProtoBufType("SENDER");
        protoBufType7.addElement(536, 1, null);
        protoBufType7.addElement(536, 2, null);
        protoBufType7.addElement(533, 3, null);
        protoBufType7.addElement(540, 4, null);
        SENDER_INSTRUCTIONS.addElement(1050, 3, protoBufType7);
        ProtoBufType protoBufType8 = new ProtoBufType("CONVERSATION");
        protoBufType8.addElement(531, 1, null);
        protoBufType8.addElement(531, 2, null);
        protoBufType8.addElement(531, 3, null);
        protoBufType8.addElement(540, 4, null);
        protoBufType8.addElement(540, 5, null);
        protoBufType8.addElement(533, 6, null);
        protoBufType8.addElement(531, 7, null);
        protoBufType8.addElement(533, 8, null);
        protoBufType8.addElement(536, 9, null);
        protoBufType8.addElement(539, 10, SENDER_INSTRUCTIONS);
        protoBufType8.addElement(1045, 11, null);
        RESPONSE_QUERY.addElement(1050, 3, protoBufType8);
        RESPONSE_START_SYNC.addElement(531, 1, null);
        RESPONSE_START_SYNC.addElement(531, 2, null);
        RESPONSE_START_SYNC.addElement(531, 3, null);
        ProtoBufType protoBufType9 = new ProtoBufType("LABEL");
        protoBufType9.addElement(533, 1, null);
        protoBufType9.addElement(540, 2, null);
        protoBufType9.addElement(540, 3, null);
        protoBufType9.addElement(533, 4, null);
        protoBufType9.addElement(533, 5, null);
        protoBufType9.addElement(533, 6, null);
        protoBufType9.addElement(540, 7, null);
        RESPONSE_START_SYNC.addElement(1050, 4, protoBufType9);
        RESPONSE_MESSAGE.addElement(531, 1, null);
        RESPONSE_MESSAGE.addElement(539, 2, EMAIL_ADDRESS);
        RESPONSE_MESSAGE.addElement(531, 3, null);
        RESPONSE_MESSAGE.addElement(531, 4, null);
        RESPONSE_MESSAGE.addElement(540, 5, null);
        RESPONSE_MESSAGE.addElement(540, 6, null);
        RESPONSE_MESSAGE.addElement(533, 7, null);
        RESPONSE_MESSAGE.addElement(536, 8, null);
        RESPONSE_MESSAGE.addElement(1051, 9, EMAIL_ADDRESS);
        RESPONSE_MESSAGE.addElement(1051, 10, EMAIL_ADDRESS);
        RESPONSE_MESSAGE.addElement(1051, 11, EMAIL_ADDRESS);
        RESPONSE_MESSAGE.addElement(1051, 12, EMAIL_ADDRESS);
        RESPONSE_MESSAGE.addElement(540, 13, null);
        RESPONSE_MESSAGE.addElement(1045, 14, null);
        ProtoBufType protoBufType10 = new ProtoBufType("ATTACHMENT");
        protoBufType10.addElement(540, 1, null);
        protoBufType10.addElement(540, 2, null);
        protoBufType10.addElement(540, 3, null);
        protoBufType10.addElement(540, 4, null);
        protoBufType10.addElement(533, 5, null);
        RESPONSE_MESSAGE.addElement(1050, 15, protoBufType10);
        RESPONSE_MESSAGE.addElement(537, 16, null);
        RESPONSE_MESSAGE.addElement(531, 17, null);
        RESPONSE_MESSAGE.addElement(537, 18, null);
        RESPONSE_MESSAGE.addElement(540, 19, null);
        EMAIL_ADDRESS.addElement(540, 1, null);
        EMAIL_ADDRESS.addElement(540, 2, null);
    }

    public static ProtoBuf doRequest(String[] strArr, ProtoBuf protoBuf) throws Exception {
        HttpURLConnection httpURLConnection;
        int responseCode;
        String str;
        int i = 0;
        do {
            String[] createUrlAndCookie = createUrlAndCookie(strArr);
            StringBuilder sb = new StringBuilder();
            sb.append(createUrlAndCookie[0]);
            sb.append("?version=25&clientVersion=25&allowAnyVersion=1");
            httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Connection", "close");
            httpURLConnection.setRequestProperty("User-Agent", "Android-GmailProvider/210 (PrinterShare); gzip");
            String str2 = "gzip";
            httpURLConnection.setRequestProperty("Accept-Encoding", str2);
            httpURLConnection.setRequestProperty("Cookie", createUrlAndCookie[1]);
            httpURLConnection.getOutputStream().write(protoBuf.toByteArray());
            responseCode = httpURLConnection.getResponseCode();
            if (responseCode != 200) {
                if (responseCode != 502) {
                    break;
                }
                i++;
            } else {
                String contentEncoding = httpURLConnection.getContentEncoding();
                InputStream inputStream = (contentEncoding == null || !str2.equals(contentEncoding)) ? httpURLConnection.getInputStream() : new GZIPInputStream(httpURLConnection.getInputStream());
                ProtoBuf protoBuf2 = new ProtoBuf(RESPONSE_CHUNK);
                protoBuf2.parse(inputStream);
                return protoBuf2;
            }
        } while (i < 3);
        String responseMessage = httpURLConnection.getResponseMessage();
        String accountGetDomain = accountGetDomain(strArr[0]);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("HTTP error ");
        sb2.append(responseCode);
        if (responseMessage != null) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(". ");
            sb3.append(responseMessage);
            str = sb3.toString();
        } else {
            str = "";
        }
        sb2.append(str);
        sb2.append(". Domain of email is ");
        sb2.append(accountGetDomain);
        throw new Exception(sb2.toString());
    }

    public static String[] createUrlAndCookie(String[] strArr) {
        String str;
        String accountGetDomain = accountGetDomain(strArr[0]);
        boolean accountDomainIsGmail = accountDomainIsGmail(accountGetDomain);
        StringBuilder sb = new StringBuilder();
        sb.append("https://mail.google.com/");
        if (accountDomainIsGmail) {
            str = "mail";
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("a/");
            sb2.append(accountGetDomain);
            str = sb2.toString();
        }
        sb.append(str);
        sb.append("/g/");
        String sb3 = sb.toString();
        if (accountDomainIsGmail) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append("GX=");
            sb4.append(strArr[1]);
            return new String[]{sb3, sb4.toString()};
        }
        StringBuilder sb5 = new StringBuilder();
        sb5.append("GXAS_SEC=");
        sb5.append(accountGetDomain);
        sb5.append("=");
        sb5.append(strArr[1]);
        return new String[]{sb3, sb5.toString()};
    }

    public static InputStream loadAttachment(String[] strArr, String str, String str2) throws Exception {
        HttpURLConnection httpURLConnection;
        int responseCode;
        String str3;
        int i = 0;
        do {
            String[] createUrlAndCookie = createUrlAndCookie(strArr);
            StringBuilder sb = new StringBuilder();
            sb.append(createUrlAndCookie[0]);
            sb.append("?version=25&clientVersion=25&allowAnyVersion=1&view=att&messageId=");
            sb.append(str);
            sb.append("&partId=");
            sb.append(str2);
            sb.append("&maxWidth=96&maxHeight=96&showOriginal=1");
            httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(false);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setRequestProperty("Connection", "close");
            httpURLConnection.setRequestProperty("User-Agent", "AndroidDownloadManager");
            httpURLConnection.setRequestProperty("Cookie", createUrlAndCookie[1]);
            responseCode = httpURLConnection.getResponseCode();
            if (responseCode != 200) {
                if (responseCode != 502) {
                    break;
                }
                i++;
            } else {
                return httpURLConnection.getInputStream();
            }
        } while (i < 3);
        String responseMessage = httpURLConnection.getResponseMessage();
        String accountGetDomain = accountGetDomain(strArr[0]);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("HTTP error ");
        sb2.append(responseCode);
        if (responseMessage != null) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(". ");
            sb3.append(responseMessage);
            str3 = sb3.toString();
        } else {
            str3 = ".";
        }
        sb2.append(str3);
        sb2.append(". Domain of email is ");
        sb2.append(accountGetDomain);
        throw new Exception(sb2.toString());
    }

    private static String accountGetDomain(String str) {
        int indexOf = str.indexOf("@");
        return indexOf != -1 ? str.substring(indexOf + 1) : "";
    }

    private static boolean accountDomainIsGmail(String str) {
        return "".equals(str) || "gmail.com".equals(str) || "googlemail.com".equals(str);
    }
}
