package com.dynamixsoftware.printershare;

import com.dynamixsoftware.printershare.ipp.IppAttribute;
import com.dynamixsoftware.printershare.snmp.SNMPBERCodec;
import com.flurry.android.Constants;
import java.lang.reflect.Array;

class AES {
    public static final int BLOCK_SIZE = 16;
    public static final int COL_SIZE = 4;
    public static final int KEY_LENGTH = 32;
    public static final int NUM_COLS = 4;
    public static final int ROOT = 283;
    public static final int ROUNDS = 14;
    static final byte[] S = {99, 124, 119, 123, -14, 107, 111, -59, SNMPBERCodec.SNMPSEQUENCE, 1, 103, 43, -2, -41, -85, 118, -54, -126, -55, 125, -6, 89, 71, -16, -83, -44, -94, -81, -100, SNMPBERCodec.SNMPTRAP, 114, -64, -73, -3, -109, 38, 54, 63, -9, -52, 52, SNMPBERCodec.SNMPv2BULKREQUEST, -27, -15, 113, -40, 49, 21, 4, -57, IppAttribute.TYPE_ENUM, -61, 24, -106, 5, -102, 7, 18, Byte.MIN_VALUE, -30, -21, 39, -78, 117, 9, -125, 44, 26, 27, 110, 90, SNMPBERCodec.SNMPGETREQUEST, 82, 59, -42, -77, 41, -29, 47, -124, 83, -47, 0, -19, 32, -4, -79, 91, 106, -53, -66, 57, 74, 76, 88, -49, -48, -17, -86, -5, SNMPBERCodec.SNMPTIMETICKS, 77, 51, -123, 69, -7, 2, Byte.MAX_VALUE, 80, 60, -97, -88, 81, SNMPBERCodec.SNMPSETREQUEST, SNMPBERCodec.SNMPIPADDRESS, -113, -110, -99, 56, -11, -68, -74, -38, IppAttribute.TYPE_INTEGER, 16, -1, -13, -46, -51, 12, 19, -20, 95, -105, 68, 23, -60, SNMPBERCodec.SNMPv2TRAP, 126, 61, 100, 93, 25, 115, 96, -127, 79, -36, IppAttribute.TYPE_BOOLEAN, 42, -112, -120, SNMPBERCodec.SNMPCOUNTER64, -18, -72, 20, -34, 94, 11, -37, -32, 50, 58, 10, IppAttribute.TYPE_MIME_MEDIA_TYPE, 6, 36, 92, -62, -45, -84, 98, -111, -107, -28, 121, -25, -56, 55, 109, -115, -43, 78, -87, 108, 86, -12, -22, 101, 122, -82, 8, -70, 120, 37, 46, 28, SNMPBERCodec.SNMPv2INFORMREQUEST, -76, -58, -24, -35, 116, 31, 75, -67, -117, -118, 112, 62, -75, 102, IppAttribute.TYPE_NATURAL_LANGUAGE, 3, -10, 14, 97, 53, 87, -71, -122, -63, 29, -98, -31, -8, -104, 17, 105, -39, -114, -108, -101, 30, -121, -23, -50, 85, 40, -33, -116, -95, -119, 13, -65, -26, 66, 104, SNMPBERCodec.SNMPCOUNTER32, -103, 45, 15, -80, 84, -69, 22};
    static final byte[] Si = {82, 9, 106, -43, SNMPBERCodec.SNMPSEQUENCE, 54, SNMPBERCodec.SNMPv2BULKREQUEST, 56, -65, SNMPBERCodec.SNMPIPADDRESS, SNMPBERCodec.SNMPSETREQUEST, -98, -127, -13, -41, -5, 124, -29, 57, -126, -101, 47, -1, -121, 52, -114, SNMPBERCodec.SNMPTIMETICKS, 68, -60, -34, -23, -53, 84, 123, -108, 50, SNMPBERCodec.SNMPv2INFORMREQUEST, -62, IppAttribute.TYPE_ENUM, 61, -18, 76, -107, 11, 66, -6, -61, 78, 8, 46, -95, 102, 40, -39, 36, -78, 118, 91, -94, IppAttribute.TYPE_MIME_MEDIA_TYPE, 109, -117, -47, 37, 114, -8, -10, 100, -122, 104, -104, 22, -44, SNMPBERCodec.SNMPTRAP, 92, -52, 93, 101, -74, -110, 108, 112, IppAttribute.TYPE_NATURAL_LANGUAGE, 80, -3, -19, -71, -38, 94, 21, SNMPBERCodec.SNMPCOUNTER64, 87, SNMPBERCodec.SNMPv2TRAP, -115, -99, -124, -112, -40, -85, 0, -116, -68, -45, 10, -9, -28, 88, 5, -72, -77, 69, 6, -48, 44, 30, -113, -54, 63, 15, 2, -63, -81, -67, 3, 1, 19, -118, 107, 58, -111, 17, SNMPBERCodec.SNMPCOUNTER32, 79, 103, -36, -22, -105, -14, -49, -50, -16, -76, -26, 115, -106, -84, 116, IppAttribute.TYPE_BOOLEAN, -25, -83, 53, -123, -30, -7, 55, -24, 28, 117, -33, 110, 71, -15, 26, 113, 29, 41, -59, -119, 111, -73, 98, 14, -86, 24, -66, 27, -4, 86, 62, 75, -58, -46, 121, 32, -102, -37, -64, -2, 120, -51, 90, -12, 31, -35, -88, 51, -120, 7, -57, 49, -79, 18, 16, 89, 39, Byte.MIN_VALUE, -20, 95, 96, 81, Byte.MAX_VALUE, -87, 25, -75, 74, 13, 45, -27, 122, -97, -109, -55, -100, -17, SNMPBERCodec.SNMPGETREQUEST, -32, 59, 77, -82, 42, -11, -80, -56, -21, -69, 60, -125, 83, -103, 97, 23, 43, 4, 126, -70, 119, -42, 38, -31, 105, 20, 99, 85, IppAttribute.TYPE_INTEGER, 12, 125};
    static final int[] alog;
    static final int[] log = new int[256];
    static final byte[] rcon = {0, 1, 2, 4, 8, 16, 32, SNMPBERCodec.SNMPIPADDRESS, Byte.MIN_VALUE, 27, 54, 108, -40, -85, 77, -102, 47, 94, -68, 99, -58, -105, 53, 106, -44, -77, 125, -6, -17, -59, -111};
    static final int[] row_shift = {0, 1, 2, 3};
    byte[][] Kd;
    byte[][] Ke;
    int numRounds;

    public static int getRounds(int i) {
        if (i != 16) {
            return i != 24 ? 14 : 12;
        }
        return 10;
    }

    public static void main(String[] strArr) {
    }

    static {
        int[] iArr = new int[256];
        alog = iArr;
        iArr[0] = 1;
        for (int i = 1; i < 256; i++) {
            int[] iArr2 = alog;
            int i2 = i - 1;
            int i3 = iArr2[i2] ^ (iArr2[i2] << 1);
            if ((i3 & 256) != 0) {
                i3 ^= ROOT;
            }
            alog[i] = i3;
        }
        for (int i4 = 1; i4 < 255; i4++) {
            log[alog[i4]] = i4;
        }
    }

    static final int mul(int i, int i2) {
        if (i == 0 || i2 == 0) {
            return 0;
        }
        int[] iArr = alog;
        int[] iArr2 = log;
        return iArr[(iArr2[i & 255] + iArr2[i2 & 255]) % 255];
    }

    public byte[] encrypt(byte[] bArr) {
        int i;
        byte[] bArr2 = bArr;
        byte[] bArr3 = new byte[16];
        byte[] bArr4 = new byte[16];
        if (bArr2 == null) {
            throw new IllegalArgumentException("Empty plaintext");
        } else if (bArr2.length == 16) {
            byte[] bArr5 = this.Ke[0];
            for (int i2 = 0; i2 < 16; i2++) {
                bArr3[i2] = (byte) (bArr2[i2] ^ bArr5[i2]);
            }
            int i3 = 1;
            while (true) {
                i = this.numRounds;
                if (i3 >= i) {
                    break;
                }
                byte[] bArr6 = this.Ke[i3];
                for (int i4 = 0; i4 < 16; i4++) {
                    bArr4[i4] = S[bArr3[i4] & Constants.UNKNOWN];
                }
                for (int i5 = 0; i5 < 16; i5++) {
                    bArr3[i5] = bArr4[((row_shift[i5 % 4] * 4) + i5) % 16];
                }
                for (int i6 = 0; i6 < 4; i6++) {
                    int i7 = i6 * 4;
                    int i8 = i7 + 1;
                    int i9 = i7 + 2;
                    int i10 = i7 + 3;
                    bArr4[i7] = (byte) (((mul(2, bArr3[i7]) ^ mul(3, bArr3[i8])) ^ bArr3[i9]) ^ bArr3[i10]);
                    bArr4[i8] = (byte) (((mul(2, bArr3[i8]) ^ bArr3[i7]) ^ mul(3, bArr3[i9])) ^ bArr3[i10]);
                    bArr4[i9] = (byte) (((bArr3[i7] ^ bArr3[i8]) ^ mul(2, bArr3[i9])) ^ mul(3, bArr3[i10]));
                    bArr4[i10] = (byte) (((mul(3, bArr3[i7]) ^ bArr3[i8]) ^ bArr3[i9]) ^ mul(2, bArr3[i10]));
                }
                for (int i11 = 0; i11 < 16; i11++) {
                    bArr3[i11] = (byte) (bArr4[i11] ^ bArr6[i11]);
                }
                i3++;
            }
            byte[] bArr7 = this.Ke[i];
            for (int i12 = 0; i12 < 16; i12++) {
                bArr3[i12] = S[bArr3[i12] & Constants.UNKNOWN];
            }
            for (int i13 = 0; i13 < 16; i13++) {
                bArr4[i13] = bArr3[((row_shift[i13 % 4] * 4) + i13) % 16];
            }
            for (int i14 = 0; i14 < 16; i14++) {
                bArr3[i14] = (byte) (bArr4[i14] ^ bArr7[i14]);
            }
            return bArr3;
        } else {
            throw new IllegalArgumentException("Incorrect plaintext length");
        }
    }

    public byte[] decrypt(byte[] bArr) {
        int i;
        byte[] bArr2 = bArr;
        byte[] bArr3 = new byte[16];
        byte[] bArr4 = new byte[16];
        if (bArr2 == null) {
            throw new IllegalArgumentException("Empty ciphertext");
        } else if (bArr2.length == 16) {
            byte[] bArr5 = this.Kd[0];
            for (int i2 = 0; i2 < 16; i2++) {
                bArr3[i2] = (byte) (bArr2[i2] ^ bArr5[i2]);
            }
            int i3 = 1;
            while (true) {
                i = this.numRounds;
                if (i3 >= i) {
                    break;
                }
                byte[] bArr6 = this.Kd[i3];
                for (int i4 = 0; i4 < 16; i4++) {
                    bArr4[i4] = bArr3[((i4 + 16) - (row_shift[i4 % 4] * 4)) % 16];
                }
                for (int i5 = 0; i5 < 16; i5++) {
                    bArr3[i5] = Si[bArr4[i5] & Constants.UNKNOWN];
                }
                for (int i6 = 0; i6 < 16; i6++) {
                    bArr4[i6] = (byte) (bArr3[i6] ^ bArr6[i6]);
                }
                int i7 = 0;
                for (int i8 = 4; i7 < i8; i8 = 4) {
                    int i9 = i7 * 4;
                    int i10 = i9 + 1;
                    int i11 = i9 + 2;
                    int i12 = i9 + 3;
                    bArr3[i9] = (byte) (mul(9, bArr4[i12]) ^ ((mul(14, bArr4[i9]) ^ mul(11, bArr4[i10])) ^ mul(13, bArr4[i11])));
                    bArr3[i10] = (byte) (((mul(9, bArr4[i9]) ^ mul(14, bArr4[i10])) ^ mul(11, bArr4[i11])) ^ mul(13, bArr4[i12]));
                    bArr3[i11] = (byte) (((mul(13, bArr4[i9]) ^ mul(9, bArr4[i10])) ^ mul(14, bArr4[i11])) ^ mul(11, bArr4[i12]));
                    bArr3[i12] = (byte) (((mul(11, bArr4[i9]) ^ mul(13, bArr4[i10])) ^ mul(9, bArr4[i11])) ^ mul(14, bArr4[i12]));
                    i7++;
                }
                i3++;
            }
            byte[] bArr7 = this.Kd[i];
            for (int i13 = 0; i13 < 16; i13++) {
                bArr4[i13] = bArr3[((i13 + 16) - (row_shift[i13 % 4] * 4)) % 16];
            }
            for (int i14 = 0; i14 < 16; i14++) {
                bArr4[i14] = Si[bArr4[i14] & Constants.UNKNOWN];
            }
            for (int i15 = 0; i15 < 16; i15++) {
                bArr3[i15] = (byte) (bArr4[i15] ^ bArr7[i15]);
            }
            return bArr3;
        } else {
            throw new IllegalArgumentException("Incorrect ciphertext length");
        }
    }

    public void setKey(byte[] bArr) {
        byte[] bArr2 = bArr;
        Class<byte> cls = byte.class;
        if (bArr2 == null) {
            throw new IllegalArgumentException("Empty key");
        } else if (bArr2.length == 16 || bArr2.length == 24 || bArr2.length == 32) {
            int length = bArr2.length;
            int i = length / 4;
            int rounds = getRounds(length);
            this.numRounds = rounds;
            int i2 = (rounds + 1) * 4;
            byte[] bArr3 = new byte[i2];
            byte[] bArr4 = new byte[i2];
            byte[] bArr5 = new byte[i2];
            byte[] bArr6 = new byte[i2];
            int i3 = rounds + 1;
            int[] iArr = new int[2];
            iArr[1] = 16;
            iArr[0] = i3;
            this.Ke = (byte[][]) Array.newInstance(cls, iArr);
            int i4 = this.numRounds + 1;
            int[] iArr2 = new int[2];
            iArr2[1] = 16;
            iArr2[0] = i4;
            this.Kd = (byte[][]) Array.newInstance(cls, iArr2);
            int i5 = 0;
            for (int i6 = 0; i6 < i; i6++) {
                int i7 = i5 + 1;
                bArr3[i6] = bArr2[i5];
                int i8 = i7 + 1;
                bArr4[i6] = bArr2[i7];
                int i9 = i8 + 1;
                bArr5[i6] = bArr2[i8];
                i5 = i9 + 1;
                bArr6[i6] = bArr2[i9];
            }
            for (int i10 = i; i10 < i2; i10++) {
                int i11 = i10 - 1;
                byte b = bArr3[i11];
                byte b2 = bArr4[i11];
                byte b3 = bArr5[i11];
                byte b4 = bArr6[i11];
                int i12 = i10 % i;
                if (i12 == 0) {
                    byte[] bArr7 = S;
                    byte b5 = (byte) (bArr7[b2 & Constants.UNKNOWN] ^ rcon[i10 / i]);
                    byte b6 = bArr7[b3 & Constants.UNKNOWN];
                    byte b7 = b6;
                    b3 = bArr7[b4 & Constants.UNKNOWN];
                    b4 = bArr7[b & Constants.UNKNOWN];
                    b = b5;
                    b2 = b7;
                } else if (i > 6 && i12 == 4) {
                    byte[] bArr8 = S;
                    b = bArr8[b & Constants.UNKNOWN];
                    b2 = bArr8[b2 & Constants.UNKNOWN];
                    b3 = bArr8[b3 & Constants.UNKNOWN];
                    b4 = bArr8[b4 & Constants.UNKNOWN];
                }
                int i13 = i10 - i;
                bArr3[i10] = (byte) (b ^ bArr3[i13]);
                bArr4[i10] = (byte) (bArr4[i13] ^ b2);
                bArr5[i10] = (byte) (bArr5[i13] ^ b3);
                bArr6[i10] = (byte) (b4 ^ bArr6[i13]);
            }
            int i14 = 0;
            for (int i15 = 0; i15 < this.numRounds + 1; i15++) {
                for (int i16 = 0; i16 < 4; i16++) {
                    byte[][] bArr9 = this.Ke;
                    int i17 = i16 * 4;
                    bArr9[i15][i17] = bArr3[i14];
                    int i18 = i17 + 1;
                    bArr9[i15][i18] = bArr4[i14];
                    int i19 = i17 + 2;
                    bArr9[i15][i19] = bArr5[i14];
                    int i20 = i17 + 3;
                    bArr9[i15][i20] = bArr6[i14];
                    byte[][] bArr10 = this.Kd;
                    int i21 = this.numRounds;
                    bArr10[i21 - i15][i17] = bArr3[i14];
                    bArr10[i21 - i15][i18] = bArr4[i14];
                    bArr10[i21 - i15][i19] = bArr5[i14];
                    bArr10[i21 - i15][i20] = bArr6[i14];
                    i14++;
                }
            }
        } else {
            throw new IllegalArgumentException("Incorrect key length");
        }
    }

    public static String static_byteArrayToString(byte[] bArr) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < bArr.length; i++) {
            byte b = bArr[i];
            stringBuffer.append((char) (b < 0 ? b + 256 : b));
        }
        return stringBuffer.toString();
    }

    public static byte[] static_stringToByteArray(String str) {
        byte[] bArr = new byte[str.length()];
        for (int i = 0; i < str.length(); i++) {
            bArr[i] = (byte) str.charAt(i);
        }
        return bArr;
    }

    public static String static_intArrayToString(int[] iArr) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i : iArr) {
            stringBuffer.append((char) i);
        }
        return stringBuffer.toString();
    }

    public String _cryptAll(String str, int i) {
        int length = str.length() - ((str.length() / 16) * 16);
        if ((length > 0) && (i == 1)) {
            for (int i2 = 0; i2 < 16 - length; i2++) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append(" ");
                str = sb.toString();
            }
        }
        int length2 = str.length() / 16;
        byte[] bArr = new byte[str.length()];
        for (int i3 = 0; i3 < length2; i3++) {
            int i4 = i3 * 16;
            byte[] static_stringToByteArray = static_stringToByteArray(str.substring(i4, i4 + 16));
            if (i == 1) {
                static_stringToByteArray = encrypt(static_stringToByteArray);
            }
            if (i == 2) {
                static_stringToByteArray = decrypt(static_stringToByteArray);
            }
            for (int i5 = 0; i5 < 16; i5++) {
                bArr[i4 + i5] = static_stringToByteArray[i5];
            }
        }
        return static_byteArrayToString(bArr);
    }

    public String Encrypt(String str) {
        return _cryptAll(str, 1);
    }

    public String Decrypt(String str) {
        return _cryptAll(str, 2);
    }

    public void setKey(String str) {
        setKey(static_stringToByteArray(str));
    }
}
