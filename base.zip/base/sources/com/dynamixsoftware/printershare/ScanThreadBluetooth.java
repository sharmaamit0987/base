package com.dynamixsoftware.printershare;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.bt.BTAdapter;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import java.util.Hashtable;
import java.util.Vector;

public class ScanThreadBluetooth extends Thread {
    private BroadcastReceiver br;
    /* access modifiers changed from: private */
    public BTAdapter bta;
    private Context context;
    private boolean[] destroyed = new boolean[1];
    private Vector<Printer> printers;
    private String rq_pid;
    private Handler status;
    private int timeout;

    public ScanThreadBluetooth(Context context2, int i, String str, Handler handler) {
        this.context = context2;
        this.timeout = i;
        this.rq_pid = str;
        this.status = handler;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
            interrupt();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x018d, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x018e, code lost:
        r0.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x0197, code lost:
        r0 = new android.os.Message();
        r0.what = 3;
        r0.arg1 = 3;
        r2 = new android.os.Bundle();
        r2.putString("message", r9);
        r0.setData(r2);
        r1.status.sendMessage(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x01b3, code lost:
        r0 = new android.os.Message();
        r0.what = 4;
        r0.arg1 = 3;
        r1.status.sendMessage(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:10:?, code lost:
        r0 = com.dynamixsoftware.printershare.bt.BTAdapter.getDefault(r1.context);
        r1.bta = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002e, code lost:
        if (r0 == null) goto L_0x008a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0034, code lost:
        if (r0.isEnabled() == false) goto L_0x008a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0036, code lost:
        r0 = r1.bta.getBondedDevices().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0044, code lost:
        if (r0.hasNext() == false) goto L_0x0066;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0046, code lost:
        r9 = (com.dynamixsoftware.printershare.bt.BTDevice) r0.next();
        r4.add(new java.lang.Object[]{r9.getAddress(), r9.getName(), r9.getDeviceClass(), null});
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0066, code lost:
        r0 = new com.dynamixsoftware.printershare.ScanThreadBluetooth.AnonymousClass1(r15);
        r1.br = r0;
        r1.context.registerReceiver(r0, r1.bta.getDiscoveryIntentFilter());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x007e, code lost:
        if (r1.bta.isDiscovering() == false) goto L_0x0085;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0080, code lost:
        r1.bta.cancelDiscovery();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0085, code lost:
        r1.bta.startDiscovery();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x008a, code lost:
        r9 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x008c, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008d, code lost:
        r9 = new java.lang.StringBuilder();
        r9.append("Internal Error: ");
        r9.append(r0.getMessage());
        r9 = r9.toString();
        r0.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0121, code lost:
        if ((java.lang.System.currentTimeMillis() - r10) >= ((long) r1.timeout)) goto L_0x0123;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0127, code lost:
        r1.context.unregisterReceiver(r1.br);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0134, code lost:
        if (r1.bta.isDiscovering() != false) goto L_0x0136;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x0136, code lost:
        r1.bta.cancelDiscovery();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x0149, code lost:
        r4 = r12.keys();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001e, code lost:
        r4 = new java.util.Vector();
        r7 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x0151, code lost:
        if (r4.hasMoreElements() != false) goto L_0x0153;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:?, code lost:
        r0 = (java.lang.Object[]) r12.get(r4.nextElement());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x015f, code lost:
        if (r0[3] == null) goto L_0x0161;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0161, code lost:
        r6 = r1.bta.getRemoteDevice((java.lang.String) r0[0]);
        r0[1] = r6.getName();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x017f, code lost:
        r0[1] = r0[0];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0183, code lost:
        r0[2] = r6.getDeviceClass();
        parseDev(r0);
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:66:0x010f */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x0197  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x01b3  */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x0127 A[EDGE_INSN: B:112:0x0127->B:73:0x0127 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0117 A[Catch:{ Exception -> 0x0142 }] */
    public void run() {
        final Vector vector;
        Object[] objArr;
        String str;
        Object[] objArr2;
        Message message = new Message();
        message.what = 1;
        message.arg1 = 3;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            if (this.destroyed[0]) {
                return;
            }
        }
        if (str == null && this.br != null) {
            long currentTimeMillis = System.currentTimeMillis();
            Hashtable hashtable = new Hashtable();
            while (true) {
                try {
                    synchronized (vector) {
                        objArr2 = vector.size() > 0 ? (Object[]) vector.remove(0) : objArr;
                    }
                    if (objArr2 != null) {
                        try {
                            Object[] objArr3 = (Object[]) hashtable.get((String) objArr2[0]);
                            if (objArr3 != null) {
                                if (objArr3[1] == null) {
                                    objArr3[1] = objArr2[1];
                                }
                                if (objArr3[2] == null) {
                                    objArr3[2] = objArr2[2];
                                }
                                objArr2 = objArr3;
                            } else {
                                hashtable.put((String) objArr2[0], objArr2);
                            }
                            if (objArr2[3] == null) {
                                parseDev(objArr2);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    } else {
                        synchronized (this.destroyed) {
                            if (this.destroyed[0]) {
                                break;
                            }
                            Thread.sleep(500);
                        }
                    }
                    if (!this.bta.isDiscovering()) {
                    }
                    objArr = null;
                } catch (Exception e2) {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                }
            }
            while (true) {
            }
        }
        if (str == null) {
        }
    }

    private void parseDev(Object[] objArr) {
        if (!(objArr[1] == null || objArr[2] == null)) {
            int intValue = objArr[2].intValue();
            if (((intValue & 7936) >> 8) != 6 || (intValue & 128) == 0) {
                objArr[3] = Boolean.FALSE;
            } else {
                String str = objArr[1];
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append("._pdl-datastream._bluetooth.local.");
                String sb2 = sb.toString();
                String str2 = this.rq_pid;
                if (str2 == null || sb2.equals(str2)) {
                    Printer printer = new Printer();
                    printer.id = sb2;
                    printer.owner = new User();
                    printer.owner.name = str;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("bluetooth://");
                    sb3.append(objArr[0]);
                    printer.direct_address = sb3.toString();
                    printer.model = recognizeModel(str);
                    printer.title = ("".equals(printer.model) || str.equals(printer.model)) ? "Bluetooth Printer" : printer.model;
                    objArr[3] = Boolean.TRUE;
                    synchronized (this.printers) {
                        this.printers.add(printer);
                    }
                    Message message = new Message();
                    message.what = 2;
                    message.arg1 = 3;
                    this.status.sendMessage(message);
                    String str3 = this.rq_pid;
                    if (str3 != null && str3.equals(printer.id)) {
                        destroy();
                    }
                    return;
                }
                objArr[3] = Boolean.FALSE;
            }
        }
    }

    public static String recognizeModel(String str) {
        if (str == null) {
            return "";
        }
        String trim = str.trim();
        String str2 = "-";
        if (trim.lastIndexOf(str2) == trim.length() - 2 && trim.charAt(trim.length() - 1) >= '0' && trim.charAt(trim.length() - 1) <= '9') {
            trim = trim.substring(0, trim.length() - 2).trim();
        }
        int indexOf = trim.indexOf("(");
        if (indexOf >= 0) {
            trim = trim.substring(0, indexOf).trim();
        }
        int indexOf2 = trim.indexOf(" S/N");
        if (indexOf2 >= 0) {
            trim = trim.substring(0, indexOf2).trim();
        }
        int indexOf3 = trim.indexOf(" SN:");
        if (indexOf3 >= 0) {
            trim = trim.substring(0, indexOf3).trim();
        }
        int indexOf4 = trim.indexOf(" series-");
        if (indexOf4 >= 0) {
            trim = trim.substring(0, indexOf4 + 1).concat("series");
        }
        String str3 = "_";
        if (trim.startsWith("Photosmart") || trim.startsWith("photosmart") || trim.startsWith("OfficeJet") || trim.startsWith("Officejet") || trim.startsWith("officejet") || trim.startsWith("Deskjet") || trim.startsWith("deskjet") || trim.startsWith("dj450")) {
            StringBuilder sb = new StringBuilder();
            sb.append("HP ");
            sb.append(trim);
            trim = sb.toString();
            int lastIndexOf = trim.lastIndexOf(str3);
            if (lastIndexOf >= 0) {
                trim = trim.substring(0, lastIndexOf).trim();
            }
        }
        if (trim.startsWith("Canon DS700")) {
            trim = "Canon SELPHY DS700";
        }
        if (trim.startsWith("Canon DS810")) {
            trim = "Canon SELPHY DS810";
        }
        String str4 = "Epson ";
        if (trim.startsWith("Stylus Photo")) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str4);
            sb2.append(trim);
            trim = sb2.toString();
        }
        if (trim.startsWith("PM-A890")) {
            trim = "Epson PM-A890";
        }
        if (trim.startsWith("TM-P")) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str4);
            sb3.append(trim);
            trim = sb3.toString();
            int lastIndexOf2 = trim.lastIndexOf(str3);
            if (lastIndexOf2 >= 0) {
                trim = trim.substring(0, lastIndexOf2).trim();
            }
        }
        if (trim.startsWith("OJL411")) {
            trim = "HP Officejet 100 Mobile L411";
        }
        if (trim.startsWith("OJL511") || "OfficeJet150".equals(trim)) {
            trim = "HP Officejet 150 Mobile L511";
        }
        String str5 = "Brother ";
        if (trim.startsWith("PJ-") || trim.startsWith("MW-") || trim.startsWith("RJ-")) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str5);
            sb4.append(trim.substring(0, trim.length() - 4));
            trim = sb4.toString();
        }
        if (trim.startsWith("MFC-")) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(str5);
            sb5.append(trim);
            trim = sb5.toString();
        }
        if (trim.startsWith("ASL Ap")) {
            int indexOf5 = trim.indexOf(str2);
            StringBuilder sb6 = new StringBuilder();
            sb6.append("Able ");
            sb6.append((indexOf5 < 0 ? trim.substring(4) : trim.substring(4, indexOf5)).trim());
            trim = sb6.toString();
        }
        if (trim.startsWith("FTP-")) {
            int indexOf6 = trim.indexOf(" ");
            StringBuilder sb7 = new StringBuilder();
            sb7.append("Fujitsu ");
            if (indexOf6 >= 0) {
                trim = trim.substring(0, indexOf6).trim();
            }
            sb7.append(trim);
            trim = sb7.toString();
        }
        if (trim.startsWith("XX")) {
            trim = "Zebra Bluetooth Printer";
        }
        if (trim.startsWith("MZ") || trim.startsWith("RW")) {
            StringBuilder sb8 = new StringBuilder();
            sb8.append("Zebra ");
            sb8.append(trim);
            trim = sb8.toString();
        }
        return trim;
    }
}
