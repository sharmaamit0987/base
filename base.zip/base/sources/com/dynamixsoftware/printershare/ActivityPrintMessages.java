package com.dynamixsoftware.printershare;

import android.content.ContentUris;
import android.database.Cursor;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Telephony.Mms;
import android.provider.Telephony.Sms;
import android.text.TextUtils;
import com.android.mms.model.SlideModel;
import com.android.mms.model.SlideshowModel;
import com.google.android.mms.MmsException;
import com.google.android.mms.pdu.EncodedStringValue;
import com.google.android.mms.pdu.MultimediaMessagePdu;
import com.google.android.mms.pdu.NotificationInd;
import com.google.android.mms.pdu.PduPersister;
import com.google.android.mms.pdu.RetrieveConf;
import com.google.android.mms.pdu.SendReq;
import java.util.StringTokenizer;
import java.util.Vector;

public class ActivityPrintMessages extends ActivityPrintText {
    private ContactInfoCache cache;
    private String dat;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String string = getIntent().getExtras().getString("data");
        this.dat = string;
        if (string == null) {
            setResult(0);
            finish();
        }
        this.cache = new ContactInfoCache(this);
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        String str;
        char c;
        char c2;
        String string;
        MmsException mmsException;
        String str2;
        long j;
        String str3;
        long date;
        String str4;
        if (checkPermission("android.permission.READ_SMS")) {
            initPage();
            Vector vector = new Vector();
            String str5 = "\n";
            StringTokenizer stringTokenizer = new StringTokenizer(this.dat, str5);
            while (true) {
                str = " ";
                int i = 3;
                int i2 = 4;
                int i3 = 2;
                c = 0;
                c2 = 1;
                if (!stringTokenizer.hasMoreTokens()) {
                    break;
                }
                String nextToken = stringTokenizer.nextToken();
                int indexOf = nextToken.indexOf(str);
                String substring = nextToken.substring(0, indexOf);
                vector.add(new Object[]{Integer.valueOf(0), nextToken.substring(indexOf + 1)});
                StringBuilder sb = new StringBuilder();
                sb.append("content://mms-sms/conversations/");
                sb.append(substring);
                Cursor query = getContentResolver().query(Uri.parse(sb.toString()), new String[]{"transport_type", "_id", "thread_id", "address", "body", "date", "read", "type", "status", "sub", "sub_cs", "date", "read", "m_type", "msg_box", "d_rpt", "rr", "err_type"}, null, null, null);
                while (query.moveToNext()) {
                    String string2 = query.getString(0);
                    long j2 = query.getLong(1);
                    String str6 = "Me";
                    String str7 = null;
                    if ("sms".equals(string2)) {
                        ContentUris.withAppendedId(Sms.CONTENT_URI, j2);
                        int i4 = query.getInt(7);
                        String string3 = query.getString(i);
                        if (!(i4 == 5 || i4 == i2 || i4 == i3 || i4 == 6)) {
                            str6 = this.cache.getContactName(string3);
                        }
                        str2 = query.getString(i2);
                        string = null;
                        str7 = String.format(getString(R.string.sent_on), new Object[]{App.formatTimeStampString(this, query.getLong(5), true)});
                    } else if ("mms".equals(string2)) {
                        Uri withAppendedId = ContentUris.withAppendedId(Mms.CONTENT_URI, j2);
                        query.getInt(14);
                        int i5 = query.getInt(13);
                        String string4 = query.getString(9);
                        string = !TextUtils.isEmpty(string4) ? new EncodedStringValue(query.getInt(10), PduPersister.getBytes(string4)).getString() : null;
                        PduPersister pduPersister = PduPersister.getPduPersister(getApplicationContext());
                        String str8 = "Anonymous";
                        if (130 == i5) {
                            try {
                                NotificationInd load = pduPersister.load(withAppendedId);
                                EncodedStringValue from = load.getFrom();
                                if (from != null) {
                                    str6 = this.cache.getContactName(from.getString());
                                } else {
                                    str6 = str8;
                                }
                                try {
                                    str3 = new String(load.getContentLocation());
                                } catch (MmsException e) {
                                    mmsException = e;
                                    str2 = null;
                                    mmsException.printStackTrace();
                                    App.reportThrowable(mmsException);
                                    i3 = 2;
                                    vector.add(new Object[]{Integer.valueOf(1), str6, str7, string, str2});
                                    i = 3;
                                    i2 = 4;
                                }
                                try {
                                    j = load.getExpiry() * 1000;
                                } catch (MmsException e2) {
                                    String str9 = str3;
                                    mmsException = e2;
                                    str2 = str9;
                                    mmsException.printStackTrace();
                                    App.reportThrowable(mmsException);
                                    i3 = 2;
                                    vector.add(new Object[]{Integer.valueOf(1), str6, str7, string, str2});
                                    i = 3;
                                    i2 = 4;
                                }
                            } catch (MmsException e3) {
                                mmsException = e3;
                                str2 = null;
                                str6 = null;
                                mmsException.printStackTrace();
                                App.reportThrowable(mmsException);
                                i3 = 2;
                                vector.add(new Object[]{Integer.valueOf(1), str6, str7, string, str2});
                                i = 3;
                                i2 = 4;
                            }
                        } else {
                            RetrieveConf retrieveConf = (MultimediaMessagePdu) pduPersister.load(withAppendedId);
                            SlideshowModel createFromPduBody = SlideshowModel.createFromPduBody(this, retrieveConf.getBody());
                            if (i5 == 132) {
                                RetrieveConf retrieveConf2 = retrieveConf;
                                EncodedStringValue from2 = retrieveConf2.getFrom();
                                if (from2 != null) {
                                    str4 = this.cache.getContactName(from2.getString());
                                } else {
                                    str4 = str8;
                                }
                                date = retrieveConf2.getDate();
                            } else {
                                date = ((SendReq) retrieveConf).getDate();
                            }
                            j = date * 1000;
                            str3 = "";
                            for (int i6 = 0; i6 < createFromPduBody.size(); i6++) {
                                SlideModel slideModel = createFromPduBody.get(i6);
                                if (slideModel != null && slideModel.hasText()) {
                                    if (slideModel.getText().isDrmProtected()) {
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append(str3);
                                        sb2.append("\n* DRM protected text *");
                                        str3 = sb2.toString();
                                    } else {
                                        StringBuilder sb3 = new StringBuilder();
                                        sb3.append(str3);
                                        sb3.append(str5);
                                        sb3.append(slideModel.getText().getText());
                                        str3 = sb3.toString();
                                    }
                                }
                            }
                            if (str3.length() > 0) {
                                str3 = str3.substring(1);
                            }
                        }
                        str7 = String.format(getString(R.string.sent_on), new Object[]{App.formatTimeStampString(this, j, true)});
                        str2 = str3;
                    }
                    i3 = 2;
                    vector.add(new Object[]{Integer.valueOf(1), str6, str7, string, str2});
                    i = 3;
                    i2 = 4;
                }
                query.close();
            }
            int i7 = 0;
            while (i7 < vector.size()) {
                newPage();
                Object[] objArr = (Object[]) vector.elementAt(i7);
                if (((Integer) objArr[c]).intValue() == 0) {
                    Paint newPaint = App.newPaint();
                    newPaint.setStyle(Style.FILL);
                    int testTextSize = testTextSize((String) objArr[c2], 70, true, 0.0f, 20) + 30;
                    if (needNew(10, testTextSize + 45)) {
                        i7--;
                    } else {
                        printRect(-2565928, 0, 0, this.page.getWidth() - (this.ml + this.mr), (int) (((float) testTextSize) * this.fontSizeCoef));
                        newPaint.setColor(-16777216);
                        printText((String) objArr[c2], 70, true, 0.0f, 20, 70, testTextSize, newPaint);
                    }
                } else {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append((String) objArr[1]);
                    sb4.append(": ");
                    String sb5 = sb4.toString();
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append((String) objArr[4]);
                    sb6.append(str);
                    String sb7 = sb6.toString();
                    String str10 = (String) objArr[3];
                    if (str10 != null && str10.length() > 0) {
                        StringBuilder sb8 = new StringBuilder();
                        sb8.append("<");
                        sb8.append(str10);
                        sb8.append("> ");
                        sb8.append(sb7);
                        sb7 = sb8.toString();
                    }
                    String str11 = sb7;
                    Paint newPaint2 = App.newPaint();
                    newPaint2.setStyle(Style.FILL);
                    newPaint2.setTextSize(45.0f);
                    StringBuilder sb9 = new StringBuilder();
                    sb9.append(sb5);
                    sb9.append(str11);
                    if (needNew(0, testTextSize(sb9.toString(), 45, true, 0.0f, 20) + (objArr[2] != null ? testTextSize((String) objArr[2], 30, false, 0.0f, 10) : 0))) {
                        StringBuilder sb10 = new StringBuilder();
                        sb10.append(sb5);
                        sb10.append(str11);
                        if (!needNew(0, testTextSize(sb10.toString(), 45, true, 0.0f, 20))) {
                            i7--;
                        }
                    }
                    int length = sb5.length();
                    float[] fArr = new float[length];
                    newPaint2.getTextWidths(sb5, 0, sb5.length(), fArr);
                    float f = 0.0f;
                    for (int i8 = 0; i8 < length; i8++) {
                        f += fArr[i8];
                    }
                    String str12 = str11;
                    Paint paint = newPaint2;
                    printText(sb5, 45, true, 0.0f, 20, 45, 55, paint);
                    this.canvas.translate(0.0f, this.fontSizeCoef * -55.0f);
                    this.th = (int) (((float) this.th) + (this.fontSizeCoef * -55.0f));
                    printText(str12, 45, false, f, 20, 45, 55, paint);
                    paint.setColor(-8355712);
                    if (objArr[2] != null) {
                        printText((String) objArr[2], 30, false, 0.0f, 10, 30, 40, paint);
                    }
                }
                i7++;
                c2 = 1;
                c = 0;
            }
            addPage();
        }
    }
}
