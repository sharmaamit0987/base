package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.SoapEnvelope;
import com.dynamixsoftware.printershare.data.XmlUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ActivityFindPrinters extends ActivityCore {
    private static final int DIALOG_SEARCH = 1;
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    /* access modifiers changed from: private */
    public View view_dialog_search;
    /* access modifiers changed from: private */
    public Thread wt;

    class AddPrinterThread extends Thread {
        private Printer prn;

        public AddPrinterThread(Printer printer) {
            this.prn = printer;
        }

        public void run() {
            String str = "printer";
            ActivityFindPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityFindPrinters.this.showProgress(ActivityFindPrinters.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityFindPrinters.this.last_error = null;
            try {
                SoapEnvelope soapEnvelope = new SoapEnvelope("ChangePrinters", "Param", "data");
                Element dataRoot = soapEnvelope.getDataRoot();
                XmlUtil.appendElement(dataRoot, "token", ActivityCore.remote_token);
                dataRoot.setAttribute("action", "like");
                XmlUtil.appendElement(XmlUtil.appendElement(dataRoot, str), "public-id", this.prn.id);
                Element dataRoot2 = App.psService.doAction(soapEnvelope).getDataRoot();
                if ("true".equals(dataRoot2.getAttribute("success"))) {
                    Printer printer = new Printer();
                    this.prn = printer;
                    printer.readFromXml(XmlUtil.getFirstElement(dataRoot2, str));
                    ActivityCore.remote_printers.add(this.prn);
                    if (ActivityCore.printer == null) {
                        ActivityFindPrinters.this.setPrinter(this.prn);
                    }
                } else {
                    ActivityFindPrinters activityFindPrinters = ActivityFindPrinters.this;
                    StringBuilder sb = new StringBuilder();
                    sb.append("Error: ");
                    sb.append(XmlUtil.getFirstNodeValue(dataRoot2, "message"));
                    activityFindPrinters.last_error = sb.toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityFindPrinters activityFindPrinters2 = ActivityFindPrinters.this;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Internal Error: ");
                sb2.append(e.getMessage());
                activityFindPrinters2.last_error = sb2.toString();
                App.reportThrowable(e);
            }
            if (ActivityFindPrinters.this.last_error == null) {
                ActivityFindPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityFindPrinters.this.hideProgress();
                        if (ActivityCore.remote_printers.size() == 1) {
                            ActivityFindPrinters.this.setResult(-1);
                        }
                        ActivityFindPrinters.this.finish();
                    }
                });
            } else {
                ActivityFindPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityFindPrinters.this.hideProgress();
                        ActivityFindPrinters.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
            }
            ActivityFindPrinters.this.wt = null;
        }
    }

    class FindPrinterThread extends Thread {
        String keyword;
        boolean online_only;

        public FindPrinterThread(String str, boolean z) {
            this.keyword = str;
            this.online_only = z;
        }

        public void run() {
            String str = "true";
            ActivityFindPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityFindPrinters.this.showProgress(ActivityFindPrinters.this.getResources().getString(R.string.label_searching));
                }
            });
            ActivityFindPrinters.this.last_error = null;
            if (ActivityFindPrinters.this.printers == null) {
                ActivityFindPrinters.this.printers = new Vector();
            }
            ActivityFindPrinters.this.printers.clear();
            try {
                SoapEnvelope soapEnvelope = new SoapEnvelope("SearchPrinters", "Param", "data");
                Element dataRoot = soapEnvelope.getDataRoot();
                XmlUtil.appendElement(dataRoot, "token", ActivityCore.remote_token);
                dataRoot.setAttribute("page-size", "50");
                dataRoot.setAttribute("echo", "mobile");
                dataRoot.setAttribute("real", str);
                if (this.online_only) {
                    dataRoot.setAttribute("online", str);
                }
                XmlUtil.appendElement(dataRoot, "keyword", this.keyword);
                Element dataRoot2 = App.psService.doAction(soapEnvelope).getDataRoot();
                if (str.equals(dataRoot2.getAttribute("success"))) {
                    NodeList elementsByTagName = dataRoot2.getElementsByTagName("printer");
                    int length = elementsByTagName.getLength();
                    for (int i = 0; i < length; i++) {
                        Printer printer = new Printer();
                        printer.readFromXml((Element) elementsByTagName.item(i));
                        ActivityFindPrinters.this.printers.add(printer);
                    }
                } else {
                    ActivityFindPrinters activityFindPrinters = ActivityFindPrinters.this;
                    StringBuilder sb = new StringBuilder();
                    sb.append("Error: ");
                    sb.append(XmlUtil.getFirstNodeValue(dataRoot2, "message"));
                    activityFindPrinters.last_error = sb.toString();
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityFindPrinters activityFindPrinters2 = ActivityFindPrinters.this;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Internal Error: ");
                sb2.append(e.getMessage());
                activityFindPrinters2.last_error = sb2.toString();
                App.reportThrowable(e);
            }
            ActivityFindPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    String str;
                    Object obj;
                    ActivityFindPrinters.this.hideProgress();
                    TextView textView = (TextView) ActivityFindPrinters.this.findViewById(R.id.hint1);
                    if (ActivityFindPrinters.this.printers != null) {
                        String string = ActivityFindPrinters.this.getResources().getString(R.string.label_found_printers);
                        Object[] objArr = new Object[1];
                        if (ActivityFindPrinters.this.printers.size() >= 50) {
                            obj = String.format(ActivityFindPrinters.this.getResources().getString(R.string.label_more_then), new Object[]{"50"});
                        } else {
                            obj = Integer.valueOf(ActivityFindPrinters.this.printers.size());
                        }
                        objArr[0] = obj;
                        str = String.format(string, objArr);
                    } else {
                        str = "";
                    }
                    textView.setText(str);
                    ((PrinterAdapter) ((ListView) ActivityFindPrinters.this.findViewById(R.id.list)).getAdapter()).fireOnChanged();
                    if (ActivityFindPrinters.this.last_error != null) {
                        ActivityFindPrinters.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                }
            });
            ActivityFindPrinters.this.wt = null;
        }
    }

    class PrinterAdapter implements ListAdapter {
        public Context mContext;
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getItemViewType(int i) {
            return 1;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        public PrinterAdapter(Context context) {
            this.mContext = context;
        }

        public int getCount() {
            if (ActivityFindPrinters.this.printers != null) {
                return ActivityFindPrinters.this.printers.size();
            }
            return 0;
        }

        public Object getItem(int i) {
            return ActivityFindPrinters.this.printers.elementAt(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            View inflate = LayoutInflater.from(this.mContext).inflate(R.layout.printer, null);
            Printer printer = (Printer) ActivityFindPrinters.this.printers.elementAt(i);
            TextView textView = (TextView) inflate.findViewById(R.id.printer_owner);
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append(printer.owner.login);
            sb.append("]");
            String sb2 = sb.toString();
            if (printer.owner.nick != null && printer.owner.nick.length() > 0) {
                sb2 = printer.owner.nick;
            }
            if (printer.owner.name != null && printer.owner.name.length() > 0) {
                sb2 = printer.owner.name;
            }
            textView.setText(sb2);
            String str = "";
            ((TextView) inflate.findViewById(R.id.printer_name)).setText((printer == null || printer.title == null) ? str : printer.title);
            TextView textView2 = (TextView) inflate.findViewById(R.id.printer_location);
            String str2 = (printer.owner.country == null || printer.owner.country.length() <= 0) ? str : printer.owner.country;
            String str3 = ", ";
            if (printer.owner.city != null && printer.owner.city.length() > 0) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append(printer.owner.city);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb3.append(str3);
                sb3.append(str2);
                str2 = sb3.toString();
            } else if (printer.owner.state != null && printer.owner.state.length() > 0) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append(printer.owner.state);
                if (str2.length() <= 0) {
                    str3 = str;
                }
                sb4.append(str3);
                sb4.append(str2);
                str2 = sb4.toString();
            }
            if (printer.location != null && printer.location.length() > 0) {
                str2 = printer.location;
            }
            if (str2 != null) {
                str = str2;
            }
            textView2.setText(str);
            int i2 = 0;
            textView2.setVisibility(str.length() > 0 ? 0 : 8);
            ImageView imageView = (ImageView) inflate.findViewById(R.id.printer_status);
            int i3 = printer.online != null ? printer.online.booleanValue() ? R.drawable.printer_on : R.drawable.printer_off : R.drawable.printer;
            imageView.setBackgroundResource(i3);
            View findViewById = inflate.findViewById(R.id.printer_current);
            if (printer != ActivityCore.printer) {
                i2 = 4;
            }
            findViewById.setVisibility(i2);
            inflate.setTag(printer);
            return inflate;
        }

        public boolean isEmpty() {
            return ActivityFindPrinters.this.printers == null || ActivityFindPrinters.this.printers.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.header_find_printers);
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.button_search);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityFindPrinters.this.showDialog(1);
            }
        });
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(new PrinterAdapter(this));
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Printer printer = (Printer) view.getTag();
                if (!ActivityCore.remote_printers.contains(printer)) {
                    ActivityFindPrinters.this.wt = new AddPrinterThread(printer);
                    ActivityFindPrinters.this.wt.start();
                }
            }
        });
        showDialog(1);
    }

    /* access modifiers changed from: protected */
    public void init() {
        if (remote_user == null) {
            this.skip_update = true;
            Intent intent = new Intent();
            intent.setClass(this, ActivityStart.class);
            startActivityForResult(intent, 1);
        }
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        LayoutInflater from = LayoutInflater.from(this);
        if (i != 1) {
            return null;
        }
        this.view_dialog_search = from.inflate(R.layout.dialog_search, null);
        return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_search_title).setView(this.view_dialog_search).setInverseBackgroundForced(true).setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                if (ActivityFindPrinters.this.printers == null) {
                    ActivityFindPrinters.this.setResult(0);
                    ActivityFindPrinters.this.finish();
                }
            }
        }).setPositiveButton(R.string.button_search, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityFindPrinters.this.wt = new FindPrinterThread(((EditText) ActivityFindPrinters.this.view_dialog_search.findViewById(R.id.printer_keyword)).getText().toString(), ((CheckBox) ActivityFindPrinters.this.view_dialog_search.findViewById(R.id.printer_status)).isChecked());
                ActivityFindPrinters.this.wt.start();
            }
        }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }).create();
    }
}
