package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.os.Bundle;

public class ActivityUSB extends ActivityCore {
    public void onCreate(Bundle bundle) {
        String str = "_";
        super.onCreate(bundle);
        npc_pid = null;
        try {
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                UsbDevice usbDevice = (UsbDevice) extras.get("device");
                if (usbDevice != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(usbDevice.getDeviceId());
                    sb.append(str);
                    sb.append(usbDevice.getVendorId());
                    sb.append(str);
                    sb.append(usbDevice.getProductId());
                    npc_pid = sb.toString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        if (remote_token != null) {
            String string = this.prefs.getString("printer", null);
            if (string == null || npc_pid == null || string.indexOf("_usb.local.") <= 0 || !string.startsWith(npc_pid)) {
                showProgress(getResources().getString(R.string.label_processing));
            } else {
                remote_token = null;
            }
        } else {
            Intent intent = new Intent();
            intent.setClass(this, ActivityMain.class);
            startActivity(intent);
        }
    }

    public void update() {
        finish();
    }
}
