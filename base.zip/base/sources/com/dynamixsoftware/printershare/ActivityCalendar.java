package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Date;

public class ActivityCalendar extends ActivityRoot {
    private static final int DIALOG_END = 1;
    private static final int DIALOG_RANGE = 2;
    private static final int DIALOG_START = 0;
    private static final int RANGE_30DAYS = 3;
    private static final int RANGE_7DAYS = 2;
    private static final int RANGE_CUSTOM = 4;
    private static final int RANGE_TODAY = 0;
    private static final int RANGE_TOMORROW = 1;
    Time end;
    private OnDateSetListener endDateSetListener = new OnDateSetListener() {
        public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
            ActivityCalendar.this.end.year = i;
            ActivityCalendar.this.end.month = i2;
            ActivityCalendar.this.end.monthDay = i3;
            ActivityCalendar.this.displayDates();
        }
    };
    private OnItemClickListener listListener = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            if (i == 0) {
                ActivityCalendar.this.showDialog(2);
            }
            if (i == 1) {
                ActivityCalendar.this.showDialog(0);
            }
            if (i == 2) {
                ActivityCalendar.this.showDialog(1);
            }
        }
    };
    ListView mList;
    OnClickListener printClickListener = new OnClickListener() {
        public void onClick(View view) {
            try {
                if (ActivityCalendar.this.end.before(ActivityCalendar.this.start)) {
                    Toast.makeText(ActivityCalendar.this, R.string.toast_incorrect_date_range, 1).show();
                    return;
                }
                Intent intent = new Intent();
                intent.setClass(ActivityCalendar.this, ActivityPrintCalendar.class);
                intent.putExtra("start", ActivityCalendar.this.start.toMillis(false));
                intent.putExtra("end", ActivityCalendar.this.end.toMillis(false));
                ActivityCalendar.this.startActivityForResult(intent, 10);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
    };
    int range = 2;
    /* access modifiers changed from: private */
    public CharSequence[] ranges;
    Time start;
    private OnDateSetListener startDateSetListener = new OnDateSetListener() {
        public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
            ActivityCalendar.this.start.year = i;
            ActivityCalendar.this.start.month = i2;
            ActivityCalendar.this.start.monthDay = i3;
            ActivityCalendar.this.displayDates();
        }
    };
    Time today_end;
    Time today_start;

    class CalendarAdapter extends BaseAdapter {
        static final String dateFormat = "%x";

        public int getCount() {
            return 3;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        CalendarAdapter() {
        }

        public Object getItem(int i) {
            return Integer.valueOf(i);
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            boolean z = false;
            if (view == null) {
                view = ActivityCalendar.this.getLayoutInflater().inflate(R.layout.list_item_calendar, viewGroup, false);
            }
            TextView textView = (TextView) view.findViewById(R.id.from);
            TextView textView2 = (TextView) view.findViewById(R.id.subject);
            ImageView imageView = (ImageView) view.findViewById(R.id.arrow);
            if (i == 0) {
                textView.setText(R.string.label_select_date_range);
                textView2.setText(ActivityCalendar.this.ranges[ActivityCalendar.this.range]);
                textView.setEnabled(true);
                textView2.setEnabled(true);
                imageView.setVisibility(0);
            }
            String str = dateFormat;
            if (i == 1) {
                textView.setText(R.string.label_from);
                textView2.setText(ActivityCalendar.this.start.format(str));
                textView.setEnabled(ActivityCalendar.this.range == 4);
                textView2.setEnabled(ActivityCalendar.this.range == 4);
                imageView.setVisibility(8);
            }
            if (i == 2) {
                textView.setText(R.string.label_to);
                textView2.setText(ActivityCalendar.this.end.format(str));
                textView.setEnabled(ActivityCalendar.this.range == 4);
                if (ActivityCalendar.this.range == 4) {
                    z = true;
                }
                textView2.setEnabled(z);
                imageView.setVisibility(8);
            }
            return view;
        }

        public boolean isEnabled(int i) {
            boolean z = true;
            if (i != 1 && i != 2) {
                return true;
            }
            if (ActivityCalendar.this.range != 4) {
                z = false;
            }
            return z;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_calendar);
        Resources resources = getResources();
        CharSequence[] charSequenceArr = new CharSequence[5];
        this.ranges = charSequenceArr;
        charSequenceArr[0] = resources.getString(R.string.label_today);
        this.ranges[1] = resources.getString(R.string.label_tomorrow);
        this.ranges[2] = resources.getString(R.string.label_7days);
        this.ranges[3] = resources.getString(R.string.label_30days);
        this.ranges[4] = resources.getString(R.string.label_custom);
        populateToday();
        calculateDates();
        ListView listView = (ListView) findViewById(R.id.list);
        this.mList = listView;
        listView.setAdapter(new CalendarAdapter());
        this.mList.setOnItemClickListener(this.listListener);
        ((Button) findViewById(R.id.button_print)).setOnClickListener(this.printClickListener);
    }

    /* access modifiers changed from: 0000 */
    public void calculateDates() {
        int i = this.range;
        if (i == 0) {
            this.start = new Time(this.today_start);
            this.end = new Time(this.today_end);
        } else if (i == 1) {
            Time time = new Time(this.today_start);
            this.start = time;
            time.monthDay++;
            this.start.normalize(false);
            Time time2 = new Time(this.today_end);
            this.end = time2;
            time2.monthDay++;
            this.end.normalize(false);
        } else if (i == 2) {
            this.start = new Time(this.today_start);
            Time time3 = new Time(this.today_end);
            this.end = time3;
            time3.monthDay += 6;
            this.end.normalize(false);
        } else if (i == 3) {
            this.start = new Time(this.today_start);
            Time time4 = new Time(this.today_end);
            this.end = time4;
            time4.monthDay += 29;
            this.end.normalize(false);
        }
    }

    private void populateToday() {
        Time time = new Time();
        this.today_start = time;
        time.set(new Date().getTime());
        this.today_start.minute = 0;
        this.today_start.hour = 0;
        this.today_start.second = 0;
        Time time2 = new Time(this.today_start);
        this.today_end = time2;
        time2.hour = 23;
        this.today_end.minute = 59;
        this.today_end.second = 59;
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        if (i == 0) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, this.startDateSetListener, this.start.year, this.start.month, this.start.monthDay);
            return datePickerDialog;
        } else if (i == 1) {
            DatePickerDialog datePickerDialog2 = new DatePickerDialog(this, this.endDateSetListener, this.end.year, this.end.month, this.end.monthDay);
            return datePickerDialog2;
        } else if (i != 2) {
            return null;
        } else {
            return createRangeDialog();
        }
    }

    /* access modifiers changed from: protected */
    public void onPrepareDialog(int i, Dialog dialog) {
        if (i == 0) {
            ((DatePickerDialog) dialog).updateDate(this.start.year, this.start.month, this.start.monthDay);
        } else if (i == 1) {
            ((DatePickerDialog) dialog).updateDate(this.end.year, this.end.month, this.end.monthDay);
        }
        super.onPrepareDialog(i, dialog);
    }

    private Dialog createRangeDialog() {
        Builder builder = new Builder(this);
        builder.setIcon(R.drawable.icon_title);
        builder.setTitle(R.string.label_select_date_range);
        builder.setSingleChoiceItems(this.ranges, this.range, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                ActivityCalendar.this.range = i;
                ActivityCalendar.this.calculateDates();
                ActivityCalendar.this.displayDates();
            }
        });
        return builder.create();
    }

    /* access modifiers changed from: protected */
    public void displayDates() {
        ((BaseAdapter) this.mList.getAdapter()).notifyDataSetChanged();
    }
}
