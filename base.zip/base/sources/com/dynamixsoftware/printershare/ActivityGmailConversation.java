package com.dynamixsoftware.printershare;

import android.content.Intent;
import android.graphics.Picture;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import com.dynamixsoftware.printershare.gmail.GmsProtos;
import com.dynamixsoftware.printershare.gmail.ProtoBuf;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class ActivityGmailConversation extends ActivityRoot {
    public static final SimpleDateFormat df = new SimpleDateFormat("MMM d, yyyy h:mm a", new DateFormatSymbols(Locale.US));
    public static volatile Picture pp;
    /* access modifiers changed from: private */
    public long client_id;
    private CookieManager cm;
    /* access modifiers changed from: private */
    public long conversation_id;
    /* access modifiers changed from: private */
    public String[] credentials;
    private String labels;
    private long s_label_id;
    private long u_label_id;
    /* access modifiers changed from: private */
    public WebView vw;
    /* access modifiers changed from: private */
    public Thread wt;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.gmail_conversation);
        setTitle((int) R.string.button_main_gmail);
        this.vw = (WebView) findViewById(R.id.web_view);
        try {
            CookieSyncManager.createInstance(this);
            CookieManager instance = CookieManager.getInstance();
            this.cm = instance;
            if (instance != null) {
                instance.setAcceptCookie(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        this.vw.setWebChromeClient(new WebChromeClient() {
            public void onReceivedTitle(WebView webView, String str) {
            }

            public void onProgressChanged(WebView webView, final int i) {
                if (i == 100) {
                    ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ((TextView) ActivityGmailConversation.this.findViewById(R.id.hint1)).setText("");
                        }
                    });
                } else if (i == 0) {
                    ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ((TextView) ActivityGmailConversation.this.findViewById(R.id.hint1)).setText(R.string.label_loading);
                        }
                    });
                } else {
                    ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                        public void run() {
                            TextView textView = (TextView) ActivityGmailConversation.this.findViewById(R.id.hint1);
                            String string = ActivityGmailConversation.this.getResources().getString(R.string.label_loading_progress);
                            StringBuilder sb = new StringBuilder();
                            sb.append(i);
                            sb.append("%");
                            textView.setText(String.format(string, new Object[]{sb.toString()}));
                        }
                    });
                }
            }
        });
        this.vw.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (str.startsWith("content://printershare/gmail_att")) {
                    Uri parse = Uri.parse(str);
                    final String substring = parse.getPath().substring(parse.getPath().indexOf("."));
                    final String queryParameter = parse.getQueryParameter("msg_id");
                    final String queryParameter2 = parse.getQueryParameter("att_id");
                    final String queryParameter3 = parse.getQueryParameter("content_type");
                    final int parseInt = Integer.parseInt(parse.getQueryParameter("size"));
                    ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityGmailConversation.this.showProgress(ActivityGmailConversation.this.getResources().getString(R.string.label_loading));
                        }
                    });
                    ActivityGmailConversation activityGmailConversation = ActivityGmailConversation.this;
                    AnonymousClass2 r1 = new Thread() {
                        public void run() {
                            try {
                                File tempDir = App.getTempDir();
                                StringBuilder sb = new StringBuilder();
                                sb.append("printershare_temp_file");
                                sb.append(substring);
                                File file = new File(tempDir, sb.toString());
                                FileOutputStream fileOutputStream = new FileOutputStream(file);
                                InputStream loadAttachment = GmsProtos.loadAttachment(ActivityGmailConversation.this.credentials, queryParameter, queryParameter2);
                                byte[] bArr = new byte[4096];
                                int i = 0;
                                int i2 = 0;
                                while (true) {
                                    int read = loadAttachment.read(bArr);
                                    if (read == -1) {
                                        break;
                                    }
                                    fileOutputStream.write(bArr, 0, read);
                                    i += read;
                                    if (parseInt > 0) {
                                        final int i3 = (i * 100) / parseInt;
                                        if (i3 != i2) {
                                            ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                                                public void run() {
                                                    ActivityGmailConversation activityGmailConversation = ActivityGmailConversation.this;
                                                    String string = ActivityGmailConversation.this.getResources().getString(R.string.label_loading_progress);
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append(i3);
                                                    sb.append("%");
                                                    activityGmailConversation.showProgress(String.format(string, new Object[]{sb.toString()}));
                                                }
                                            });
                                            i2 = i3;
                                        }
                                    }
                                }
                                fileOutputStream.close();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.putExtra("temp_file", file.getAbsolutePath());
                                if (queryParameter3.startsWith("image/")) {
                                    intent.setClass(ActivityGmailConversation.this, ActivityPrintPictures.class);
                                } else if (queryParameter3.equals(NanoHTTPD.MIME_HTML)) {
                                    intent.setClass(ActivityGmailConversation.this, ActivityPrintWeb.class);
                                } else if (queryParameter3.equals("application/pdf")) {
                                    intent.setClass(ActivityGmailConversation.this, ActivityPrintPDF.class);
                                } else {
                                    intent.setClass(ActivityGmailConversation.this, ActivityPrintDocuments.class);
                                }
                                intent.setDataAndType(Uri.fromFile(file), queryParameter3);
                                ActivityGmailConversation.this.startActivity(intent);
                            } catch (Exception e) {
                                e.printStackTrace();
                                App.reportThrowable(e);
                            }
                            ActivityGmailConversation.this.wt = null;
                            ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    ActivityGmailConversation.this.hideProgress();
                                }
                            });
                        }
                    };
                    activityGmailConversation.wt = r1;
                    ActivityGmailConversation.this.wt.start();
                } else {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.addCategory("android.intent.category.BROWSABLE");
                    intent.setData(Uri.parse(str));
                    ActivityGmailConversation.this.startActivity(intent);
                }
                return true;
            }
        });
        this.vw.setHorizontalScrollBarEnabled(true);
        this.vw.getSettings().setJavaScriptEnabled(true);
        this.vw.getSettings().setBlockNetworkImage(false);
        this.vw.getSettings().setLoadsImagesAutomatically(true);
        this.vw.getSettings().setSupportMultipleWindows(false);
        this.vw.getSettings().setBuiltInZoomControls(false);
        this.vw.getSettings().setSupportZoom(false);
        this.vw.getSettings().setUseWideViewPort(true);
        this.vw.getSettings().setLayoutAlgorithm(LayoutAlgorithm.NORMAL);
        WebView webView = this.vw;
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body><b>");
        sb.append(getResources().getString(R.string.label_loading));
        sb.append("</b></body></html>");
        webView.loadDataWithBaseURL(null, sb.toString(), NanoHTTPD.MIME_HTML, "UTF-8", null);
        ((Button) findViewById(R.id.button_print)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityGmailConversation.this.vw.scrollTo(0, 0);
                Picture capturePicture = ActivityGmailConversation.this.vw.capturePicture();
                if (capturePicture != null) {
                    try {
                        ActivityGmailConversation.pp = capturePicture;
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setClass(ActivityGmailConversation.this, ActivityPrintGmail.class);
                        ActivityGmailConversation.this.startActivityForResult(intent, 10);
                    } catch (Exception e) {
                        ActivityGmailConversation.pp = null;
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
            }
        });
        Intent intent = getIntent();
        String string = intent.getExtras().getString("credentials");
        this.credentials = string != null ? string.split("\u0000") : null;
        this.client_id = intent.getExtras().getLong("client_id");
        this.conversation_id = Long.parseLong(intent.getExtras().getString("conversation_id"));
        this.labels = intent.getExtras().getString("labels");
        String[] strArr = this.credentials;
        if (strArr == null || strArr.length != 2) {
            setResult(0);
            finish();
            return;
        }
        this.s_label_id = intent.getExtras().getLong("s_label_id");
        this.u_label_id = intent.getExtras().getLong("u_label_id");
        final String[] createUrlAndCookie = GmsProtos.createUrlAndCookie(this.credentials);
        CookieManager cookieManager = this.cm;
        if (cookieManager != null) {
            try {
                cookieManager.setCookie("mail.google.com", createUrlAndCookie[1]);
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }
        AnonymousClass4 r10 = new Thread() {
            public void run() {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException unused) {
                }
                try {
                    ProtoBuf protoBuf = new ProtoBuf(GmsProtos.REQUEST);
                    protoBuf.setLong(1, ActivityGmailConversation.this.client_id);
                    ProtoBuf newProtoBuf = protoBuf.setNewProtoBuf(3);
                    ProtoBuf newProtoBuf2 = newProtoBuf.setNewProtoBuf(1);
                    newProtoBuf2.setLong(1, ActivityGmailConversation.this.conversation_id);
                    newProtoBuf2.setLong(2, 0);
                    newProtoBuf.setLong(4, ActivityGmailConversation.this.conversation_id);
                    ProtoBuf newProtoBuf3 = protoBuf.setNewProtoBuf(4);
                    newProtoBuf3.setLong(1, 0);
                    newProtoBuf3.setLong(2, 0);
                    newProtoBuf3.setLong(3, 200);
                    newProtoBuf3.setBool(6, true);
                    newProtoBuf3.setInt(7, 0);
                    newProtoBuf3.setBool(8, true);
                    newProtoBuf3.setBool(9, true);
                    protoBuf.setNewProtoBuf(7).setLong(2, 0);
                    final String access$500 = ActivityGmailConversation.this.buildConversation(GmsProtos.doRequest(ActivityGmailConversation.this.credentials, protoBuf));
                    ActivityGmailConversation.this.runOnUiThread(new Runnable() {
                        public void run() {
                            if (!ActivityGmailConversation.this.isFinishing()) {
                                ActivityGmailConversation.this.vw.loadDataWithBaseURL(createUrlAndCookie[0], access$500, NanoHTTPD.MIME_HTML, "UTF-8", null);
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                    ActivityGmailConversation.this.setResult(0);
                    ActivityGmailConversation.this.finish();
                }
                ActivityGmailConversation.this.wt = null;
            }
        };
        this.wt = r10;
        r10.start();
    }

    /* access modifiers changed from: private */
    public String buildConversation(ProtoBuf protoBuf) {
        ProtoBuf protoBuf2 = protoBuf;
        StringBuilder sb = new StringBuilder();
        sb.append("<html><head><meta name=\"viewport\" content=\"width=650, target-densitydpi=medium-dpi\"><link type=\"text/css\" rel=\"stylesheet\" href=\"file:///android_asset/styles.css\"><script type=\"text/javascript\" src=\"file:///android_asset/script.js\"></script></head><body>");
        int i = 11;
        int count = protoBuf2.getCount(11) - 1;
        int i2 = 0;
        int i3 = 0;
        while (i2 <= count) {
            ProtoBuf protoBuf3 = protoBuf2.getProtoBuf(i, i2);
            if (i2 == 0) {
                sb.append("<div class=\"conversationHeaderDiv\" style=\"width:auto\">");
                sb.append(TextUtils.htmlEncode(protoBuf3.getString(5)));
                sb.append("<br><div id=\"labels\">");
                String[] split = this.labels.split("\\\u0000");
                for (String htmlEncode : split) {
                    sb.append("<span class=\"labelsDiv\">");
                    sb.append(TextUtils.htmlEncode(htmlEncode));
                    sb.append("</span>&nbsp;");
                }
                sb.append("</div></div>");
            }
            int count2 = protoBuf3.getCount(14);
            boolean z = false;
            boolean z2 = false;
            for (int i4 = 0; i4 < count2; i4++) {
                long j = protoBuf3.getLong(14, i4);
                if (this.s_label_id == j) {
                    z2 = true;
                }
                if (this.u_label_id == j) {
                    z = true;
                }
            }
            if (z || i2 == count) {
                if (i3 > 0) {
                    int i5 = i2 - i3;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("_collapsed");
                    sb2.append(i5);
                    String sb3 = sb2.toString();
                    sb.append("<div id=\"");
                    sb.append(sb3);
                    sb.append("\"><a onClick=\"uncollapse('");
                    sb.append(sb3);
                    sb.append("', ");
                    sb.append(i5);
                    sb.append(", ");
                    sb.append(i2 - 1);
                    sb.append(")\"><div class=\"superCollapsedDiv size");
                    String str = i3 == 1 ? "1" : i3 == 2 ? "2" : "n";
                    sb.append(str);
                    sb.append("\"><div class=\"superCollapsedLabel\">");
                    sb.append(i3);
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(" read message");
                    sb4.append(i3 > 1 ? "s" : "");
                    sb.append(sb4.toString());
                    sb.append("</div></div></a></div>");
                }
                appendMessage(protoBuf3, sb, i2, false, z2);
                i3 = 0;
            } else {
                appendMessage(protoBuf3, sb, i2, true, z2);
                i3++;
            }
            i2++;
            i = 11;
        }
        sb.append("</body></html>");
        return sb.toString();
    }

    private void appendMessage(ProtoBuf protoBuf, StringBuilder sb, int i, boolean z, boolean z2) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        ProtoBuf protoBuf2 = protoBuf;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        sb3.append("<table id=\"mp_");
        sb3.append(i);
        sb3.append("\" border=\"0\" ");
        String str6 = "style=\"display:none\" ";
        String str7 = "";
        sb3.append(z ? str6 : str7);
        sb3.append("cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr><td class=\"headerDiv\">");
        sb2.append(sb3.toString());
        sb2.append("<table border=\"0\" cellpadding=\"0\" width=\"100%\"><tr>");
        StringBuilder sb4 = new StringBuilder();
        sb4.append("<td><img src=\"file:///android_asset/star_");
        sb4.append(z2 ? "on" : "off");
        sb4.append(".png\"></td>");
        sb2.append(sb4.toString());
        sb2.append("<td width=\"100%\" class=\"fromDiv\">&nbsp;");
        ProtoBuf protoBuf3 = protoBuf2.getProtoBuf(2);
        StringBuilder sb5 = new StringBuilder();
        sb5.append(protoBuf3.getString(2));
        String str8 = " <";
        sb5.append(str8);
        sb5.append(protoBuf3.getString(1));
        String str9 = ">";
        sb5.append(str9);
        String htmlEncode = TextUtils.htmlEncode(sb5.toString());
        StringBuilder sb6 = new StringBuilder();
        sb6.append("<a onclick=\"toggleHeader('");
        sb6.append(protoBuf2.getLong(1));
        sb6.append("')\">");
        sb2.append(sb6.toString());
        sb2.append(htmlEncode);
        sb2.append("</a></td>");
        int count = protoBuf2.getCount(15);
        if (count > 0) {
            sb2.append("<td><img src=\"file:///android_asset/paperclip.png\"></td>");
        }
        sb2.append("<td nowrap=\"nowrap\">");
        sb2.append(df.format(new Date(protoBuf2.getLong(3))));
        String str10 = "</td>";
        sb2.append(str10);
        sb2.append("</tr></table>");
        StringBuilder sb7 = new StringBuilder();
        sb7.append("<table id=\"");
        sb7.append(protoBuf2.getLong(1));
        sb7.append("_hl2\" ");
        sb7.append(z ? str6 : str7);
        sb7.append("border=\"0\" cellpadding=\"0\" width=\"100%\">");
        sb2.append(sb7.toString());
        int count2 = protoBuf2.getCount(9);
        int i2 = 0;
        while (true) {
            str = "</tr>";
            str2 = "<td>&nbsp;";
            str3 = " ";
            str4 = "<td width=\"30px\" align=\"right\">";
            str5 = "<tr>";
            if (i2 >= count2) {
                break;
            }
            sb2.append(str5);
            StringBuilder sb8 = new StringBuilder();
            sb8.append(str4);
            if (i2 == 0) {
                str3 = "To:";
            }
            sb8.append(str3);
            sb8.append(str10);
            sb2.append(sb8.toString());
            sb2.append(str2);
            ProtoBuf protoBuf4 = protoBuf2.getProtoBuf(9, i2);
            StringBuilder sb9 = new StringBuilder();
            sb9.append(protoBuf4.getString(2));
            sb9.append(str8);
            sb9.append(protoBuf4.getString(1));
            sb9.append(str9);
            sb2.append(TextUtils.htmlEncode(sb9.toString()));
            sb2.append(str10);
            sb2.append(str);
            i2++;
        }
        int count3 = protoBuf2.getCount(10);
        int i3 = 0;
        while (i3 < count3) {
            sb2.append(str5);
            StringBuilder sb10 = new StringBuilder();
            sb10.append(str4);
            sb10.append(i3 == 0 ? "Cc:" : str3);
            sb10.append(str10);
            sb2.append(sb10.toString());
            sb2.append(str2);
            ProtoBuf protoBuf5 = protoBuf2.getProtoBuf(10, i3);
            StringBuilder sb11 = new StringBuilder();
            String str11 = str6;
            int i4 = count3;
            sb11.append(protoBuf5.getString(2));
            sb11.append(str8);
            sb11.append(protoBuf5.getString(1));
            sb11.append(str9);
            sb2.append(TextUtils.htmlEncode(sb11.toString()));
            sb2.append(str10);
            sb2.append(str);
            i3++;
            str6 = str11;
            count3 = i4;
        }
        String str12 = str6;
        int i5 = 11;
        int count4 = protoBuf2.getCount(11);
        int i6 = 0;
        while (i6 < count4) {
            sb2.append(str5);
            StringBuilder sb12 = new StringBuilder();
            sb12.append(str4);
            sb12.append(i6 == 0 ? "Bcc:" : str3);
            sb12.append(str10);
            sb2.append(sb12.toString());
            sb2.append(str2);
            ProtoBuf protoBuf6 = protoBuf2.getProtoBuf(i5, i6);
            StringBuilder sb13 = new StringBuilder();
            int i7 = count4;
            sb13.append(protoBuf6.getString(2));
            sb13.append(str8);
            sb13.append(protoBuf6.getString(1));
            sb13.append(str9);
            sb2.append(TextUtils.htmlEncode(sb13.toString()));
            sb2.append(str10);
            sb2.append(str);
            i6++;
            count4 = i7;
            i5 = 11;
        }
        sb2.append("</table>");
        StringBuilder sb14 = new StringBuilder();
        String str13 = "<div id=\"";
        sb14.append(str13);
        sb14.append(protoBuf2.getLong(1));
        sb14.append("_snp\" class=\"snpDiv\"");
        sb14.append(z ? str7 : " style=\"display:none\"");
        sb14.append(str9);
        sb2.append(sb14.toString());
        sb2.append(TextUtils.htmlEncode(protoBuf2.getString(6)));
        String str14 = "</div>";
        sb2.append(str14);
        sb2.append("</td><tr><td class=\"bodyCell\">");
        StringBuilder sb15 = new StringBuilder();
        sb15.append(str13);
        sb15.append(protoBuf2.getLong(1));
        sb15.append("_msg\" ");
        sb15.append(z ? str12 : str7);
        sb15.append("class=\"bodyDiv\">");
        sb2.append(sb15.toString());
        sb2.append(protoBuf2.getString(13));
        if (count > 0) {
            sb2.append("<hr>");
            for (int i8 = 0; i8 < count; i8++) {
                ProtoBuf protoBuf7 = protoBuf2.getProtoBuf(15, i8);
                String string = protoBuf7.getString(3);
                int indexOf = string.indexOf(";");
                if (indexOf > 0) {
                    string = string.substring(0, indexOf);
                }
                String extByMimeType = App.getExtByMimeType(string);
                sb2.append("<div class=\"attachmentDiv\">");
                sb2.append("<img valign=\"middle\" src=\"file:///android_asset/attachment.png\">");
                sb2.append("&nbsp;&nbsp;&nbsp;");
                String str15 = "</b>";
                String str16 = "<b>";
                if (!str7.equals(extByMimeType)) {
                    StringBuilder sb16 = new StringBuilder();
                    sb16.append("<a onclick=\"location='content://printershare/gmail_att.");
                    sb16.append(extByMimeType);
                    sb16.append("?msg_id=");
                    String str17 = string;
                    sb16.append(protoBuf2.getLong(1));
                    sb16.append("&att_id=");
                    sb16.append(protoBuf7.getString(1));
                    sb16.append("&content_type=");
                    sb16.append(str17);
                    sb16.append("&size=");
                    sb16.append(protoBuf7.getInt(5));
                    sb16.append("'\">");
                    sb2.append(sb16.toString());
                    StringBuilder sb17 = new StringBuilder();
                    sb17.append(str16);
                    sb17.append(protoBuf7.getString(2));
                    sb17.append(str15);
                    sb2.append(sb17.toString());
                    sb2.append("</a>");
                } else {
                    StringBuilder sb18 = new StringBuilder();
                    sb18.append(str16);
                    sb18.append(protoBuf7.getString(2));
                    sb18.append(str15);
                    sb2.append(sb18.toString());
                }
                sb2.append(str14);
            }
        }
        sb2.append(str14);
        sb2.append("</td></tr></table>");
    }
}
