package com.dynamixsoftware.printershare;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.gmail.ProtoBufType;
import com.flurry.android.Constants;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

public class ScanThreadTPL extends Thread {
    /* access modifiers changed from: private */
    public boolean[] destroyed = new boolean[1];
    /* access modifiers changed from: private */
    public List<DatagramPacket> packets = new ArrayList();
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    /* access modifiers changed from: private */
    public String rq_pid;
    private Thread sender = new Thread() {
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x001d, code lost:
            r3 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0028, code lost:
            if (r3 >= com.dynamixsoftware.printershare.ScanThreadTPL.access$600(r11.this$0).size()) goto L_0x0096;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x002a, code lost:
            r4 = com.dynamixsoftware.printershare.ScanThreadTPL.access$000(r11.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0030, code lost:
            monitor-enter(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x0039, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadTPL.access$000(r11.this$0)[0] == false) goto L_0x003d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x003b, code lost:
            monitor-exit(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x003c, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x003d, code lost:
            monitor-exit(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
            r4 = (com.dynamixsoftware.printershare.ScanThreadTPL.SocketThread) com.dynamixsoftware.printershare.ScanThreadTPL.access$600(r11.this$0).get(r3);
            r5 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x004f, code lost:
            if (r5 >= r0.size()) goto L_0x0090;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0051, code lost:
            r6 = com.dynamixsoftware.printershare.ScanThreadTPL.access$000(r11.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x0057, code lost:
            monitor-enter(r6);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x0060, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadTPL.access$000(r11.this$0)[0] == false) goto L_0x0064;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x0062, code lost:
            monitor-exit(r6);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x0063, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x0064, code lost:
            monitor-exit(r6);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
            r7 = new byte[53];
            java.lang.System.arraycopy("WHERE ARE YOU KC300".getBytes(), 0, r7, 0, 19);
            r7[50] = (byte) 1;
            r4.send(new java.net.DatagramPacket(r7, 53, (java.net.InetAddress) r0.get(r5), r4.port));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:39:0x008a, code lost:
            r5 = r5 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0090, code lost:
            r3 = r3 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:53:?, code lost:
            java.lang.Thread.sleep(1000);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x009b, code lost:
            r2 = r2 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:0x009f, code lost:
            return;
         */
        public void run() {
            try {
                Vector broadcastAdrresses = App.getBroadcastAdrresses();
                int i = 0;
                while (i < 3) {
                    synchronized (ScanThreadTPL.this.destroyed) {
                        if (ScanThreadTPL.this.destroyed[0]) {
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
    };
    /* access modifiers changed from: private */
    public ArrayList<SocketThread> sockets = new ArrayList<>();
    /* access modifiers changed from: private */
    public Handler status;
    /* access modifiers changed from: private */
    public int timeout;
    private ArrayList<DetectThread> workers = new ArrayList<>();

    class DetectThread extends Thread {
        DatagramPacket packet;

        DetectThread(DatagramPacket datagramPacket) {
            this.packet = datagramPacket;
        }

        /* JADX WARNING: type inference failed for: r2v33 */
        /* JADX WARNING: type inference failed for: r26v0 */
        /* JADX WARNING: type inference failed for: r4v9, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r1v16, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r26v1 */
        /* JADX WARNING: type inference failed for: r12v6, types: [int] */
        /* JADX WARNING: type inference failed for: r15v18, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r14v12, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r8v9, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v10, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r8v11 */
        /* JADX WARNING: type inference failed for: r4v16 */
        /* JADX WARNING: type inference failed for: r14v13 */
        /* JADX WARNING: type inference failed for: r15v19 */
        /* JADX WARNING: type inference failed for: r14v14 */
        /* JADX WARNING: type inference failed for: r15v20 */
        /* JADX WARNING: type inference failed for: r26v6 */
        /* JADX WARNING: type inference failed for: r15v21 */
        /* JADX WARNING: type inference failed for: r14v15 */
        /* JADX WARNING: type inference failed for: r4v17 */
        /* JADX WARNING: type inference failed for: r23v0 */
        /* JADX WARNING: type inference failed for: r8v15 */
        /* JADX WARNING: type inference failed for: r4v18 */
        /* JADX WARNING: type inference failed for: r9v9, types: [java.lang.String[]] */
        /* JADX WARNING: type inference failed for: r26v7 */
        /* JADX WARNING: type inference failed for: r15v22 */
        /* JADX WARNING: type inference failed for: r14v16 */
        /* JADX WARNING: type inference failed for: r4v19 */
        /* JADX WARNING: type inference failed for: r26v8 */
        /* JADX WARNING: type inference failed for: r23v1 */
        /* JADX WARNING: type inference failed for: r15v23 */
        /* JADX WARNING: type inference failed for: r14v17 */
        /* JADX WARNING: type inference failed for: r4v20 */
        /* JADX WARNING: type inference failed for: r23v2 */
        /* JADX WARNING: type inference failed for: r4v21, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r4v22 */
        /* JADX WARNING: type inference failed for: r4v23, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r4v24, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r4v25, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r26v9 */
        /* JADX WARNING: type inference failed for: r4v26, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r4v27, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r14v18 */
        /* JADX WARNING: type inference failed for: r4v28, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r4v29, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r15v24 */
        /* JADX WARNING: type inference failed for: r23v3 */
        /* JADX WARNING: type inference failed for: r26v10 */
        /* JADX WARNING: type inference failed for: r12v9 */
        /* JADX WARNING: type inference failed for: r26v11 */
        /* JADX WARNING: type inference failed for: r12v10 */
        /* JADX WARNING: type inference failed for: r12v11 */
        /* JADX WARNING: type inference failed for: r26v12 */
        /* JADX WARNING: type inference failed for: r12v13, types: [int] */
        /* JADX WARNING: type inference failed for: r26v13 */
        /* JADX WARNING: type inference failed for: r26v14 */
        /* JADX WARNING: type inference failed for: r26v15 */
        /* JADX WARNING: type inference failed for: r26v16 */
        /* JADX WARNING: type inference failed for: r26v17 */
        /* JADX WARNING: type inference failed for: r26v18 */
        /* JADX WARNING: type inference failed for: r26v19 */
        /* JADX WARNING: type inference failed for: r26v20 */
        /* JADX WARNING: type inference failed for: r26v21 */
        /* JADX WARNING: type inference failed for: r26v22 */
        /* JADX WARNING: type inference failed for: r26v23 */
        /* JADX WARNING: type inference failed for: r26v24 */
        /* JADX WARNING: type inference failed for: r26v25 */
        /* JADX WARNING: type inference failed for: r26v26 */
        /* JADX WARNING: type inference failed for: r26v27 */
        /* JADX WARNING: type inference failed for: r26v28 */
        /* JADX WARNING: type inference failed for: r26v29 */
        /* JADX WARNING: type inference failed for: r26v30 */
        /* JADX WARNING: type inference failed for: r26v31 */
        /* JADX WARNING: type inference failed for: r26v32 */
        /* JADX WARNING: type inference failed for: r26v33 */
        /* JADX WARNING: type inference failed for: r26v34 */
        /* JADX WARNING: type inference failed for: r26v35 */
        /* JADX WARNING: type inference failed for: r1v69 */
        /* JADX WARNING: type inference failed for: r26v36 */
        /* JADX WARNING: type inference failed for: r26v37 */
        /* JADX WARNING: type inference failed for: r1v75 */
        /* JADX WARNING: type inference failed for: r26v38 */
        /* JADX WARNING: type inference failed for: r26v43 */
        /* JADX WARNING: type inference failed for: r2v50 */
        /* JADX WARNING: type inference failed for: r26v44 */
        /* JADX WARNING: type inference failed for: r26v45 */
        /* JADX WARNING: type inference failed for: r4v42 */
        /* JADX WARNING: type inference failed for: r1v88 */
        /* JADX WARNING: type inference failed for: r26v46 */
        /* JADX WARNING: type inference failed for: r14v37 */
        /* JADX WARNING: type inference failed for: r15v41 */
        /* JADX WARNING: type inference failed for: r14v38 */
        /* JADX WARNING: type inference failed for: r15v42 */
        /* JADX WARNING: type inference failed for: r26v47 */
        /* JADX WARNING: type inference failed for: r26v48 */
        /* JADX WARNING: type inference failed for: r15v43 */
        /* JADX WARNING: type inference failed for: r15v44 */
        /* JADX WARNING: type inference failed for: r15v45 */
        /* JADX WARNING: type inference failed for: r15v46 */
        /* JADX WARNING: type inference failed for: r14v39 */
        /* JADX WARNING: type inference failed for: r14v40 */
        /* JADX WARNING: type inference failed for: r14v41 */
        /* JADX WARNING: type inference failed for: r26v49 */
        /* JADX WARNING: type inference failed for: r15v47 */
        /* JADX WARNING: type inference failed for: r14v42 */
        /* JADX WARNING: type inference failed for: r4v43 */
        /* JADX WARNING: type inference failed for: r26v50 */
        /* JADX WARNING: type inference failed for: r15v48 */
        /* JADX WARNING: type inference failed for: r14v43 */
        /* JADX WARNING: type inference failed for: r23v5 */
        /* JADX WARNING: type inference failed for: r23v6 */
        /* JADX WARNING: type inference failed for: r4v44 */
        /* JADX WARNING: type inference failed for: r26v51 */
        /* JADX WARNING: type inference failed for: r14v44 */
        /* JADX WARNING: type inference failed for: r15v49 */
        /* JADX WARNING: type inference failed for: r26v52 */
        /* JADX WARNING: type inference failed for: r12v18 */
        /* JADX WARNING: type inference failed for: r26v53 */
        /* JADX WARNING: type inference failed for: r12v19 */
        /* JADX WARNING: type inference failed for: r12v20 */
        /* JADX WARNING: type inference failed for: r12v21 */
        /* JADX WARNING: type inference failed for: r12v22 */
        /* JADX WARNING: type inference failed for: r12v23 */
        /* JADX WARNING: type inference failed for: r12v24 */
        /* JADX WARNING: type inference failed for: r12v25 */
        /* JADX WARNING: type inference failed for: r12v26 */
        /* JADX WARNING: type inference failed for: r26v54 */
        /* JADX WARNING: type inference failed for: r26v55 */
        /* JADX WARNING: type inference failed for: r26v56 */
        /* JADX WARNING: type inference failed for: r26v57 */
        /* JADX WARNING: type inference failed for: r26v58 */
        /* JADX WARNING: type inference failed for: r26v59 */
        /* JADX WARNING: type inference failed for: r26v60 */
        /* JADX WARNING: type inference failed for: r26v61 */
        /* JADX WARNING: Code restructure failed: missing block: B:176:0x03c4, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:177:0x03c5, code lost:
            r8 = r0;
            r26 = r1;
            r1 = null;
            r12 = r12;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:216:0x0488, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:217:0x0489, code lost:
            r8 = r0;
            r1 = null;
            r12 = r12;
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:241:0x04d8, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:245:0x04e1, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:246:0x04e3, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:249:0x04e7, code lost:
            r8 = r0;
            r12 = r12;
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x0060, code lost:
            r7 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:250:0x04ea, code lost:
            r0 = e;
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0063, code lost:
            if (r7 >= 16) goto L_0x006e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:272:0x0558, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:273:0x0559, code lost:
            r26 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:288:0x05c9, code lost:
            r0 = e;
            r12 = r12;
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:289:0x05cb, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:290:0x05cc, code lost:
            r26 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:291:0x05cf, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:292:0x05d0, code lost:
            r26 = r1;
            r6 = r30;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:293:0x05d4, code lost:
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:294:0x05d9, code lost:
            r12 = r12;
            r26 = r26;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:295:0x05dc, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:296:0x05dd, code lost:
            r12 = r26;
            r6 = r30;
            r26 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:301:0x05f4, code lost:
            r1 = r1.split(";");
            r8 = 0;
            r4 = r4;
            r26 = r26;
            r14 = 0;
            r15 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:303:0x05fe, code lost:
            if (r8 < r1.length) goto L_0x0600;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:304:0x0600, code lost:
            r9 = r1[r8].split(":");
            r30 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:305:0x060c, code lost:
            if (r9.length < 2) goto L_0x060e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:306:0x060e, code lost:
            r23 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:307:0x0612, code lost:
            r23 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x0069, code lost:
            if (r5[r7 + 19] == 0) goto L_0x006e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:312:0x0631, code lost:
            if ("MANUFACTURER".equals(r9[0]) != false) goto L_0x0633;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:315:0x063c, code lost:
            if ("MDL".equals(r9[0]) == false) goto L_0x063e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:317:0x0646, code lost:
            if ("MODEL".equals(r9[0]) != false) goto L_0x0648;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x006b, code lost:
            r7 = r7 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:320:0x0651, code lost:
            if ("CMD".equals(r9[0]) == false) goto L_0x0653;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:322:0x065b, code lost:
            if ("COMMAND SET".equals(r9[0]) != false) goto L_0x065d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:325:0x0666, code lost:
            if ("URF".equals(r9[0]) != false) goto L_0x0668;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:326:0x0668, code lost:
            r15 = r9[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:327:0x066b, code lost:
            r4 = r23;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:328:0x066f, code lost:
            r26 = r26;
            r15 = r15;
            r23 = r23;
            r14 = r9[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:329:0x0673, code lost:
            r15 = r15;
            r14 = r14;
            r23 = r23;
            r26 = r9[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:331:0x067a, code lost:
            r8 = r8 + 1;
            r1 = r30;
            r26 = r26;
            r15 = r15;
            r14 = r14;
            r4 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:332:0x0681, code lost:
            r8 = r4;
            r4 = r26;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:333:0x068a, code lost:
            r8 = r4;
            r4 = r26;
            r14 = 0;
            r15 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:336:0x06b3, code lost:
            r26 = r7;
            r7 = new java.lang.StringBuilder();
            r31 = r11;
            r7.append(" [");
            r7.append(r3);
            r7.append("]");
            r3 = r7.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:337:0x06ce, code lost:
            r26 = r7;
            r31 = r11;
            r3 = "";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:?, code lost:
            r11 = new java.lang.String(r5, 19, r7);
            r5 = new byte[]{92, 19, 11, 89, -46, 98, 66, 100, -98, -44, -120, 56, 45, 94, -82, -52};
            r15 = new com.dynamixsoftware.printershare.AES();
            r15.setKey(r5);
            r5 = new java.net.Socket();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:340:0x070d, code lost:
            r11 = new java.lang.StringBuilder();
            r11.append("_");
            r11.append(r7);
            r7 = r11.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:341:0x071f, code lost:
            r7 = "";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:344:0x072c, code lost:
            r3 = r9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:345:0x072e, code lost:
            r3 = "Network Printer";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:349:0x0735, code lost:
            r9 = "";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:352:0x0742, code lost:
            r1.capabilities.put("usb_MFG", r8);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:354:0x074b, code lost:
            r1.capabilities.put("usb_MDL", r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:356:0x0754, code lost:
            r1.capabilities.put("usb_CMD", r14);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:358:0x075d, code lost:
            r1.capabilities.put("URF", r15);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
            r5.connect(new java.net.InetSocketAddress(r3, 20005), 3000);
            r5.setSoTimeout(3000);
            r3 = r5.getInputStream();
            r12 = r5.getOutputStream();
            r12.write(new byte[]{86, 5});
            r12.write(new byte[16]);
            r12.flush();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:362:0x0776, code lost:
            if (r2.equals(com.dynamixsoftware.printershare.ScanThreadTPL.access$300(r5.this$0)) != false) goto L_0x0778;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:368:?, code lost:
            com.dynamixsoftware.printershare.ScanThreadTPL.access$400(r5.this$0).add(r1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x0100, code lost:
            r2 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:373:0x07a9, code lost:
            r5.this$0.destroy();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:375:0x07bf, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x0101, code lost:
            r14 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:380:?, code lost:
            throw r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:381:0x07c3, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:382:0x07c5, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x0102, code lost:
            if (r2 >= 16) goto L_0x0117;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:390:0x07d6, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:391:0x07d7, code lost:
            r27 = r5;
            r5 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:393:0x07de, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:394:0x07df, code lost:
            r27 = r5;
            r5 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:405:0x07ef, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
            r7 = r3.read();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x0108, code lost:
            if (r7 == -1) goto L_0x0117;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:424:?, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:425:0x0817, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:426:0x0818, code lost:
            r2 = r0;
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x010a, code lost:
            r2 = r2 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:43:0x010d, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:44:0x010e, code lost:
            r2 = r5;
            r5 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0112, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x0113, code lost:
            r2 = r5;
            r5 = r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:470:0x067a, code lost:
            r26 = r26;
            r15 = r15;
            r14 = r14;
            r4 = r9[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:471:0x067a, code lost:
            r26 = r26;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x0117, code lost:
            if (r2 == 16) goto L_0x0126;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:49:?, code lost:
            r5.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:50:0x011d, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:51:0x011e, code lost:
            r2 = r0;
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:?, code lost:
            r2 = new byte[16];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:0x0128, code lost:
            r13 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x0129, code lost:
            if (r13 >= 16) goto L_0x013a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:?, code lost:
            r7 = r3.read();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:59:0x012f, code lost:
            if (r7 == r14) goto L_0x013a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:60:0x0131, code lost:
            r23 = r13 + 1;
            r2[r13] = (byte) r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:61:0x0136, code lost:
            r13 = r23;
            r14 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:62:0x013a, code lost:
            if (r13 == 16) goto L_0x0149;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:64:?, code lost:
            r5.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:65:0x0140, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:66:0x0141, code lost:
            r2 = r0;
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:69:?, code lost:
            r12.write(r15.encrypt(r2));
            r12.write(new byte[]{7, 0, 0, 0});
            r12.write("ANDROID".getBytes());
            r12.write(new byte[]{7, 0, 0, 0});
            r12.flush();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:70:0x017c, code lost:
            r2 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:71:0x017d, code lost:
            if (r2 >= 4) goto L_0x0196;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:73:?, code lost:
            r7 = r3.read();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:75:0x0184, code lost:
            if (r7 != -1) goto L_0x0193;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:77:?, code lost:
            r5.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:78:0x018a, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:79:0x018b, code lost:
            r2 = r0;
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:81:0x0193, code lost:
            r2 = r2 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:83:?, code lost:
            r2 = new java.io.ByteArrayOutputStream();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:84:0x019b, code lost:
            r13 = false;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:86:?, code lost:
            r7 = r3.read();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:87:0x01a1, code lost:
            if (r7 == -1) goto L_0x01af;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:88:0x01a3, code lost:
            r2.write(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:89:0x01a6, code lost:
            if (r13 != false) goto L_0x019c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:90:0x01a8, code lost:
            r5.setSoTimeout(500);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:91:0x01ad, code lost:
            r13 = true;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r15v21
  assigns: []
  uses: []
  mth insns count: 831
        	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$0(DepthTraversal.java:13)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:13)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
        	at jadx.core.ProcessClass.process(ProcessClass.java:35)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
         */
        /* JADX WARNING: Removed duplicated region for block: B:105:0x01d9 A[Catch:{ Exception -> 0x07de, all -> 0x07d6 }] */
        /* JADX WARNING: Removed duplicated region for block: B:301:0x05f4 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:333:0x068a A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:336:0x06b3 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:337:0x06ce A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:340:0x070d A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:341:0x071f A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:344:0x072c A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:345:0x072e A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:348:0x0734 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:349:0x0735 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:352:0x0742 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:354:0x074b A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:356:0x0754 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:358:0x075d A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:361:0x076c A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:367:0x0783 A[SYNTHETIC, Splitter:B:367:0x0783] */
        /* JADX WARNING: Removed duplicated region for block: B:373:0x07a9 A[Catch:{ all -> 0x07bf, Exception -> 0x07c5, all -> 0x07c3 }] */
        /* JADX WARNING: Removed duplicated region for block: B:381:0x07c3 A[ExcHandler: all (th java.lang.Throwable), Splitter:B:145:0x0359] */
        /* JADX WARNING: Removed duplicated region for block: B:415:0x0802 A[SYNTHETIC, Splitter:B:415:0x0802] */
        /* JADX WARNING: Removed duplicated region for block: B:423:0x0813 A[SYNTHETIC, Splitter:B:423:0x0813] */
        /* JADX WARNING: Unknown variable types count: 63 */
        public void run() {
            Socket socket;
            Throwable th;
            Exception exc;
            String str;
            int i;
            String str2;
            Socket socket2;
            Socket socket3;
            InputStream inputStream;
            OutputStream outputStream;
            ByteArrayOutputStream byteArrayOutputStream;
            DataInputStream dataInputStream;
            ? r26;
            ? r12;
            OutputStream outputStream2;
            String str3;
            ? r15;
            ? r14;
            ? r8;
            ? r4;
            String fullModelName;
            String str4;
            DataInputStream dataInputStream2;
            String str5;
            byte b;
            String str6;
            String str7;
            ? r122;
            byte b2;
            DetectThread detectThread = this;
            try {
                InetAddress address = detectThread.packet.getAddress();
                String hostAddress = address.getHostAddress();
                if (address.getAddress().length != 4) {
                    try {
                        StringBuilder sb = new StringBuilder();
                        sb.append("[");
                        sb.append(hostAddress);
                        sb.append("]");
                        hostAddress = sb.toString();
                    } catch (Exception e) {
                        e = e;
                        DetectThread detectThread2 = detectThread;
                        socket = null;
                        exc = e;
                        try {
                            exc.printStackTrace();
                            App.reportThrowable(exc);
                            if (socket != null) {
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            th = th;
                            if (socket != null) {
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        DetectThread detectThread3 = detectThread;
                        socket = null;
                        th = th;
                        if (socket != null) {
                        }
                        throw th;
                    }
                }
                byte[] data = detectThread.packet.getData();
                if ("KANNOU".equals(new String(data, 0, 6))) {
                    synchronized (ScanThreadTPL.this.destroyed) {
                        try {
                            if (ScanThreadTPL.this.destroyed[0]) {
                                return;
                            }
                        } catch (Exception e2) {
                            e = e2;
                        } catch (Throwable th4) {
                            th = th4;
                            th = th;
                            socket = null;
                            if (socket != null) {
                            }
                            throw th;
                        }
                    }
                } else {
                    return;
                }
                return;
                return;
                if (i == -1) {
                    try {
                        socket2.close();
                    } catch (Exception e3) {
                        Exception exc2 = e3;
                        exc2.printStackTrace();
                        App.reportThrowable(exc2);
                    }
                }
                socket2.setSoTimeout(3000);
                dataInputStream = new DataInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
                while (dataInputStream.read() == 2) {
                    int readUnsignedShort = dataInputStream.readUnsignedShort();
                    int i2 = ((readUnsignedShort & ProtoBufType.MASK_MODIFIER) >> 8) | ((readUnsignedShort & 255) << 8);
                    dataInputStream.readUnsignedShort();
                    dataInputStream.readUnsignedShort();
                    dataInputStream.readUnsignedShort();
                    dataInputStream.readUnsignedShort();
                    int readUnsignedShort2 = dataInputStream.readUnsignedShort();
                    int i3 = ((readUnsignedShort2 & ProtoBufType.MASK_MODIFIER) >> 8) | ((readUnsignedShort2 & 255) << 8);
                    int readUnsignedShort3 = dataInputStream.readUnsignedShort();
                    int i4 = ((readUnsignedShort3 & 255) << 8) | ((readUnsignedShort3 & ProtoBufType.MASK_MODIFIER) >> 8);
                    dataInputStream.readUnsignedShort();
                    dataInputStream.readUnsignedShort();
                    dataInputStream.readUnsignedShort();
                    int readUnsignedShort4 = dataInputStream.readUnsignedShort();
                    int i5 = (readUnsignedShort4 >> 8) | ((readUnsignedShort4 & 255) << 8);
                    byte[] bArr = new byte[i5];
                    dataInputStream.readFully(bArr);
                    int i6 = 9;
                    byte b3 = -1;
                    byte b4 = -1;
                    byte b5 = -1;
                    String str8 = null;
                    while (b4 == b3 && i6 < i5) {
                        try {
                            byte b6 = bArr[i6 + 2];
                            socket3 = socket2;
                            try {
                                byte b7 = bArr[i6 + 3];
                                String str9 = str;
                                byte b8 = bArr[i6 + 4];
                                InputStream inputStream2 = inputStream;
                                byte b9 = bArr[i6 + 5];
                                OutputStream outputStream3 = outputStream;
                                byte b10 = bArr[i6 + 7];
                                i6 += 9;
                                ? r262 = i2;
                                byte b11 = b5;
                                int i7 = 0;
                                while (i6 < i5 && i7 < b8) {
                                    byte b12 = b8;
                                    if (b9 != 7 || b10 >= 3) {
                                        b2 = b9;
                                    } else {
                                        int i8 = i6 + 2;
                                        b2 = b9;
                                        if ((bArr[i8] & 128) == 0 && b4 == -1) {
                                            StringBuilder sb2 = new StringBuilder();
                                            sb2.append(b6);
                                            sb2.append("_");
                                            sb2.append(b7);
                                            b4 = bArr[i8] & 15;
                                            str8 = sb2.toString();
                                        } else if ((bArr[i8] & 128) != 0 && b11 == -1) {
                                            b11 = bArr[i8] & 15;
                                        }
                                    }
                                    i6 += 7;
                                    i7++;
                                    b8 = b12;
                                    b9 = b2;
                                }
                                b5 = b11;
                                i2 = r262;
                                socket2 = socket3;
                                str = str9;
                                inputStream = inputStream2;
                                outputStream = outputStream3;
                                b3 = -1;
                            } catch (Exception e4) {
                                e = e4;
                                exc = e;
                                socket = socket3;
                                exc.printStackTrace();
                                App.reportThrowable(exc);
                                if (socket != null) {
                                }
                            } catch (Throwable th5) {
                                th = th5;
                                th = th;
                                socket = socket3;
                                if (socket != null) {
                                }
                                throw th;
                            }
                        } catch (Exception e5) {
                            e = e5;
                            socket3 = socket2;
                            exc = e;
                            socket = socket3;
                            exc.printStackTrace();
                            App.reportThrowable(exc);
                            if (socket != null) {
                                socket.close();
                            }
                        } catch (Throwable th6) {
                            th = th6;
                            socket3 = socket2;
                            th = th;
                            socket = socket3;
                            if (socket != null) {
                            }
                            throw th;
                        }
                    }
                    ? r263 = i2;
                    InputStream inputStream3 = inputStream;
                    String str10 = str;
                    socket3 = socket2;
                    OutputStream outputStream4 = outputStream;
                    dataInputStream.readInt();
                    int readInt = dataInputStream.readInt();
                    byte[] bArr2 = new byte[(((readInt & -16777216) >> 24) | ((readInt & 16711680) >> 16))];
                    dataInputStream.readFully(bArr2);
                    int readInt2 = dataInputStream.readInt();
                    byte[] bArr3 = new byte[(((readInt2 & -16777216) >> 24) | ((readInt2 & 16711680) >> 16))];
                    dataInputStream.readFully(bArr3);
                    int readInt3 = dataInputStream.readInt();
                    byte[] bArr4 = new byte[(((16711680 & readInt3) >> 16) | ((-16777216 & readInt3) >> 24))];
                    dataInputStream.readFully(bArr4);
                    dataInputStream.readInt();
                    if (b4 == -1) {
                        detectThread = this;
                    } else {
                        ? str11 = new String(bArr2);
                        ? str12 = new String(bArr3);
                        String str13 = new String(bArr4);
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(str2);
                        sb3.append("_");
                        sb3.append(i3);
                        sb3.append("_");
                        sb3.append(i4);
                        String sb4 = sb3.toString();
                        StringBuilder sb5 = new StringBuilder();
                        sb5.append(sb4);
                        sb5.append("._pdl-datastream._tpl.local.");
                        String sb6 = sb5.toString();
                        try {
                            if (ScanThreadTPL.this.rq_pid == null || sb6.equals(ScanThreadTPL.this.rq_pid)) {
                                byte[] bArr5 = new byte[3];
                                bArr5[0] = 6;
                                r122 = r263;
                                byte b13 = (byte) r122;
                                bArr5[1] = b13;
                                bArr5[2] = 6;
                                outputStream2 = outputStream4;
                                outputStream2.write(bArr5);
                                outputStream2.flush();
                                if (inputStream3.read() != 9) {
                                    ? r264 = str12;
                                    throw new IOException();
                                } else if (inputStream3.read() == r122) {
                                    int read = inputStream3.read();
                                    int i9 = -1;
                                    if (read != -1) {
                                        int i10 = (read & 255) | 0;
                                        int read2 = inputStream3.read();
                                        if (read2 != -1) {
                                            int i11 = i10 | ((read2 & 255) << 8);
                                            int i12 = 0;
                                            while (i12 < i11 + 4) {
                                                if (inputStream3.read() != i9) {
                                                    i12++;
                                                    i9 = -1;
                                                } else {
                                                    throw new IOException();
                                                }
                                            }
                                            if (inputStream3.read() != 8) {
                                                ? r265 = str12;
                                                throw new IOException();
                                            } else if (inputStream3.read() != r122) {
                                                ? r266 = str12;
                                                throw new IOException();
                                            } else if (inputStream3.read() == 1) {
                                                byte[] bArr6 = new byte[12];
                                                bArr6[0] = (byte) ((r122 & 15) | 128);
                                                bArr6[1] = -64;
                                                bArr6[2] = -95;
                                                bArr6[3] = 0;
                                                bArr6[4] = 0;
                                                bArr6[5] = 0;
                                                bArr6[6] = 0;
                                                bArr6[7] = 0;
                                                bArr6[8] = -15;
                                                bArr6[9] = 3;
                                                bArr6[10] = -15;
                                                ? r267 = r263;
                                                bArr6[11] = 3;
                                                outputStream2.write(bArr6);
                                                outputStream2.flush();
                                                if (inputStream3.read() != (bArr6[0] & Constants.UNKNOWN)) {
                                                    ? r268 = str12;
                                                    throw new IOException();
                                                } else if (inputStream3.read() != 144) {
                                                    ? r269 = str12;
                                                    throw new IOException();
                                                } else if (inputStream3.read() != 0) {
                                                    ? r2610 = str12;
                                                    throw new IOException();
                                                } else if (inputStream3.read() == 0) {
                                                    int read3 = inputStream3.read();
                                                    int i13 = -1;
                                                    if (read3 != -1) {
                                                        int i14 = (read3 & 255) | 0;
                                                        int read4 = inputStream3.read();
                                                        if (read4 != -1) {
                                                            int i15 = i14 | ((read4 & 255) << 8);
                                                            r267 = r263;
                                                            if (inputStream3.read() == -1) {
                                                                ? r2611 = str12;
                                                                throw new IOException();
                                                            } else if (inputStream3.read() != -1) {
                                                                byte[] bArr7 = new byte[i15];
                                                                int i16 = 0;
                                                                ? r1 = str12;
                                                                while (i16 < i15) {
                                                                    ? r2612 = r1;
                                                                    int read5 = inputStream3.read();
                                                                    if (read5 != i13) {
                                                                        bArr7[i16] = (byte) read5;
                                                                        i16++;
                                                                        r1 = r2612;
                                                                        i13 = -1;
                                                                    } else {
                                                                        throw new IOException();
                                                                    }
                                                                }
                                                                ? r2613 = r1;
                                                                str3 = new String(bArr7, 2, i15 - 2);
                                                                outputStream2.write(new byte[]{5, b13});
                                                                outputStream2.flush();
                                                                if (inputStream3.read() != 10) {
                                                                    throw new IOException();
                                                                } else if (inputStream3.read() != r122) {
                                                                    throw new IOException();
                                                                } else if (inputStream3.read() != 7) {
                                                                    throw new IOException();
                                                                } else if (inputStream3.read() == r122) {
                                                                    r12 = r122;
                                                                    r26 = r2613;
                                                                    if (str3 != null) {
                                                                    }
                                                                    fullModelName = App.getFullModelName(r8, r4);
                                                                    Printer printer = new Printer();
                                                                    printer.owner = new User();
                                                                    User user = printer.owner;
                                                                    OutputStream outputStream5 = outputStream2;
                                                                    StringBuilder sb7 = new StringBuilder();
                                                                    sb7.append(str2);
                                                                    if (str13.length() > 0) {
                                                                    }
                                                                    sb7.append(str5);
                                                                    user.name = sb7.toString();
                                                                    printer.id = sb6;
                                                                    StringBuilder sb8 = new StringBuilder();
                                                                    sb8.append("tpl://");
                                                                    String str14 = str10;
                                                                    sb8.append(str14);
                                                                    sb8.append(":20005/");
                                                                    sb8.append(r12);
                                                                    sb8.append("/");
                                                                    sb8.append(str8);
                                                                    sb8.append("/");
                                                                    sb8.append(b4);
                                                                    b = b5;
                                                                    if (b != -1) {
                                                                    }
                                                                    sb8.append(str6);
                                                                    printer.direct_address = sb8.toString();
                                                                    if (fullModelName != null) {
                                                                    }
                                                                    printer.title = str7;
                                                                    if (fullModelName != null) {
                                                                    }
                                                                    printer.model = fullModelName;
                                                                    printer.capabilities = new Hashtable<>();
                                                                    if (r8 != 0) {
                                                                    }
                                                                    if (r4 != 0) {
                                                                    }
                                                                    if (r14 != 0) {
                                                                    }
                                                                    if (r15 != 0) {
                                                                    }
                                                                    if (ScanThreadTPL.this.rq_pid != null) {
                                                                    }
                                                                    synchronized (ScanThreadTPL.this.printers) {
                                                                    }
                                                                    Message message = new Message();
                                                                    message.what = 2;
                                                                    message.arg1 = 6;
                                                                    ScanThreadTPL.this.status.sendMessage(message);
                                                                    if (ScanThreadTPL.this.rq_pid != null) {
                                                                    }
                                                                    detectThread = this;
                                                                    str = str14;
                                                                    dataInputStream = dataInputStream2;
                                                                    socket2 = socket3;
                                                                    inputStream = inputStream3;
                                                                    outputStream = outputStream5;
                                                                    str2 = str4;
                                                                } else {
                                                                    throw new IOException();
                                                                }
                                                            } else {
                                                                r267 = str12;
                                                                throw new IOException();
                                                            }
                                                        } else {
                                                            ? r2614 = str12;
                                                            throw new IOException();
                                                        }
                                                    } else {
                                                        ? r2615 = str12;
                                                        throw new IOException();
                                                    }
                                                } else {
                                                    ? r2616 = str12;
                                                    throw new IOException();
                                                }
                                            } else {
                                                ? r2617 = str12;
                                                throw new IOException();
                                            }
                                        } else {
                                            ? r2618 = str12;
                                            throw new IOException();
                                        }
                                    } else {
                                        ? r2619 = str12;
                                        throw new IOException();
                                    }
                                } else {
                                    ? r2620 = str12;
                                    throw new IOException();
                                }
                            } else {
                                detectThread = this;
                            }
                        } catch (Exception e6) {
                            e = e6;
                            ? r2621 = str12;
                            ? r123 = r122;
                            ? r2622 = r2621;
                            Exception exc3 = e;
                            str3 = null;
                            ? r2623 = r2622;
                            ? r124 = r123;
                            exc3.printStackTrace();
                            App.reportThrowable(exc3);
                            r26 = r2623;
                            r12 = r124;
                            if (str3 != null) {
                            }
                            fullModelName = App.getFullModelName(r8, r4);
                            Printer printer2 = new Printer();
                            printer2.owner = new User();
                            User user2 = printer2.owner;
                            OutputStream outputStream52 = outputStream2;
                            StringBuilder sb72 = new StringBuilder();
                            sb72.append(str2);
                            if (str13.length() > 0) {
                            }
                            sb72.append(str5);
                            user2.name = sb72.toString();
                            printer2.id = sb6;
                            StringBuilder sb82 = new StringBuilder();
                            sb82.append("tpl://");
                            String str142 = str10;
                            sb82.append(str142);
                            sb82.append(":20005/");
                            sb82.append(r12);
                            sb82.append("/");
                            sb82.append(str8);
                            sb82.append("/");
                            sb82.append(b4);
                            b = b5;
                            if (b != -1) {
                            }
                            sb82.append(str6);
                            printer2.direct_address = sb82.toString();
                            if (fullModelName != null) {
                            }
                            printer2.title = str7;
                            if (fullModelName != null) {
                            }
                            printer2.model = fullModelName;
                            printer2.capabilities = new Hashtable<>();
                            if (r8 != 0) {
                            }
                            if (r4 != 0) {
                            }
                            if (r14 != 0) {
                            }
                            if (r15 != 0) {
                            }
                            if (ScanThreadTPL.this.rq_pid != null) {
                            }
                            synchronized (ScanThreadTPL.this.printers) {
                            }
                            Message message2 = new Message();
                            message2.what = 2;
                            message2.arg1 = 6;
                            ScanThreadTPL.this.status.sendMessage(message2);
                            if (ScanThreadTPL.this.rq_pid != null) {
                            }
                            detectThread = this;
                            str = str142;
                            dataInputStream = dataInputStream2;
                            socket2 = socket3;
                            inputStream = inputStream3;
                            outputStream = outputStream52;
                            str2 = str4;
                        } catch (Throwable th7) {
                        }
                    }
                    socket2 = socket3;
                    str = str10;
                    inputStream = inputStream3;
                    outputStream = outputStream4;
                }
                Socket socket4 = socket2;
                DetectThread detectThread4 = detectThread;
                try {
                    socket4.close();
                } catch (Exception e7) {
                    Exception exc4 = e7;
                    exc4.printStackTrace();
                    App.reportThrowable(exc4);
                }
                while (dataInputStream.read() == 2) {
                }
                Socket socket42 = socket2;
                DetectThread detectThread42 = detectThread;
                socket42.close();
            } catch (Exception e8) {
                e = e8;
                DetectThread detectThread5 = detectThread;
                exc = e;
                socket = null;
                exc.printStackTrace();
                App.reportThrowable(exc);
                if (socket != null) {
                }
            } catch (Throwable th8) {
                th = th8;
                DetectThread detectThread6 = detectThread;
                th = th;
                socket = null;
                if (socket != null) {
                }
                throw th;
            }
        }
    }

    class SocketThread extends Thread {
        int port;
        DatagramSocket socket;

        SocketThread(int i) throws IOException {
            this.port = i;
            DatagramSocket datagramSocket = new DatagramSocket(null);
            this.socket = datagramSocket;
            datagramSocket.setReuseAddress(true);
            this.socket.bind(new InetSocketAddress(i));
            try {
                this.socket.setBroadcast(true);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }

        public void run() {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                while (true) {
                    synchronized (ScanThreadTPL.this.destroyed) {
                        if (ScanThreadTPL.this.destroyed[0]) {
                            break;
                        }
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        if (currentTimeMillis2 >= ((long) ScanThreadTPL.this.timeout)) {
                            break;
                        }
                        this.socket.setSoTimeout((int) (((long) ScanThreadTPL.this.timeout) - currentTimeMillis2));
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[4096], 4096);
                        try {
                            this.socket.receive(datagramPacket);
                            if (datagramPacket.getLength() != 53 || datagramPacket.getData()[0] != 87) {
                                synchronized (ScanThreadTPL.this.packets) {
                                    ScanThreadTPL.this.packets.add(datagramPacket);
                                    ScanThreadTPL.this.packets.notifyAll();
                                }
                            }
                        } catch (SocketTimeoutException unused) {
                        } catch (IOException e) {
                            synchronized (ScanThreadTPL.this.destroyed) {
                                if (!ScanThreadTPL.this.destroyed[0]) {
                                    throw e;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                } catch (Throwable th) {
                    this.socket.close();
                    throw th;
                }
            }
            this.socket.close();
            synchronized (ScanThreadTPL.this.packets) {
                ScanThreadTPL.this.packets.notifyAll();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
            if (r3.socket.isClosed() == false) goto L_0x0021;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0020, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r3.socket.send(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
            java.lang.Thread.sleep(100);
         */
        public synchronized void send(DatagramPacket datagramPacket) {
            try {
                synchronized (ScanThreadTPL.this.destroyed) {
                    if (ScanThreadTPL.this.destroyed[0]) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("src: ");
                sb.append(this.socket.getLocalAddress());
                sb.append(" dst: ");
                sb.append(datagramPacket.getAddress());
                App.reportThrowable(e, sb.toString());
            }
            return;
        }

        public void interrupt() {
            super.interrupt();
            this.socket.close();
        }
    }

    public ScanThreadTPL(Context context, int i, String str, Handler handler) {
        this.timeout = i;
        this.status = handler;
        this.rq_pid = str;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        int i;
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        for (int i2 = 0; i2 < this.workers.size(); i2++) {
            DetectThread detectThread = (DetectThread) this.workers.get(i2);
            if (detectThread.isAlive()) {
                detectThread.interrupt();
            }
        }
        for (i = 0; i < this.sockets.size(); i++) {
            ((SocketThread) this.sockets.get(i)).interrupt();
        }
        interrupt();
    }

    /* JADX WARNING: Removed duplicated region for block: B:128:0x01e6 A[EDGE_INSN: B:128:0x01e6->B:104:0x01e6 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x019b  */
    public void run() {
        String str;
        Object[] array;
        Message message = new Message();
        message.what = 1;
        message.arg1 = 6;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            try {
                Vector activeNetworkInterfaces = App.getActiveNetworkInterfaces();
                if (activeNetworkInterfaces == null || activeNetworkInterfaces.size() != 0) {
                    int[] iArr = {9303, 30202, 7410, 7411, 7412, 7413, 7414, 7415, 7416, 7417, 7418, 7419, 7420, 7421, 7422, 7423, 7424, 7425, 7426, 7427, 7428, 7429, 7430, 7431, 7432, 7433, 7434, 7435, 7436, 7437, 7438, 7439, 7440, 7472};
                    for (int i = 0; i < 34; i++) {
                        try {
                            SocketThread socketThread = new SocketThread(iArr[i]);
                            socketThread.start();
                            this.sockets.add(socketThread);
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    }
                    str = null;
                } else {
                    Message message2 = new Message();
                    message2.what = 4;
                    message2.arg1 = 6;
                    this.status.sendMessage(message2);
                    return;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e2.getMessage());
                String sb2 = sb.toString();
                App.reportThrowable(e2);
                str = sb2;
            }
        }
        if (str == null) {
            this.sender.start();
            HashSet hashSet = new HashSet();
            while (true) {
                synchronized (this.destroyed) {
                    if (!this.destroyed[0]) {
                        while (true) {
                            synchronized (this.packets) {
                                if (this.packets.size() != 0) {
                                    break;
                                }
                                int i2 = 0;
                                for (int i3 = 0; i3 < this.sockets.size(); i3++) {
                                    if (((SocketThread) this.sockets.get(i3)).isAlive()) {
                                        i2++;
                                    }
                                }
                                if (i2 != this.sockets.size()) {
                                    if (i2 <= 0) {
                                        break;
                                    }
                                    Thread.yield();
                                } else {
                                    try {
                                        this.packets.wait();
                                        break;
                                    } catch (InterruptedException unused) {
                                    }
                                }
                            }
                        }
                        array = this.packets.toArray();
                        this.packets.clear();
                        if (array.length == 0) {
                            int i4 = 0;
                            while (true) {
                                if (i4 >= array.length) {
                                    break;
                                }
                                synchronized (this.destroyed) {
                                    if (this.destroyed[0]) {
                                        break;
                                    }
                                    DatagramPacket datagramPacket = (DatagramPacket) array[i4];
                                    InetAddress address = datagramPacket.getAddress();
                                    if (!hashSet.contains(address)) {
                                        hashSet.add(address);
                                        DetectThread detectThread = new DetectThread(datagramPacket);
                                        synchronized (this.destroyed) {
                                            if (!this.destroyed[0]) {
                                                this.workers.add(detectThread);
                                                detectThread.start();
                                            }
                                        }
                                    }
                                    i4++;
                                }
                            }
                        } else {
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
        }
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        if (str != null) {
            Message message3 = new Message();
            message3.what = 3;
            message3.arg1 = 6;
            Bundle bundle = new Bundle();
            bundle.putString("message", str);
            message3.setData(bundle);
            this.status.sendMessage(message3);
        } else {
            Message message4 = new Message();
            message4.what = 4;
            message4.arg1 = 6;
            this.status.sendMessage(message4);
        }
        return;
        array = this.packets.toArray();
        this.packets.clear();
        if (array.length == 0) {
        }
    }
}
