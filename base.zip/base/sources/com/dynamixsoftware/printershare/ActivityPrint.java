package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Picture;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import com.dynamixsoftware.printershare.App.PCanvas;
import com.dynamixsoftware.printershare.data.OutputColor;
import com.dynamixsoftware.printershare.data.OutputDuplex;
import com.dynamixsoftware.printershare.data.OutputMode;
import com.dynamixsoftware.printershare.data.Paper;
import com.dynamixsoftware.printershare.data.PaperSource;
import com.dynamixsoftware.printershare.data.PaperType;
import com.dynamixsoftware.printershare.ijs.IjsDriver;
import com.flurry.android.FlurryAgent;
import com.flurry.android.FlurryConfig;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

public abstract class ActivityPrint extends ActivityBase {
    protected static final int DIALOG_AUTHORIZATION = 2;
    protected static final int DIALOG_PAGES = 1;
    public static volatile Picture pp;
    protected boolean external_call;
    protected int margins = 2;
    protected CharSequence[] marginsOptions;
    protected boolean need_update_pages;
    protected int orientation = 0;
    protected CharSequence[] orientationOptions;
    protected OutputColor outputColor;
    protected OutputDuplex outputDuplex;
    protected OutputMode outputMode;
    protected Vector<Page> pages;
    protected Paper paper;
    protected PaperSource paperSource;
    protected PaperType paperType;
    protected Handler progressHandler = new Handler() {
        public void handleMessage(Message message) {
            int i = message.what;
            boolean z = true;
            String str = "message";
            if (i == 1) {
                ActivityPrint.this.showProgress(message.getData().getString(str));
            } else if (i == 2) {
                ActivityPrint.this.showProgress(message.getData().getString(str));
            } else if (i == 3) {
                ActivityPrint.this.pt = null;
                if (ActivityPrint.this.test_page_bmp == null) {
                    z = false;
                } else if (!ActivityPrint.this.getClass().getSimpleName().endsWith("TestPage")) {
                    ActivityPrint.this.test_page_bmp = null;
                }
                App.freeMem();
                ActivityPrint.this.doOK(z);
            } else if (i == 4) {
                ActivityPrint.this.pt = null;
                App.freeMem();
                ActivityPrint.this.hideProgress();
                ActivityPrint.this.last_error = message.getData().getString(str);
                ActivityPrint.this.displayLastError(new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
            } else if (i == 5) {
                ActivityPrint.this.pt = null;
                App.freeMem();
                ActivityPrint.this.hideProgress();
                ActivityPrint.this.showDialog(2);
            }
            super.handleMessage(message);
        }
    };
    /* access modifiers changed from: private */
    public Thread pt;
    /* access modifiers changed from: private */
    public ArrayList<PageView> rl = new ArrayList<>();
    private ArrayList<Thumb> rl_data = new ArrayList<>();
    /* access modifiers changed from: private */
    public boolean[] rl_flag = new boolean[1];
    /* access modifiers changed from: private */
    public Thread rl_thread;
    /* access modifiers changed from: private */
    public int sel_margins;
    /* access modifiers changed from: private */
    public int sel_orientation;
    /* access modifiers changed from: private */
    public int sel_outputColor;
    /* access modifiers changed from: private */
    public int sel_outputDuplex;
    /* access modifiers changed from: private */
    public int sel_outputMode;
    /* access modifiers changed from: private */
    public HashSet<Integer> sel_pages = new HashSet<>();
    /* access modifiers changed from: private */
    public int sel_paper;
    /* access modifiers changed from: private */
    public int sel_paperSource;
    /* access modifiers changed from: private */
    public int sel_paperType;
    /* access modifiers changed from: private */
    public Bitmap test_page_bmp;
    /* access modifiers changed from: private */
    public Thread ut;
    protected View view_dialog_authorization;
    protected View view_dialog_pages;

    public static class Page {
        public boolean landscape = false;
        private Picture picture;
        public boolean print = true;

        public Page(boolean z) {
            this.landscape = z;
        }

        public Page(Picture picture2) {
            boolean z = true;
            this.picture = picture2;
            if (picture2.getWidth() <= picture2.getHeight()) {
                z = false;
            }
            this.landscape = z;
        }

        public Picture getPicture() {
            return this.picture;
        }
    }

    class PageView extends View {
        public PageView(Context context) {
            super(context);
        }

        public void onDraw(Canvas canvas) {
            float f = getResources().getDisplayMetrics().density;
            int measuredWidth = getMeasuredWidth();
            int measuredHeight = getMeasuredHeight();
            Paint newPaint = App.newPaint();
            newPaint.setAntiAlias(true);
            newPaint.setStyle(Style.FILL);
            Bitmap access$1900 = ActivityPrint.this.getThumb(this);
            if (access$1900 != null) {
                canvas.drawBitmap(access$1900, 0.0f, 0.0f, newPaint);
            } else {
                ActivityPrint.this.proceedCreateThumb(this);
                canvas.drawColor(-1);
                newPaint.setColor(-12566464);
                newPaint.setTextSize(12.0f * f);
                String string = getResources().getString(R.string.label_rendering);
                canvas.drawText(string, (((float) measuredWidth) - newPaint.measureText(string)) / 2.0f, ((float) measuredHeight) / 2.0f, newPaint);
            }
            newPaint.setColor(-6250336);
            float f2 = (float) measuredWidth;
            float f3 = f * 1.0f;
            canvas.drawRect(new RectF(0.0f, 0.0f, f2, f3), newPaint);
            float f4 = (float) measuredHeight;
            canvas.drawRect(new RectF(0.0f, 0.0f, f3, f4), newPaint);
            canvas.drawRect(new RectF(f2 - f3, 0.0f, f2, f4), newPaint);
            canvas.drawRect(new RectF(0.0f, f4 - f3, f2, f4), newPaint);
        }
    }

    static class Thumb {
        Bitmap bmp;
        PageView pv;

        Thumb() {
        }
    }

    /* access modifiers changed from: protected */
    public abstract void createPages();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 4) {
                new Object() {
                    {
                        String str = ActivityPrint.this.getIntent().getPackage();
                        if (str != null && str.indexOf(BuildConfig.FLAVOR_base) > 0) {
                            ActivityPrint.this.external_call = true;
                            ActivityPrint.this.setResult(0);
                        }
                    }
                };
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        Resources resources = getResources();
        initPrinterParams();
        this.orientationOptions = new CharSequence[]{resources.getString(R.string.label_page_orientation_auto), resources.getString(R.string.label_page_orientation_portrait), resources.getString(R.string.label_page_orientation_landscape)};
        SharedPreferences sharedPreferences = this.prefs;
        StringBuilder sb = new StringBuilder();
        sb.append(getActivityClassName());
        sb.append("#orientation");
        this.orientation = sharedPreferences.getInt(sb.toString(), this.orientation);
        this.marginsOptions = new CharSequence[]{resources.getString(R.string.label_page_margins_no), resources.getString(R.string.label_font_size_small), resources.getString(R.string.label_font_size_normal), resources.getString(R.string.label_font_size_large)};
        SharedPreferences sharedPreferences2 = this.prefs;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getActivityClassName());
        sb2.append("#margins");
        this.margins = sharedPreferences2.getInt(sb2.toString(), this.margins);
        setContentView(R.layout.print);
        setTitle((int) R.string.header_print_preview);
        findViewById(R.id.print_button).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (ActivityPrint.this.pages != null) {
                    if (ActivityCore.printer == null) {
                        ActivityPrint.this.printers_menu.show();
                    } else if (ActivityPrint.this.checkContraints()) {
                        ActivityPrint.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    } else {
                        ActivityPrint.this.print(true);
                    }
                }
            }
        });
        findViewById(R.id.options_button).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityPrint.this.findViewById(R.id.page_preview_container).showContextMenu();
            }
        });
        findViewById(R.id.page_preview_container).setOnCreateContextMenuListener(this);
        View findViewById = findViewById(R.id.upgrade_banner);
        if (findViewById != null) {
            findViewById.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Billing.showUpgradeDialog(ActivityPrint.this);
                }
            });
        }
        this.need_update_pages = true;
    }

    /* access modifiers changed from: protected */
    public void initPrinterParams() {
        this.paper = null;
        SharedPreferences sharedPreferences = this.prefs;
        StringBuilder sb = new StringBuilder();
        sb.append(getActivityClassName());
        sb.append("#paper");
        String string = sharedPreferences.getString(sb.toString(), this.prefs.getString("paper", null));
        Locale locale = Locale.getDefault();
        String str = "Letter";
        String str2 = "A4";
        String str3 = (locale.equals(Locale.CANADA) || locale.equals(Locale.CANADA_FRENCH) || locale.equals(Locale.US)) ? str : str2;
        if (printer != null && printer.paper_list != null) {
            int size = printer.paper_list.size() - 1;
            while (true) {
                if (size < 0) {
                    break;
                }
                Paper paper2 = (Paper) printer.paper_list.elementAt(size);
                if (paper2.id.equals(string)) {
                    this.paper = paper2;
                    break;
                }
                if ((paper2.id.equals(printer.paper_default) && this.paper == null) || paper2.id.equalsIgnoreCase(str3)) {
                    this.paper = paper2;
                }
                size--;
            }
        }
        String str4 = "";
        if (this.paper == null) {
            if (str2.equals(str3)) {
                this.paper = new Paper(str4, str2, 2100, 2970);
            } else {
                this.paper = new Paper(str4, str, 2159, 2794);
            }
            this.paper.custom = true;
        }
        Paper paper3 = this.paper;
        paper3.height = paper3.height_orig;
        this.paperType = null;
        SharedPreferences sharedPreferences2 = this.prefs;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getActivityClassName());
        sb2.append("#type");
        String string2 = sharedPreferences2.getString(sb2.toString(), this.prefs.getString("type", null));
        if (printer != null && printer.paperType_list != null) {
            int size2 = printer.paperType_list.size() - 1;
            while (true) {
                if (size2 < 0) {
                    break;
                }
                PaperType paperType2 = (PaperType) printer.paperType_list.elementAt(size2);
                if (paperType2.id.equals(string2)) {
                    this.paperType = paperType2;
                    break;
                }
                if (paperType2.id.equals(printer.paperType_default)) {
                    this.paperType = paperType2;
                }
                size2--;
            }
        }
        if (this.paperType == null) {
            PaperType paperType3 = new PaperType();
            this.paperType = paperType3;
            paperType3.id = str4;
            this.paperType.name = "Plain Paper";
        }
        this.paperSource = null;
        SharedPreferences sharedPreferences3 = this.prefs;
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getActivityClassName());
        sb3.append("#tray");
        String string3 = sharedPreferences3.getString(sb3.toString(), this.prefs.getString("tray", null));
        if (printer != null && printer.paperSource_list != null) {
            int size3 = printer.paperSource_list.size() - 1;
            while (true) {
                if (size3 < 0) {
                    break;
                }
                PaperSource paperSource2 = (PaperSource) printer.paperSource_list.elementAt(size3);
                if (paperSource2.id.equals(string3)) {
                    this.paperSource = paperSource2;
                    break;
                }
                if (paperSource2.id.equals(printer.paperSource_default)) {
                    this.paperSource = paperSource2;
                }
                size3--;
            }
        }
        if (this.paperSource == null) {
            PaperSource paperSource3 = new PaperSource();
            this.paperSource = paperSource3;
            paperSource3.id = str4;
            this.paperSource.name = "Default Tray";
        }
        this.outputMode = null;
        SharedPreferences sharedPreferences4 = this.prefs;
        StringBuilder sb4 = new StringBuilder();
        sb4.append(getActivityClassName());
        sb4.append("#mode");
        String string4 = sharedPreferences4.getString(sb4.toString(), this.prefs.getString("mode", null));
        if (printer != null && printer.outputMode_list != null) {
            int size4 = printer.outputMode_list.size() - 1;
            while (true) {
                if (size4 < 0) {
                    break;
                }
                OutputMode outputMode2 = (OutputMode) printer.outputMode_list.elementAt(size4);
                if (outputMode2.id.equals(string4)) {
                    this.outputMode = outputMode2;
                    break;
                }
                if (outputMode2.id.equals(printer.outputMode_default)) {
                    this.outputMode = outputMode2;
                }
                size4--;
            }
        }
        if (this.outputMode == null) {
            OutputMode outputMode3 = new OutputMode();
            this.outputMode = outputMode3;
            outputMode3.id = str4;
            this.outputMode.name = "Normal";
            this.outputMode.resolution = "150";
        }
        this.outputColor = null;
        SharedPreferences sharedPreferences5 = this.prefs;
        StringBuilder sb5 = new StringBuilder();
        sb5.append(getActivityClassName());
        sb5.append("#color");
        String string5 = sharedPreferences5.getString(sb5.toString(), this.prefs.getString("color", null));
        if (printer != null && printer.outputColor_list != null) {
            int size5 = printer.outputColor_list.size() - 1;
            while (true) {
                if (size5 < 0) {
                    break;
                }
                OutputColor outputColor2 = (OutputColor) printer.outputColor_list.elementAt(size5);
                if (outputColor2.id.equals(string5)) {
                    this.outputColor = outputColor2;
                    break;
                }
                if (outputColor2.id.equals(printer.outputColor_default)) {
                    this.outputColor = outputColor2;
                }
                size5--;
            }
        }
        if (this.outputColor == null) {
            OutputColor outputColor3 = new OutputColor();
            this.outputColor = outputColor3;
            outputColor3.id = str4;
            this.outputColor.name = "Default";
        }
        this.outputDuplex = null;
        SharedPreferences sharedPreferences6 = this.prefs;
        StringBuilder sb6 = new StringBuilder();
        sb6.append(getActivityClassName());
        sb6.append("#duplex");
        String string6 = sharedPreferences6.getString(sb6.toString(), this.prefs.getString("duplex", null));
        if (printer != null && printer.outputDuplex_list != null) {
            int size6 = printer.outputDuplex_list.size() - 1;
            while (true) {
                if (size6 < 0) {
                    break;
                }
                OutputDuplex outputDuplex2 = (OutputDuplex) printer.outputDuplex_list.elementAt(size6);
                if (outputDuplex2.id.equals(string6)) {
                    this.outputDuplex = outputDuplex2;
                    break;
                }
                if (outputDuplex2.id.equals(printer.outputDuplex_default)) {
                    this.outputDuplex = outputDuplex2;
                }
                size6--;
            }
        }
        if (this.outputDuplex == null) {
            OutputDuplex outputDuplex3 = new OutputDuplex();
            this.outputDuplex = outputDuplex3;
            outputDuplex3.id = str4;
            this.outputDuplex.name = "Off";
        }
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int i) {
        LayoutInflater from = LayoutInflater.from(this);
        if (i == 1) {
            View inflate = from.inflate(R.layout.dialog_pages, null);
            this.view_dialog_pages = inflate;
            final EditText editText = (EditText) inflate.findViewById(R.id.print_copies);
            editText.setFocusable(false);
            editText.setFocusableInTouchMode(false);
            editText.setClickable(false);
            editText.setKeyListener(null);
            editText.setInputType(0);
            ((Button) this.view_dialog_pages.findViewById(R.id.print_copies_plus)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int parseInt = Integer.parseInt(editText.getText().toString());
                    if (parseInt < 99) {
                        parseInt++;
                    }
                    editText.setText(String.valueOf(parseInt));
                }
            });
            ((Button) this.view_dialog_pages.findViewById(R.id.print_copies_minus)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int parseInt = Integer.parseInt(editText.getText().toString());
                    if (parseInt > 1) {
                        parseInt--;
                    }
                    editText.setText(String.valueOf(parseInt));
                }
            });
            ((EditText) this.view_dialog_pages.findViewById(R.id.print_pages)).setOnFocusChangeListener(new OnFocusChangeListener() {
                public void onFocusChange(View view, boolean z) {
                    if (z) {
                        ((RadioButton) ActivityPrint.this.view_dialog_pages.findViewById(R.id.print_range)).setChecked(true);
                    }
                }
            });
            ((RadioButton) this.view_dialog_pages.findViewById(R.id.print_range)).setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        EditText editText = (EditText) ActivityPrint.this.view_dialog_pages.findViewById(R.id.print_pages);
                        editText.requestFocus();
                        editText.requestFocusFromTouch();
                        return;
                    }
                    ActivityPrint.this.view_dialog_pages.requestFocus();
                    try {
                        InputMethodManager inputMethodManager = (InputMethodManager) ActivityPrint.this.getSystemService("input_method");
                        if (inputMethodManager != null) {
                            inputMethodManager.hideSoftInputFromWindow(ActivityPrint.this.view_dialog_pages.getWindowToken(), 2);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
            });
            return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_print_options).setView(this.view_dialog_pages).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityPrint.this.print(false);
                }
            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create();
        } else if (i != 2) {
            return null;
        } else {
            this.view_dialog_authorization = from.inflate(R.layout.dialog_authorization, null);
            return new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_authorization_title).setView(this.view_dialog_authorization).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    EditText editText = (EditText) ActivityPrint.this.view_dialog_authorization.findViewById(R.id.login_edit);
                    ActivityCore.printer.owner.login = editText.getText().toString();
                    EditText editText2 = (EditText) ActivityPrint.this.view_dialog_authorization.findViewById(R.id.password_edit);
                    ActivityCore.printer.owner.password = editText2.getText().toString();
                    Editor edit = ActivityPrint.this.prefs.edit();
                    edit.putString("printer_login", ActivityCore.printer.owner.login);
                    edit.putString("printer_password", ActivityCore.printer.owner.password);
                    edit.commit();
                    ActivityPrint.this.print(false);
                }
            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create();
        }
    }

    /* access modifiers changed from: protected */
    public void onPrepareDialog(int i, Dialog dialog) {
        String str = "";
        if (i == 1) {
            RadioButton radioButton = (RadioButton) this.view_dialog_pages.findViewById(R.id.print_all);
            RadioButton radioButton2 = (RadioButton) this.view_dialog_pages.findViewById(R.id.print_selected);
            if (this.sel_pages.size() == 0) {
                radioButton2.setEnabled(false);
                if (radioButton2.isChecked()) {
                    radioButton.setChecked(true);
                }
            } else if (!radioButton2.isEnabled()) {
                radioButton2.setEnabled(true);
                radioButton2.setChecked(true);
            }
            EditText editText = (EditText) this.view_dialog_pages.findViewById(R.id.print_pages);
            if (((RadioButton) this.view_dialog_pages.findViewById(R.id.print_range)).isChecked() && str.equals(editText.getText().toString())) {
                radioButton.setChecked(true);
            }
            this.view_dialog_pages.requestFocus();
        } else if (i == 2) {
            ((EditText) this.view_dialog_authorization.findViewById(R.id.login_edit)).setText(printer.owner.login != null ? printer.owner.login : str);
            ((EditText) this.view_dialog_authorization.findViewById(R.id.password_edit)).setText(str);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't wrap try/catch for region: R(9:3|4|5|6|(1:8)|9|10|11|(2:50|13)(1:14)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x002c */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0034 A[Catch:{ Exception -> 0x013e }, LOOP:0: B:1:0x0007->B:14:0x0034, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0033 A[SYNTHETIC] */
    public final Page prepareTestPage() {
        int i;
        int i2;
        this.test_page_bmp = null;
        int i3 = 0;
        while (true) {
            if (i3 >= 3) {
                break;
            }
            try {
                InputStream openRawResource = getResources().openRawResource(R.raw.test_page);
                Options options = new Options();
                options.inPreferredConfig = Config.ARGB_8888;
                options.inDither = false;
                if (i3 > 0) {
                    options.inSampleSize = i3 * 2;
                }
                this.test_page_bmp = BitmapFactory.decodeStream(openRawResource, null, options);
                openRawResource.close();
                if (this.test_page_bmp == null) {
                    break;
                }
                i3++;
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
                return null;
            }
        }
        int i4 = this.paper.width;
        int i5 = this.paper.height;
        int i6 = this.paper.margin_left > 0 ? this.paper.margin_left : 0;
        int i7 = this.paper.margin_right > 0 ? this.paper.margin_right : 0;
        int i8 = this.paper.margin_top > 0 ? this.paper.margin_top : 0;
        int i9 = this.paper.margin_bottom > 0 ? this.paper.margin_bottom : 0;
        if (this.test_page_bmp != null) {
            i2 = this.test_page_bmp.getWidth();
            i = this.test_page_bmp.getHeight();
        } else {
            i2 = 0;
            i = 0;
        }
        Picture picture = new Picture();
        Canvas beginRecording = picture.beginRecording(i4, i5);
        beginRecording.drawColor(-1);
        Paint newPaint = App.newPaint();
        newPaint.setColor(-16777216);
        newPaint.setStyle(Style.STROKE);
        int i10 = i4 - i7;
        int i11 = i5 - i9;
        Picture picture2 = picture;
        beginRecording.drawRect(new Rect(i6 + 5, i8 + 5, i10 - 5, i11 - 5), newPaint);
        beginRecording.drawRect(new Rect(i6 + 15, i8 + 15, i10 - 15, i11 - 15), newPaint);
        beginRecording.drawRect(new Rect(i6 + 25, i8 + 25, i10 - 25, i11 - 25), newPaint);
        beginRecording.drawRect(new Rect(i6 + 35, i8 + 35, i10 - 35, i11 - 35), newPaint);
        beginRecording.drawRect(new Rect(i6 + 45, i8 + 45, i10 - 45, i11 - 45), newPaint);
        if (this.test_page_bmp != null) {
            int i12 = 1016;
            int i13 = (i * 1016) / i2;
            int i14 = i4 - ((i6 + i7) + 100);
            if (i14 < 1016) {
                i13 = (i14 * i) / i2;
                i12 = i14;
            }
            int i15 = i5 - ((i8 + i9) + 100);
            if (i15 < i13) {
                i12 = (i15 * i2) / i;
                i13 = i15;
            }
            int i16 = i4 - i12;
            int i17 = i5 - i13;
            beginRecording.drawBitmap(this.test_page_bmp, new Rect(0, 0, i2, i), new Rect(i16 / 2, i17 / 2, (i16 / 2) + i12, (i17 / 2) + i13), App.newPaint());
        }
        picture2.endRecording();
        return new Page(picture2);
    }

    /* access modifiers changed from: protected */
    public final void startPrintThread(Vector<Page> vector) {
        int parseInt = Integer.parseInt(((EditText) this.view_dialog_pages.findViewById(R.id.print_copies)).getText().toString());
        if (parseInt < 1) {
            parseInt = 1;
        }
        startPrintThread(vector, parseInt);
    }

    private void startPrintThread(Vector<Page> vector, int i) {
        proceedCreateThumb(null);
        App.freeMem();
        PrintThread printThread = new PrintThread(this, printer, this.paper, this.paperType, this.paperSource, this.outputMode, this.outputColor, this.outputDuplex, vector, i, this.progressHandler);
        this.pt = printThread;
        printThread.start();
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00cd A[SYNTHETIC, Splitter:B:34:0x00cd] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00d5  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00d8  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00df  */
    public void print(boolean z) {
        String str;
        int i;
        int i2;
        if (!z) {
            if (((RadioButton) this.view_dialog_pages.findViewById(R.id.print_all)).isChecked()) {
                for (int i3 = 0; i3 < this.pages.size(); i3++) {
                    ((Page) this.pages.elementAt(i3)).print = true;
                }
                startPrint();
            } else if (((RadioButton) this.view_dialog_pages.findViewById(R.id.print_selected)).isChecked()) {
                for (int i4 = 0; i4 < this.pages.size(); i4++) {
                    if (this.sel_pages.contains(Integer.valueOf(i4))) {
                        ((Page) this.pages.elementAt(i4)).print = true;
                    } else {
                        ((Page) this.pages.elementAt(i4)).print = false;
                    }
                }
                startPrint();
            } else {
                EditText editText = (EditText) this.view_dialog_pages.findViewById(R.id.print_pages);
                int size = this.pages.size();
                boolean[] zArr = new boolean[size];
                StringTokenizer stringTokenizer = new StringTokenizer(editText.getText().toString(), ",");
                while (stringTokenizer.hasMoreTokens()) {
                    String nextToken = stringTokenizer.nextToken();
                    int indexOf = nextToken.indexOf("-");
                    if (indexOf >= 0) {
                        str = nextToken.substring(indexOf + 1);
                        nextToken = nextToken.substring(0, indexOf);
                    } else {
                        str = "";
                    }
                    String trim = nextToken.trim();
                    String trim2 = str.trim();
                    if (trim.length() > 0) {
                        try {
                            i = Integer.parseInt(trim);
                        } catch (Exception unused) {
                        }
                        if (trim2.length() > 0) {
                            try {
                                i2 = Integer.parseInt(trim2);
                            } catch (Exception unused2) {
                            }
                            if (i == 0) {
                                i = i2;
                            }
                            if (i2 == 0) {
                                i2 = i;
                            }
                            if (i > 0 && i2 >= i) {
                                while (i <= i2) {
                                    int i5 = i - 1;
                                    if (i5 < size) {
                                        zArr[i5] = true;
                                    }
                                    i++;
                                }
                            }
                        }
                        i2 = 0;
                        if (i == 0) {
                        }
                        if (i2 == 0) {
                        }
                        while (i <= i2) {
                        }
                    }
                    i = 0;
                    if (trim2.length() > 0) {
                    }
                    i2 = 0;
                    if (i == 0) {
                    }
                    if (i2 == 0) {
                    }
                    while (i <= i2) {
                    }
                }
                int i6 = 0;
                for (int i7 = 0; i7 < this.pages.size(); i7++) {
                    if (zArr[i7]) {
                        ((Page) this.pages.elementAt(i7)).print = true;
                        i6++;
                    } else {
                        ((Page) this.pages.elementAt(i7)).print = false;
                    }
                }
                if (i6 > 0) {
                    startPrint();
                } else {
                    Toast.makeText(this, R.string.toast_incorrect_print_range, 1).show();
                }
            }
        } else {
            showDialog(1);
        }
    }

    private void startPrint() {
        final String lowerCase = getClass().getSimpleName().toLowerCase();
        Billing.action.run(new Runnable() {
            public void run() {
                if (ActivityPrint.this.test_page_bmp == null) {
                    String str = "smb://";
                    if (ActivityCore.printer.id.endsWith(".local.") || ActivityCore.printer.id.startsWith(str) || ActivityCore.printer.id.indexOf("cloudprint.google.") > 0) {
                        String str2 = "pri";
                        boolean z = false;
                        boolean z2 = lowerCase.endsWith(str2.concat("ntp").concat("df")) || lowerCase.endsWith(str2.concat("ntdo").concat("cume").concat("nts"));
                        boolean endsWith = lowerCase.endsWith(str2.concat("ntand").concat("roid"));
                        boolean endsWith2 = lowerCase.endsWith(str2.concat("ntw").concat("eb"));
                        boolean endsWith3 = lowerCase.endsWith(str2.concat("ntpict").concat("ures"));
                        if (!ActivityCore.printer.id.startsWith(str) && ActivityCore.printer.id.indexOf("_tpl.") <= 0 && ActivityCore.printer.id.indexOf("@") <= 0) {
                            z = true;
                        }
                        if (!z || (!z2 && !endsWith && !endsWith2 && !endsWith3)) {
                            ActivityPrint activityPrint = ActivityPrint.this;
                            activityPrint.startPrintThread(activityPrint.pages);
                            return;
                        }
                        Billing.showUpgradeDialog(ActivityPrint.this);
                        return;
                    }
                    ActivityPrint activityPrint2 = ActivityPrint.this;
                    activityPrint2.startPrintThread(activityPrint2.pages);
                    return;
                }
                ActivityPrint activityPrint3 = ActivityPrint.this;
                activityPrint3.startPrintThread(activityPrint3.pages);
            }
        }, new Runnable() {
            public void run() {
                ActivityPrint activityPrint = ActivityPrint.this;
                activityPrint.startPrintThread(activityPrint.pages);
            }
        });
    }

    public void onDestroy() {
        recyclePages();
        super.onDestroy();
    }

    /* access modifiers changed from: private */
    public void doOK(boolean z) {
        String str = "smb://";
        String str2 = ".local.";
        setResult(-1);
        final Hashtable createEventParams = createEventParams();
        final String[] strArr = {"print_remote"};
        try {
            if (getClass().getSimpleName().endsWith("TestPage")) {
                z = true;
            }
            if (printer.id.endsWith(str2) || printer.id.startsWith(str)) {
                strArr[0] = "print_local";
            }
            if (printer.id.endsWith("cloudprint.google.")) {
                strArr[0] = "print_cloud";
            }
            if (z) {
                strArr[0] = strArr[0].concat("_test_page");
            } else {
                Billing.action.run(null, new Runnable() {
                    public void run() {
                        String[] strArr = strArr;
                        strArr[0] = strArr[0].concat("_pr").concat("emi").concat("um");
                    }
                });
            }
            FlurryAgent.logEvent(strArr[0], (Map<String, String>) createEventParams);
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        if (!isFinishing()) {
            boolean z2 = !z && getVendorID() == null;
            if (z2) {
                String str3 = "review_cf";
                int i = this.prefs.getInt(str3, 0);
                if (i < 0 || i > 30 || i % 10 != 2) {
                    z2 = false;
                }
                if (i >= 0 && i <= 30) {
                    Editor edit = this.prefs.edit();
                    edit.putInt(str3, i + 1);
                    edit.commit();
                }
            }
            String str4 = SmbConstants.NATIVE_LANMAN;
            if (z2) {
                hideProgress();
                StringBuilder sb = new StringBuilder();
                sb.append(getResources().getString(R.string.label_printing_completed));
                sb.append("\n\n");
                sb.append(getResources().getString(R.string.label_review));
                new Builder(this).setIcon(R.drawable.icon_title).setTitle(str4).setMessage(sb.toString()).setCancelable(false).setPositiveButton(R.string.button_review, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String str = "android.intent.action.VIEW";
                        String[] strArr = {BuildConfig.APPLICATION_ID};
                        try {
                            ActivityPrint activityPrint = ActivityPrint.this;
                            StringBuilder sb = new StringBuilder();
                            sb.append("market://details?id=");
                            sb.append(strArr[0]);
                            activityPrint.startActivity(new Intent(str, Uri.parse(sb.toString())));
                        } catch (ActivityNotFoundException unused) {
                            ActivityPrint activityPrint2 = ActivityPrint.this;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("http://play.google.com/store/apps/details?id=");
                            sb2.append(strArr[0]);
                            activityPrint2.startActivity(new Intent(str, Uri.parse(sb2.toString())));
                        }
                        Editor edit = ActivityPrint.this.prefs.edit();
                        edit.putInt("review_cf", -1);
                        edit.commit();
                        if (ActivityPrint.this.external_call) {
                            ActivityPrint.this.finish();
                        }
                    }
                }).setNegativeButton(R.string.button_skip, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ActivityPrint.this.external_call) {
                            ActivityPrint.this.finish();
                        }
                    }
                }).show();
                return;
            }
            Builder positiveButton = new Builder(this).setIcon(R.drawable.icon_title).setTitle(str4).setMessage(R.string.label_printing_completed).setCancelable(false).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (ActivityPrint.this.external_call) {
                        ActivityPrint.this.finish();
                    }
                }
            });
            if ("1".equals(FlurryConfig.getInstance().getString("report_problem", "0")) && (printer.id.endsWith(str2) || printer.id.startsWith(str))) {
                positiveButton.setNeutralButton(R.string.button_troubleshooting, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            final String[] strArr = {"not_printed", ActivityPrint.this.getString(R.string.print_problem_not_printed), "get_error", ActivityPrint.this.getString(R.string.print_problem_get_error), "blank_pages", ActivityPrint.this.getString(R.string.print_problem_blank_pages), "partially_printed", ActivityPrint.this.getString(R.string.print_problem_partially_printed), "bad_printouts", ActivityPrint.this.getString(R.string.print_problem_bad_printouts), "bad_colors", ActivityPrint.this.getString(R.string.print_problem_bad_colors), "no_duplex", ActivityPrint.this.getString(R.string.print_problem_no_duplex), "other", ActivityPrint.this.getString(R.string.print_problem_other)};
                            CharSequence[] charSequenceArr = new CharSequence[8];
                            for (int i2 = 0; i2 < 8; i2++) {
                                charSequenceArr[i2] = strArr[(i2 * 2) + 1];
                            }
                            new Builder(ActivityPrint.this).setIcon(R.drawable.icon_title).setTitle(R.string.button_troubleshooting).setCancelable(true).setItems(charSequenceArr, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    try {
                                        ActivityPrint.this.sendFeedback(strArr[(i * 2) + 1].toString());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                    try {
                                        createEventParams.put("problem", strArr[i * 2].toString());
                                        FlurryAgent.logEvent("btn_print_problem", (Map<String, String>) createEventParams);
                                    } catch (Exception e2) {
                                        e2.printStackTrace();
                                        App.reportThrowable(e2);
                                    }
                                }
                            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            }).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    }
                });
            }
            hideProgress();
            positiveButton.show();
            return;
        }
        hideProgress();
    }

    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenuInfo contextMenuInfo) {
        contextMenu.setHeaderTitle(getResources().getString(R.string.label_print_options));
        contextMenu.setHeaderIcon(R.drawable.icon_title);
        onCreateOptionsMenu(contextMenu);
        if (printer != null) {
            if (printer.paper_list != null && printer.paper_list.size() > 0) {
                contextMenu.add(0, 771, 0, R.string.label_paper_size);
            }
            if (printer.paperType_list != null && printer.paperType_list.size() > 0) {
                contextMenu.add(0, 772, 0, R.string.label_paper_type);
            }
            if (printer.paperSource_list != null && printer.paperSource_list.size() > 0) {
                contextMenu.add(0, 773, 0, R.string.label_paper_source);
            }
            if (printer.outputMode_list != null && printer.outputMode_list.size() > 0) {
                contextMenu.add(0, 881, 0, R.string.label_output_mode);
            }
            if (printer.outputColor_list != null && printer.outputColor_list.size() > 0) {
                contextMenu.add(0, 882, 0, R.string.label_output_color);
            }
            if (printer.outputDuplex_list != null && printer.outputDuplex_list.size() > 0) {
                contextMenu.add(0, 883, 0, R.string.label_output_duplex);
            }
        }
        contextMenu.add(0, 999, 0, R.string.menu_select_printer);
    }

    public void onCreateOptionsMenu(ContextMenu contextMenu) {
        contextMenu.add(0, 30, 0, R.string.label_page_margins);
        contextMenu.add(0, 23, 0, R.string.label_page_orientation);
    }

    private String getOptionNameValue(int i, int i2) {
        String str = ": ";
        if (i == 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(getString(R.string.label_paper_size));
            sb.append(str);
            sb.append(((Paper) printer.paper_list.get(i2)).name);
            return sb.toString();
        } else if (i == 1) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(getString(R.string.label_paper_type));
            sb2.append(str);
            sb2.append(((PaperType) printer.paperType_list.get(i2)).name);
            return sb2.toString();
        } else if (i == 2) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(getString(R.string.label_paper_source));
            sb3.append(str);
            sb3.append(((PaperSource) printer.paperSource_list.get(i2)).name);
            return sb3.toString();
        } else if (i == 3) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(getString(R.string.label_output_mode));
            sb4.append(str);
            sb4.append(((OutputMode) printer.outputMode_list.get(i2)).name);
            return sb4.toString();
        } else if (i == 4) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(getString(R.string.label_output_color));
            sb5.append(str);
            sb5.append(((OutputColor) printer.outputColor_list.get(i2)).name);
            return sb5.toString();
        } else if (i != 5) {
            return null;
        } else {
            StringBuilder sb6 = new StringBuilder();
            sb6.append(getString(R.string.label_output_duplex));
            sb6.append(str);
            sb6.append(((OutputDuplex) printer.outputDuplex_list.get(i2)).name);
            return sb6.toString();
        }
    }

    /* access modifiers changed from: private */
    public boolean checkContraints() {
        StringBuilder sb;
        String str;
        StringBuilder sb2;
        String str2 = "\n";
        String str3 = "=";
        String str4 = "";
        if (!(printer == null || printer.constraint_list == null)) {
            for (int i = 0; i < 6; i++) {
                int i2 = -1;
                try {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(i);
                    sb3.append(str4);
                    String sb4 = sb3.toString();
                    Vector vector = new Vector();
                    if (i == 0) {
                        if (printer.paper_default.equals(this.paper.id)) {
                            sb4 = null;
                        }
                        i2 = 0;
                        while (i2 < printer.paper_list.size() && !this.paper.id.equals(((Paper) printer.paper_list.get(i2)).id)) {
                            i2++;
                        }
                        vector.add(str4);
                    } else if (printer.paper_list != null) {
                        if (!this.paper.id.equals(printer.paper_default)) {
                            vector.add("0");
                        }
                        int i3 = 0;
                        while (i3 < printer.paper_list.size() && !this.paper.id.equals(((Paper) printer.paper_list.get(i3)).id)) {
                            i3++;
                        }
                        StringBuilder sb5 = new StringBuilder();
                        sb5.append("0=");
                        sb5.append(i3);
                        vector.add(sb5.toString());
                    }
                    if (i == 1) {
                        if (printer.paperType_default.equals(this.paperType.id)) {
                            sb4 = null;
                        }
                        int i4 = 0;
                        while (i2 < printer.paperType_list.size() && !this.paperType.id.equals(((PaperType) printer.paperType_list.get(i2)).id)) {
                            i4 = i2 + 1;
                        }
                        vector.add(str4);
                    } else if (printer.paperType_list != null) {
                        if (!this.paperType.id.equals(printer.paperType_default)) {
                            vector.add("1");
                        }
                        int i5 = 0;
                        while (i5 < printer.paperType_list.size() && !this.paperType.id.equals(((PaperType) printer.paperType_list.get(i5)).id)) {
                            i5++;
                        }
                        StringBuilder sb6 = new StringBuilder();
                        sb6.append("1=");
                        sb6.append(i5);
                        vector.add(sb6.toString());
                    }
                    if (i == 2) {
                        if (printer.paperSource_default.equals(this.paperSource.id)) {
                            sb4 = null;
                        }
                        int i6 = 0;
                        while (i2 < printer.paperSource_list.size() && !this.paperSource.id.equals(((PaperSource) printer.paperSource_list.get(i2)).id)) {
                            i6 = i2 + 1;
                        }
                        vector.add(str4);
                    } else if (printer.paperSource_list != null) {
                        if (!this.paperSource.id.equals(printer.paperSource_default)) {
                            vector.add("2");
                        }
                        int i7 = 0;
                        while (i7 < printer.paperSource_list.size() && !this.paperSource.id.equals(((PaperSource) printer.paperSource_list.get(i7)).id)) {
                            i7++;
                        }
                        StringBuilder sb7 = new StringBuilder();
                        sb7.append("2=");
                        sb7.append(i7);
                        vector.add(sb7.toString());
                    }
                    if (i == 3) {
                        if (printer.outputMode_default.equals(this.outputMode.id)) {
                            sb4 = null;
                        }
                        int i8 = 0;
                        while (i2 < printer.outputMode_list.size() && !this.outputMode.id.equals(((OutputMode) printer.outputMode_list.get(i2)).id)) {
                            i8 = i2 + 1;
                        }
                        vector.add(str4);
                    } else if (printer.outputMode_list != null) {
                        if (!this.outputMode.id.equals(printer.outputMode_default)) {
                            vector.add("3");
                        }
                        int i9 = 0;
                        while (i9 < printer.outputMode_list.size() && !this.outputMode.id.equals(((OutputMode) printer.outputMode_list.get(i9)).id)) {
                            i9++;
                        }
                        StringBuilder sb8 = new StringBuilder();
                        sb8.append("3=");
                        sb8.append(i9);
                        vector.add(sb8.toString());
                    }
                    if (i == 4) {
                        if (printer.outputColor_default.equals(this.outputColor.id)) {
                            sb4 = null;
                        }
                        int i10 = 0;
                        while (i2 < printer.outputColor_list.size() && !this.outputColor.id.equals(((OutputColor) printer.outputColor_list.get(i2)).id)) {
                            i10 = i2 + 1;
                        }
                        vector.add(str4);
                    } else if (printer.outputColor_list != null) {
                        if (!this.outputColor.id.equals(printer.outputColor_default)) {
                            vector.add("4");
                        }
                        int i11 = 0;
                        while (i11 < printer.outputColor_list.size() && !this.outputColor.id.equals(((OutputColor) printer.outputColor_list.get(i11)).id)) {
                            i11++;
                        }
                        StringBuilder sb9 = new StringBuilder();
                        sb9.append("4=");
                        sb9.append(i11);
                        vector.add(sb9.toString());
                    }
                    if (i == 5) {
                        if (printer.outputDuplex_default.equals(this.outputDuplex.id)) {
                            sb4 = null;
                        }
                        int i12 = 0;
                        while (i2 < printer.outputDuplex_list.size() && !this.outputDuplex.id.equals(((OutputDuplex) printer.outputDuplex_list.get(i2)).id)) {
                            i12 = i2 + 1;
                        }
                        vector.add(str4);
                    } else if (printer.outputDuplex_list != null) {
                        if (!this.outputDuplex.id.equals(printer.outputDuplex_default)) {
                            vector.add("5");
                        }
                        int i13 = 0;
                        while (i13 < printer.outputDuplex_list.size() && !this.outputDuplex.id.equals(((OutputDuplex) printer.outputDuplex_list.get(i13)).id)) {
                            i13++;
                        }
                        StringBuilder sb10 = new StringBuilder();
                        sb10.append("5=");
                        sb10.append(i13);
                        vector.add(sb10.toString());
                    }
                    StringBuilder sb11 = new StringBuilder();
                    sb11.append(i);
                    sb11.append(str3);
                    sb11.append(i2);
                    String sb12 = sb11.toString();
                    boolean z = false;
                    for (int i14 = 0; i14 < vector.size(); i14++) {
                        String str5 = (String) vector.get(i14);
                        if (str5.length() == 0) {
                            z = true;
                        } else {
                            String str6 = "/";
                            if (!z) {
                                sb = new StringBuilder();
                                sb.append(str5);
                                sb.append(str6);
                                sb.append(sb12);
                            } else {
                                sb = new StringBuilder();
                                sb.append(sb12);
                                sb.append(str6);
                                sb.append(str5);
                            }
                            String sb13 = sb.toString();
                            if (sb4 == null) {
                                str = null;
                            } else {
                                if (!z) {
                                    sb2 = new StringBuilder();
                                    sb2.append(str5);
                                    sb2.append(str6);
                                    sb2.append(sb4);
                                } else {
                                    sb2 = new StringBuilder();
                                    sb2.append(sb4);
                                    sb2.append(str6);
                                    sb2.append(str5);
                                }
                                str = sb2.toString();
                            }
                            if (!printer.constraint_list.contains(sb13)) {
                                if (str != null && printer.constraint_list.contains(str)) {
                                }
                            }
                            StringBuilder sb14 = new StringBuilder();
                            sb14.append(getString(R.string.dialog_incompatible_settings_title));
                            sb14.append(": ");
                            sb14.append(getString(R.string.dialog_incompatible_settings_text));
                            sb14.append("\n\n");
                            this.last_error = sb14.toString();
                            StringBuilder sb15 = new StringBuilder();
                            sb15.append(getOptionNameValue(i, i2));
                            sb15.append(str2);
                            String sb16 = sb15.toString();
                            int indexOf = str5.indexOf(str3);
                            if (indexOf < 0) {
                                str5 = (String) vector.get(i14 + 1);
                                indexOf = str5.indexOf(str3);
                            }
                            StringBuilder sb17 = new StringBuilder();
                            sb17.append(getOptionNameValue(Integer.parseInt(str5.substring(0, indexOf)), Integer.parseInt(str5.substring(indexOf + 1))));
                            sb17.append(str2);
                            String sb18 = sb17.toString();
                            if (z) {
                                StringBuilder sb19 = new StringBuilder();
                                sb19.append(this.last_error);
                                sb19.append(sb16);
                                sb19.append(sb18);
                                this.last_error = sb19.toString().trim();
                            } else {
                                StringBuilder sb20 = new StringBuilder();
                                sb20.append(this.last_error);
                                sb20.append(sb18);
                                sb20.append(sb16);
                                this.last_error = sb20.toString().trim();
                            }
                            return true;
                        }
                    }
                    continue;
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
        }
        return false;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        CharSequence[] charSequenceArr;
        CharSequence[] charSequenceArr2;
        CharSequence[] charSequenceArr3;
        CharSequence[] charSequenceArr4;
        CharSequence[] charSequenceArr5;
        CharSequence[] charSequenceArr6;
        int itemId = menuItem.getItemId();
        if (itemId == 23) {
            Builder negativeButton = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_page_orientation).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityPrint activityPrint = ActivityPrint.this;
                    activityPrint.orientation = activityPrint.sel_orientation;
                    Editor edit = ActivityPrint.this.prefs.edit();
                    StringBuilder sb = new StringBuilder();
                    sb.append(ActivityPrint.this.getActivityClassName());
                    sb.append("#orientation");
                    edit.putInt(sb.toString(), ActivityPrint.this.orientation);
                    edit.commit();
                    ActivityPrint.this.need_update_pages = true;
                    ActivityPrint.this.update();
                }
            }).setNegativeButton(R.string.button_cancel, null);
            negativeButton.setSingleChoiceItems(this.orientationOptions, this.orientation, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityPrint.this.sel_orientation = i;
                }
            });
            this.sel_orientation = this.orientation;
            negativeButton.show();
            return true;
        } else if (itemId == 30) {
            Builder negativeButton2 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_page_margins).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityPrint activityPrint = ActivityPrint.this;
                    activityPrint.margins = activityPrint.sel_margins;
                    Editor edit = ActivityPrint.this.prefs.edit();
                    StringBuilder sb = new StringBuilder();
                    sb.append(ActivityPrint.this.getActivityClassName());
                    sb.append("#margins");
                    edit.putInt(sb.toString(), ActivityPrint.this.margins);
                    edit.commit();
                    ActivityPrint.this.need_update_pages = true;
                    ActivityPrint.this.update();
                }
            }).setNegativeButton(R.string.button_cancel, null);
            negativeButton2.setSingleChoiceItems(this.marginsOptions, this.margins, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityPrint.this.sel_margins = i;
                }
            });
            this.sel_margins = this.margins;
            negativeButton2.show();
            return true;
        } else if (itemId != 999) {
            int i2 = -1;
            int i3 = 0;
            switch (itemId) {
                case 771:
                    Builder negativeButton3 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_paper_size).setPositiveButton(R.string.button_ok, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (ActivityPrint.this.sel_paper >= 0 && ActivityCore.printer != null && ActivityCore.printer.paper_list != null && ActivityCore.printer.paper_list.size() != 0) {
                                ActivityPrint.this.paper = (Paper) ActivityCore.printer.paper_list.elementAt(ActivityPrint.this.sel_paper);
                                Editor edit = ActivityPrint.this.prefs.edit();
                                StringBuilder sb = new StringBuilder();
                                sb.append(ActivityPrint.this.getActivityClassName());
                                sb.append("#paper");
                                edit.putString(sb.toString(), ActivityPrint.this.paper.id);
                                edit.commit();
                                ActivityPrint.this.need_update_pages = true;
                                ActivityPrint.this.update();
                            }
                        }
                    }).setNegativeButton(R.string.button_cancel, null);
                    if (printer == null || printer.paper_list == null || printer.paper_list.size() <= 0) {
                        charSequenceArr = new CharSequence[]{this.paper.name};
                    } else {
                        charSequenceArr = new CharSequence[printer.paper_list.size()];
                        while (i3 < printer.paper_list.size()) {
                            Paper paper2 = (Paper) printer.paper_list.elementAt(i3);
                            charSequenceArr[i3] = paper2.name;
                            if (this.paper == paper2) {
                                i2 = i3;
                            }
                            i3++;
                        }
                        i3 = i2;
                    }
                    this.sel_paper = i3;
                    negativeButton3.setSingleChoiceItems(charSequenceArr, i3, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityPrint.this.sel_paper = i;
                        }
                    });
                    negativeButton3.show();
                    return true;
                case 772:
                    Builder negativeButton4 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_paper_type).setPositiveButton(R.string.button_ok, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (ActivityPrint.this.sel_paperType >= 0 && ActivityCore.printer != null && ActivityCore.printer.paperType_list != null && ActivityCore.printer.paperType_list.size() != 0) {
                                ActivityPrint.this.paperType = (PaperType) ActivityCore.printer.paperType_list.elementAt(ActivityPrint.this.sel_paperType);
                                Editor edit = ActivityPrint.this.prefs.edit();
                                StringBuilder sb = new StringBuilder();
                                sb.append(ActivityPrint.this.getActivityClassName());
                                sb.append("#type");
                                edit.putString(sb.toString(), ActivityPrint.this.paperType.id);
                                edit.commit();
                                ActivityPrint.this.need_update_pages = true;
                                ActivityPrint.this.update();
                            }
                        }
                    }).setNegativeButton(R.string.button_cancel, null);
                    if (printer == null || printer.paperType_list == null || printer.paperType_list.size() <= 0) {
                        charSequenceArr2 = new CharSequence[]{this.paperType.name};
                    } else {
                        charSequenceArr2 = new CharSequence[printer.paperType_list.size()];
                        while (i3 < printer.paperType_list.size()) {
                            PaperType paperType2 = (PaperType) printer.paperType_list.elementAt(i3);
                            charSequenceArr2[i3] = paperType2.name;
                            if (paperType2 == this.paperType) {
                                i2 = i3;
                            }
                            i3++;
                        }
                        i3 = i2;
                    }
                    this.sel_paperType = i3;
                    negativeButton4.setSingleChoiceItems(charSequenceArr2, i3, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityPrint.this.sel_paperType = i;
                        }
                    });
                    negativeButton4.show();
                    return true;
                case 773:
                    Builder negativeButton5 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_paper_source).setPositiveButton(R.string.button_ok, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (ActivityPrint.this.sel_paperSource >= 0 && ActivityCore.printer != null && ActivityCore.printer.paperSource_list != null && ActivityCore.printer.paperSource_list.size() != 0) {
                                ActivityPrint.this.paperSource = (PaperSource) ActivityCore.printer.paperSource_list.elementAt(ActivityPrint.this.sel_paperSource);
                                Editor edit = ActivityPrint.this.prefs.edit();
                                StringBuilder sb = new StringBuilder();
                                sb.append(ActivityPrint.this.getActivityClassName());
                                sb.append("#tray");
                                edit.putString(sb.toString(), ActivityPrint.this.paperSource.id);
                                edit.commit();
                                ActivityPrint.this.need_update_pages = true;
                                ActivityPrint.this.update();
                            }
                        }
                    }).setNegativeButton(R.string.button_cancel, null);
                    if (printer == null || printer.paperSource_list == null || printer.paperSource_list.size() <= 0) {
                        charSequenceArr3 = new CharSequence[]{this.paperSource.name};
                    } else {
                        charSequenceArr3 = new CharSequence[printer.paperSource_list.size()];
                        while (i3 < printer.paperSource_list.size()) {
                            PaperSource paperSource2 = (PaperSource) printer.paperSource_list.elementAt(i3);
                            charSequenceArr3[i3] = paperSource2.name;
                            if (paperSource2 == this.paperSource) {
                                i2 = i3;
                            }
                            i3++;
                        }
                        i3 = i2;
                    }
                    this.sel_paperSource = i3;
                    negativeButton5.setSingleChoiceItems(charSequenceArr3, i3, new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityPrint.this.sel_paperSource = i;
                        }
                    });
                    negativeButton5.show();
                    return true;
                default:
                    switch (itemId) {
                        case 881:
                            Builder negativeButton6 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_output_mode).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    if (ActivityPrint.this.sel_outputMode >= 0 && ActivityCore.printer != null && ActivityCore.printer.outputMode_list != null && ActivityCore.printer.outputMode_list.size() != 0) {
                                        ActivityPrint.this.outputMode = (OutputMode) ActivityCore.printer.outputMode_list.elementAt(ActivityPrint.this.sel_outputMode);
                                        Editor edit = ActivityPrint.this.prefs.edit();
                                        StringBuilder sb = new StringBuilder();
                                        sb.append(ActivityPrint.this.getActivityClassName());
                                        sb.append("#mode");
                                        edit.putString(sb.toString(), ActivityPrint.this.outputMode.id);
                                        edit.commit();
                                        ActivityPrint.this.need_update_pages = true;
                                        ActivityPrint.this.update();
                                    }
                                }
                            }).setNegativeButton(R.string.button_cancel, null);
                            if (printer == null || printer.outputMode_list == null || printer.outputMode_list.size() <= 0) {
                                charSequenceArr4 = new CharSequence[]{this.outputMode.name};
                            } else {
                                charSequenceArr4 = new CharSequence[printer.outputMode_list.size()];
                                while (i3 < printer.outputMode_list.size()) {
                                    OutputMode outputMode2 = (OutputMode) printer.outputMode_list.elementAt(i3);
                                    charSequenceArr4[i3] = outputMode2.name;
                                    if (this.outputMode == outputMode2) {
                                        i2 = i3;
                                    }
                                    i3++;
                                }
                                i3 = i2;
                            }
                            this.sel_outputMode = i3;
                            negativeButton6.setSingleChoiceItems(charSequenceArr4, i3, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrint.this.sel_outputMode = i;
                                }
                            });
                            negativeButton6.show();
                            return true;
                        case 882:
                            Builder negativeButton7 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_output_color).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    if (ActivityPrint.this.sel_outputColor >= 0 && ActivityCore.printer != null && ActivityCore.printer.outputColor_list != null && ActivityCore.printer.outputColor_list.size() != 0) {
                                        ActivityPrint.this.outputColor = (OutputColor) ActivityCore.printer.outputColor_list.elementAt(ActivityPrint.this.sel_outputColor);
                                        Editor edit = ActivityPrint.this.prefs.edit();
                                        StringBuilder sb = new StringBuilder();
                                        sb.append(ActivityPrint.this.getActivityClassName());
                                        sb.append("#color");
                                        edit.putString(sb.toString(), ActivityPrint.this.outputColor.id);
                                        edit.commit();
                                        ActivityPrint.this.need_update_pages = true;
                                        ActivityPrint.this.update();
                                    }
                                }
                            }).setNegativeButton(R.string.button_cancel, null);
                            if (printer == null || printer.outputColor_list == null || printer.outputColor_list.size() <= 0) {
                                charSequenceArr5 = new CharSequence[]{this.outputColor.name};
                            } else {
                                charSequenceArr5 = new CharSequence[printer.outputColor_list.size()];
                                while (i3 < printer.outputColor_list.size()) {
                                    OutputColor outputColor2 = (OutputColor) printer.outputColor_list.elementAt(i3);
                                    charSequenceArr5[i3] = outputColor2.name;
                                    if (this.outputColor == outputColor2) {
                                        i2 = i3;
                                    }
                                    i3++;
                                }
                                i3 = i2;
                            }
                            this.sel_outputColor = i3;
                            negativeButton7.setSingleChoiceItems(charSequenceArr5, i3, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrint.this.sel_outputColor = i;
                                }
                            });
                            negativeButton7.show();
                            return true;
                        case 883:
                            Builder negativeButton8 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_output_duplex).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    if (ActivityPrint.this.sel_outputDuplex >= 0 && ActivityCore.printer != null && ActivityCore.printer.outputDuplex_list != null && ActivityCore.printer.outputDuplex_list.size() != 0) {
                                        ActivityPrint.this.outputDuplex = (OutputDuplex) ActivityCore.printer.outputDuplex_list.elementAt(ActivityPrint.this.sel_outputDuplex);
                                        Editor edit = ActivityPrint.this.prefs.edit();
                                        StringBuilder sb = new StringBuilder();
                                        sb.append(ActivityPrint.this.getActivityClassName());
                                        sb.append("#duplex");
                                        edit.putString(sb.toString(), ActivityPrint.this.outputDuplex.id);
                                        edit.commit();
                                        ActivityPrint.this.need_update_pages = true;
                                        ActivityPrint.this.update();
                                    }
                                }
                            }).setNegativeButton(R.string.button_cancel, null);
                            if (printer == null || printer.outputDuplex_list == null || printer.outputDuplex_list.size() <= 0) {
                                charSequenceArr6 = new CharSequence[]{this.outputDuplex.name};
                            } else {
                                charSequenceArr6 = new CharSequence[printer.outputDuplex_list.size()];
                                while (i3 < printer.outputDuplex_list.size()) {
                                    OutputDuplex outputDuplex2 = (OutputDuplex) printer.outputDuplex_list.elementAt(i3);
                                    charSequenceArr6[i3] = outputDuplex2.name;
                                    if (this.outputDuplex == outputDuplex2) {
                                        i2 = i3;
                                    }
                                    i3++;
                                }
                                i3 = i2;
                            }
                            this.sel_outputDuplex = i3;
                            negativeButton8.setSingleChoiceItems(charSequenceArr6, i3, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrint.this.sel_outputDuplex = i;
                                }
                            });
                            negativeButton8.show();
                            return true;
                        default:
                            return super.onMenuItemSelected(i, menuItem);
                    }
            }
        } else {
            this.printers_menu.show();
            return true;
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        int i;
        IjsDriver ijsDriver;
        String str = "\\,";
        String str2 = "x";
        if (npc_pid != null) {
            String str3 = npc_pid;
            npc_pid = null;
            if (printer == null || printer.id.indexOf("_usb.local.") <= 0 || !printer.id.startsWith(str3)) {
                startLocalPrintersUSB();
            } else {
                if (this.pages != null) {
                    this.need_update_pages = true;
                }
                initPrinterParams();
            }
        }
        super.update();
        final View findViewById = findViewById(R.id.upgrade_banner);
        if (findViewById != null) {
            Billing.action.run(new Runnable() {
                public void run() {
                    findViewById.setVisibility(0);
                }
            }, new Runnable() {
                public void run() {
                    findViewById.setVisibility(8);
                }
            });
        }
        TextView textView = (TextView) findViewById(R.id.paper_size);
        Paper paper2 = this.paper;
        String str4 = "";
        textView.setText(paper2 != null ? paper2.name : str4);
        TextView textView2 = (TextView) findViewById(R.id.paper_mode);
        StringBuilder sb = new StringBuilder();
        OutputColor outputColor2 = this.outputColor;
        sb.append((outputColor2 == null || str4.equals(outputColor2.id)) ? str4 : this.outputColor.name);
        OutputColor outputColor3 = this.outputColor;
        sb.append((outputColor3 == null || str4.equals(outputColor3.id) || this.outputMode == null) ? str4 : " / ");
        OutputMode outputMode2 = this.outputMode;
        sb.append(outputMode2 != null ? outputMode2.name : str4);
        textView2.setText(sb.toString());
        TextView textView3 = (TextView) findViewById(R.id.paper_tray);
        PaperSource paperSource2 = this.paperSource;
        textView3.setText(paperSource2 != null ? paperSource2.name : str4);
        ImageView imageView = (ImageView) findViewById(R.id.paper_orientation);
        int i2 = this.orientation;
        int i3 = i2 == 0 ? R.drawable.paper_auto : i2 == 1 ? R.drawable.paper_portrait : R.drawable.paper_landscape;
        imageView.setBackgroundResource(i3);
        if (this.need_update_pages) {
            int i4 = 0;
            this.need_update_pages = false;
            if (!(printer == null || printer.drv_name == null || printer.drv_name.indexOf("ijs_") <= 0)) {
                int i5 = 0;
                while (true) {
                    try {
                        if (i5 >= printer.paper_list.size()) {
                            break;
                        }
                        Paper paper3 = (Paper) printer.paper_list.get(i5);
                        if (paper3.id.equals(this.paper.id)) {
                            this.paper = paper3;
                            break;
                        }
                        i5++;
                    } catch (Exception e) {
                        Exception exc = e;
                        try {
                            ijsDriver.terminate();
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                        if (!(exc instanceof IOException)) {
                            if (!"Broken pipe".equals(exc.getMessage())) {
                                throw exc;
                            }
                        }
                        throw new IJSException(this, exc);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                        App.reportThrowable(e3);
                    }
                }
                String[] split = printer.drv_name.split("\\|");
                int indexOf = this.outputMode.resolution.indexOf(str2);
                int parseInt = Integer.parseInt(indexOf < 0 ? this.outputMode.resolution : this.outputMode.resolution.substring(0, indexOf));
                if (indexOf < 0) {
                    i = parseInt;
                } else {
                    i = Integer.parseInt(this.outputMode.resolution.substring(indexOf + 1));
                }
                int i6 = (this.paper.width * parseInt) / 254;
                int i7 = (this.paper.height * i) / 254;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Width=");
                sb2.append(String.valueOf(i6));
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Height=");
                sb3.append(String.valueOf(i7));
                StringBuilder sb4 = new StringBuilder();
                sb4.append("Dpi=");
                sb4.append(parseInt);
                sb4.append(str2);
                sb4.append(i);
                String[] strArr = {"OutputFD=2", "NumChan=3", "BitsPerSample=8", "ColorSpace=DeviceRGB", sb2.toString(), sb3.toString(), sb4.toString()};
                String[] split2 = printer.drv_params.split(str);
                String[] split3 = this.paper.drv_params.split(str);
                String[] split4 = this.outputMode.drv_params != null ? this.outputMode.drv_params.split(str) : new String[0];
                String[] split5 = this.outputDuplex.drv_params != null ? this.outputDuplex.drv_params.split(str) : new String[0];
                String[] split6 = this.paperSource.drv_params != null ? this.paperSource.drv_params.split(str) : new String[0];
                ijsDriver = new IjsDriver(new File(App.getFilesDirInt(split[0]), split[2]), printer.drv_envp);
                this.rd = new DataReadThread();
                this.rd.start(ijsDriver.proc_es);
                if (!ijsDriver.connect()) {
                    throw new IJSException();
                } else if (!ijsDriver.open()) {
                    throw new IJSException();
                } else if (ijsDriver.beginJob(0)) {
                    int i8 = 0;
                    while (true) {
                        String str5 = "\\=";
                        if (i8 < 7) {
                            String[] split7 = strArr[i8].split(str5);
                            if (ijsDriver.setParam(0, split7[0], split7[1])) {
                                i8++;
                            } else {
                                throw new IJSException();
                            }
                        } else {
                            int i9 = 0;
                            while (i9 < split2.length) {
                                String[] split8 = split2[i9].split(str5);
                                if (ijsDriver.setParam(0, split8[0], split8[1])) {
                                    i9++;
                                } else {
                                    throw new IJSException();
                                }
                            }
                            int i10 = 0;
                            while (i10 < split4.length) {
                                String[] split9 = split4[i10].split(str5);
                                if (ijsDriver.setParam(0, split9[0], split9[1])) {
                                    i10++;
                                } else {
                                    throw new IJSException();
                                }
                            }
                            int i11 = 0;
                            while (i11 < split5.length) {
                                String[] split10 = split5[i11].split(str5);
                                if (ijsDriver.setParam(0, split10[0], split10[1])) {
                                    i11++;
                                } else {
                                    throw new IJSException();
                                }
                            }
                            int i12 = 0;
                            while (i12 < split6.length) {
                                String[] split11 = split6[i12].split(str5);
                                if (ijsDriver.setParam(0, split11[0], split11[1])) {
                                    i12++;
                                } else {
                                    throw new IJSException();
                                }
                            }
                            int i13 = 0;
                            while (i13 < split3.length) {
                                String[] split12 = split3[i13].split(str5);
                                if (ijsDriver.setParam(0, split12[0], split12[1])) {
                                    i13++;
                                } else {
                                    throw new IJSException();
                                }
                            }
                            String param = ijsDriver.getParam(0, "PaperSize");
                            String param2 = ijsDriver.getParam(0, "PrintableArea");
                            String param3 = ijsDriver.getParam(0, "PrintableTopLeft");
                            if (!(param == null || param2 == null || param3 == null)) {
                                String[] split13 = param.split(str2);
                                double parseDouble = Double.parseDouble(split13[0]);
                                double parseDouble2 = Double.parseDouble(split13[1]);
                                String[] split14 = param3.split(str2);
                                double parseDouble3 = Double.parseDouble(split14[0]);
                                double parseDouble4 = Double.parseDouble(split14[1]);
                                String[] split15 = param2.split(str2);
                                double parseDouble5 = (parseDouble - Double.parseDouble(split15[0])) - parseDouble3;
                                double parseDouble6 = (parseDouble2 - Double.parseDouble(split15[1])) - parseDouble4;
                                int round = (int) Math.round(parseDouble * 254.0d);
                                int round2 = (int) Math.round(parseDouble2 * 254.0d);
                                int round3 = (int) Math.round(parseDouble3 * 254.0d);
                                int round4 = (int) Math.round(parseDouble4 * 254.0d);
                                int round5 = (int) Math.round(parseDouble5 * 254.0d);
                                int round6 = (int) Math.round(parseDouble6 * 254.0d);
                                this.paper.width = round;
                                this.paper.height = round2;
                                this.paper.margin_left = round3;
                                this.paper.margin_top = round4;
                                this.paper.margin_right = round5;
                                this.paper.margin_bottom = round6;
                            }
                            if (!ijsDriver.cancelJob(0)) {
                                throw new IJSException();
                            } else if (!ijsDriver.close()) {
                                throw new IJSException();
                            } else if (ijsDriver.disconnect() == 0) {
                                while (this.rd.isAlive()) {
                                    Thread.yield();
                                }
                            } else {
                                throw new IJSException();
                            }
                        }
                    }
                } else {
                    throw new IJSException();
                }
            }
            Vector<Page> vector = this.pages;
            int size = vector != null ? vector.size() : 0;
            updatePages();
            Vector<Page> vector2 = this.pages;
            if (vector2 != null) {
                i4 = vector2.size();
            }
            if (size != i4) {
                View view = this.view_dialog_pages;
                if (view != null) {
                    ((EditText) view.findViewById(R.id.print_pages)).setText(str4);
                }
            }
        }
    }

    private final void updatePages() {
        showProgress(getResources().getString(R.string.label_processing));
        recyclePages();
        AnonymousClass39 r0 = new Thread() {
            public void run() {
                ActivityPrint.this.createPages();
                ActivityPrint.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrint.this.showPages();
                        ActivityPrint.this.hideProgress();
                    }
                });
                ActivityPrint.this.ut = null;
            }
        };
        this.ut = r0;
        r0.start();
    }

    /* access modifiers changed from: private */
    public synchronized Bitmap getThumb(PageView pageView) {
        Bitmap bitmap;
        int i = 0;
        int maxMemory = App.getMaxMemory() / 4;
        bitmap = null;
        for (int size = this.rl_data.size() - 1; size >= 0; size--) {
            Thumb thumb = (Thumb) this.rl_data.get(size);
            if (thumb.bmp != null) {
                if (thumb.pv == pageView) {
                    this.rl_data.remove(size);
                    if (thumb.bmp.getWidth() == pageView.getMeasuredWidth() && thumb.bmp.getHeight() == pageView.getMeasuredHeight()) {
                        this.rl_data.add(thumb);
                        bitmap = thumb.bmp;
                    } else {
                        thumb.bmp.recycle();
                        thumb.bmp = null;
                    }
                } else if (i > maxMemory && !thumb.pv.getGlobalVisibleRect(new Rect())) {
                    thumb.bmp.recycle();
                    thumb.bmp = null;
                }
                if (thumb.bmp != null) {
                    i += (thumb.bmp.getRowBytes() * thumb.bmp.getHeight()) / 1024;
                }
            }
        }
        return bitmap;
    }

    /* access modifiers changed from: private */
    public void createThumb(PageView pageView) {
        int intValue = ((Integer) pageView.getTag()).intValue();
        int measuredWidth = pageView.getMeasuredWidth();
        int measuredHeight = pageView.getMeasuredHeight();
        Bitmap createBitmap = Bitmap.createBitmap(measuredWidth, measuredHeight, Config.ARGB_8888);
        int i = 0;
        new PCanvas(createBitmap, true).drawPicture(((Page) this.pages.get(intValue)).getPicture(), new Rect(0, 0, measuredWidth, measuredHeight));
        synchronized (this) {
            if (this.rl_thread != null) {
                Thumb thumb = null;
                while (true) {
                    if (i >= this.rl_data.size()) {
                        break;
                    } else if (((Thumb) this.rl_data.get(i)).pv == pageView) {
                        thumb = (Thumb) this.rl_data.remove(i);
                        break;
                    } else {
                        i++;
                    }
                }
                if (thumb == null) {
                    thumb = new Thumb();
                }
                thumb.pv = pageView;
                thumb.bmp = createBitmap;
                this.rl_data.add(thumb);
            }
        }
    }

    /* access modifiers changed from: private */
    public synchronized void proceedCreateThumb(PageView pageView) {
        if (pageView == null) {
            this.rl.clear();
            this.rl_flag[0] = true;
            this.rl_thread = null;
            for (int i = 0; i < this.rl_data.size(); i++) {
                Thumb thumb = (Thumb) this.rl_data.get(i);
                if (thumb.bmp != null && !thumb.pv.getGlobalVisibleRect(new Rect())) {
                    thumb.bmp.recycle();
                    thumb.bmp = null;
                }
            }
        } else {
            if (!this.rl.contains(pageView)) {
                this.rl.add(pageView);
                this.rl_flag[0] = true;
            }
            if (this.rl_thread == null || !this.rl_thread.isAlive()) {
                AnonymousClass40 r5 = new Thread() {
                    /* JADX WARNING: Code restructure failed: missing block: B:34:0x005c, code lost:
                        if (r1.getGlobalVisibleRect(new android.graphics.Rect()) == false) goto L_0x0063;
                     */
                    /* JADX WARNING: Code restructure failed: missing block: B:35:0x005e, code lost:
                        com.dynamixsoftware.printershare.ActivityPrint.access$1700(r4.this$0, r1);
                     */
                    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0063, code lost:
                        r4.this$0.runOnUiThread(new com.dynamixsoftware.printershare.ActivityPrint.AnonymousClass40.AnonymousClass1(r4));
                     */
                    public void run() {
                        boolean z;
                        while (true) {
                            try {
                                synchronized (ActivityPrint.this) {
                                    z = ActivityPrint.this.rl_flag[0];
                                    ActivityPrint.this.rl_flag[0] = false;
                                }
                                if (z) {
                                    Thread.sleep(250);
                                }
                                synchronized (ActivityPrint.this) {
                                    if (!ActivityPrint.this.rl_flag[0]) {
                                        if (ActivityPrint.this.rl.size() == 0) {
                                            synchronized (ActivityPrint.this) {
                                                ActivityPrint.this.rl_thread = null;
                                            }
                                            return;
                                        }
                                        final PageView pageView = (PageView) ActivityPrint.this.rl.remove(0);
                                    }
                                }
                            } catch (Throwable th) {
                                th.printStackTrace();
                                App.reportThrowable(th);
                            }
                        }
                    }
                };
                this.rl_thread = r5;
                r5.start();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void showPreview(Page page) {
        pp = page.getPicture();
        Intent intent = new Intent();
        intent.setClass(this, ActivityPreview.class);
        startActivityForResult(intent, 10);
    }

    /* access modifiers changed from: private */
    public void showPages() {
        if (this.pages != null) {
            final float f = getResources().getDisplayMetrics().density;
            final View findViewById = findViewById(R.id.page_preview_scroll);
            LinearLayout linearLayout = (LinearLayout) findViewById(R.id.page_preview_container);
            int i = 0;
            while (i < this.pages.size()) {
                PageView pageView = new PageView(this);
                pageView.setTag(Integer.valueOf(i));
                pageView.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        Page page = (Page) ActivityPrint.this.pages.get(((Integer) view.getTag()).intValue());
                        ActivityPrint.this.proceedCreateThumb(null);
                        App.freeMem();
                        ActivityPrint.this.showPreview(page);
                    }
                });
                CheckBox checkBox = new CheckBox(this);
                checkBox.setButtonDrawable(R.drawable.check);
                checkBox.setBackgroundColor(0);
                checkBox.setChecked(false);
                if (this.pages.size() == 1) {
                    checkBox.setVisibility(8);
                }
                checkBox.setTag(Integer.valueOf(i));
                checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                        if (z) {
                            ActivityPrint.this.sel_pages.add((Integer) compoundButton.getTag());
                        } else {
                            ActivityPrint.this.sel_pages.remove((Integer) compoundButton.getTag());
                        }
                        if (ActivityPrint.this.view_dialog_pages != null) {
                            RadioButton radioButton = (RadioButton) ActivityPrint.this.view_dialog_pages.findViewById(R.id.print_selected);
                            if (ActivityPrint.this.sel_pages.size() > 0) {
                                radioButton.setEnabled(true);
                                radioButton.setChecked(true);
                            }
                        }
                    }
                });
                TextView textView = new TextView(this);
                textView.setTextSize(1, 12.0f);
                textView.setTextColor(-14671840);
                StringBuilder sb = new StringBuilder();
                int i2 = i + 1;
                sb.append(String.valueOf(i2));
                sb.append(" / ");
                sb.append(this.pages.size());
                textView.setText(sb.toString());
                textView.setGravity(17);
                AnonymousClass43 r9 = new ViewGroup(this) {
                    /* access modifiers changed from: protected */
                    /* JADX WARNING: Code restructure failed: missing block: B:13:0x008f, code lost:
                        if (r7 == 0) goto L_0x00c1;
                     */
                    public void onMeasure(int i, int i2) {
                        int i3;
                        int i4;
                        boolean z = false;
                        View childAt = getChildAt(0);
                        View childAt2 = getChildAt(1);
                        View childAt3 = getChildAt(2);
                        childAt3.measure(MeasureSpec.makeMeasureSpec(0, 0), MeasureSpec.makeMeasureSpec(0, 0));
                        childAt2.measure(MeasureSpec.makeMeasureSpec(0, 0), MeasureSpec.makeMeasureSpec(0, 0));
                        int measuredWidth = findViewById.getMeasuredWidth() - ((int) (f * 30.0f));
                        int size = MeasureSpec.getSize(i2) - childAt3.getMeasuredHeight();
                        if (measuredWidth <= 0 || measuredWidth >= size) {
                            measuredWidth = size;
                        }
                        if (!(ActivityPrint.this.pages == null || childAt == null)) {
                            z = ((Page) ActivityPrint.this.pages.get(((Integer) childAt.getTag()).intValue())).landscape;
                        }
                        if (!z) {
                            if (ActivityPrint.this.paper.width > ActivityPrint.this.paper.height) {
                                i4 = (ActivityPrint.this.paper.height * measuredWidth) / ActivityPrint.this.paper.width;
                            } else {
                                i4 = (ActivityPrint.this.paper.width * measuredWidth) / ActivityPrint.this.paper.height;
                            }
                            if (i4 != 0) {
                                int i5 = measuredWidth;
                                measuredWidth = i4;
                                i3 = i5;
                                childAt.measure(MeasureSpec.makeMeasureSpec(measuredWidth, SmbConstants.CAP_EXTENDED_SECURITY), MeasureSpec.makeMeasureSpec(i3, SmbConstants.CAP_EXTENDED_SECURITY));
                                setMeasuredDimension(measuredWidth, i2);
                            }
                        } else if (ActivityPrint.this.paper.width > ActivityPrint.this.paper.height) {
                            i3 = (ActivityPrint.this.paper.height * measuredWidth) / ActivityPrint.this.paper.width;
                        } else {
                            i3 = (ActivityPrint.this.paper.width * measuredWidth) / ActivityPrint.this.paper.height;
                        }
                        i3 = measuredWidth;
                        childAt.measure(MeasureSpec.makeMeasureSpec(measuredWidth, SmbConstants.CAP_EXTENDED_SECURITY), MeasureSpec.makeMeasureSpec(i3, SmbConstants.CAP_EXTENDED_SECURITY));
                        setMeasuredDimension(measuredWidth, i2);
                    }

                    /* access modifiers changed from: protected */
                    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
                        View childAt = getChildAt(0);
                        View childAt2 = getChildAt(1);
                        View childAt3 = getChildAt(2);
                        childAt.layout(0, 0, childAt.getMeasuredWidth(), childAt.getMeasuredHeight());
                        childAt2.layout(0, childAt.getMeasuredHeight() - childAt2.getMeasuredHeight(), childAt2.getMeasuredWidth(), childAt.getMeasuredHeight());
                        int measuredWidth = ((i3 - i) - childAt3.getMeasuredWidth()) / 2;
                        childAt3.layout(measuredWidth, childAt.getMeasuredHeight(), childAt3.getMeasuredWidth() + measuredWidth, childAt.getMeasuredHeight() + childAt3.getMeasuredHeight());
                    }
                };
                r9.addView(pageView, new LayoutParams(-1, -1));
                r9.addView(checkBox, new LayoutParams(-2, -2));
                r9.addView(textView, new LayoutParams(-2, -2));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
                if (i != this.pages.size() - 1) {
                    layoutParams.setMargins(0, 0, (int) (15.0f * f), 0);
                }
                linearLayout.addView(r9, layoutParams);
                i = i2;
            }
        }
    }

    private void recyclePages() {
        ((LinearLayout) findViewById(R.id.page_preview_container)).removeAllViews();
        proceedCreateThumb(null);
        synchronized (this) {
            for (int i = 0; i < this.rl_data.size(); i++) {
                Thumb thumb = (Thumb) this.rl_data.get(i);
                if (thumb.bmp != null) {
                    thumb.bmp.recycle();
                    thumb.bmp = null;
                }
            }
            this.rl_data.clear();
        }
        Vector<Page> vector = this.pages;
        if (vector != null) {
            vector.removeAllElements();
        }
        this.pages = null;
        this.sel_pages.clear();
        App.freeMem();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && (i == 1 || i == 2)) {
            if (this.pages != null) {
                this.need_update_pages = true;
            }
            initPrinterParams();
        }
        super.onActivityResult(i, i2, intent);
    }
}
