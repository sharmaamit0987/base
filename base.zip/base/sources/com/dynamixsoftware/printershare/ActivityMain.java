package com.dynamixsoftware.printershare;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import com.flurry.android.FlurryConfig;

public class ActivityMain extends ActivityBase {
    private static int adc;
    /* access modifiers changed from: private */
    public AlertDialog ad_alert;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.main);
        setTitle((int) R.string.app_name);
        findViewById(R.id.select_button).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivityMain.this.printers_menu.show();
            }
        });
        findViewById(R.id.print_pictures).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityPrintPictures.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        ((ImageButton) findViewById(R.id.print_web_pages)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityWeb.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        ((ImageButton) findViewById(R.id.print_contacts)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityContacts.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        ((ImageButton) findViewById(R.id.print_calendar)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityCalendar.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        ImageButton imageButton = (ImageButton) findViewById(R.id.print_call_log);
        imageButton.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://printershare.com/sms-permissions.aspx"));
                if (ActivityMain.this.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                    ActivityMain.this.startActivity(intent);
                } else {
                    ActivityMain.this.startActivity(Intent.createChooser(intent, null));
                }
            }
        });
        if (!App.has_feature_call_log) {
            imageButton.setEnabled(false);
        }
        ImageButton imageButton2 = (ImageButton) findViewById(R.id.print_messages);
        imageButton2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://printershare.com/sms-permissions.aspx"));
                if (ActivityMain.this.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                    ActivityMain.this.startActivity(intent);
                } else {
                    ActivityMain.this.startActivity(Intent.createChooser(intent, null));
                }
            }
        });
        if (!App.has_feature_messages) {
            imageButton2.setEnabled(false);
        }
        ImageButton imageButton3 = (ImageButton) findViewById(R.id.print_gmail);
        imageButton3.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityGmail.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        if (!App.has_feature_gls) {
            imageButton3.setEnabled(false);
        }
        ImageButton imageButton4 = (ImageButton) findViewById(R.id.print_gdocs);
        imageButton4.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityGDocsBrowser.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        if (!App.has_feature_gls) {
            imageButton4.setEnabled(false);
        }
        ((ImageButton) findViewById(R.id.print_docs)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(ActivityMain.this, ActivityDocsBrowser.class);
                ActivityMain.this.startActivity(intent);
            }
        });
        View findViewById = findViewById(R.id.upgrade_banner);
        if (findViewById != null) {
            findViewById.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Billing.showUpgradeDialog(ActivityMain.this);
                }
            });
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 111, 0, R.string.menu_help).setIcon(17301568);
        menu.add(0, 222, 0, R.string.button_send_feedback).setIcon(17301584);
        menu.add(0, 333, 0, R.string.button_print_test_page).setIcon(17301569);
        menu.add(0, 444, 0, R.string.menu_about).setIcon(17301569);
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 111) {
            Intent intent = new Intent();
            intent.setClass(this, ActivityHelp.class);
            startActivity(intent);
            return true;
        } else if (itemId == 222) {
            sendFeedback();
            return true;
        } else if (itemId == 333) {
            Intent intent2 = new Intent();
            intent2.setClass(this, ActivityPrintTestPage.class);
            startActivity(intent2);
            return true;
        } else if (itemId != 444) {
            return super.onMenuItemSelected(i, menuItem);
        } else {
            Intent intent3 = new Intent();
            intent3.setClass(this, ActivityAbout.class);
            startActivity(intent3);
            return true;
        }
    }

    /* access modifiers changed from: protected */
    public void update() {
        super.update();
        StringBuilder sb = new StringBuilder();
        sb.append(getResources().getString(R.string.app_name));
        sb.append(getTitleSuffix());
        setTitle((CharSequence) sb.toString());
        Billing.action.run(new Runnable() {
            public void run() {
                ActivityMain.this.findViewById(R.id.upgrade_banner).setVisibility(0);
            }
        }, new Runnable() {
            public void run() {
                ActivityMain.this.findViewById(R.id.upgrade_banner).setVisibility(8);
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (remote_token != null) {
            int i = adc;
            adc = i + 1;
            if (i == 1) {
                Billing.action.run(new Runnable() {
                    public void run() {
                        try {
                            String string = FlurryConfig.getInstance().getString("ad_enabled", "0");
                            final String string2 = FlurryConfig.getInstance().getString("ad_url", null);
                            if ("1".equals(string) && string2 != null && string2.length() > 0) {
                                SharedPreferences sharedPreferences = ActivityMain.this.prefs;
                                StringBuilder sb = new StringBuilder();
                                sb.append("ad_");
                                sb.append(string2.hashCode());
                                if (sharedPreferences.getInt(sb.toString(), 0) < 3) {
                                    ActivityMain.this.ad_alert = new Builder(ActivityMain.this).create();
                                    WebView webView = new WebView(ActivityMain.this);
                                    webView.getSettings().setJavaScriptEnabled(true);
                                    webView.getSettings().setBlockNetworkImage(false);
                                    webView.getSettings().setLoadsImagesAutomatically(true);
                                    webView.getSettings().setSupportMultipleWindows(false);
                                    webView.getSettings().setBuiltInZoomControls(false);
                                    webView.getSettings().setSupportZoom(false);
                                    webView.setWebViewClient(new WebViewClient() {
                                        boolean error;
                                        boolean showed;

                                        public void onPageFinished(WebView webView, String str) {
                                            String str2 = "ad_";
                                            try {
                                                if (!this.showed && !this.error) {
                                                    ActivityMain.this.ad_alert.show();
                                                    this.showed = true;
                                                    Editor edit = ActivityMain.this.prefs.edit();
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append(str2);
                                                    sb.append(string2.hashCode());
                                                    String sb2 = sb.toString();
                                                    SharedPreferences sharedPreferences = ActivityMain.this.prefs;
                                                    StringBuilder sb3 = new StringBuilder();
                                                    sb3.append(str2);
                                                    sb3.append(string2.hashCode());
                                                    edit.putInt(sb2, sharedPreferences.getInt(sb3.toString(), 0) + 1);
                                                    edit.apply();
                                                }
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                App.reportThrowable(e);
                                            }
                                        }

                                        public void onReceivedError(WebView webView, int i, String str, String str2) {
                                            this.error = true;
                                        }

                                        /* JADX WARNING: Removed duplicated region for block: B:24:0x0070 A[SYNTHETIC, Splitter:B:24:0x0070] */
                                        /* JADX WARNING: Removed duplicated region for block: B:29:0x00a2 A[SYNTHETIC, Splitter:B:29:0x00a2] */
                                        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                                            boolean z;
                                            boolean z2;
                                            boolean z3;
                                            Exception e;
                                            if (this.showed) {
                                                boolean z4 = false;
                                                try {
                                                    if (!str.startsWith("close:")) {
                                                        if (!str.startsWith("disable:")) {
                                                            if (str.startsWith("http")) {
                                                                try {
                                                                    Intent intent = new Intent("android.intent.action.VIEW");
                                                                    intent.addCategory("android.intent.category.BROWSABLE");
                                                                    intent.setData(Uri.parse(str));
                                                                    if (ActivityMain.this.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                                                                        ActivityMain.this.startActivity(intent);
                                                                    } else {
                                                                        ActivityMain.this.startActivity(Intent.createChooser(intent, null));
                                                                    }
                                                                } catch (Exception e2) {
                                                                    e = e2;
                                                                    z3 = true;
                                                                    z2 = true;
                                                                    e.printStackTrace();
                                                                    App.reportThrowable(e);
                                                                    z4 = z3;
                                                                    z = z2;
                                                                    if (z4) {
                                                                    }
                                                                    if (z) {
                                                                    }
                                                                    return super.shouldOverrideUrlLoading(webView, str);
                                                                }
                                                            } else {
                                                                z = false;
                                                                if (z4) {
                                                                    try {
                                                                        Editor edit = ActivityMain.this.prefs.edit();
                                                                        StringBuilder sb = new StringBuilder();
                                                                        sb.append("ad_");
                                                                        sb.append(string2.hashCode());
                                                                        edit.putInt(sb.toString(), 5);
                                                                        edit.apply();
                                                                    } catch (Exception e3) {
                                                                        e3.printStackTrace();
                                                                        App.reportThrowable(e3);
                                                                    }
                                                                }
                                                                if (z) {
                                                                    try {
                                                                        ActivityMain.this.ad_alert.dismiss();
                                                                    } catch (Exception e4) {
                                                                        e4.printStackTrace();
                                                                        App.reportThrowable(e4);
                                                                    }
                                                                    return true;
                                                                }
                                                            }
                                                        }
                                                        z4 = true;
                                                    }
                                                    z = true;
                                                } catch (Exception e5) {
                                                    e = e5;
                                                    z3 = false;
                                                    z2 = false;
                                                    e.printStackTrace();
                                                    App.reportThrowable(e);
                                                    z4 = z3;
                                                    z = z2;
                                                    if (z4) {
                                                    }
                                                    if (z) {
                                                    }
                                                    return super.shouldOverrideUrlLoading(webView, str);
                                                }
                                                if (z4) {
                                                }
                                                if (z) {
                                                }
                                            }
                                            return super.shouldOverrideUrlLoading(webView, str);
                                        }
                                    });
                                    webView.loadUrl(string2);
                                    ActivityMain.this.ad_alert.setView(webView);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    }
                }, null);
            }
        }
    }
}
