package com.dynamixsoftware.printershare;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.provider.CallLog.Calls;
import android.widget.Toast;

public class ActivityPrintCallLog extends ActivityPrintText {
    private Impl impl = Impl.getImpl();
    Bitmap itp;
    Bitmap mtp;
    Bitmap otp;

    /* access modifiers changed from: protected */
    public void createPages() {
        if (checkPermission("android.permission.READ_CALL_LOG")) {
            initPage();
            Cursor query = getContentResolver().query(Calls.CONTENT_URI, new String[]{"number", "date", "type", "duration", "name", "numberlabel", "numbertype"}, null, null, "date DESC");
            int i = -1;
            int i2 = -1;
            while (true) {
                if (i2 < 0 || (query != null && query.moveToNext())) {
                    newPage();
                    if (i2 != i) {
                        String string = query.getString(0);
                        if (string == null || "-1".equals(string)) {
                            string = "(unknown)";
                        }
                        if ("-2".equals(string)) {
                            string = "(private)";
                        }
                        if ("-3".equals(string)) {
                            string = "(payphone)";
                        }
                        String str = string;
                        long j = query.getLong(1);
                        int i3 = query.getInt(2);
                        int i4 = query.getInt(3);
                        String string2 = query.getString(4);
                        Bitmap bitmap = null;
                        if (i3 == 1) {
                            if (this.itp == null) {
                                this.itp = BitmapFactory.decodeResource(getResources(), R.drawable.call_log_incoming_call);
                            }
                            bitmap = this.itp;
                        } else if (i3 == 2) {
                            if (this.otp == null) {
                                this.otp = BitmapFactory.decodeResource(getResources(), R.drawable.call_log_outgoing_call);
                            }
                            bitmap = this.otp;
                        } else if (i3 == 3) {
                            if (this.mtp == null) {
                                this.mtp = BitmapFactory.decodeResource(getResources(), R.drawable.call_log_missed_call);
                            }
                            bitmap = this.mtp;
                        }
                        if (needNew(20, 210)) {
                            query.moveToPrevious();
                        } else {
                            Paint newPaint = App.newPaint();
                            if (bitmap != null) {
                                this.canvas.drawBitmap(bitmap, new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()), new Rect(0, 0, (int) (this.fontSizeCoef * 50.0f), (int) (this.fontSizeCoef * 50.0f)), newPaint);
                            }
                            Paint newPaint2 = App.newPaint();
                            newPaint2.setStyle(Style.FILL);
                            newPaint2.setColor(-16777216);
                            int i5 = i3;
                            long j2 = j;
                            printText(string2 != null ? string2 : str, 70, false, 0.0f, 75, 45, 70, newPaint2);
                            if (string2 != null) {
                                StringBuilder sb = new StringBuilder();
                                sb.append(this.impl.getPhoneTypeLabel(this, query.getInt(6), query.getString(5)).toString().trim());
                                sb.append(" ");
                                sb.append(str);
                                printText(sb.toString().trim(), 45, false, 0.0f, 75, 25, 45, newPaint2);
                            }
                            printText(App.formatTimeStampString(this, j2, true), 40, false, 0.0f, 75, 25, 45, newPaint2);
                            if (i5 != 3) {
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append(i4 / 60);
                                sb2.append(" mins ");
                                sb2.append(i4 % 60);
                                sb2.append(" secs");
                                printText(sb2.toString(), 40, false, 0.0f, 75, 25, 45, newPaint2);
                            }
                        }
                    }
                    i2++;
                    i = -1;
                }
            }
            addPage();
            if (query != null) {
                query.close();
            }
            if (i2 == 0) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(ActivityPrintCallLog.this, R.string.toast_empty_call_log, 1).show();
                    }
                });
            }
        }
    }
}
