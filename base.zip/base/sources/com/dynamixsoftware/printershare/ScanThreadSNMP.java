package com.dynamixsoftware.printershare;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.App.NetworkInterfaceData;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.snmp.SNMPBERCodec;
import com.dynamixsoftware.printershare.snmp.SNMPMessage;
import com.dynamixsoftware.printershare.snmp.SNMPNull;
import com.dynamixsoftware.printershare.snmp.SNMPObjectIdentifier;
import com.dynamixsoftware.printershare.snmp.SNMPPDU;
import com.dynamixsoftware.printershare.snmp.SNMPSequence;
import com.dynamixsoftware.printershare.snmp.SNMPVariablePair;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

public class ScanThreadSNMP extends Thread {
    /* access modifiers changed from: private */
    public boolean[] destroyed = new boolean[1];
    /* access modifiers changed from: private */
    public List<DatagramPacket> packets = new ArrayList();
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    private int[] rid = new int[1];
    /* access modifiers changed from: private */
    public String rq_pid;
    private Thread sender = new Thread() {
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0023, code lost:
            r4 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x002e, code lost:
            if (r4 >= com.dynamixsoftware.printershare.ScanThreadSNMP.access$800(r11.this$0).size()) goto L_0x00a4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0030, code lost:
            r5 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r11.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0036, code lost:
            monitor-enter(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x003f, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r11.this$0)[0] == false) goto L_0x0043;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0041, code lost:
            monitor-exit(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0042, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0043, code lost:
            monitor-exit(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
            r5 = (com.dynamixsoftware.printershare.ScanThreadSNMP.SocketThread) com.dynamixsoftware.printershare.ScanThreadSNMP.access$800(r11.this$0).get(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0052, code lost:
            if (r5.ia == null) goto L_0x0066;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x0054, code lost:
            r5.send(com.dynamixsoftware.printershare.ScanThreadSNMP.access$1000(r11.this$0, r1, com.dynamixsoftware.printershare.ScanThreadSNMP.access$900(r11.this$0), "1.3.6.1.2.1.1.5.0"));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0066, code lost:
            r6 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x006b, code lost:
            if (r6 >= r0.size()) goto L_0x009e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x006d, code lost:
            r7 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r11.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x0073, code lost:
            monitor-enter(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x007c, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r11.this$0)[0] == false) goto L_0x0080;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x007e, code lost:
            monitor-exit(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x007f, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x0080, code lost:
            monitor-exit(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
            r5.send(com.dynamixsoftware.printershare.ScanThreadSNMP.access$1000(r11.this$0, (java.net.InetAddress) r0.get(r6), com.dynamixsoftware.printershare.ScanThreadSNMP.access$900(r11.this$0), "1.3.6.1.2.1.1.5.0"));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x0098, code lost:
            r6 = r6 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x009e, code lost:
            r4 = r4 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:?, code lost:
            java.lang.Thread.sleep(1000);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x00a9, code lost:
            r3 = r3 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x00ad, code lost:
            return;
         */
        public void run() {
            try {
                Vector broadcastAdrresses = App.getBroadcastAdrresses();
                InetAddress byName = InetAddress.getByName("FF02::1");
                int i = 0;
                while (i < 3) {
                    synchronized (ScanThreadSNMP.this.destroyed) {
                        if (ScanThreadSNMP.this.destroyed[0]) {
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
    };
    /* access modifiers changed from: private */
    public ArrayList<SocketThread> sockets = new ArrayList<>();
    /* access modifiers changed from: private */
    public Handler status;
    /* access modifiers changed from: private */
    public int timeout;
    private ArrayList<DetectThread> workers = new ArrayList<>();

    class DetectThread extends Thread {
        DatagramPacket packet;
        DatagramSocket socket;

        DetectThread(DatagramPacket datagramPacket) {
            this.packet = datagramPacket;
        }

        /* JADX WARNING: type inference failed for: r4v3, types: [java.lang.String[]] */
        /* JADX WARNING: type inference failed for: r6v1 */
        /* JADX WARNING: type inference failed for: r4v4, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v5, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v11, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r15v0, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r14v1, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r11v3, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r10v1, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v7, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r5v2, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r12v9, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v12, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v13 */
        /* JADX WARNING: type inference failed for: r7v8, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v9, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r5v5, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v10, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v6, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r21v0 */
        /* JADX WARNING: type inference failed for: r4v14 */
        /* JADX WARNING: type inference failed for: r4v15, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v29, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v30 */
        /* JADX WARNING: type inference failed for: r6v37, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v11 */
        /* JADX WARNING: type inference failed for: r7v12 */
        /* JADX WARNING: type inference failed for: r7v13, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v14, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v15 */
        /* JADX WARNING: type inference failed for: r15v1 */
        /* JADX WARNING: type inference failed for: r14v2 */
        /* JADX WARNING: type inference failed for: r12v10, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r11v4 */
        /* JADX WARNING: type inference failed for: r10v2 */
        /* JADX WARNING: type inference failed for: r7v16 */
        /* JADX WARNING: type inference failed for: r6v44 */
        /* JADX WARNING: type inference failed for: r21v1 */
        /* JADX WARNING: type inference failed for: r5v15, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r12v11, types: [java.lang.Object, java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v46 */
        /* JADX WARNING: type inference failed for: r21v2 */
        /* JADX WARNING: type inference failed for: r22v6 */
        /* JADX WARNING: type inference failed for: r15v2, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r14v3, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r11v5 */
        /* JADX WARNING: type inference failed for: r10v4 */
        /* JADX WARNING: type inference failed for: r7v20 */
        /* JADX WARNING: type inference failed for: r6v47, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r21v3 */
        /* JADX WARNING: type inference failed for: r6v48, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v21, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v49, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r22v7 */
        /* JADX WARNING: type inference failed for: r23v1 */
        /* JADX WARNING: type inference failed for: r23v2 */
        /* JADX WARNING: type inference failed for: r22v8 */
        /* JADX WARNING: type inference failed for: r15v3 */
        /* JADX WARNING: type inference failed for: r14v4 */
        /* JADX WARNING: type inference failed for: r5v16, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r5v17 */
        /* JADX WARNING: type inference failed for: r13v34 */
        /* JADX WARNING: type inference failed for: r11v7 */
        /* JADX WARNING: type inference failed for: r10v9 */
        /* JADX WARNING: type inference failed for: r7v22 */
        /* JADX WARNING: type inference failed for: r25v0 */
        /* JADX WARNING: type inference failed for: r23v3 */
        /* JADX WARNING: type inference failed for: r15v6 */
        /* JADX WARNING: type inference failed for: r14v5 */
        /* JADX WARNING: type inference failed for: r13v39 */
        /* JADX WARNING: type inference failed for: r5v19 */
        /* JADX WARNING: type inference failed for: r22v9 */
        /* JADX WARNING: type inference failed for: r5v20 */
        /* JADX WARNING: type inference failed for: r23v4 */
        /* JADX WARNING: type inference failed for: r15v7 */
        /* JADX WARNING: type inference failed for: r14v6 */
        /* JADX WARNING: type inference failed for: r13v40 */
        /* JADX WARNING: type inference failed for: r23v5 */
        /* JADX WARNING: type inference failed for: r5v21 */
        /* JADX WARNING: type inference failed for: r13v41 */
        /* JADX WARNING: type inference failed for: r15v8 */
        /* JADX WARNING: type inference failed for: r26v0 */
        /* JADX WARNING: type inference failed for: r8v33, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r14v14 */
        /* JADX WARNING: type inference failed for: r15v14 */
        /* JADX WARNING: type inference failed for: r13v53 */
        /* JADX WARNING: type inference failed for: r23v6 */
        /* JADX WARNING: type inference failed for: r5v22 */
        /* JADX WARNING: type inference failed for: r23v7 */
        /* JADX WARNING: type inference failed for: r5v23 */
        /* JADX WARNING: type inference failed for: r23v8 */
        /* JADX WARNING: type inference failed for: r5v24, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r13v54 */
        /* JADX WARNING: type inference failed for: r13v55, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r15v15 */
        /* JADX WARNING: type inference failed for: r15v16, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r14v15 */
        /* JADX WARNING: type inference failed for: r14v16, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r8v40, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r8v41 */
        /* JADX WARNING: type inference failed for: r13v56 */
        /* JADX WARNING: type inference failed for: r15v17 */
        /* JADX WARNING: type inference failed for: r14v17 */
        /* JADX WARNING: type inference failed for: r6v50, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v51 */
        /* JADX WARNING: type inference failed for: r21v4 */
        /* JADX WARNING: type inference failed for: r6v52, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r21v5 */
        /* JADX WARNING: type inference failed for: r21v6 */
        /* JADX WARNING: type inference failed for: r6v54, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v55 */
        /* JADX WARNING: type inference failed for: r7v26 */
        /* JADX WARNING: type inference failed for: r10v11 */
        /* JADX WARNING: type inference failed for: r10v12 */
        /* JADX WARNING: type inference failed for: r21v7 */
        /* JADX WARNING: type inference failed for: r15v20 */
        /* JADX WARNING: type inference failed for: r14v35 */
        /* JADX WARNING: type inference failed for: r11v30 */
        /* JADX WARNING: type inference failed for: r10v13 */
        /* JADX WARNING: type inference failed for: r22v11 */
        /* JADX WARNING: type inference failed for: r24v1 */
        /* JADX WARNING: type inference failed for: r7v29 */
        /* JADX WARNING: type inference failed for: r7v31, types: [java.lang.String[]] */
        /* JADX WARNING: type inference failed for: r22v12 */
        /* JADX WARNING: type inference failed for: r21v8 */
        /* JADX WARNING: type inference failed for: r15v21 */
        /* JADX WARNING: type inference failed for: r14v36 */
        /* JADX WARNING: type inference failed for: r11v31 */
        /* JADX WARNING: type inference failed for: r10v15 */
        /* JADX WARNING: type inference failed for: r24v2 */
        /* JADX WARNING: type inference failed for: r21v9 */
        /* JADX WARNING: type inference failed for: r15v22 */
        /* JADX WARNING: type inference failed for: r14v37 */
        /* JADX WARNING: type inference failed for: r10v16 */
        /* JADX WARNING: type inference failed for: r11v32 */
        /* JADX WARNING: type inference failed for: r24v3 */
        /* JADX WARNING: type inference failed for: r21v10 */
        /* JADX WARNING: type inference failed for: r15v23 */
        /* JADX WARNING: type inference failed for: r14v38 */
        /* JADX WARNING: type inference failed for: r10v17 */
        /* JADX WARNING: type inference failed for: r24v4 */
        /* JADX WARNING: type inference failed for: r11v33, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v33 */
        /* JADX WARNING: type inference failed for: r14v39 */
        /* JADX WARNING: type inference failed for: r11v34, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v35, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v36, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v34 */
        /* JADX WARNING: type inference failed for: r15v24 */
        /* JADX WARNING: type inference failed for: r11v37, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v38, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v35 */
        /* JADX WARNING: type inference failed for: r10v33 */
        /* JADX WARNING: type inference failed for: r11v39, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v40, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v36 */
        /* JADX WARNING: type inference failed for: r21v11 */
        /* JADX WARNING: type inference failed for: r11v41, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v42, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v37 */
        /* JADX WARNING: type inference failed for: r11v43 */
        /* JADX WARNING: type inference failed for: r10v44 */
        /* JADX WARNING: type inference failed for: r24v5 */
        /* JADX WARNING: type inference failed for: r12v12 */
        /* JADX WARNING: type inference failed for: r6v56 */
        /* JADX WARNING: type inference failed for: r6v62 */
        /* JADX WARNING: type inference failed for: r12v13 */
        /* JADX WARNING: type inference failed for: r6v64, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v65, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v66, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v67, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v68, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v69, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v70, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v71, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r5v47, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v72 */
        /* JADX WARNING: type inference failed for: r6v73, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v74, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v75, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v76, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r6v77, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r20v0 */
        /* JADX WARNING: type inference failed for: r6v78 */
        /* JADX WARNING: type inference failed for: r20v1 */
        /* JADX WARNING: type inference failed for: r5v54 */
        /* JADX WARNING: type inference failed for: r20v2 */
        /* JADX WARNING: type inference failed for: r6v82, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r20v3 */
        /* JADX WARNING: type inference failed for: r20v4 */
        /* JADX WARNING: type inference failed for: r5v63 */
        /* JADX WARNING: type inference failed for: r12v14 */
        /* JADX WARNING: type inference failed for: r12v15, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r7v38 */
        /* JADX WARNING: type inference failed for: r10v45 */
        /* JADX WARNING: type inference failed for: r11v44 */
        /* JADX WARNING: type inference failed for: r14v40 */
        /* JADX WARNING: type inference failed for: r15v25 */
        /* JADX WARNING: type inference failed for: r14v41 */
        /* JADX WARNING: type inference failed for: r15v26 */
        /* JADX WARNING: type inference failed for: r16v0 */
        /* JADX WARNING: type inference failed for: r17v3 */
        /* JADX WARNING: type inference failed for: r18v0 */
        /* JADX WARNING: type inference failed for: r18v1 */
        /* JADX WARNING: type inference failed for: r17v4 */
        /* JADX WARNING: type inference failed for: r16v1 */
        /* JADX WARNING: type inference failed for: r15v27 */
        /* JADX WARNING: type inference failed for: r14v42 */
        /* JADX WARNING: type inference failed for: r7v39 */
        /* JADX WARNING: type inference failed for: r10v47 */
        /* JADX WARNING: type inference failed for: r11v46 */
        /* JADX WARNING: type inference failed for: r7v41, types: [java.lang.String[]] */
        /* JADX WARNING: type inference failed for: r18v2 */
        /* JADX WARNING: type inference failed for: r17v5 */
        /* JADX WARNING: type inference failed for: r16v2 */
        /* JADX WARNING: type inference failed for: r15v28 */
        /* JADX WARNING: type inference failed for: r14v43 */
        /* JADX WARNING: type inference failed for: r11v48, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r14v44 */
        /* JADX WARNING: type inference failed for: r11v49, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v50, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v51, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r15v29 */
        /* JADX WARNING: type inference failed for: r11v52, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v53, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r17v6 */
        /* JADX WARNING: type inference failed for: r11v54, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v55, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r16v3 */
        /* JADX WARNING: type inference failed for: r11v56, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r11v57, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r18v3 */
        /* JADX WARNING: type inference failed for: r4v49, types: [java.lang.String] */
        /* JADX WARNING: type inference failed for: r4v51 */
        /* JADX WARNING: type inference failed for: r6v97 */
        /* JADX WARNING: type inference failed for: r15v30 */
        /* JADX WARNING: type inference failed for: r14v46 */
        /* JADX WARNING: type inference failed for: r11v58 */
        /* JADX WARNING: type inference failed for: r10v70 */
        /* JADX WARNING: type inference failed for: r7v42 */
        /* JADX WARNING: type inference failed for: r7v43 */
        /* JADX WARNING: type inference failed for: r5v64 */
        /* JADX WARNING: type inference failed for: r12v50 */
        /* JADX WARNING: type inference failed for: r6v98 */
        /* JADX WARNING: type inference failed for: r4v52 */
        /* JADX WARNING: type inference failed for: r7v44 */
        /* JADX WARNING: type inference failed for: r7v45 */
        /* JADX WARNING: type inference failed for: r15v31 */
        /* JADX WARNING: type inference failed for: r15v32 */
        /* JADX WARNING: type inference failed for: r14v47 */
        /* JADX WARNING: type inference failed for: r14v48 */
        /* JADX WARNING: type inference failed for: r11v59 */
        /* JADX WARNING: type inference failed for: r11v60 */
        /* JADX WARNING: type inference failed for: r5v65 */
        /* JADX WARNING: type inference failed for: r12v51 */
        /* JADX WARNING: type inference failed for: r21v12 */
        /* JADX WARNING: type inference failed for: r15v33 */
        /* JADX WARNING: type inference failed for: r14v49 */
        /* JADX WARNING: type inference failed for: r6v99 */
        /* JADX WARNING: type inference failed for: r6v100 */
        /* JADX WARNING: type inference failed for: r15v34 */
        /* JADX WARNING: type inference failed for: r14v50 */
        /* JADX WARNING: type inference failed for: r14v51 */
        /* JADX WARNING: type inference failed for: r15v35 */
        /* JADX WARNING: type inference failed for: r14v52 */
        /* JADX WARNING: type inference failed for: r15v36 */
        /* JADX WARNING: type inference failed for: r14v53 */
        /* JADX WARNING: type inference failed for: r13v106 */
        /* JADX WARNING: type inference failed for: r14v54 */
        /* JADX WARNING: type inference failed for: r14v55 */
        /* JADX WARNING: type inference failed for: r14v56 */
        /* JADX WARNING: type inference failed for: r15v37 */
        /* JADX WARNING: type inference failed for: r15v38 */
        /* JADX WARNING: type inference failed for: r15v39 */
        /* JADX WARNING: type inference failed for: r13v107 */
        /* JADX WARNING: type inference failed for: r13v108 */
        /* JADX WARNING: type inference failed for: r13v109 */
        /* JADX WARNING: type inference failed for: r23v10 */
        /* JADX WARNING: type inference failed for: r23v11 */
        /* JADX WARNING: type inference failed for: r23v12 */
        /* JADX WARNING: type inference failed for: r5v66 */
        /* JADX WARNING: type inference failed for: r5v67 */
        /* JADX WARNING: type inference failed for: r5v68 */
        /* JADX WARNING: type inference failed for: r5v69 */
        /* JADX WARNING: type inference failed for: r13v110 */
        /* JADX WARNING: type inference failed for: r15v40 */
        /* JADX WARNING: type inference failed for: r14v57 */
        /* JADX WARNING: type inference failed for: r8v87 */
        /* JADX WARNING: type inference failed for: r6v101 */
        /* JADX WARNING: type inference failed for: r6v102 */
        /* JADX WARNING: type inference failed for: r6v103 */
        /* JADX WARNING: type inference failed for: r21v13 */
        /* JADX WARNING: type inference failed for: r21v14 */
        /* JADX WARNING: type inference failed for: r21v15 */
        /* JADX WARNING: type inference failed for: r15v41 */
        /* JADX WARNING: type inference failed for: r15v42 */
        /* JADX WARNING: type inference failed for: r15v43 */
        /* JADX WARNING: type inference failed for: r15v44 */
        /* JADX WARNING: type inference failed for: r14v58 */
        /* JADX WARNING: type inference failed for: r14v59 */
        /* JADX WARNING: type inference failed for: r14v60 */
        /* JADX WARNING: type inference failed for: r14v61 */
        /* JADX WARNING: type inference failed for: r11v61 */
        /* JADX WARNING: type inference failed for: r10v71 */
        /* JADX WARNING: type inference failed for: r21v16 */
        /* JADX WARNING: type inference failed for: r15v45 */
        /* JADX WARNING: type inference failed for: r14v62 */
        /* JADX WARNING: type inference failed for: r11v62 */
        /* JADX WARNING: type inference failed for: r10v72 */
        /* JADX WARNING: type inference failed for: r21v17 */
        /* JADX WARNING: type inference failed for: r15v46 */
        /* JADX WARNING: type inference failed for: r14v63 */
        /* JADX WARNING: type inference failed for: r10v73 */
        /* JADX WARNING: type inference failed for: r24v6 */
        /* JADX WARNING: type inference failed for: r21v18 */
        /* JADX WARNING: type inference failed for: r15v47 */
        /* JADX WARNING: type inference failed for: r14v64 */
        /* JADX WARNING: type inference failed for: r24v7 */
        /* JADX WARNING: type inference failed for: r24v8 */
        /* JADX WARNING: type inference failed for: r24v9 */
        /* JADX WARNING: type inference failed for: r24v10 */
        /* JADX WARNING: type inference failed for: r12v52 */
        /* JADX WARNING: type inference failed for: r6v104 */
        /* JADX WARNING: type inference failed for: r6v105 */
        /* JADX WARNING: type inference failed for: r6v106 */
        /* JADX WARNING: type inference failed for: r6v107 */
        /* JADX WARNING: type inference failed for: r6v108 */
        /* JADX WARNING: type inference failed for: r6v109 */
        /* JADX WARNING: type inference failed for: r6v110 */
        /* JADX WARNING: type inference failed for: r20v5 */
        /* JADX WARNING: type inference failed for: r12v53 */
        /* JADX WARNING: type inference failed for: r7v46 */
        /* JADX WARNING: type inference failed for: r10v74 */
        /* JADX WARNING: type inference failed for: r11v63 */
        /* JADX WARNING: type inference failed for: r14v65 */
        /* JADX WARNING: type inference failed for: r15v48 */
        /* JADX WARNING: type inference failed for: r18v4 */
        /* JADX WARNING: type inference failed for: r18v5 */
        /* JADX WARNING: type inference failed for: r18v6 */
        /* JADX WARNING: type inference failed for: r18v7 */
        /* JADX WARNING: type inference failed for: r18v8 */
        /* JADX WARNING: type inference failed for: r18v9 */
        /* JADX WARNING: type inference failed for: r17v7 */
        /* JADX WARNING: type inference failed for: r17v8 */
        /* JADX WARNING: type inference failed for: r17v9 */
        /* JADX WARNING: type inference failed for: r17v10 */
        /* JADX WARNING: type inference failed for: r17v11 */
        /* JADX WARNING: type inference failed for: r17v12 */
        /* JADX WARNING: type inference failed for: r16v4 */
        /* JADX WARNING: type inference failed for: r16v5 */
        /* JADX WARNING: type inference failed for: r16v6 */
        /* JADX WARNING: type inference failed for: r16v7 */
        /* JADX WARNING: type inference failed for: r16v8 */
        /* JADX WARNING: type inference failed for: r16v9 */
        /* JADX WARNING: type inference failed for: r15v49 */
        /* JADX WARNING: type inference failed for: r15v50 */
        /* JADX WARNING: type inference failed for: r15v51 */
        /* JADX WARNING: type inference failed for: r15v52 */
        /* JADX WARNING: type inference failed for: r15v53 */
        /* JADX WARNING: type inference failed for: r15v54 */
        /* JADX WARNING: type inference failed for: r15v55 */
        /* JADX WARNING: type inference failed for: r14v66 */
        /* JADX WARNING: type inference failed for: r14v67 */
        /* JADX WARNING: type inference failed for: r14v68 */
        /* JADX WARNING: type inference failed for: r14v69 */
        /* JADX WARNING: type inference failed for: r14v70 */
        /* JADX WARNING: type inference failed for: r14v71 */
        /* JADX WARNING: type inference failed for: r14v72 */
        /* JADX WARNING: type inference failed for: r18v10 */
        /* JADX WARNING: type inference failed for: r17v13 */
        /* JADX WARNING: type inference failed for: r16v10 */
        /* JADX WARNING: type inference failed for: r15v56 */
        /* JADX WARNING: type inference failed for: r14v73 */
        /* JADX WARNING: type inference failed for: r14v74 */
        /* JADX WARNING: type inference failed for: r15v57 */
        /* JADX WARNING: type inference failed for: r17v14 */
        /* JADX WARNING: type inference failed for: r16v11 */
        /* JADX WARNING: type inference failed for: r18v11 */
        /* JADX WARNING: type inference failed for: r4v53 */
        /* JADX WARNING: Code restructure failed: missing block: B:101:0x023e, code lost:
            if (r9 >= r13.length) goto L_0x0254;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:103:0x0241, code lost:
            if (r9 >= r6.length) goto L_0x0254;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:104:0x0243, code lost:
            r20 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:105:0x024d, code lost:
            if (r13[r9].equals(r6[r9]) == false) goto L_0x0256;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:106:0x024f, code lost:
            r9 = r9 + 1;
            r5 = r20;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:107:0x0254, code lost:
            r20 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:109:0x0257, code lost:
            if (r9 <= 1) goto L_0x027e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:110:0x0259, code lost:
            r5 = "";
            r6 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:111:0x025c, code lost:
            if (r6 >= r9) goto L_0x0277;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:112:0x025e, code lost:
            r8 = new java.lang.StringBuilder();
            r8.append(r5);
            r8.append(" ");
            r8.append(r13[r6]);
            r5 = r8.toString();
            r6 = r6 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:113:0x0277, code lost:
            r6 = r5.trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:114:0x027c, code lost:
            r20 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:115:0x027e, code lost:
            r6 = r20;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:116:0x0280, code lost:
            if (r6 == 0) goto L_0x0321;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:117:0x0282, code lost:
            r5 = r6.indexOf("PID:");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:118:0x0288, code lost:
            if (r5 < 0) goto L_0x0294;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:119:0x028a, code lost:
            r6 = r6.substring(r5 + 4).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:120:0x0294, code lost:
            r5 = r6.indexOf(";");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:121:0x029a, code lost:
            if (r5 < 0) goto L_0x02a5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:122:0x029c, code lost:
            r6 = r6.substring(0, r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:123:0x02a5, code lost:
            r5 = r6.indexOf(",");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:124:0x02ab, code lost:
            if (r5 < 0) goto L_0x02b6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:125:0x02ad, code lost:
            r6 = r6.substring(0, r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:126:0x02b6, code lost:
            r5 = r6.toLowerCase().indexOf(" Rev.");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:127:0x02c0, code lost:
            if (r5 < 0) goto L_0x02cb;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:128:0x02c2, code lost:
            r6 = r6.substring(0, r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:129:0x02cb, code lost:
            r5 = r6.toLowerCase().indexOf(" version");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:130:0x02d5, code lost:
            if (r5 < 0) goto L_0x02e0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:131:0x02d7, code lost:
            r6 = r6.substring(0, r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:132:0x02e0, code lost:
            r5 = r6.toLowerCase().indexOf(" v ");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:133:0x02ea, code lost:
            if (r5 < 0) goto L_0x02f6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:134:0x02ec, code lost:
            r6 = r6.substring(0, r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:136:0x02fc, code lost:
            if (r6.startsWith("Eastman Kodak Company") == false) goto L_0x0321;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:137:0x02fe, code lost:
            r6 = r6.substring(21).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:138:0x030e, code lost:
            if (r6.startsWith("KODAK") != false) goto L_0x0321;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:139:0x0310, code lost:
            r5 = new java.lang.StringBuilder();
            r5.append("KODAK ");
            r5.append(r6);
            r6 = r5.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:140:0x0321, code lost:
            r5 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r1.this$0, r1.socket, r2, "1.3.6.1.4.1.2699.1.2.1.1.2.0");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:141:0x032b, code lost:
            if (r5 == null) goto L_0x092e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:143:?, code lost:
            r5 = java.lang.Integer.parseInt(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:144:0x0332, code lost:
            r5 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:155:0x034a, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:156:0x034c, code lost:
            if (r2 == null) goto L_0x0351;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:157:0x034e, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:158:0x0351, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:162:?, code lost:
            r8 = r1.this$0;
            r13 = r1.socket;
            r19 = r5;
            r5 = new java.lang.StringBuilder();
            r21 = r6;
            r5.append("1.3.6.1.4.1.2699.1.2.1.2.1.1.2.");
            r9 = r9 + 1;
            r5.append(r9);
            r5 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r8, r13, r2, r5.toString());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:163:0x0372, code lost:
            if (r5 == 0) goto L_0x0396;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:165:0x037a, code lost:
            if (r5.startsWith("Canon") == false) goto L_0x0386;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:167:0x0382, code lost:
            if (r5.length() != 11) goto L_0x0386;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:168:0x0384, code lost:
            r12 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0050, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:170:0x038a, code lost:
            if (r5.startsWith(r12) != false) goto L_0x0396;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:172:0x0392, code lost:
            if (r5.equalsIgnoreCase("TO BE DETERMINED") != false) goto L_0x0396;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:173:0x0394, code lost:
            r6 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:174:0x0396, code lost:
            r6 = r21;
            r12 = r12;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:175:0x0398, code lost:
            r8 = r1.this$0;
            r13 = r1.socket;
            r21 = r7;
            r7 = new java.lang.StringBuilder();
            r22 = r10;
            r7.append("1.3.6.1.4.1.2699.1.2.1.2.1.1.3.");
            r7.append(r9);
            r7 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r8, r13, r2, r7.toString());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:176:0x03b5, code lost:
            if (r7 == null) goto L_0x0471;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:177:0x03b7, code lost:
            r7 = r7.split(";");
            r10 = r22;
            r8 = 0;
            r15 = r15;
            r14 = r14;
            r11 = r11;
            r21 = r21;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:179:0x03c1, code lost:
            if (r8 >= r7.length) goto L_0x046a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0052, code lost:
            if (r2 == null) goto L_0x0057;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:180:0x03c3, code lost:
            r23 = r7;
            r7 = r7[r8].split(":");
            r22 = r10;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:181:0x03d1, code lost:
            if (r7.length >= 2) goto L_0x03d7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:182:0x03d3, code lost:
            r24 = r11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:183:0x03d7, code lost:
            r24 = r11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:184:0x03e2, code lost:
            if ("MFG".equals(r7[0]) != false) goto L_0x045f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:186:0x03ec, code lost:
            if ("MFR".equals(r7[0]) != false) goto L_0x045f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:188:0x03f6, code lost:
            if ("MANUFACTURER".equals(r7[0]) == false) goto L_0x03fa;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x0054, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:191:0x0402, code lost:
            if ("MDL".equals(r7[0]) != false) goto L_0x045a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:193:0x040c, code lost:
            if ("MODEL".equals(r7[0]) == false) goto L_0x040f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:196:0x0417, code lost:
            if ("CMD".equals(r7[0]) != false) goto L_0x0455;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:198:0x0421, code lost:
            if ("COMMAND SET".equals(r7[0]) == false) goto L_0x0424;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x0057, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:201:0x042c, code lost:
            if ("DES".equals(r7[0]) != false) goto L_0x044f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:203:0x0436, code lost:
            if ("DESCRIPTION".equals(r7[0]) == false) goto L_0x0439;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:206:0x0441, code lost:
            if ("URF".equals(r7[0]) == false) goto L_0x044a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:207:0x0443, code lost:
            r11 = r7[1];
            r10 = r22;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:208:0x044a, code lost:
            r10 = r22;
            r24 = r24;
            r21 = r21;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:209:0x044c, code lost:
            r11 = r24;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:210:0x044f, code lost:
            r21 = r7[1];
            r15 = r15;
            r14 = r14;
            r24 = r24;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:211:0x0455, code lost:
            r10 = r7[1];
            r21 = r21;
            r15 = r15;
            r14 = r14;
            r24 = r24;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:212:0x045a, code lost:
            r15 = r7[1];
            r21 = r21;
            r14 = r14;
            r24 = r24;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:213:0x045f, code lost:
            r14 = r7[1];
            r21 = r21;
            r15 = r15;
            r24 = r24;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:214:0x0464, code lost:
            r8 = r8 + 1;
            r7 = r23;
            r21 = r21;
            r15 = r15;
            r14 = r14;
            r11 = r11;
            r10 = r10;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:215:0x046a, code lost:
            r22 = r10;
            r24 = r11;
            r7 = r21;
            r15 = r15;
            r14 = r14;
            r11 = r11;
            r10 = r10;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:216:0x0471, code lost:
            r7 = r21;
            r10 = r22;
            r15 = r15;
            r14 = r14;
            r11 = r11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:217:0x0475, code lost:
            if (r6 != 0) goto L_0x0478;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:218:0x0477, code lost:
            r6 = r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:219:0x0478, code lost:
            if (r6 == 0) goto L_0x04a9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:220:0x047a, code lost:
            r8 = r6.indexOf(" ");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:221:0x0480, code lost:
            if (r8 < 0) goto L_0x04a6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:222:0x0482, code lost:
            r21 = r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:223:0x049b, code lost:
            if (r6.substring(r8 + 1).toLowerCase().startsWith(r6.substring(0, r8).toLowerCase()) == false) goto L_0x04ad;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:224:0x049d, code lost:
            r6 = r6.substring(r8).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:225:0x04a6, code lost:
            r21 = r7;
            r6 = r6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:226:0x04a9, code lost:
            r21 = r7;
            r6 = "Network Printer";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:227:0x04ad, code lost:
            r7 = com.dynamixsoftware.printershare.App.getFullModelName(r14, r15);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:228:0x04bb, code lost:
            if (r6.toUpperCase().startsWith("HP ETHERNET MULTI-ENVIRONMENT") != false) goto L_0x04c9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:230:0x04c7, code lost:
            if (r6.toUpperCase().startsWith("ETHERNET MULTI_ENVIRONMENT") == false) goto L_0x04cf;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:231:0x04c9, code lost:
            if (r7 == 0) goto L_0x04cd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:232:0x04cb, code lost:
            r6 = r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:233:0x04cd, code lost:
            r6 = "Network Printer";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:234:0x04cf, code lost:
            r8 = r1.this$0;
            r13 = r1.socket;
            r22 = r11;
            r11 = new java.lang.StringBuilder();
            r23 = r10;
            r11.append("1.3.6.1.4.1.2699.1.2.1.2.1.1.4.");
            r11.append(r9);
            r8 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r8, r13, r2, r11.toString());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:235:0x04ec, code lost:
            if (r8 == null) goto L_0x04f3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:237:?, code lost:
            r8 = java.lang.Integer.parseInt(r8);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:238:0x04f3, code lost:
            r8 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
            r6 = new java.net.DatagramSocket(new java.net.InetSocketAddress(null, 0));
            r1.socket = r6;
            r6.setSoTimeout(3000);
            r4 = r4[0];
            r11 = 2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:240:0x04f4, code lost:
            r10 = 0;
            r5 = r5;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:241:0x04f5, code lost:
            if (r10 < r8) goto L_0x04f7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:244:0x04fd, code lost:
            monitor-enter(com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r1.this$0));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:247:0x0508, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadSNMP.access$000(r1.this$0)[0] != false) goto L_0x050a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:249:0x050b, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x0076, code lost:
            if (r4.length() != 0) goto L_0x00d8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:250:0x050d, code lost:
            if (r2 == null) goto L_0x0512;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:251:0x050f, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:252:0x0512, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:256:?, code lost:
            r11 = r1.this$0;
            r13 = r1.socket;
            r24 = r8;
            r8 = new java.lang.StringBuilder();
            r25 = r15;
            r8.append("1.3.6.1.4.1.2699.1.2.1.3.1.1.2.");
            r8.append(r9);
            r8.append(".");
            r10 = r10 + 1;
            r8.append(r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:257:0x0541, code lost:
            if ("0".equals(com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r11, r13, r2, r8.toString())) != false) goto L_0x08f3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:258:0x0543, code lost:
            r8 = r1.this$0;
            r11 = r1.socket;
            r13 = new java.lang.StringBuilder();
            r13.append("1.3.6.1.4.1.2699.1.2.1.3.1.1.4.");
            r13.append(r9);
            r13.append(".");
            r13.append(r10);
            r8 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r8, r11, r2, r13.toString());
            r11 = r1.this$0;
            r13 = r1.socket;
            r15 = new java.lang.StringBuilder();
            r26 = r14;
            r15.append("1.3.6.1.4.1.2699.1.2.1.3.1.1.5.");
            r15.append(r9);
            r15.append(".");
            r15.append(r10);
            r11 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r11, r13, r2, r15.toString());
            r13 = r1.this$0;
            r14 = r1.socket;
            r15 = new java.lang.StringBuilder();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0078, code lost:
            r6 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r1.this$0, r1.socket, r2, "1.3.6.1.2.1.2.2.1.6.2");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:261:?, code lost:
            r15.append("1.3.6.1.4.1.2699.1.2.1.3.1.1.6.");
            r15.append(r9);
            r15.append(".");
            r15.append(r10);
            r1 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r13, r14, r2, r15.toString());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:262:0x05a8, code lost:
            if (r8 == null) goto L_0x06da;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:263:0x05aa, code lost:
            r13 = r8.indexOf("://");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:264:0x05b0, code lost:
            if (r13 < 0) goto L_0x06bb;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:265:0x05b2, code lost:
            r15 = r8.substring(0, r13);
            r8 = r8.substring(r13 + 3);
            r13 = r8.lastIndexOf(":");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:266:0x05c3, code lost:
            if (r13 < 0) goto L_0x05d9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:267:0x05c5, code lost:
            r27 = r9;
            r9 = r8.substring(0, r13);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:268:0x05d1, code lost:
            if (r9.indexOf(":") <= 0) goto L_0x05db;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0082, code lost:
            if (r6 == null) goto L_0x00d8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:270:?, code lost:
            java.net.InetAddress.getByName(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:271:0x05d7, code lost:
            r13 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:273:0x05d9, code lost:
            r27 = r9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x0084, code lost:
            r6 = r6.toCharArray();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0089, code lost:
            if (r6.length <= 2) goto L_0x00d8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x008b, code lost:
            r4 = new java.lang.StringBuilder();
            r4.append("NPI");
            r4.append(java.lang.Integer.toHexString(r6[r6.length - 3] + 256).toUpperCase().substring(1));
            r4.append(java.lang.Integer.toHexString(r6[r6.length - 2] + 256).toUpperCase().substring(1));
            r4.append(java.lang.Integer.toHexString(r6[r6.length - 1] + 256).toUpperCase().substring(1));
            r4 = r4.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x00de, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadSNMP.access$500(r1.this$0) == null) goto L_0x0105;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:328:0x06bb, code lost:
            r27 = r9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:329:0x06c3, code lost:
            if (r8.indexOf(" ") >= 0) goto L_0x06dc;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x00e0, code lost:
            r6 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$500(r1.this$0);
            r12 = new java.lang.StringBuilder();
            r12.append("snmp_");
            r12.append(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:331:0x06cd, code lost:
            if (r8.equals(r8.toLowerCase()) != false) goto L_0x06dd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:333:0x06d7, code lost:
            if (r8.equals(r8.toUpperCase()) == false) goto L_0x06dc;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:334:0x06da, code lost:
            r27 = r9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:335:0x06dc, code lost:
            r8 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:336:0x06dd, code lost:
            r9 = 0;
            r15 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x00fb, code lost:
            if (r6.startsWith(r12.toString()) != false) goto L_0x0105;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x00fd, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x00ff, code lost:
            if (r2 == null) goto L_0x0104;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x0101, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x0104, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x0105, code lost:
            r6 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x0110, code lost:
            if (r6 >= com.dynamixsoftware.printershare.ScanThreadSNMP.access$600(r1.this$0).size()) goto L_0x0156;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:424:0x08e5, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:425:0x08e6, code lost:
            r1 = r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:429:?, code lost:
            throw r1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:430:0x08e9, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:431:0x08ea, code lost:
            r1 = r28;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:432:0x08ee, code lost:
            r0 = e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:433:0x08ef, code lost:
            r1 = r28;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:434:0x08f3, code lost:
            r8 = r1;
            r27 = r9;
            r13 = r23;
            r15 = r25;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:437:0x090b, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:43:0x0124, code lost:
            if (((com.dynamixsoftware.printershare.data.Printer) com.dynamixsoftware.printershare.ScanThreadSNMP.access$600(r1.this$0).get(r6)).direct_address.indexOf(r3) <= 0) goto L_0x0153;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:443:?, code lost:
            throw r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:444:0x0910, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:445:0x0911, code lost:
            r2 = r0;
            r1 = r8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:446:0x0915, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:447:0x0916, code lost:
            r2 = r0;
            r1 = r8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:448:0x091a, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:449:0x091c, code lost:
            r27 = r9;
            r11 = r22;
            r10 = r23;
            r5 = r19;
            r7 = r21;
            r12 = r12;
            r6 = r6;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:44:0x0126, code lost:
            r12 = ((com.dynamixsoftware.printershare.data.Printer) com.dynamixsoftware.printershare.ScanThreadSNMP.access$600(r1.this$0).get(r6)).id;
            r13 = new java.lang.StringBuilder();
            r13.append("snmp_");
            r13.append(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:456:0x092e, code lost:
            if (r7 == 0) goto L_0x0939;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:458:0x0936, code lost:
            if (r7.indexOf(" ") <= 0) goto L_0x0939;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:459:0x0938, code lost:
            r7 = r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0149, code lost:
            if (r12.startsWith(r13.toString()) == false) goto L_0x0153;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:460:0x0939, code lost:
            r7 = r6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:461:0x093a, code lost:
            if (r7 == 0) goto L_0x0966;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:462:0x093c, code lost:
            r5 = r7.indexOf(" ");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:463:0x0942, code lost:
            if (r5 < 0) goto L_0x0968;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:465:0x095b, code lost:
            if (r7.substring(r5 + 1).toLowerCase().startsWith(r7.substring(0, r5).toLowerCase()) == false) goto L_0x0968;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:466:0x095d, code lost:
            r7 = r7.substring(r5).trim();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:467:0x0966, code lost:
            r7 = "Network Printer";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:468:0x0968, code lost:
            r5 = com.dynamixsoftware.printershare.App.getFullModelName(r14, r15);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:469:0x0976, code lost:
            if (r7.toUpperCase().startsWith("HP ETHERNET MULTI-ENVIRONMENT") != false) goto L_0x0984;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x014b, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:471:0x0982, code lost:
            if (r7.toUpperCase().startsWith("ETHERNET MULTI_ENVIRONMENT") == false) goto L_0x098b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:472:0x0984, code lost:
            if (r5 == 0) goto L_0x0988;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:473:0x0986, code lost:
            r7 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:474:0x0988, code lost:
            r7 = "Network Printer";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:475:0x098b, code lost:
            r6 = 3;
            r8 = new int[]{515, 631, 9100};
            r9 = 0;
            r4 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x014d, code lost:
            if (r2 == null) goto L_0x0152;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:483:0x09b4, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:484:0x09b6, code lost:
            if (r2 == null) goto L_0x09bb;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:485:0x09b8, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:486:0x09bb, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:48:0x014f, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:490:?, code lost:
            r6 = new java.lang.StringBuilder();
            r6.append("snmp_");
            r6.append(r4);
            r6 = r6.toString();
            r21 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:491:0x09d4, code lost:
            if (r8[r9] != 515) goto L_0x09fe;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:492:0x09d6, code lost:
            r13 = new java.lang.StringBuilder();
            r13.append("lpd://");
            r13.append(r3);
            r13.append(":515/lp");
            r4 = r13.toString();
            r13 = new java.lang.StringBuilder();
            r13.append(r6);
            r13.append("._printer._tcp.local.");
            r6 = r13.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:493:0x09fe, code lost:
            r4 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:494:0x09ff, code lost:
            r22 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:495:0x0a05, code lost:
            if (r8[r9] != 631) goto L_0x0a2f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:496:0x0a07, code lost:
            r13 = new java.lang.StringBuilder();
            r13.append("ipp://");
            r13.append(r3);
            r13.append(":631/ipp");
            r4 = r13.toString();
            r13 = new java.lang.StringBuilder();
            r13.append(r6);
            r13.append("._ipp._tcp.local.");
            r6 = r13.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:497:0x0a2f, code lost:
            r4 = r22;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:498:0x0a31, code lost:
            r22 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:499:0x0a37, code lost:
            if (r8[r9] != 9100) goto L_0x0a61;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:49:0x0152, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:500:0x0a39, code lost:
            r13 = new java.lang.StringBuilder();
            r13.append("pdl://");
            r13.append(r3);
            r13.append(":9100");
            r4 = r13.toString();
            r13 = new java.lang.StringBuilder();
            r13.append(r6);
            r13.append("._pdl-datastream._tcp.local.");
            r6 = r13.toString();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:501:0x0a61, code lost:
            r4 = r22;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:503:?, code lost:
            r13 = new java.net.Socket();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:504:0x0a68, code lost:
            r22 = r3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:506:?, code lost:
            r23 = r4;
            r13.connect(new java.net.InetSocketAddress(r2, r8[r9]), org.nanohttpd.protocols.http.NanoHTTPD.SOCKET_READ_TIMEOUT);
            r13.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:507:0x0a7b, code lost:
            r4 = r23;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:508:0x0a7e, code lost:
            r22 = r3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:50:0x0153, code lost:
            r6 = r6 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:510:0x0a80, code lost:
            r4 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:512:0x0a81, code lost:
            if (r4 != null) goto L_0x0a87;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:515:?, code lost:
            r3 = new com.dynamixsoftware.printershare.data.Printer();
            r3.owner = new com.dynamixsoftware.printershare.data.User();
            r3.owner.name = r12;
            r3.id = r6;
            r3.direct_address = r4;
            r3.title = r7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:516:0x0a9d, code lost:
            if (r5 != 0) goto L_0x0a9f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:517:0x0a9f, code lost:
            r4 = r5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:518:0x0aa1, code lost:
            r4 = "";
         */
        /* JADX WARNING: Code restructure failed: missing block: B:519:0x0aa3, code lost:
            r3.model = r4;
            r3.capabilities = new java.util.Hashtable<>();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:520:0x0aac, code lost:
            if (r14 != 0) goto L_0x0aae;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:521:0x0aae, code lost:
            r3.capabilities.put("usb_MFG", r14);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:522:0x0ab5, code lost:
            if (r15 != 0) goto L_0x0ab7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:523:0x0ab7, code lost:
            r3.capabilities.put("usb_MDL", r15);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:524:0x0abe, code lost:
            if (r10 != 0) goto L_0x0ac0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:525:0x0ac0, code lost:
            r3.capabilities.put("usb_CMD", r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:526:0x0ac7, code lost:
            if (r11 != 0) goto L_0x0ac9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:527:0x0ac9, code lost:
            r3.capabilities.put("URF", r11);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:52:?, code lost:
            r6 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r1.this$0, r1.socket, r2, "1.3.6.1.2.1.1.1.0");
            r12 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r1.this$0, r1.socket, r2, "1.3.6.1.4.1.11.2.3.9.1.1.7.0");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:533:0x0aea, code lost:
            monitor-enter(com.dynamixsoftware.printershare.ScanThreadSNMP.access$600(r1.this$0));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:535:?, code lost:
            com.dynamixsoftware.printershare.ScanThreadSNMP.access$600(r1.this$0).add(r3);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:538:?, code lost:
            r3 = new android.os.Message();
            r3.what = 2;
            r3.arg1 = 1;
            com.dynamixsoftware.printershare.ScanThreadSNMP.access$700(r1.this$0).sendMessage(r3);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:539:0x0b0f, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadSNMP.access$500(r1.this$0) != null) goto L_0x0b11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:53:0x016a, code lost:
            if (r12 == null) goto L_0x020e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:540:0x0b11, code lost:
            r1.this$0.destroy();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:541:0x0b16, code lost:
            r9 = r9 + 1;
            r4 = r21;
            r3 = r22;
            r6 = 3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x016c, code lost:
            r12 = r12.split(";");
            r14 = 0;
            r15 = 0;
            r16 = 0;
            r17 = 0;
            r18 = 0;
            r13 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:555:0x0b29, code lost:
            if (r2 != null) goto L_0x0b47;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:566:0x0b38, code lost:
            r0 = th;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:567:0x0b39, code lost:
            r2 = r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:569:0x0b3c, code lost:
            r2 = r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x017c, code lost:
            if (r13 >= r12.length) goto L_0x0207;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:571:?, code lost:
            r2.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:572:0x0b43, code lost:
            r2 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:573:0x0b45, code lost:
            if (r2 == null) goto L_0x0b4a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:574:0x0b47, code lost:
            r2.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:575:0x0b4a, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:576:0x0b4b, code lost:
            r3 = r1.socket;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:577:0x0b4d, code lost:
            if (r3 != null) goto L_0x0b4f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:578:0x0b4f, code lost:
            r3.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:579:0x0b52, code lost:
            throw r2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x017e, code lost:
            r7 = r12[r13].split(":");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:584:0x0201, code lost:
            r18 = r18;
            r17 = r17;
            r16 = r16;
            r15 = r15;
            r14 = r7[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:585:0x0201, code lost:
            r18 = r18;
            r17 = r17;
            r16 = r16;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:586:0x0201, code lost:
            r18 = r18;
            r17 = r17;
            r16 = r16;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:587:0x0201, code lost:
            r17 = r17;
            r16 = r16;
            r15 = r15;
            r14 = r14;
            r18 = r7[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:588:0x0201, code lost:
            r18 = r18;
            r17 = r17;
            r15 = r15;
            r14 = r14;
            r16 = r7[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:589:0x0201, code lost:
            r18 = r18;
            r16 = r16;
            r15 = r15;
            r14 = r14;
            r17 = r7[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:0x0187, code lost:
            if (r7.length >= r11) goto L_0x018b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:590:0x0201, code lost:
            r18 = r18;
            r17 = r17;
            r16 = r16;
            r14 = r14;
            r15 = r7[1];
         */
        /* JADX WARNING: Code restructure failed: missing block: B:592:0x0256, code lost:
            r20 = r20;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:600:0x0464, code lost:
            r21 = r21;
            r15 = r15;
            r14 = r14;
            r10 = r10;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:61:0x0193, code lost:
            if ("MFG".equals(r7[0]) != false) goto L_0x01ff;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:63:0x019d, code lost:
            if ("MFR".equals(r7[0]) != false) goto L_0x01ff;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:65:0x01a7, code lost:
            if ("MANUFACTURER".equals(r7[0]) == false) goto L_0x01aa;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:68:0x01b2, code lost:
            if ("MDL".equals(r7[0]) != false) goto L_0x01fc;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:70:0x01bc, code lost:
            if ("MODEL".equals(r7[0]) == false) goto L_0x01bf;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:73:0x01c7, code lost:
            if ("CMD".equals(r7[0]) != false) goto L_0x01f9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:75:0x01d1, code lost:
            if ("COMMAND SET".equals(r7[0]) == false) goto L_0x01d4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:78:0x01dc, code lost:
            if ("DES".equals(r7[0]) != false) goto L_0x01f6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:80:0x01e6, code lost:
            if ("DESCRIPTION".equals(r7[0]) == false) goto L_0x01e9;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:83:0x01f1, code lost:
            if ("URF".equals(r7[0]) == false) goto L_0x0201;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:89:0x0201, code lost:
            r13 = r13 + 1;
            r11 = 2;
            r18 = r18;
            r17 = r17;
            r16 = r16;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:90:0x0207, code lost:
            r7 = r16;
            r10 = r17;
            r11 = r18;
            r15 = r15;
            r14 = r14;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:91:0x020e, code lost:
            r7 = 0;
            r10 = 0;
            r11 = 0;
            r14 = 0;
            r15 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:92:0x0213, code lost:
            r5 = com.dynamixsoftware.printershare.ScanThreadSNMP.access$400(r1.this$0, r1.socket, r2, "1.3.6.1.2.1.25.3.2.1.3.1");
            r12 = r4.indexOf(".");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:93:0x0223, code lost:
            if (r12 <= 0) goto L_0x022a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:94:0x0225, code lost:
            r12 = r4.substring(0, r12);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:95:0x022a, code lost:
            r12 = r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:96:0x022b, code lost:
            if (r5 != 0) goto L_0x022e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:97:0x022d, code lost:
            r6 = r6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:98:0x022e, code lost:
            if (r6 == 0) goto L_0x027c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:99:0x0230, code lost:
            r13 = r5.split(" ");
            r6 = r6.split(" ");
            r9 = 0;
            r5 = r5;
         */
        /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r15v1
  assigns: []
  uses: []
  mth insns count: 1284
        	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$0(DepthTraversal.java:13)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:13)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
        	at jadx.core.ProcessClass.process(ProcessClass.java:35)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
         */
        /* JADX WARNING: Removed duplicated region for block: B:148:0x0336 A[SYNTHETIC, Splitter:B:148:0x0336] */
        /* JADX WARNING: Removed duplicated region for block: B:327:0x06b4 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:338:0x06e1 A[SYNTHETIC, Splitter:B:338:0x06e1] */
        /* JADX WARNING: Removed duplicated region for block: B:343:0x06e9  */
        /* JADX WARNING: Removed duplicated region for block: B:356:0x0728 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:361:0x0731 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:364:0x074e A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:367:0x0769 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:374:0x0799 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:381:0x07d3 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:384:0x07f0 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:388:0x080c A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:391:0x0831 A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:392:0x083b A[Catch:{ Exception -> 0x08ee, all -> 0x08e9 }] */
        /* JADX WARNING: Removed duplicated region for block: B:514:0x0a87 A[SYNTHETIC, Splitter:B:514:0x0a87] */
        /* JADX WARNING: Removed duplicated region for block: B:578:0x0b4f  */
        /* JADX WARNING: Unknown variable types count: 152 */
        public void run() {
            ? r4;
            ? r15;
            ? r14;
            ? r11;
            ? r10;
            ? r7;
            ? r12;
            ? r6;
            int i;
            int i2;
            int i3;
            int i4;
            ? r122;
            ? r62;
            ? fullModelName;
            ? r22;
            ? r23;
            ? r5;
            int i5;
            ? r25;
            int i6;
            ? r232;
            ? r152;
            ? r142;
            ? r13;
            DetectThread detectThread;
            ? r52;
            ? r153;
            ? r132;
            ? r26;
            String access$400;
            String access$4002;
            String str;
            int i7;
            String str2;
            int i8;
            String str3;
            ? r143;
            ? r154;
            ? r133;
            ? r233;
            ? r53;
            ? r234;
            int lastIndexOf;
            String str4;
            DetectThread detectThread2 = this;
            try {
                InetAddress address = detectThread2.packet.getAddress();
                String hostAddress = address.getHostAddress();
                if (address.getAddress().length != 4) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("[");
                    sb.append(hostAddress);
                    sb.append("]");
                    hostAddress = sb.toString();
                }
                ? access$300 = ScanThreadSNMP.this.parseResponse(detectThread2.packet, 0, "1.3.6.1.2.1.1.5.0", true);
                if (access$300 != 0) {
                    if (access$300[0] != 0) {
                        synchronized (ScanThreadSNMP.this.destroyed) {
                            if (ScanThreadSNMP.this.destroyed[0]) {
                            }
                        }
                    }
                }
                DatagramSocket datagramSocket = detectThread2.socket;
                if (datagramSocket != null) {
                    datagramSocket.close();
                }
                return;
                i4 = 0;
                ? r155 = r15;
                ? r144 = r14;
                ? r112 = r11;
                ? r102 = r10;
                ? r72 = r7;
                ? r123 = r12;
                ? r63 = r6;
                while (i4 < i3) {
                    synchronized (ScanThreadSNMP.this.destroyed) {
                        if (ScanThreadSNMP.this.destroyed[0]) {
                        }
                    }
                }
                DatagramSocket datagramSocket2 = detectThread2.socket;
                while (i4 < i3) {
                }
                DatagramSocket datagramSocket22 = detectThread2.socket;
                if (lastIndexOf >= 0) {
                    String substring = str2.substring(lastIndexOf + 1);
                    int indexOf = substring.indexOf("/");
                    th = indexOf >= 0 ? substring.substring(indexOf + 1) : null;
                    if (indexOf >= 0) {
                        try {
                            substring = substring.substring(0, indexOf);
                        } catch (NumberFormatException unused) {
                            str2 = th;
                            i7 = 0;
                            if (i7 == 0) {
                            }
                            i8 = i7;
                            if (i8 == 0) {
                            }
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("snmp_");
                            sb2.append(r4);
                            sb2.append("_");
                            sb2.append(r5);
                            String sb3 = sb2.toString();
                            if (!"8".equals(access$400)) {
                            }
                            if (i8 == 0) {
                            }
                            StringBuilder sb4 = new StringBuilder();
                            sb4.append("lpd://");
                            sb4.append(hostAddress);
                            sb4.append(":");
                            sb4.append(i8);
                            str3 = sb4.toString();
                            if (str2 == null) {
                            }
                            StringBuilder sb5 = new StringBuilder();
                            sb5.append(sb3);
                            sb5.append("._printer._tcp.local.");
                            sb3 = sb5.toString();
                            if (i8 == 0) {
                            }
                            StringBuilder sb6 = new StringBuilder();
                            sb6.append("pdl://");
                            sb6.append(hostAddress);
                            sb6.append(":");
                            sb6.append(i8);
                            str3 = sb6.toString();
                            StringBuilder sb7 = new StringBuilder();
                            sb7.append(sb3);
                            sb7.append("._pdl-datastream._tcp.local.");
                            sb3 = sb7.toString();
                            if (i8 == 0) {
                            }
                            StringBuilder sb8 = new StringBuilder();
                            sb8.append("ipp://");
                            sb8.append(hostAddress);
                            sb8.append(":");
                            sb8.append(i8);
                            String sb9 = sb8.toString();
                            if (str2 != null) {
                            }
                            str3 = sb9;
                            StringBuilder sb10 = new StringBuilder();
                            sb10.append(sb3);
                            sb10.append("._ipp._tcp.local.");
                            sb3 = sb10.toString();
                            if (str3 != null) {
                            }
                        }
                    }
                    i7 = Integer.parseInt(substring);
                    if (i7 == 0) {
                    }
                    i8 = i7;
                    if (i8 == 0) {
                    }
                    StringBuilder sb22 = new StringBuilder();
                    sb22.append("snmp_");
                    sb22.append(r4);
                    sb22.append("_");
                    sb22.append(r5);
                    String sb32 = sb22.toString();
                    if (!"8".equals(access$400)) {
                    }
                    if (i8 == 0) {
                    }
                    StringBuilder sb42 = new StringBuilder();
                    sb42.append("lpd://");
                    sb42.append(hostAddress);
                    sb42.append(":");
                    sb42.append(i8);
                    str3 = sb42.toString();
                    if (str2 == null) {
                    }
                    StringBuilder sb52 = new StringBuilder();
                    sb52.append(sb32);
                    sb52.append("._printer._tcp.local.");
                    sb32 = sb52.toString();
                    if (i8 == 0) {
                    }
                    StringBuilder sb62 = new StringBuilder();
                    sb62.append("pdl://");
                    sb62.append(hostAddress);
                    sb62.append(":");
                    sb62.append(i8);
                    str3 = sb62.toString();
                    StringBuilder sb72 = new StringBuilder();
                    sb72.append(sb32);
                    sb72.append("._pdl-datastream._tcp.local.");
                    sb32 = sb72.toString();
                    if (i8 == 0) {
                    }
                    StringBuilder sb82 = new StringBuilder();
                    sb82.append("ipp://");
                    sb82.append(hostAddress);
                    sb82.append(":");
                    sb82.append(i8);
                    String sb92 = sb82.toString();
                    if (str2 != null) {
                    }
                    str3 = sb92;
                    StringBuilder sb102 = new StringBuilder();
                    sb102.append(sb32);
                    sb102.append("._ipp._tcp.local.");
                    sb32 = sb102.toString();
                    if (str3 != null) {
                    }
                } else {
                    if (!str2.equals(r4)) {
                        StringBuilder sb11 = new StringBuilder();
                        sb11.append(r4);
                        sb11.append("/");
                        if (!str2.startsWith(sb11.toString())) {
                            if (!str2.equals(r122)) {
                                StringBuilder sb12 = new StringBuilder();
                                sb12.append(r122);
                                sb12.append("/");
                                if (!str2.startsWith(sb12.toString())) {
                                    if (!str2.equals(hostAddress)) {
                                        StringBuilder sb13 = new StringBuilder();
                                        sb13.append(hostAddress);
                                        sb13.append("/");
                                        if (!str2.startsWith(sb13.toString())) {
                                            if (str2.indexOf(".") > 0 || str2.indexOf(":") > 0) {
                                                int indexOf2 = str2.indexOf("/");
                                                if (indexOf2 < 0) {
                                                    str4 = str2;
                                                } else {
                                                    try {
                                                        str4 = str2.substring(0, indexOf2);
                                                    } catch (UnknownHostException unused2) {
                                                        if (str2.startsWith("/")) {
                                                            str2 = str2.substring(1);
                                                        }
                                                        i7 = 0;
                                                        if (i7 == 0) {
                                                            try {
                                                                i8 = Integer.parseInt(access$4002);
                                                            } catch (NumberFormatException unused3) {
                                                                i8 = i7;
                                                                if (i8 == 0) {
                                                                }
                                                                StringBuilder sb222 = new StringBuilder();
                                                                sb222.append("snmp_");
                                                                sb222.append(r4);
                                                                sb222.append("_");
                                                                sb222.append(r5);
                                                                String sb322 = sb222.toString();
                                                                if (!"8".equals(access$400)) {
                                                                }
                                                                if (i8 == 0) {
                                                                }
                                                                StringBuilder sb422 = new StringBuilder();
                                                                sb422.append("lpd://");
                                                                sb422.append(hostAddress);
                                                                sb422.append(":");
                                                                sb422.append(i8);
                                                                str3 = sb422.toString();
                                                                if (str2 == null) {
                                                                }
                                                                StringBuilder sb522 = new StringBuilder();
                                                                sb522.append(sb322);
                                                                sb522.append("._printer._tcp.local.");
                                                                sb322 = sb522.toString();
                                                                if (i8 == 0) {
                                                                }
                                                                StringBuilder sb622 = new StringBuilder();
                                                                sb622.append("pdl://");
                                                                sb622.append(hostAddress);
                                                                sb622.append(":");
                                                                sb622.append(i8);
                                                                str3 = sb622.toString();
                                                                StringBuilder sb722 = new StringBuilder();
                                                                sb722.append(sb322);
                                                                sb722.append("._pdl-datastream._tcp.local.");
                                                                sb322 = sb722.toString();
                                                                if (i8 == 0) {
                                                                }
                                                                StringBuilder sb822 = new StringBuilder();
                                                                sb822.append("ipp://");
                                                                sb822.append(hostAddress);
                                                                sb822.append(":");
                                                                sb822.append(i8);
                                                                String sb922 = sb822.toString();
                                                                if (str2 != null) {
                                                                }
                                                                str3 = sb922;
                                                                StringBuilder sb1022 = new StringBuilder();
                                                                sb1022.append(sb322);
                                                                sb1022.append("._ipp._tcp.local.");
                                                                sb322 = sb1022.toString();
                                                                if (str3 != null) {
                                                                }
                                                            }
                                                            if (i8 == 0) {
                                                                if ("socket".equals(str)) {
                                                                    i8 = 9100;
                                                                }
                                                                if ("lpr".equals(str)) {
                                                                    i8 = 515;
                                                                }
                                                                if ("ipp".equals(str)) {
                                                                    i8 = 631;
                                                                }
                                                            }
                                                            StringBuilder sb2222 = new StringBuilder();
                                                            sb2222.append("snmp_");
                                                            sb2222.append(r4);
                                                            sb2222.append("_");
                                                            sb2222.append(r5);
                                                            String sb3222 = sb2222.toString();
                                                            if (!"8".equals(access$400)) {
                                                                if (i8 != 515) {
                                                                    str3 = null;
                                                                    if ("11".equals(access$400) || i8 == 9100) {
                                                                        if (i8 == 0) {
                                                                            i8 = 9100;
                                                                        }
                                                                        StringBuilder sb6222 = new StringBuilder();
                                                                        sb6222.append("pdl://");
                                                                        sb6222.append(hostAddress);
                                                                        sb6222.append(":");
                                                                        sb6222.append(i8);
                                                                        str3 = sb6222.toString();
                                                                        StringBuilder sb7222 = new StringBuilder();
                                                                        sb7222.append(sb3222);
                                                                        sb7222.append("._pdl-datastream._tcp.local.");
                                                                        sb3222 = sb7222.toString();
                                                                    }
                                                                    if ("44".equals(access$400) || i8 == 631) {
                                                                        if (i8 == 0) {
                                                                            i8 = 631;
                                                                        }
                                                                        StringBuilder sb8222 = new StringBuilder();
                                                                        sb8222.append("ipp://");
                                                                        sb8222.append(hostAddress);
                                                                        sb8222.append(":");
                                                                        sb8222.append(i8);
                                                                        String sb9222 = sb8222.toString();
                                                                        if (str2 != null) {
                                                                            StringBuilder sb14 = new StringBuilder();
                                                                            sb14.append(sb9222);
                                                                            sb14.append("/ipp");
                                                                            sb9222 = sb14.toString();
                                                                        } else if (str2.length() > 0) {
                                                                            StringBuilder sb15 = new StringBuilder();
                                                                            sb15.append(sb9222);
                                                                            sb15.append("/");
                                                                            sb15.append(str2);
                                                                            sb9222 = sb15.toString();
                                                                        }
                                                                        str3 = sb9222;
                                                                        StringBuilder sb10222 = new StringBuilder();
                                                                        sb10222.append(sb3222);
                                                                        sb10222.append("._ipp._tcp.local.");
                                                                        sb3222 = sb10222.toString();
                                                                    }
                                                                    if (str3 != null) {
                                                                        detectThread = this;
                                                                        ? r134 = r23;
                                                                        ? r156 = r25;
                                                                        ? r145 = r26;
                                                                        r232 = r5;
                                                                        r52 = r22;
                                                                        r152 = r153;
                                                                        r142 = r145;
                                                                        r13 = r132;
                                                                        r22 = r52;
                                                                        detectThread2 = detectThread;
                                                                        r5 = r232;
                                                                        int i9 = i5;
                                                                        i4 = i6;
                                                                        r23 = r13;
                                                                        ? r157 = r152;
                                                                        ? r146 = r142;
                                                                    } else {
                                                                        Printer printer = new Printer();
                                                                        printer.owner = new User();
                                                                        printer.owner.name = r122;
                                                                        printer.id = sb3222;
                                                                        printer.direct_address = str3;
                                                                        printer.title = r62;
                                                                        printer.model = fullModelName != 0 ? fullModelName : "";
                                                                        printer.capabilities = new Hashtable<>();
                                                                        if (r26 != 0) {
                                                                            ? r147 = r26;
                                                                            printer.capabilities.put("usb_MFG", r147);
                                                                            r143 = r147;
                                                                        } else {
                                                                            r143 = r26;
                                                                        }
                                                                        if (r25 != 0) {
                                                                            r153 = r25;
                                                                            printer.capabilities.put("usb_MDL", r153);
                                                                            r154 = r153;
                                                                        } else {
                                                                            r154 = r25;
                                                                        }
                                                                        if (r23 != 0) {
                                                                            r132 = r23;
                                                                            printer.capabilities.put("usb_CMD", r132);
                                                                            r133 = r132;
                                                                        } else {
                                                                            r133 = r23;
                                                                        }
                                                                        if (r22 != 0) {
                                                                            r234 = r5;
                                                                            ? r54 = r22;
                                                                            printer.capabilities.put("URF", r54);
                                                                            r53 = r54;
                                                                        } else {
                                                                            r234 = r5;
                                                                            r53 = r22;
                                                                        }
                                                                        detectThread = this;
                                                                        if (ScanThreadSNMP.this.rq_pid == null || sb3222.equals(ScanThreadSNMP.this.rq_pid)) {
                                                                            synchronized (ScanThreadSNMP.this.printers) {
                                                                                ScanThreadSNMP.this.printers.add(printer);
                                                                            }
                                                                            Message message = new Message();
                                                                            message.what = 2;
                                                                            message.arg1 = 1;
                                                                            ScanThreadSNMP.this.status.sendMessage(message);
                                                                            if (ScanThreadSNMP.this.rq_pid != null) {
                                                                                ScanThreadSNMP.this.destroy();
                                                                                r142 = r143;
                                                                                r152 = r154;
                                                                                r13 = r133;
                                                                                r232 = r233;
                                                                                r52 = r53;
                                                                            } else {
                                                                                r142 = r143;
                                                                                r152 = r154;
                                                                                r13 = r133;
                                                                                r232 = r233;
                                                                                r52 = r53;
                                                                            }
                                                                            r22 = r52;
                                                                            detectThread2 = detectThread;
                                                                            r5 = r232;
                                                                            int i92 = i5;
                                                                            i4 = i6;
                                                                            r23 = r13;
                                                                            ? r1572 = r152;
                                                                            ? r1462 = r142;
                                                                        } else {
                                                                            r142 = r143;
                                                                            r152 = r154;
                                                                            r13 = r133;
                                                                            r232 = r233;
                                                                            r52 = r53;
                                                                            r22 = r52;
                                                                            detectThread2 = detectThread;
                                                                            r5 = r232;
                                                                            int i922 = i5;
                                                                            i4 = i6;
                                                                            r23 = r13;
                                                                            ? r15722 = r152;
                                                                            ? r14622 = r142;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            if (i8 == 0) {
                                                                i8 = 515;
                                                            }
                                                            StringBuilder sb4222 = new StringBuilder();
                                                            sb4222.append("lpd://");
                                                            sb4222.append(hostAddress);
                                                            sb4222.append(":");
                                                            sb4222.append(i8);
                                                            str3 = sb4222.toString();
                                                            if (str2 == null) {
                                                                StringBuilder sb16 = new StringBuilder();
                                                                sb16.append(str3);
                                                                sb16.append("/lp");
                                                                str3 = sb16.toString();
                                                            } else if (str2.length() > 0) {
                                                                StringBuilder sb17 = new StringBuilder();
                                                                sb17.append(str3);
                                                                sb17.append("/");
                                                                sb17.append(str2);
                                                                str3 = sb17.toString();
                                                            }
                                                            StringBuilder sb5222 = new StringBuilder();
                                                            sb5222.append(sb3222);
                                                            sb5222.append("._printer._tcp.local.");
                                                            sb3222 = sb5222.toString();
                                                            if (i8 == 0) {
                                                            }
                                                            StringBuilder sb62222 = new StringBuilder();
                                                            sb62222.append("pdl://");
                                                            sb62222.append(hostAddress);
                                                            sb62222.append(":");
                                                            sb62222.append(i8);
                                                            str3 = sb62222.toString();
                                                            StringBuilder sb72222 = new StringBuilder();
                                                            sb72222.append(sb3222);
                                                            sb72222.append("._pdl-datastream._tcp.local.");
                                                            sb3222 = sb72222.toString();
                                                            if (i8 == 0) {
                                                            }
                                                            StringBuilder sb82222 = new StringBuilder();
                                                            sb82222.append("ipp://");
                                                            sb82222.append(hostAddress);
                                                            sb82222.append(":");
                                                            sb82222.append(i8);
                                                            String sb92222 = sb82222.toString();
                                                            if (str2 != null) {
                                                            }
                                                            str3 = sb92222;
                                                            StringBuilder sb102222 = new StringBuilder();
                                                            sb102222.append(sb3222);
                                                            sb102222.append("._ipp._tcp.local.");
                                                            sb3222 = sb102222.toString();
                                                            if (str3 != null) {
                                                            }
                                                        }
                                                        i8 = i7;
                                                        if (i8 == 0) {
                                                        }
                                                        StringBuilder sb22222 = new StringBuilder();
                                                        sb22222.append("snmp_");
                                                        sb22222.append(r4);
                                                        sb22222.append("_");
                                                        sb22222.append(r5);
                                                        String sb32222 = sb22222.toString();
                                                        if (!"8".equals(access$400)) {
                                                        }
                                                        if (i8 == 0) {
                                                        }
                                                        StringBuilder sb42222 = new StringBuilder();
                                                        sb42222.append("lpd://");
                                                        sb42222.append(hostAddress);
                                                        sb42222.append(":");
                                                        sb42222.append(i8);
                                                        str3 = sb42222.toString();
                                                        if (str2 == null) {
                                                        }
                                                        StringBuilder sb52222 = new StringBuilder();
                                                        sb52222.append(sb32222);
                                                        sb52222.append("._printer._tcp.local.");
                                                        sb32222 = sb52222.toString();
                                                        if (i8 == 0) {
                                                        }
                                                        StringBuilder sb622222 = new StringBuilder();
                                                        sb622222.append("pdl://");
                                                        sb622222.append(hostAddress);
                                                        sb622222.append(":");
                                                        sb622222.append(i8);
                                                        str3 = sb622222.toString();
                                                        StringBuilder sb722222 = new StringBuilder();
                                                        sb722222.append(sb32222);
                                                        sb722222.append("._pdl-datastream._tcp.local.");
                                                        sb32222 = sb722222.toString();
                                                        if (i8 == 0) {
                                                        }
                                                        StringBuilder sb822222 = new StringBuilder();
                                                        sb822222.append("ipp://");
                                                        sb822222.append(hostAddress);
                                                        sb822222.append(":");
                                                        sb822222.append(i8);
                                                        String sb922222 = sb822222.toString();
                                                        if (str2 != null) {
                                                        }
                                                        str3 = sb922222;
                                                        StringBuilder sb1022222 = new StringBuilder();
                                                        sb1022222.append(sb32222);
                                                        sb1022222.append("._ipp._tcp.local.");
                                                        sb32222 = sb1022222.toString();
                                                        if (str3 != null) {
                                                        }
                                                    }
                                                }
                                                InetAddress.getByName(str4);
                                                str2 = indexOf2 < 0 ? "" : str2.substring(indexOf2 + 1);
                                            }
                                            if (str2.startsWith("/")) {
                                            }
                                            i7 = 0;
                                            if (i7 == 0) {
                                            }
                                            i8 = i7;
                                            if (i8 == 0) {
                                            }
                                            StringBuilder sb222222 = new StringBuilder();
                                            sb222222.append("snmp_");
                                            sb222222.append(r4);
                                            sb222222.append("_");
                                            sb222222.append(r5);
                                            String sb322222 = sb222222.toString();
                                            if (!"8".equals(access$400)) {
                                            }
                                            if (i8 == 0) {
                                            }
                                            StringBuilder sb422222 = new StringBuilder();
                                            sb422222.append("lpd://");
                                            sb422222.append(hostAddress);
                                            sb422222.append(":");
                                            sb422222.append(i8);
                                            str3 = sb422222.toString();
                                            if (str2 == null) {
                                            }
                                            StringBuilder sb522222 = new StringBuilder();
                                            sb522222.append(sb322222);
                                            sb522222.append("._printer._tcp.local.");
                                            sb322222 = sb522222.toString();
                                            if (i8 == 0) {
                                            }
                                            StringBuilder sb6222222 = new StringBuilder();
                                            sb6222222.append("pdl://");
                                            sb6222222.append(hostAddress);
                                            sb6222222.append(":");
                                            sb6222222.append(i8);
                                            str3 = sb6222222.toString();
                                            StringBuilder sb7222222 = new StringBuilder();
                                            sb7222222.append(sb322222);
                                            sb7222222.append("._pdl-datastream._tcp.local.");
                                            sb322222 = sb7222222.toString();
                                            if (i8 == 0) {
                                            }
                                            StringBuilder sb8222222 = new StringBuilder();
                                            sb8222222.append("ipp://");
                                            sb8222222.append(hostAddress);
                                            sb8222222.append(":");
                                            sb8222222.append(i8);
                                            String sb9222222 = sb8222222.toString();
                                            if (str2 != null) {
                                            }
                                            str3 = sb9222222;
                                            StringBuilder sb10222222 = new StringBuilder();
                                            sb10222222.append(sb322222);
                                            sb10222222.append("._ipp._tcp.local.");
                                            sb322222 = sb10222222.toString();
                                            if (str3 != null) {
                                            }
                                        }
                                    }
                                    str2 = str2.substring(hostAddress.length());
                                    if (str2.startsWith("/")) {
                                    }
                                    i7 = 0;
                                    if (i7 == 0) {
                                    }
                                    i8 = i7;
                                    if (i8 == 0) {
                                    }
                                    StringBuilder sb2222222 = new StringBuilder();
                                    sb2222222.append("snmp_");
                                    sb2222222.append(r4);
                                    sb2222222.append("_");
                                    sb2222222.append(r5);
                                    String sb3222222 = sb2222222.toString();
                                    if (!"8".equals(access$400)) {
                                    }
                                    if (i8 == 0) {
                                    }
                                    StringBuilder sb4222222 = new StringBuilder();
                                    sb4222222.append("lpd://");
                                    sb4222222.append(hostAddress);
                                    sb4222222.append(":");
                                    sb4222222.append(i8);
                                    str3 = sb4222222.toString();
                                    if (str2 == null) {
                                    }
                                    StringBuilder sb5222222 = new StringBuilder();
                                    sb5222222.append(sb3222222);
                                    sb5222222.append("._printer._tcp.local.");
                                    sb3222222 = sb5222222.toString();
                                    if (i8 == 0) {
                                    }
                                    StringBuilder sb62222222 = new StringBuilder();
                                    sb62222222.append("pdl://");
                                    sb62222222.append(hostAddress);
                                    sb62222222.append(":");
                                    sb62222222.append(i8);
                                    str3 = sb62222222.toString();
                                    StringBuilder sb72222222 = new StringBuilder();
                                    sb72222222.append(sb3222222);
                                    sb72222222.append("._pdl-datastream._tcp.local.");
                                    sb3222222 = sb72222222.toString();
                                    if (i8 == 0) {
                                    }
                                    StringBuilder sb82222222 = new StringBuilder();
                                    sb82222222.append("ipp://");
                                    sb82222222.append(hostAddress);
                                    sb82222222.append(":");
                                    sb82222222.append(i8);
                                    String sb92222222 = sb82222222.toString();
                                    if (str2 != null) {
                                    }
                                    str3 = sb92222222;
                                    StringBuilder sb102222222 = new StringBuilder();
                                    sb102222222.append(sb3222222);
                                    sb102222222.append("._ipp._tcp.local.");
                                    sb3222222 = sb102222222.toString();
                                    if (str3 != null) {
                                    }
                                }
                            }
                            str2 = str2.substring(r122.length() + 1);
                            if (str2.startsWith("/")) {
                            }
                            i7 = 0;
                            if (i7 == 0) {
                            }
                            i8 = i7;
                            if (i8 == 0) {
                            }
                            StringBuilder sb22222222 = new StringBuilder();
                            sb22222222.append("snmp_");
                            sb22222222.append(r4);
                            sb22222222.append("_");
                            sb22222222.append(r5);
                            String sb32222222 = sb22222222.toString();
                            if (!"8".equals(access$400)) {
                            }
                            if (i8 == 0) {
                            }
                            StringBuilder sb42222222 = new StringBuilder();
                            sb42222222.append("lpd://");
                            sb42222222.append(hostAddress);
                            sb42222222.append(":");
                            sb42222222.append(i8);
                            str3 = sb42222222.toString();
                            if (str2 == null) {
                            }
                            StringBuilder sb52222222 = new StringBuilder();
                            sb52222222.append(sb32222222);
                            sb52222222.append("._printer._tcp.local.");
                            sb32222222 = sb52222222.toString();
                            if (i8 == 0) {
                            }
                            StringBuilder sb622222222 = new StringBuilder();
                            sb622222222.append("pdl://");
                            sb622222222.append(hostAddress);
                            sb622222222.append(":");
                            sb622222222.append(i8);
                            str3 = sb622222222.toString();
                            StringBuilder sb722222222 = new StringBuilder();
                            sb722222222.append(sb32222222);
                            sb722222222.append("._pdl-datastream._tcp.local.");
                            sb32222222 = sb722222222.toString();
                            if (i8 == 0) {
                            }
                            StringBuilder sb822222222 = new StringBuilder();
                            sb822222222.append("ipp://");
                            sb822222222.append(hostAddress);
                            sb822222222.append(":");
                            sb822222222.append(i8);
                            String sb922222222 = sb822222222.toString();
                            if (str2 != null) {
                            }
                            str3 = sb922222222;
                            StringBuilder sb1022222222 = new StringBuilder();
                            sb1022222222.append(sb32222222);
                            sb1022222222.append("._ipp._tcp.local.");
                            sb32222222 = sb1022222222.toString();
                            if (str3 != null) {
                            }
                        }
                    }
                    str2 = str2.substring(r4.length());
                    if (str2.startsWith("/")) {
                    }
                    i7 = 0;
                    if (i7 == 0) {
                    }
                    i8 = i7;
                    if (i8 == 0) {
                    }
                    StringBuilder sb222222222 = new StringBuilder();
                    sb222222222.append("snmp_");
                    sb222222222.append(r4);
                    sb222222222.append("_");
                    sb222222222.append(r5);
                    String sb322222222 = sb222222222.toString();
                    if (!"8".equals(access$400)) {
                    }
                    if (i8 == 0) {
                    }
                    StringBuilder sb422222222 = new StringBuilder();
                    sb422222222.append("lpd://");
                    sb422222222.append(hostAddress);
                    sb422222222.append(":");
                    sb422222222.append(i8);
                    str3 = sb422222222.toString();
                    if (str2 == null) {
                    }
                    StringBuilder sb522222222 = new StringBuilder();
                    sb522222222.append(sb322222222);
                    sb522222222.append("._printer._tcp.local.");
                    sb322222222 = sb522222222.toString();
                    if (i8 == 0) {
                    }
                    StringBuilder sb6222222222 = new StringBuilder();
                    sb6222222222.append("pdl://");
                    sb6222222222.append(hostAddress);
                    sb6222222222.append(":");
                    sb6222222222.append(i8);
                    str3 = sb6222222222.toString();
                    StringBuilder sb7222222222 = new StringBuilder();
                    sb7222222222.append(sb322222222);
                    sb7222222222.append("._pdl-datastream._tcp.local.");
                    sb322222222 = sb7222222222.toString();
                    if (i8 == 0) {
                    }
                    StringBuilder sb8222222222 = new StringBuilder();
                    sb8222222222.append("ipp://");
                    sb8222222222.append(hostAddress);
                    sb8222222222.append(":");
                    sb8222222222.append(i8);
                    String sb9222222222 = sb8222222222.toString();
                    if (str2 != null) {
                    }
                    str3 = sb9222222222;
                    StringBuilder sb10222222222 = new StringBuilder();
                    sb10222222222.append(sb322222222);
                    sb10222222222.append("._ipp._tcp.local.");
                    sb322222222 = sb10222222222.toString();
                    if (str3 != null) {
                    }
                }
                while (i2 < i) {
                    synchronized (ScanThreadSNMP.this.destroyed) {
                        if (ScanThreadSNMP.this.destroyed[0]) {
                        }
                    }
                }
                DatagramSocket datagramSocket222 = detectThread2.socket;
            } catch (Exception e) {
                e = e;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }

        public void interrupt() {
            super.interrupt();
            DatagramSocket datagramSocket = this.socket;
            if (datagramSocket != null) {
                datagramSocket.close();
            }
        }
    }

    class SocketThread extends Thread {
        InetAddress ia;
        DatagramSocket socket;

        SocketThread(InetAddress inetAddress) throws IOException {
            this.ia = inetAddress;
            DatagramSocket datagramSocket = new DatagramSocket(new InetSocketAddress(inetAddress, 0));
            this.socket = datagramSocket;
            try {
                datagramSocket.setBroadcast(true);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }

        public void run() {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                while (true) {
                    synchronized (ScanThreadSNMP.this.destroyed) {
                        if (ScanThreadSNMP.this.destroyed[0]) {
                            break;
                        }
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        if (currentTimeMillis2 >= ((long) ScanThreadSNMP.this.timeout)) {
                            break;
                        }
                        this.socket.setSoTimeout((int) (((long) ScanThreadSNMP.this.timeout) - currentTimeMillis2));
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[4096], 4096);
                        try {
                            this.socket.receive(datagramPacket);
                            synchronized (ScanThreadSNMP.this.packets) {
                                ScanThreadSNMP.this.packets.add(datagramPacket);
                                ScanThreadSNMP.this.packets.notifyAll();
                            }
                        } catch (SocketTimeoutException unused) {
                        } catch (IOException e) {
                            synchronized (ScanThreadSNMP.this.destroyed) {
                                if (!ScanThreadSNMP.this.destroyed[0]) {
                                    throw e;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                } catch (Throwable th) {
                    this.socket.close();
                    throw th;
                }
            }
            this.socket.close();
            synchronized (ScanThreadSNMP.this.packets) {
                ScanThreadSNMP.this.packets.notifyAll();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
            if (r3.socket.isClosed() == false) goto L_0x0021;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0020, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r3.socket.send(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
            java.lang.Thread.sleep(100);
         */
        public synchronized void send(DatagramPacket datagramPacket) {
            try {
                synchronized (ScanThreadSNMP.this.destroyed) {
                    if (ScanThreadSNMP.this.destroyed[0]) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("src: ");
                sb.append(this.socket.getLocalAddress());
                sb.append(" dst: ");
                sb.append(datagramPacket.getAddress());
                sb.append(" | ");
                sb.append(this.ia);
                App.reportThrowable(e, sb.toString());
            }
            return;
        }

        public void interrupt() {
            super.interrupt();
            this.socket.close();
        }
    }

    public ScanThreadSNMP(Context context, int i, String str, Handler handler) {
        this.timeout = i;
        this.status = handler;
        this.rq_pid = str;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        int i;
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        for (int i2 = 0; i2 < this.workers.size(); i2++) {
            DetectThread detectThread = (DetectThread) this.workers.get(i2);
            if (detectThread.isAlive()) {
                detectThread.interrupt();
            }
        }
        for (i = 0; i < this.sockets.size(); i++) {
            ((SocketThread) this.sockets.get(i)).interrupt();
        }
        interrupt();
    }

    /* access modifiers changed from: private */
    public int getNextRid() {
        int i;
        synchronized (this.rid) {
            int[] iArr = this.rid;
            iArr[0] = iArr[0] + 1;
            i = this.rid[0];
        }
        return i;
    }

    /* access modifiers changed from: private */
    public DatagramPacket prepareRequest(InetAddress inetAddress, int i, String str) throws Exception {
        SNMPSequence sNMPSequence = new SNMPSequence();
        sNMPSequence.addSNMPObject(new SNMPVariablePair(new SNMPObjectIdentifier(str), new SNMPNull()));
        SNMPPDU snmppdu = new SNMPPDU(SNMPBERCodec.SNMPGETREQUEST, i, 0, 0, sNMPSequence);
        byte[] bEREncoding = new SNMPMessage(0, "public", snmppdu).getBEREncoding();
        return new DatagramPacket(bEREncoding, bEREncoding.length, inetAddress, 161);
    }

    private String[] parseResponse(DatagramPacket datagramPacket, int i, String str) throws Exception {
        return parseResponse(datagramPacket, i, str, false);
    }

    /* access modifiers changed from: private */
    public String[] parseResponse(DatagramPacket datagramPacket, int i, String str, boolean z) throws Exception {
        SNMPPDU pdu = new SNMPMessage(SNMPBERCodec.extractNextTLV(datagramPacket.getData(), 0).value).getPDU();
        if (i != 0 && pdu.getRequestID() != i) {
            return null;
        }
        SNMPSequence varBindList = pdu.getVarBindList();
        for (int i2 = 0; i2 < varBindList.size(); i2++) {
            SNMPSequence sNMPSequence = (SNMPSequence) varBindList.getSNMPObjectAt(i2);
            String sNMPObject = sNMPSequence.getSNMPObjectAt(0).toString();
            String sNMPObject2 = sNMPSequence.getSNMPObjectAt(1).toString();
            if (sNMPObject2 != null && (sNMPObject2.equalsIgnoreCase("null") || (!z && sNMPObject2.length() == 0))) {
                sNMPObject2 = null;
            }
            if (str.equals(sNMPObject)) {
                return new String[]{sNMPObject2};
            }
        }
        return new String[]{null};
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0012, code lost:
        r2 = getNextRid();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001a, code lost:
        if (r8.isClosed() == false) goto L_0x001d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001c, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
        r8.send(prepareRequest(r9, r2, r10));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0024, code lost:
        r4 = r7.destroyed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0026, code lost:
        monitor-enter(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002b, code lost:
        if (r7.destroyed[0] == false) goto L_0x002f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x002d, code lost:
        monitor-exit(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x002e, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x002f, code lost:
        monitor-exit(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0030, code lost:
        r6 = new java.net.DatagramPacket(new byte[com.dynamixsoftware.printershare.smb.SmbConstants.FLAGS2_EXTENDED_SECURITY_NEGOTIATION], com.dynamixsoftware.printershare.smb.SmbConstants.FLAGS2_EXTENDED_SECURITY_NEGOTIATION);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
        r8.receive(r6);
        r4 = parseResponse(r6, r2, r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0040, code lost:
        if (r4 != null) goto L_0x0043;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0045, code lost:
        return r4[0];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0046, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0049, code lost:
        monitor-enter(r7.destroyed);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x004e, code lost:
        if (r7.destroyed[0] != false) goto L_0x0050;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0052, code lost:
        throw r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0056, code lost:
        r1 = r1 + 1;
     */
    public String getData(DatagramSocket datagramSocket, InetAddress inetAddress, String str) throws Exception {
        int i = 0;
        while (i < 3) {
            synchronized (this.destroyed) {
                if (this.destroyed[0]) {
                    return null;
                }
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:110:0x0144 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x0168  */
    /* JADX WARNING: Removed duplicated region for block: B:135:0x0141 A[EDGE_INSN: B:135:0x0141->B:108:0x0141 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x00f6  */
    public void run() {
        String str;
        HashSet hashSet;
        Object[] array;
        Message message = new Message();
        message.what = 1;
        message.arg1 = 1;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            str = null;
            try {
                Vector activeNetworkInterfaces = App.getActiveNetworkInterfaces();
                if (activeNetworkInterfaces == null || activeNetworkInterfaces.size() != 0) {
                    SocketThread socketThread = new SocketThread(null);
                    socketThread.start();
                    this.sockets.add(socketThread);
                    if (activeNetworkInterfaces != null) {
                        for (int i = 0; i < activeNetworkInterfaces.size(); i++) {
                            NetworkInterfaceData networkInterfaceData = (NetworkInterfaceData) activeNetworkInterfaces.get(i);
                            if (networkInterfaceData.is_multicast && networkInterfaceData.ipv6_linklocal_address != null) {
                                try {
                                    SocketThread socketThread2 = new SocketThread(networkInterfaceData.ipv6_linklocal_address);
                                    socketThread2.start();
                                    this.sockets.add(socketThread2);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    App.reportThrowable(e);
                                }
                            }
                        }
                    }
                } else {
                    Message message2 = new Message();
                    message2.what = 4;
                    message2.arg1 = 1;
                    this.status.sendMessage(message2);
                    return;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e2.getMessage());
                String sb2 = sb.toString();
                App.reportThrowable(e2);
                str = sb2;
            }
        }
        array = this.packets.toArray();
        this.packets.clear();
        if (array.length != 0) {
            synchronized (this.destroyed) {
                this.destroyed[0] = true;
            }
            if (str == null) {
                Message message3 = new Message();
                message3.what = 3;
                message3.arg1 = 1;
                Bundle bundle = new Bundle();
                bundle.putString("message", str);
                message3.setData(bundle);
                this.status.sendMessage(message3);
            } else {
                Message message4 = new Message();
                message4.what = 4;
                message4.arg1 = 1;
                this.status.sendMessage(message4);
            }
        }
        int i2 = 0;
        while (true) {
            if (i2 >= array.length) {
                break;
            }
            synchronized (this.destroyed) {
                if (this.destroyed[0]) {
                    break;
                }
                DatagramPacket datagramPacket = (DatagramPacket) array[i2];
                InetAddress address = datagramPacket.getAddress();
                if (!hashSet.contains(address)) {
                    hashSet.add(address);
                    DetectThread detectThread = new DetectThread(datagramPacket);
                    synchronized (this.destroyed) {
                        if (!this.destroyed[0]) {
                            this.workers.add(detectThread);
                            detectThread.start();
                        }
                    }
                }
                i2++;
            }
        }
        while (true) {
        }
        if (str == null) {
            this.sender.start();
            hashSet = new HashSet();
            while (true) {
                synchronized (this.destroyed) {
                    if (this.destroyed[0]) {
                        break;
                    }
                    while (true) {
                        synchronized (this.packets) {
                            if (this.packets.size() != 0) {
                                break;
                            }
                            int i3 = 0;
                            for (int i4 = 0; i4 < this.sockets.size(); i4++) {
                                if (((SocketThread) this.sockets.get(i4)).isAlive()) {
                                    i3++;
                                }
                            }
                            if (i3 != this.sockets.size()) {
                                if (i3 <= 0) {
                                    break;
                                }
                                Thread.yield();
                            } else {
                                try {
                                    this.packets.wait();
                                    break;
                                } catch (InterruptedException unused) {
                                }
                            }
                        }
                    }
                    array = this.packets.toArray();
                    this.packets.clear();
                    if (array.length != 0) {
                    }
                }
            }
            while (true) {
            }
        }
        synchronized (this.destroyed) {
        }
        if (str == null) {
        }
    }
}
