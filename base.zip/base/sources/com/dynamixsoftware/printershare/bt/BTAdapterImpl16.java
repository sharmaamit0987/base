package com.dynamixsoftware.printershare.bt;

import android.bluetooth.IBluetoothDeviceCallback;
import android.bluetooth.IBluetoothDeviceCallback.Stub;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.RemoteException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.UUID;

class BTAdapterImpl16 extends BTAdapter {
    /* access modifiers changed from: private */
    public Object bd;
    /* access modifiers changed from: private */
    public Field bd_BOND_BONDED;
    private Method bd_cancelDiscovery;
    /* access modifiers changed from: private */
    public Method bd_getBondState;
    private Method bd_getRemoteClass;
    private Method bd_getRemoteName;
    /* access modifiers changed from: private */
    public Method bd_getRemoteServiceChannel;
    private Method bd_isDiscovering;
    private Method bd_isEnabled;
    private Method bd_startDiscovery;
    /* access modifiers changed from: private */
    public Class<?> rfs;
    /* access modifiers changed from: private */
    public Method rfs_connect;
    /* access modifiers changed from: private */
    public Method rfs_create;
    /* access modifiers changed from: private */
    public Method rfs_destroy;
    /* access modifiers changed from: private */
    public Method rfs_getInputStream;
    /* access modifiers changed from: private */
    public Method rfs_getOutputStream;

    static class BDC implements IBluetoothDeviceCallback {
        String address;
        IBinder binder = new Stub() {
            public void onGetRemoteServiceChannelResult(String str, int i) throws RemoteException {
                if (str.equals(BDC.this.address)) {
                    synchronized (BDC.this.ch) {
                        BDC.this.ch[0] = i;
                        BDC.this.ch.notifyAll();
                    }
                }
            }
        };
        int[] ch;

        public void onGetRemoteServiceChannelResult(String str, int i) throws RemoteException {
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [com.dynamixsoftware.printershare.bt.BTAdapterImpl16$BDC$1, android.os.IBinder] */
        /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r0v0, types: [com.dynamixsoftware.printershare.bt.BTAdapterImpl16$BDC$1, android.os.IBinder]
  assigns: [com.dynamixsoftware.printershare.bt.BTAdapterImpl16$BDC$1]
  uses: [android.os.IBinder]
  mth insns count: 5
        	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$0(DepthTraversal.java:13)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:13)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
        	at java.util.ArrayList.forEach(Unknown Source)
        	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
        	at jadx.core.ProcessClass.process(ProcessClass.java:35)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
         */
        /* JADX WARNING: Unknown variable types count: 1 */
        public BDC(String str, int[] iArr) {
            this.address = str;
            this.ch = iArr;
        }

        public IBinder asBinder() {
            return this.binder;
        }
    }

    class DeviceImpl extends BTDevice {
        private String address;
        private Integer cls;
        private String name;

        /* access modifiers changed from: 0000 */
        public BTSocket createInsecureRfcommSocket(int i) throws Exception {
            return null;
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createInsecureRfcommSocketToServiceRecord(UUID uuid) throws Exception {
            return null;
        }

        DeviceImpl(String str, String str2, Integer num) throws Exception {
            this.address = str;
            this.name = str2;
            this.cls = num;
        }

        public String getAddress() {
            return this.address;
        }

        public String getName() {
            return this.name;
        }

        public Integer getDeviceClass() {
            return this.cls;
        }

        /* access modifiers changed from: 0000 */
        public BTAdapter getAdapter() {
            return BTAdapterImpl16.this;
        }

        /* access modifiers changed from: 0000 */
        public boolean isPaired() throws Exception {
            return BTAdapterImpl16.this.bd_BOND_BONDED.get(null).equals(BTAdapterImpl16.this.bd_getBondState.invoke(BTAdapterImpl16.this.bd, new Object[]{this.address}));
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createRfcommSocketToServiceRecord(UUID uuid) throws Exception {
            BTSocket bTSocket = null;
            if (BTAdapterImpl16.this.bd_getRemoteServiceChannel == null) {
                return null;
            }
            int[] iArr = new int[1];
            synchronized (iArr) {
                Short valueOf = Short.valueOf(Short.parseShort(uuid.toString().substring(4, 8), 16));
                Method access$300 = BTAdapterImpl16.this.bd_getRemoteServiceChannel;
                Object access$000 = BTAdapterImpl16.this.bd;
                StringBuilder sb = new StringBuilder();
                sb.append(getClass().getName());
                sb.append("$BDC");
                access$300.invoke(access$000, new Object[]{this.address, valueOf, Class.forName(sb.toString()).getConstructor(new Class[]{String.class, int[].class}).newInstance(new Object[]{this.address, iArr})});
                iArr.wait(10000);
                if (iArr[0] > 0) {
                    bTSocket = createRfcommSocket(iArr[0]);
                }
            }
            return bTSocket;
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createRfcommSocket(int i) throws Exception {
            return new SocketImpl(this.address, i);
        }
    }

    class SocketImpl extends BTSocket {
        private String address;
        private int channel;
        Object sk;

        SocketImpl(String str, int i) throws Exception {
            this.address = str;
            this.channel = i;
            this.sk = BTAdapterImpl16.this.rfs.newInstance();
            BTAdapterImpl16.this.rfs_create.invoke(this.sk, new Object[0]);
        }

        /* access modifiers changed from: protected */
        public boolean connect() throws Exception {
            return ((Boolean) BTAdapterImpl16.this.rfs_connect.invoke(this.sk, new Object[]{this.address, Integer.valueOf(this.channel)})).booleanValue();
        }

        public InputStream getInputStream() throws Exception {
            return (InputStream) BTAdapterImpl16.this.rfs_getInputStream.invoke(this.sk, new Object[0]);
        }

        public OutputStream getOutputStream() throws Exception {
            return (OutputStream) BTAdapterImpl16.this.rfs_getOutputStream.invoke(this.sk, new Object[0]);
        }

        public void destroy() throws Exception {
            BTAdapterImpl16.this.rfs_destroy.invoke(this.sk, new Object[0]);
        }
    }

    private BTAdapterImpl16(Object obj) throws Exception {
        this.bd = obj;
        Class cls = obj.getClass();
        this.bd_BOND_BONDED = cls.getField("BOND_BONDED");
        this.bd_isEnabled = cls.getMethod("isEnabled", new Class[0]);
        this.bd_isDiscovering = cls.getMethod("isDiscovering", new Class[0]);
        this.bd_startDiscovery = cls.getMethod("startDiscovery", new Class[0]);
        this.bd_cancelDiscovery = cls.getMethod("cancelDiscovery", new Class[0]);
        this.bd_getRemoteName = cls.getMethod("getRemoteName", new Class[]{String.class});
        this.bd_getRemoteClass = cls.getMethod("getRemoteClass", new Class[]{String.class});
        try {
            this.bd_getRemoteServiceChannel = cls.getMethod("getRemoteServiceChannel", new Class[]{String.class, Short.TYPE, Class.forName("android.bluetooth.IBluetoothDeviceCallback")});
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
        }
        this.bd_getBondState = cls.getMethod("getBondState", new Class[]{String.class});
        Class<?> cls2 = Class.forName("android.bluetooth.RfcommSocket");
        this.rfs = cls2;
        this.rfs_create = cls2.getMethod("create", new Class[0]);
        this.rfs_connect = this.rfs.getMethod("connect", new Class[]{String.class, Integer.TYPE});
        this.rfs_getInputStream = this.rfs.getMethod("getInputStream", new Class[0]);
        this.rfs_getOutputStream = this.rfs.getMethod("getOutputStream", new Class[0]);
        this.rfs_destroy = this.rfs.getMethod("destroy", new Class[0]);
    }

    public static BTAdapter getDefault(Context context) throws Exception {
        Object systemService = context.getSystemService("bluetooth");
        if (systemService != null) {
            return new BTAdapterImpl16(systemService);
        }
        return null;
    }

    public boolean isEnabled() throws Exception {
        return ((Boolean) this.bd_isEnabled.invoke(this.bd, new Object[0])).booleanValue();
    }

    public boolean isDiscovering() throws Exception {
        return ((Boolean) this.bd_isDiscovering.invoke(this.bd, new Object[0])).booleanValue();
    }

    public void doStartDiscovery() throws Exception {
        this.bd_startDiscovery.invoke(this.bd, new Object[0]);
    }

    public void doCancelDiscovery() throws Exception {
        this.bd_cancelDiscovery.invoke(this.bd, new Object[0]);
    }

    public IntentFilter getDiscoveryIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.intent.action.REMOTE_DEVICE_FOUND");
        intentFilter.addAction("android.bluetooth.intent.action.REMOTE_NAME_UPDATED");
        intentFilter.addAction("android.bluetooth.intent.action.REMOTE_CLASS_UPDATED");
        return intentFilter;
    }

    public IntentFilter getBondStateChangedIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.intent.action.BOND_STATE_CHANGED_ACTION");
        return intentFilter;
    }

    public IntentFilter getConnectionStateIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.intent.action.REMOTE_DEVICE_CONNECTED");
        intentFilter.addAction("android.bluetooth.intent.action.REMOTE_DEVICE_DISCONNECTED");
        return intentFilter;
    }

    public String getDeviceAddressFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            return intent.getStringExtra("android.bluetooth.intent.ADDRESS");
        }
        return null;
    }

    public String getDeviceNameFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            return intent.getStringExtra("android.bluetooth.intent.NAME");
        }
        return null;
    }

    public Integer getDeviceClassFromIntentResult(Intent intent) throws Exception {
        if (intent == null) {
            return null;
        }
        int intExtra = intent.getIntExtra("android.bluetooth.intent.CLASS", -1);
        if (intExtra != -1) {
            return Integer.valueOf(intExtra);
        }
        return null;
    }

    public Integer getDeviceBondStateChangedReasonFromIntentResult(Intent intent) throws Exception {
        if (intent == null) {
            return null;
        }
        int intExtra = intent.getIntExtra("android.bluetooth.intent.REASON", -1);
        if (intExtra != -1) {
            return Integer.valueOf(intExtra);
        }
        return null;
    }

    public Boolean getDeviceConnectionStateFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            if ("android.bluetooth.intent.action.REMOTE_DEVICE_CONNECTED".equals(intent.getAction())) {
                return Boolean.valueOf(true);
            }
            if ("android.bluetooth.intent.action.REMOTE_DEVICE_DISCONNECTED".equals(intent.getAction())) {
                return Boolean.valueOf(false);
            }
        }
        return null;
    }

    public BTDevice getRemoteDevice(String str) throws Exception {
        return new DeviceImpl(str, (String) this.bd_getRemoteName.invoke(this.bd, new Object[]{str}), (Integer) this.bd_getRemoteClass.invoke(this.bd, new Object[]{str}));
    }

    public ArrayList<BTDevice> getBondedDevices() throws Exception {
        return new ArrayList<>();
    }
}
