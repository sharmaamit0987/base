package com.dynamixsoftware.printershare.bt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Looper;
import com.dynamixsoftware.printershare.App;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.UUID;

class BTAdapterImpl20 extends BTAdapter {
    private Object ba;
    private Method ba_cancelDiscovery;
    private Method ba_getRemoteDevice;
    private Method ba_isDiscovering;
    private Method ba_isEnabled;
    private Method ba_startDiscovery;
    private Method bc_getDeviceClass;
    private Class<?> bcc;
    /* access modifiers changed from: private */
    public Field bd_BOND_BONDED;
    /* access modifiers changed from: private */
    public Method bd_createInsecureRfcommSocket;
    /* access modifiers changed from: private */
    public Method bd_createInsecureRfcommSocketToServiceRecord;
    /* access modifiers changed from: private */
    public Method bd_createRfcommSocket;
    /* access modifiers changed from: private */
    public Method bd_createRfcommSocketToServiceRecord;
    private Method bd_getAddress = this.bdc.getMethod("getAddress", new Class[0]);
    private Method bd_getBluetoothClass = this.bdc.getMethod("getBluetoothClass", new Class[0]);
    /* access modifiers changed from: private */
    public Method bd_getBondState = this.bdc.getMethod("getBondState", new Class[0]);
    private Method bd_getName = this.bdc.getMethod("getName", new Class[0]);
    /* access modifiers changed from: private */
    public Method bd_getServiceChannel;
    private Class<?> bdc;
    /* access modifiers changed from: private */
    public Method bs_close;
    /* access modifiers changed from: private */
    public Method bs_connect;
    /* access modifiers changed from: private */
    public Method bs_getInputStream;
    /* access modifiers changed from: private */
    public Method bs_getOutputStream;
    private Class<?> bsc;

    class DeviceImpl extends BTDevice {
        private String address;
        private Object bd;
        private Integer cls;
        private String name;

        DeviceImpl(Object obj, String str, String str2, Integer num) throws Exception {
            this.bd = obj;
            this.address = str;
            this.name = str2;
            this.cls = num;
        }

        public String getAddress() {
            return this.address;
        }

        public String getName() {
            return this.name;
        }

        public Integer getDeviceClass() {
            return this.cls;
        }

        /* access modifiers changed from: 0000 */
        public BTAdapter getAdapter() {
            return BTAdapterImpl20.this;
        }

        /* access modifiers changed from: 0000 */
        public boolean isPaired() throws Exception {
            return BTAdapterImpl20.this.bd_BOND_BONDED.get(null).equals(BTAdapterImpl20.this.bd_getBondState.invoke(this.bd, new Object[0]));
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createInsecureRfcommSocketToServiceRecord(UUID uuid) throws Exception {
            if (BTAdapterImpl20.this.bd_getServiceChannel != null) {
                try {
                    int intValue = ((Integer) BTAdapterImpl20.this.bd_getServiceChannel.invoke(this.bd, new Object[]{Class.forName("android.os.ParcelUuid").getConstructor(new Class[]{UUID.class}).newInstance(new Object[]{uuid})})).intValue();
                    if (intValue > 0) {
                        return new SocketImpl(BTAdapterImpl20.this.bd_createInsecureRfcommSocket.invoke(this.bd, new Object[]{Integer.valueOf(intValue)}));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            if (BTAdapterImpl20.this.bd_createInsecureRfcommSocketToServiceRecord == null) {
                return null;
            }
            BTAdapterImpl20 bTAdapterImpl20 = BTAdapterImpl20.this;
            return new SocketImpl(bTAdapterImpl20.bd_createInsecureRfcommSocketToServiceRecord.invoke(this.bd, new Object[]{uuid}));
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createRfcommSocketToServiceRecord(UUID uuid) throws Exception {
            if (BTAdapterImpl20.this.bd_getServiceChannel != null) {
                try {
                    int intValue = ((Integer) BTAdapterImpl20.this.bd_getServiceChannel.invoke(this.bd, new Object[]{Class.forName("android.os.ParcelUuid").getConstructor(new Class[]{UUID.class}).newInstance(new Object[]{uuid})})).intValue();
                    if (intValue > 0) {
                        return new SocketImpl(BTAdapterImpl20.this.bd_createRfcommSocket.invoke(this.bd, new Object[]{Integer.valueOf(intValue)}));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            BTAdapterImpl20 bTAdapterImpl20 = BTAdapterImpl20.this;
            return new SocketImpl(bTAdapterImpl20.bd_createRfcommSocketToServiceRecord.invoke(this.bd, new Object[]{uuid}));
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createInsecureRfcommSocket(int i) throws Exception {
            if (BTAdapterImpl20.this.bd_createInsecureRfcommSocket == null) {
                return null;
            }
            BTAdapterImpl20 bTAdapterImpl20 = BTAdapterImpl20.this;
            return new SocketImpl(bTAdapterImpl20.bd_createInsecureRfcommSocket.invoke(this.bd, new Object[]{Integer.valueOf(i)}));
        }

        /* access modifiers changed from: 0000 */
        public BTSocket createRfcommSocket(int i) throws Exception {
            if (BTAdapterImpl20.this.bd_createRfcommSocket == null) {
                return null;
            }
            BTAdapterImpl20 bTAdapterImpl20 = BTAdapterImpl20.this;
            return new SocketImpl(bTAdapterImpl20.bd_createRfcommSocket.invoke(this.bd, new Object[]{Integer.valueOf(i)}));
        }
    }

    class SocketImpl extends BTSocket {
        Object sk;

        SocketImpl(Object obj) throws Exception {
            this.sk = obj;
        }

        /* access modifiers changed from: protected */
        public boolean connect() throws Exception {
            BTAdapterImpl20.this.bs_connect.invoke(this.sk, new Object[0]);
            return true;
        }

        public InputStream getInputStream() throws Exception {
            return (InputStream) BTAdapterImpl20.this.bs_getInputStream.invoke(this.sk, new Object[0]);
        }

        public OutputStream getOutputStream() throws Exception {
            return (OutputStream) BTAdapterImpl20.this.bs_getOutputStream.invoke(this.sk, new Object[0]);
        }

        public void destroy() throws Exception {
            BTAdapterImpl20.this.bs_close.invoke(this.sk, new Object[0]);
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|7|8|9|10|11|13) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0091 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x00c1 */
    private BTAdapterImpl20(Object obj) throws Exception {
        this.ba = obj;
        Class cls = obj.getClass();
        this.ba_isEnabled = cls.getMethod("isEnabled", new Class[0]);
        this.ba_isDiscovering = cls.getMethod("isDiscovering", new Class[0]);
        this.ba_startDiscovery = cls.getMethod("startDiscovery", new Class[0]);
        this.ba_cancelDiscovery = cls.getMethod("cancelDiscovery", new Class[0]);
        this.ba_getRemoteDevice = cls.getMethod("getRemoteDevice", new Class[]{String.class});
        Class<?> cls2 = Class.forName("android.bluetooth.BluetoothDevice");
        this.bdc = cls2;
        this.bd_BOND_BONDED = cls2.getField("BOND_BONDED");
        this.bd_createRfcommSocket = this.bdc.getMethod("createRfcommSocket", new Class[]{Integer.TYPE});
        try {
            this.bd_createInsecureRfcommSocket = this.bdc.getMethod("createInsecureRfcommSocket", new Class[]{Integer.TYPE});
        } catch (NoSuchMethodException unused) {
        }
        this.bd_createRfcommSocketToServiceRecord = this.bdc.getMethod("createRfcommSocketToServiceRecord", new Class[]{UUID.class});
        this.bd_createInsecureRfcommSocketToServiceRecord = this.bdc.getMethod("createInsecureRfcommSocketToServiceRecord", new Class[]{UUID.class});
        this.bd_getServiceChannel = this.bdc.getMethod("getServiceChannel", new Class[]{Class.forName("android.os.ParcelUuid")});
        Class<?> cls3 = Class.forName("android.bluetooth.BluetoothClass");
        this.bcc = cls3;
        this.bc_getDeviceClass = cls3.getMethod("getDeviceClass", new Class[0]);
        Class<?> cls4 = Class.forName("android.bluetooth.BluetoothSocket");
        this.bsc = cls4;
        this.bs_connect = cls4.getMethod("connect", new Class[0]);
        this.bs_getInputStream = this.bsc.getMethod("getInputStream", new Class[0]);
        this.bs_getOutputStream = this.bsc.getMethod("getOutputStream", new Class[0]);
        this.bs_close = this.bsc.getMethod("close", new Class[0]);
    }

    public static BTAdapter getDefault(Context context) throws Exception {
        Object obj;
        try {
            Class cls = Class.forName("android.bluetooth.BluetoothAdapter");
            if (Looper.myLooper() == null) {
                Looper.prepare();
            }
            obj = cls.getMethod("getDefaultAdapter", new Class[0]).invoke(null, new Object[0]);
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            obj = null;
        }
        if (obj != null) {
            return new BTAdapterImpl20(obj);
        }
        return null;
    }

    public boolean isEnabled() throws Exception {
        Object obj = this.ba;
        return obj != null && ((Boolean) this.ba_isEnabled.invoke(obj, new Object[0])).booleanValue();
    }

    public boolean isDiscovering() throws Exception {
        return ((Boolean) this.ba_isDiscovering.invoke(this.ba, new Object[0])).booleanValue();
    }

    public void doStartDiscovery() throws Exception {
        this.ba_startDiscovery.invoke(this.ba, new Object[0]);
    }

    public void doCancelDiscovery() throws Exception {
        this.ba_cancelDiscovery.invoke(this.ba, new Object[0]);
    }

    public IntentFilter getDiscoveryIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.device.action.FOUND");
        intentFilter.addAction("android.bluetooth.device.action.NAME_CHANGED");
        intentFilter.addAction("android.bluetooth.device.action.CLASS_CHANGED");
        return intentFilter;
    }

    public IntentFilter getBondStateChangedIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.device.action.BOND_STATE_CHANGED");
        return intentFilter;
    }

    public IntentFilter getConnectionStateIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.device.action.ACL_CONNECTED");
        intentFilter.addAction("android.bluetooth.device.action.ACL_DISCONNECTED");
        return intentFilter;
    }

    public String getDeviceAddressFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            Object cast = this.bdc.cast(intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE"));
            if (cast != null) {
                return (String) this.bd_getAddress.invoke(cast, new Object[0]);
            }
        }
        return null;
    }

    public String getDeviceNameFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            return intent.getStringExtra("android.bluetooth.device.extra.NAME");
        }
        return null;
    }

    public Integer getDeviceBondStateChangedReasonFromIntentResult(Intent intent) throws Exception {
        if (intent == null) {
            return null;
        }
        int intExtra = intent.getIntExtra("android.bluetooth.device.extra.REASON", -1);
        if (intExtra != -1) {
            return Integer.valueOf(intExtra);
        }
        return null;
    }

    public Integer getDeviceClassFromIntentResult(Intent intent) throws Exception {
        if (intent == null) {
            return null;
        }
        Object cast = this.bcc.cast(intent.getParcelableExtra("android.bluetooth.device.extra.CLASS"));
        if (cast != null) {
            return (Integer) this.bc_getDeviceClass.invoke(cast, new Object[0]);
        }
        return null;
    }

    public Boolean getDeviceConnectionStateFromIntentResult(Intent intent) throws Exception {
        if (intent != null) {
            if ("android.bluetooth.device.action.ACL_CONNECTED".equals(intent.getAction())) {
                return Boolean.valueOf(true);
            }
            if ("android.bluetooth.device.action.ACL_DISCONNECTED".equals(intent.getAction())) {
                return Boolean.valueOf(false);
            }
        }
        return null;
    }

    public BTDevice getRemoteDevice(String str) throws Exception {
        Object cast = this.bdc.cast(this.ba_getRemoteDevice.invoke(this.ba, new Object[]{str}));
        String str2 = (String) this.bd_getName.invoke(cast, new Object[0]);
        Object cast2 = this.bcc.cast(this.bd_getBluetoothClass.invoke(cast, new Object[0]));
        DeviceImpl deviceImpl = new DeviceImpl(cast, str, str2, cast2 != null ? (Integer) this.bc_getDeviceClass.invoke(cast2, new Object[0]) : null);
        return deviceImpl;
    }

    public ArrayList<BTDevice> getBondedDevices() throws Exception {
        ArrayList<BTDevice> arrayList = new ArrayList<>();
        for (BluetoothDevice bluetoothDevice : ((BluetoothAdapter) this.ba).getBondedDevices()) {
            DeviceImpl deviceImpl = new DeviceImpl(bluetoothDevice, bluetoothDevice.getAddress(), bluetoothDevice.getName(), Integer.valueOf(bluetoothDevice.getBluetoothClass().getDeviceClass()));
            arrayList.add(deviceImpl);
        }
        return arrayList;
    }
}
