package com.dynamixsoftware.printershare.bt;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build.VERSION;
import java.util.ArrayList;

public abstract class BTAdapter {
    /* access modifiers changed from: 0000 */
    public abstract void doCancelDiscovery() throws Exception;

    /* access modifiers changed from: 0000 */
    public abstract void doStartDiscovery() throws Exception;

    public abstract IntentFilter getBondStateChangedIntentFilter();

    public abstract ArrayList<BTDevice> getBondedDevices() throws Exception;

    public abstract IntentFilter getConnectionStateIntentFilter();

    public abstract String getDeviceAddressFromIntentResult(Intent intent) throws Exception;

    public abstract Integer getDeviceBondStateChangedReasonFromIntentResult(Intent intent) throws Exception;

    public abstract Integer getDeviceClassFromIntentResult(Intent intent) throws Exception;

    public abstract Boolean getDeviceConnectionStateFromIntentResult(Intent intent) throws Exception;

    public abstract String getDeviceNameFromIntentResult(Intent intent) throws Exception;

    public abstract IntentFilter getDiscoveryIntentFilter();

    public abstract BTDevice getRemoteDevice(String str) throws Exception;

    public abstract boolean isDiscovering() throws Exception;

    public abstract boolean isEnabled() throws Exception;

    public static BTAdapter getDefault(Context context) throws Exception {
        if (Integer.parseInt(VERSION.SDK) > 4) {
            return BTAdapterImpl20.getDefault(context);
        }
        return BTAdapterImpl16.getDefault(context);
    }

    public void startDiscovery() throws Exception {
        doStartDiscovery();
        int i = 0;
        while (i < 3) {
            try {
                Thread.sleep(500);
                if (!isDiscovering()) {
                    Thread.sleep(500);
                    i++;
                } else {
                    return;
                }
            } catch (InterruptedException unused) {
                return;
            }
        }
    }

    public void cancelDiscovery() throws Exception {
        doCancelDiscovery();
        int i = 0;
        while (i < 3) {
            try {
                Thread.sleep(500);
                if (isDiscovering()) {
                    Thread.sleep(500);
                    i++;
                } else {
                    return;
                }
            } catch (InterruptedException unused) {
                return;
            }
        }
    }
}
