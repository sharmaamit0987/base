package com.dynamixsoftware.printershare.bt;

import java.io.InputStream;
import java.io.OutputStream;

public abstract class BTSocket {
    /* access modifiers changed from: 0000 */
    public abstract boolean connect() throws Exception;

    public abstract void destroy() throws Exception;

    public abstract InputStream getInputStream() throws Exception;

    public abstract OutputStream getOutputStream() throws Exception;
}
