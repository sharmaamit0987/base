package com.dynamixsoftware.printershare.bt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.dynamixsoftware.printershare.App;
import java.util.UUID;

public abstract class BTDevice {
    public static final UUID UUID_OBEX_OPP = UUID.fromString("00001105-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_RFCOMM = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    /* access modifiers changed from: 0000 */
    public abstract BTSocket createInsecureRfcommSocket(int i) throws Exception;

    /* access modifiers changed from: 0000 */
    public abstract BTSocket createInsecureRfcommSocketToServiceRecord(UUID uuid) throws Exception;

    /* access modifiers changed from: 0000 */
    public abstract BTSocket createRfcommSocket(int i) throws Exception;

    /* access modifiers changed from: 0000 */
    public abstract BTSocket createRfcommSocketToServiceRecord(UUID uuid) throws Exception;

    /* access modifiers changed from: 0000 */
    public abstract BTAdapter getAdapter();

    public abstract String getAddress();

    public abstract Integer getDeviceClass();

    public abstract String getName();

    /* access modifiers changed from: 0000 */
    public abstract boolean isPaired() throws Exception;

    public BTSocket connectRfcommSocket(Context context) throws Exception {
        return connectRfcommSocket(context, UUID_RFCOMM);
    }

    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r5v1 */
    /* JADX WARNING: type inference failed for: r5v2, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v3 */
    /* JADX WARNING: type inference failed for: r5v4 */
    /* JADX WARNING: type inference failed for: r5v5, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v6 */
    /* JADX WARNING: type inference failed for: r5v7, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v8, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v9 */
    /* JADX WARNING: type inference failed for: r5v10 */
    /* JADX WARNING: type inference failed for: r5v11 */
    /* JADX WARNING: type inference failed for: r5v12, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v13 */
    /* JADX WARNING: type inference failed for: r5v14 */
    /* JADX WARNING: type inference failed for: r5v15, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v16 */
    /* JADX WARNING: type inference failed for: r5v17, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v18 */
    /* JADX WARNING: type inference failed for: r5v19 */
    /* JADX WARNING: type inference failed for: r5v22 */
    /* JADX WARNING: type inference failed for: r5v23, types: [com.dynamixsoftware.printershare.bt.BTSocket] */
    /* JADX WARNING: type inference failed for: r5v24, types: [java.lang.Throwable, java.lang.Exception] */
    /* JADX WARNING: type inference failed for: r5v25, types: [java.lang.Exception] */
    /* JADX WARNING: type inference failed for: r5v27, types: [java.lang.Exception] */
    /* JADX WARNING: type inference failed for: r5v28, types: [android.content.IntentFilter] */
    /* JADX WARNING: type inference failed for: r5v29 */
    /* JADX WARNING: type inference failed for: r5v30 */
    /* JADX WARNING: type inference failed for: r5v31 */
    /* JADX WARNING: type inference failed for: r5v32 */
    /* JADX WARNING: type inference failed for: r5v33 */
    /* JADX WARNING: type inference failed for: r5v34 */
    /* JADX WARNING: type inference failed for: r5v35 */
    /* JADX WARNING: type inference failed for: r5v36 */
    /* JADX WARNING: type inference failed for: r5v37 */
    /* JADX WARNING: type inference failed for: r5v38 */
    /* JADX WARNING: type inference failed for: r5v39 */
    /* JADX WARNING: type inference failed for: r5v40 */
    /* JADX WARNING: type inference failed for: r5v41 */
    /* JADX WARNING: type inference failed for: r5v42 */
    /* JADX WARNING: type inference failed for: r5v43 */
    /* JADX WARNING: type inference failed for: r5v44 */
    /* JADX WARNING: type inference failed for: r5v45 */
    /* JADX WARNING: type inference failed for: r5v46 */
    /* JADX WARNING: type inference failed for: r5v47 */
    /* JADX WARNING: type inference failed for: r5v48 */
    /* JADX WARNING: type inference failed for: r5v49 */
    /* JADX WARNING: type inference failed for: r5v50 */
    /* JADX WARNING: type inference failed for: r5v51 */
    /* JADX WARNING: type inference failed for: r5v52 */
    /* JADX WARNING: type inference failed for: r5v53 */
    /* JADX WARNING: type inference failed for: r5v54 */
    /* JADX WARNING: type inference failed for: r5v55 */
    /* JADX WARNING: type inference failed for: r5v56 */
    /* JADX WARNING: type inference failed for: r5v57 */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x012c, code lost:
        if (r6 == null) goto L_0x0139;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:124:?, code lost:
        r13.unregisterReceiver(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x0132, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x0133, code lost:
        r13.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x01c2, code lost:
        if (r6 == null) goto L_0x01cf;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:?, code lost:
        r13.unregisterReceiver(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x01c8, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:185:0x01c9, code lost:
        r13.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:189:0x01d1, code lost:
        r5 = r5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00a9, code lost:
        if (r6 == null) goto L_0x00b6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:?, code lost:
        r13.unregisterReceiver(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00af, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x00b0, code lost:
        r13.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x00b8, code lost:
        r5 = r5;
     */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r5v0
  assigns: []
  uses: []
  mth insns count: 289
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x0118 A[SYNTHETIC, Splitter:B:110:0x0118] */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x0126 A[Catch:{ Exception -> 0x005f, all -> 0x0033 }] */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0158 A[SYNTHETIC, Splitter:B:143:0x0158] */
    /* JADX WARNING: Removed duplicated region for block: B:226:0x0230 A[SYNTHETIC, Splitter:B:226:0x0230] */
    /* JADX WARNING: Removed duplicated region for block: B:232:0x023d A[SYNTHETIC, Splitter:B:232:0x023d] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x003c A[SYNTHETIC, Splitter:B:23:0x003c] */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x00bf  */
    /* JADX WARNING: Unknown variable types count: 17 */
    public BTSocket connectRfcommSocket(Context context, UUID uuid) throws Exception {
        boolean z;
        BroadcastReceiver broadcastReceiver;
        BroadcastReceiver broadcastReceiver2 = null;
        try {
            z = isPaired();
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
            z = false;
        } catch (Throwable th) {
            th = th;
            if (broadcastReceiver2 != null) {
                try {
                    context.unregisterReceiver(broadcastReceiver2);
                } catch (Exception e2) {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                }
            }
            throw th;
        }
        int i = 1;
        final Integer[] numArr = new Integer[1];
        if (!z) {
            try {
                final BTAdapter adapter = getAdapter();
                broadcastReceiver = new BroadcastReceiver() {
                    public void onReceive(Context context, Intent intent) {
                        try {
                            synchronized (numArr) {
                                if (BTDevice.this.getAddress().equals(adapter.getDeviceAddressFromIntentResult(intent))) {
                                    numArr[0] = adapter.getDeviceBondStateChangedReasonFromIntentResult(intent);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            App.reportThrowable(e);
                        }
                    }
                };
                try {
                    r5 = adapter.getBondStateChangedIntentFilter();
                    context.registerReceiver(broadcastReceiver, r5);
                    r5 = r5;
                } catch (Exception e3) {
                    r5 = e3;
                }
            } catch (Exception e4) {
                broadcastReceiver = null;
                r5 = e4;
                try {
                    r5.printStackTrace();
                    App.reportThrowable(r5);
                    r5 = r5;
                    if (z) {
                    }
                } catch (Exception e5) {
                    e5.printStackTrace();
                    synchronized (numArr) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(getAddress());
                        sb.append("|");
                        sb.append(getName());
                        sb.append("|");
                        sb.append(numArr[0]);
                        App.reportThrowable(e5, sb.toString());
                        r5 = r5;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    broadcastReceiver2 = broadcastReceiver;
                }
                r5 = r5;
                r5 = createRfcommSocketToServiceRecord(uuid);
                if (r5 != 0) {
                }
                r5 = r5;
                Thread.sleep(250);
                r5 = r5;
                if (r5 != 0) {
                }
                if (!z) {
                }
                String name = getName();
                i = 3;
                if (!z) {
                }
                try {
                    r5 = r5;
                    r5 = createRfcommSocket(i);
                    if (r5 != 0) {
                    }
                    r5 = r5;
                    Thread.sleep(250);
                    r5 = r5;
                } catch (Exception e6) {
                    e6.printStackTrace();
                    synchronized (numArr) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(getAddress());
                        sb2.append("|");
                        sb2.append(getName());
                        sb2.append("|");
                        sb2.append(numArr[0]);
                        App.reportThrowable(e6, sb2.toString());
                        r5 = r5;
                    }
                } catch (Throwable th3) {
                    Thread.sleep(250);
                    throw th3;
                }
                if (r5 != 0) {
                }
                if (broadcastReceiver != null) {
                }
                return null;
            }
        } else {
            broadcastReceiver = null;
        }
        if (z) {
            try {
                r5 = r5;
                r5 = createInsecureRfcommSocketToServiceRecord(uuid);
                if (r5 != 0) {
                    try {
                        if (r5.connect()) {
                            r5 = r5;
                            Thread.sleep(250);
                            r5 = r5;
                            if (broadcastReceiver != null) {
                                try {
                                    context.unregisterReceiver(broadcastReceiver);
                                } catch (Exception e7) {
                                    e7.printStackTrace();
                                    App.reportThrowable(e7);
                                }
                            }
                            return r5;
                        }
                    } catch (Throwable th4) {
                        th = th4;
                        Thread.sleep(250);
                        throw th;
                    }
                }
                r5 = r5;
                Thread.sleep(250);
                r5 = r5;
                if (r5 != 0) {
                    try {
                        r5.destroy();
                    } catch (Exception e8) {
                        e8.printStackTrace();
                        App.reportThrowable(e8);
                    }
                    r5 = 0;
                }
                synchronized (numArr) {
                    if (numArr[0] != null) {
                    }
                }
            } catch (Throwable th5) {
                th = th5;
                Thread.sleep(250);
                throw th;
            }
        } else {
            r5 = 0;
        }
        try {
            r5 = r5;
            r5 = createRfcommSocketToServiceRecord(uuid);
            if (r5 != 0 || !r5.connect()) {
                r5 = r5;
                Thread.sleep(250);
                r5 = r5;
                if (r5 != 0) {
                    try {
                        r5.destroy();
                    } catch (Exception e9) {
                        e9.printStackTrace();
                        App.reportThrowable(e9);
                    }
                    r5 = 0;
                }
                if (!z) {
                    synchronized (numArr) {
                        if (numArr[0] != null) {
                        }
                    }
                }
                String name2 = getName();
                if (name2 != null && (name2.startsWith("OJL411") || name2.startsWith("OJL511"))) {
                    i = 3;
                }
                if (!z) {
                    try {
                        r5 = createInsecureRfcommSocket(i);
                        if (r5 == 0 || !r5.connect()) {
                            r5 = r5;
                            Thread.sleep(250);
                            r5 = r5;
                            if (r5 != 0) {
                                try {
                                    r5.destroy();
                                } catch (Exception e10) {
                                    e10.printStackTrace();
                                    App.reportThrowable(e10);
                                }
                                r5 = 0;
                            }
                            synchronized (numArr) {
                                if (numArr[0] != null) {
                                }
                            }
                        } else {
                            r5 = r5;
                            Thread.sleep(250);
                            r5 = r5;
                            if (broadcastReceiver != null) {
                                try {
                                    context.unregisterReceiver(broadcastReceiver);
                                } catch (Exception e11) {
                                    e11.printStackTrace();
                                    App.reportThrowable(e11);
                                }
                            }
                            return r5;
                        }
                    } catch (Exception e12) {
                        e12.printStackTrace();
                        synchronized (numArr) {
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(getAddress());
                            sb3.append("|");
                            sb3.append(getName());
                            sb3.append("|");
                            sb3.append(numArr[0]);
                            App.reportThrowable(e12, sb3.toString());
                            r5 = r5;
                        }
                    } catch (Throwable th6) {
                        Thread.sleep(250);
                        throw th6;
                    }
                }
                r5 = r5;
                r5 = createRfcommSocket(i);
                if (r5 != 0 || !r5.connect()) {
                    r5 = r5;
                    Thread.sleep(250);
                    r5 = r5;
                    if (r5 != 0) {
                        try {
                            r5.destroy();
                        } catch (Exception e13) {
                            e13.printStackTrace();
                            App.reportThrowable(e13);
                        }
                    }
                    if (broadcastReceiver != null) {
                        try {
                            context.unregisterReceiver(broadcastReceiver);
                        } catch (Exception e14) {
                            e14.printStackTrace();
                            App.reportThrowable(e14);
                        }
                    }
                    return null;
                }
                r5 = r5;
                Thread.sleep(250);
                r5 = r5;
                if (broadcastReceiver != null) {
                    try {
                        context.unregisterReceiver(broadcastReceiver);
                    } catch (Exception e15) {
                        e15.printStackTrace();
                        App.reportThrowable(e15);
                    }
                }
                return r5;
            }
            r5 = r5;
            Thread.sleep(250);
            r5 = r5;
            if (broadcastReceiver != null) {
                try {
                    context.unregisterReceiver(broadcastReceiver);
                } catch (Exception e16) {
                    e16.printStackTrace();
                    App.reportThrowable(e16);
                }
            }
            return r5;
        } catch (Exception e17) {
            e17.printStackTrace();
            synchronized (numArr) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append(getAddress());
                sb4.append("|");
                sb4.append(getName());
                sb4.append("|");
                sb4.append(numArr[0]);
                App.reportThrowable(e17, sb4.toString());
                r5 = r5;
            }
        } catch (Throwable th7) {
            Thread.sleep(250);
            throw th7;
        }
        return null;
        return null;
        return null;
    }
}
