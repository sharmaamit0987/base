package com.dynamixsoftware.printershare;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.bjnp.BJNPSocket;
import com.dynamixsoftware.printershare.bt.BTAdapter;
import com.dynamixsoftware.printershare.bt.BTDevice;
import com.dynamixsoftware.printershare.bt.BTSocket;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.ipp.IppAttribute;
import com.dynamixsoftware.printershare.ipp.IppConnection;
import com.dynamixsoftware.printershare.ipp.IppMessage;
import com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication;
import com.dynamixsoftware.printershare.smb.SmbAuthException;
import com.dynamixsoftware.printershare.smb.SmbFile;
import com.flurry.android.FlurryAgent;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.UUID;
import java.util.Vector;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class ActivityLocalPrinters extends ActivityCore {
    private static final int SCAN_TYPE_BT = 1;
    private static final int SCAN_TYPE_USB = 2;
    private static final int SCAN_TYPE_WIFI = 0;
    /* access modifiers changed from: private */
    public static Printer xprn;
    /* access modifiers changed from: private */
    public PrinterAdapter adapter;
    /* access modifiers changed from: private */
    public AlertDialog dialog_authorization;
    /* access modifiers changed from: private */
    public AlertDialog error_dialog;
    /* access modifiers changed from: private */
    public Vector<Printer> printers;
    private Handler scanProgressHandler = new Handler() {
        /* JADX WARNING: Code restructure failed: missing block: B:258:0x0416, code lost:
            r10.addAll(r6);
            r2 = r18;
            r3 = r19;
            r2.remove(r3);
         */
        public synchronized void handleMessage(Message message) {
            Vector vector;
            Vector vector2;
            int i;
            Vector vector3;
            Vector vector4;
            int i2;
            char c;
            int i3;
            Vector vector5;
            Vector vector6;
            char c2;
            int indexOf;
            int i4;
            Message message2 = message;
            synchronized (this) {
                Button button = (Button) ActivityLocalPrinters.this.findViewById(R.id.button_print);
                ActivityLocalPrinters.this.last_error = null;
                int i5 = message2.what;
                if (i5 == 1) {
                    if (button.isEnabled()) {
                        ActivityLocalPrinters.this.printers.clear();
                    }
                    button.setEnabled(false);
                    if (ActivityLocalPrinters.this.smb_stack.size() < 2) {
                        ((TextView) ActivityLocalPrinters.this.findViewById(R.id.hint1)).setText(ActivityLocalPrinters.this.getResources().getString(R.string.label_scanning));
                        TextView textView = (TextView) ActivityLocalPrinters.this.findViewById(R.id.hint2);
                        if (ActivityLocalPrinters.this.scan_type == 1) {
                            textView.setText(R.string.menu_nearby_bt);
                        } else if (ActivityLocalPrinters.this.scan_type == 2) {
                            textView.setText(R.string.menu_nearby_usb);
                        } else {
                            textView.setText(R.string.menu_nearby_wifi);
                        }
                    }
                } else if (i5 != 2) {
                    if (i5 == 3) {
                        ActivityLocalPrinters.this.last_error = message.getData().getString("message");
                    } else if (i5 != 4) {
                    }
                    if (message2.arg1 == 0) {
                        ActivityLocalPrinters.this.stf_bonjour = false;
                    } else if (message2.arg1 == 1) {
                        ActivityLocalPrinters.this.stf_snmp = false;
                    } else if (message2.arg1 == 2) {
                        ActivityLocalPrinters.this.stf_bjnp = false;
                    } else if (message2.arg1 == 3) {
                        ActivityLocalPrinters.this.stf_bluetooth = false;
                    } else if (message2.arg1 == 4) {
                        ActivityLocalPrinters.this.stf_usb = false;
                    } else if (message2.arg1 == 5) {
                        ActivityLocalPrinters.this.stf_wsd = false;
                    } else if (message2.arg1 == 6) {
                        ActivityLocalPrinters.this.stf_tpl = false;
                    }
                    if (!ActivityLocalPrinters.this.stf_bonjour && !ActivityLocalPrinters.this.stf_snmp && !ActivityLocalPrinters.this.stf_bjnp && !ActivityLocalPrinters.this.stf_wsd && !ActivityLocalPrinters.this.stf_tpl && !ActivityLocalPrinters.this.stf_bluetooth && !ActivityLocalPrinters.this.stf_usb) {
                        button.setEnabled(true);
                        if (ActivityLocalPrinters.this.smb_stack.size() < 2) {
                            ((TextView) ActivityLocalPrinters.this.findViewById(R.id.hint1)).setText(String.format(ActivityLocalPrinters.this.getResources().getString(R.string.label_found_printers), new Object[]{Integer.valueOf(ActivityLocalPrinters.this.printers.size())}));
                        }
                        synchronized (ActivityLocalPrinters.this) {
                            try {
                                if (ActivityLocalPrinters.this.wl != null && ActivityLocalPrinters.this.wl.isHeld()) {
                                    ActivityLocalPrinters.this.wl.release();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                App.reportThrowable(e);
                            }
                            ActivityLocalPrinters.this.wl = null;
                        }
                        if (ActivityLocalPrinters.this.last_error == null && ActivityLocalPrinters.this.printers.size() == 0 && !ActivityLocalPrinters.this.isFinishing()) {
                            Builder neutralButton = new Builder(ActivityLocalPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_no_printers_title).setNeutralButton(R.string.button_ok, null);
                            if (ActivityLocalPrinters.this.scan_type == 2) {
                                neutralButton.setMessage(R.string.dialog_no_usb_printers_text);
                            } else if (ActivityLocalPrinters.this.scan_type == 1) {
                                neutralButton.setMessage(R.string.dialog_no_bt_printers_text);
                            } else {
                                neutralButton.setMessage(R.string.dialog_no_wifi_printers_text);
                            }
                            ActivityLocalPrinters.this.error_dialog = neutralButton.show();
                        }
                    }
                } else if (!button.isEnabled()) {
                    Vector vector7 = new Vector();
                    if (ActivityLocalPrinters.this.st_usb != null) {
                        Vector printers = ActivityLocalPrinters.this.st_usb.getPrinters();
                        synchronized (printers) {
                            vector7.addAll(printers);
                        }
                    }
                    if (ActivityLocalPrinters.this.st_bluetooth != null) {
                        Vector printers2 = ActivityLocalPrinters.this.st_bluetooth.getPrinters();
                        synchronized (printers2) {
                            vector7.addAll(printers2);
                        }
                    }
                    Vector vector8 = new Vector();
                    if (ActivityLocalPrinters.this.st_bonjour != null) {
                        Vector printers3 = ActivityLocalPrinters.this.st_bonjour.getPrinters();
                        synchronized (printers3) {
                            for (int i6 = 0; i6 < printers3.size(); i6++) {
                                Printer printer = (Printer) printers3.get(i6);
                                if (printer.id.endsWith("_printershare._tcp.local.")) {
                                    vector7.add(printer);
                                } else {
                                    vector8.add(printer);
                                }
                            }
                        }
                    }
                    if (ActivityLocalPrinters.this.st_bjnp != null) {
                        Vector printers4 = ActivityLocalPrinters.this.st_bjnp.getPrinters();
                        synchronized (printers4) {
                            vector8.addAll(printers4);
                        }
                    }
                    if (ActivityLocalPrinters.this.st_snmp != null) {
                        Vector printers5 = ActivityLocalPrinters.this.st_snmp.getPrinters();
                        synchronized (printers5) {
                            vector8.addAll(printers5);
                        }
                    }
                    if (ActivityLocalPrinters.this.st_wsd != null) {
                        Vector printers6 = ActivityLocalPrinters.this.st_wsd.getPrinters();
                        synchronized (printers6) {
                            vector8.addAll(printers6);
                        }
                    }
                    if (ActivityLocalPrinters.this.st_tpl != null) {
                        Vector printers7 = ActivityLocalPrinters.this.st_tpl.getPrinters();
                        synchronized (printers7) {
                            vector8.addAll(printers7);
                        }
                    }
                    Hashtable hashtable = new Hashtable();
                    for (int i7 = 0; i7 < vector8.size(); i7++) {
                        try {
                            Printer printer2 = (Printer) vector8.get(i7);
                            String substring = printer2.id.substring(0, printer2.id.indexOf("."));
                            Vector vector9 = (Vector) hashtable.get(substring);
                            if (vector9 == null) {
                                vector9 = new Vector();
                                hashtable.put(substring, vector9);
                            }
                            vector9.add(printer2);
                        } catch (Exception e2) {
                            e2.printStackTrace();
                            App.reportThrowable(e2);
                        }
                    }
                    Vector vector10 = new Vector();
                    Enumeration keys = hashtable.keys();
                    while (keys.hasMoreElements()) {
                        vector10.add(hashtable.get((String) keys.nextElement()));
                    }
                    int size = vector10.size() - 1;
                    while (size >= 0) {
                        Vector vector11 = (Vector) vector10.get(size);
                        int i8 = 0;
                        while (true) {
                            if (i8 >= size) {
                                vector = vector7;
                                vector2 = vector10;
                                i = size;
                                break;
                            }
                            Vector vector12 = (Vector) vector10.get(i8);
                            char c3 = 0;
                            int i9 = 0;
                            boolean z = false;
                            while (i9 < vector12.size() && !z) {
                                Printer printer3 = (Printer) vector12.get(i9);
                                char c4 = c3;
                                int i10 = 0;
                                while (true) {
                                    if (i10 >= vector11.size()) {
                                        vector3 = vector7;
                                        vector4 = vector10;
                                        i2 = size;
                                        c = c4;
                                        break;
                                    }
                                    Printer printer4 = (Printer) vector11.get(i10);
                                    if (printer4.direct_address.equals(printer3.direct_address)) {
                                        vector3 = vector7;
                                        vector4 = vector10;
                                        i2 = size;
                                        c = c4;
                                        z = true;
                                        break;
                                    }
                                    if (c4 == 0) {
                                        try {
                                            int indexOf2 = printer4.direct_address.indexOf("://");
                                            c2 = c4;
                                            int i11 = indexOf2 + 3;
                                            try {
                                                int indexOf3 = printer4.direct_address.indexOf("]", i11);
                                                if (indexOf3 < 0) {
                                                    indexOf3 = printer4.direct_address.indexOf(":", i11);
                                                }
                                                if (indexOf3 < 0) {
                                                    indexOf3 = printer4.direct_address.indexOf("/", i11);
                                                }
                                                if (indexOf3 < 0) {
                                                    indexOf3 = printer4.direct_address.length();
                                                }
                                                vector6 = vector7;
                                                try {
                                                    indexOf = printer3.direct_address.indexOf("://");
                                                    vector5 = vector10;
                                                    i3 = size;
                                                    i4 = indexOf + 3;
                                                } catch (Exception e3) {
                                                    e = e3;
                                                    vector5 = vector10;
                                                    i3 = size;
                                                    e.printStackTrace();
                                                    App.reportThrowable(e);
                                                    c4 = c2;
                                                    i10++;
                                                    Message message3 = message;
                                                    vector7 = vector6;
                                                    vector10 = vector5;
                                                    size = i3;
                                                }
                                                try {
                                                    int indexOf4 = printer3.direct_address.indexOf("]", i4);
                                                    if (indexOf4 < 0) {
                                                        indexOf4 = printer3.direct_address.indexOf(":", i4);
                                                    }
                                                    if (indexOf4 < 0) {
                                                        indexOf4 = printer3.direct_address.indexOf("/", i4);
                                                    }
                                                    if (indexOf4 < 0) {
                                                        indexOf4 = printer3.direct_address.length();
                                                    }
                                                    if (printer4.direct_address.substring(i11, indexOf3).equals(printer3.direct_address.substring(i4, indexOf4))) {
                                                        c4 = printer4.direct_address.substring(0, indexOf2).equals(printer3.direct_address.substring(0, indexOf)) ? (char) 65535 : 1;
                                                        i10++;
                                                        Message message32 = message;
                                                        vector7 = vector6;
                                                        vector10 = vector5;
                                                        size = i3;
                                                    }
                                                } catch (Exception e4) {
                                                    e = e4;
                                                    e.printStackTrace();
                                                    App.reportThrowable(e);
                                                    c4 = c2;
                                                    i10++;
                                                    Message message322 = message;
                                                    vector7 = vector6;
                                                    vector10 = vector5;
                                                    size = i3;
                                                }
                                            } catch (Exception e5) {
                                                e = e5;
                                                vector6 = vector7;
                                                vector5 = vector10;
                                                i3 = size;
                                                e.printStackTrace();
                                                App.reportThrowable(e);
                                                c4 = c2;
                                                i10++;
                                                Message message3222 = message;
                                                vector7 = vector6;
                                                vector10 = vector5;
                                                size = i3;
                                            }
                                        } catch (Exception e6) {
                                            e = e6;
                                            vector6 = vector7;
                                            vector5 = vector10;
                                            i3 = size;
                                            c2 = c4;
                                            e.printStackTrace();
                                            App.reportThrowable(e);
                                            c4 = c2;
                                            i10++;
                                            Message message32222 = message;
                                            vector7 = vector6;
                                            vector10 = vector5;
                                            size = i3;
                                        }
                                    } else {
                                        vector6 = vector7;
                                        vector5 = vector10;
                                        i3 = size;
                                        c2 = c4;
                                    }
                                    c4 = c2;
                                    i10++;
                                    Message message322222 = message;
                                    vector7 = vector6;
                                    vector10 = vector5;
                                    size = i3;
                                }
                                i9++;
                                Message message4 = message;
                                c3 = c;
                                vector7 = vector3;
                                vector10 = vector4;
                                size = i2;
                            }
                            vector = vector7;
                            Vector vector13 = vector10;
                            int i12 = size;
                            if (z) {
                                break;
                            } else if (c3 == 1) {
                                break;
                            } else {
                                i8++;
                                Message message5 = message;
                                vector7 = vector;
                                vector10 = vector13;
                                size = i12;
                            }
                        }
                        size = i - 1;
                        vector10 = vector2;
                        vector7 = vector;
                        Message message6 = message;
                    }
                    Vector vector14 = vector7;
                    Vector vector15 = vector10;
                    int i13 = 0;
                    while (i13 < vector15.size()) {
                        Vector<Printer> vector16 = (Vector) vector15.get(i13);
                        Collections.sort(vector16);
                        Printer printer5 = (Printer) vector16.remove(0);
                        if (vector16.size() > 0) {
                            printer5.otherServices = vector16;
                        }
                        Vector vector17 = vector14;
                        vector17.add(printer5);
                        i13++;
                        vector14 = vector17;
                    }
                    Vector vector18 = vector14;
                    ActivityLocalPrinters.this.printers.clear();
                    ActivityLocalPrinters.this.printers.addAll(vector18);
                }
                ActivityLocalPrinters.this.adapter.fireOnChanged();
                if (ActivityLocalPrinters.this.last_error != null) {
                    ActivityLocalPrinters.this.displayLastError(new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                }
                super.handleMessage(message);
            }
        }
    };
    /* access modifiers changed from: private */
    public int scan_type;
    /* access modifiers changed from: private */
    public Vector<SmbFile> smb_files;
    /* access modifiers changed from: private */
    public Vector<Printer> smb_printers;
    /* access modifiers changed from: private */
    public Stack<SmbFile> smb_stack;
    /* access modifiers changed from: private */
    public ScanThreadBJNP st_bjnp;
    /* access modifiers changed from: private */
    public ScanThreadBluetooth st_bluetooth;
    /* access modifiers changed from: private */
    public ScanThreadBonjour st_bonjour;
    /* access modifiers changed from: private */
    public Thread st_smb;
    /* access modifiers changed from: private */
    public ScanThreadSNMP st_snmp;
    /* access modifiers changed from: private */
    public ScanThreadTPL st_tpl;
    /* access modifiers changed from: private */
    public ScanThreadUSB st_usb;
    /* access modifiers changed from: private */
    public ScanThreadWSD st_wsd;
    /* access modifiers changed from: private */
    public boolean stf_bjnp;
    /* access modifiers changed from: private */
    public boolean stf_bluetooth;
    /* access modifiers changed from: private */
    public boolean stf_bonjour;
    /* access modifiers changed from: private */
    public boolean stf_snmp;
    /* access modifiers changed from: private */
    public boolean stf_tpl;
    /* access modifiers changed from: private */
    public boolean stf_usb;
    /* access modifiers changed from: private */
    public boolean stf_wsd;
    /* access modifiers changed from: private */
    public View view_dialog_authorization;
    /* access modifiers changed from: private */
    public WakeLock wl;
    /* access modifiers changed from: private */
    public Thread wt;

    class AddPrinterThread extends Thread {
        private Boolean first_check;
        /* access modifiers changed from: private */
        public Printer prn;

        public AddPrinterThread(Printer printer, Boolean bool) {
            this.prn = printer;
            this.first_check = bool;
        }

        /* JADX WARNING: Removed duplicated region for block: B:13:0x0042  */
        /* JADX WARNING: Removed duplicated region for block: B:17:0x0066  */
        public void run() {
            boolean z;
            String str;
            ActivityLocalPrinters.this.last_error = null;
            ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityLocalPrinters.this.showProgress(ActivityLocalPrinters.this.getResources().getString(R.string.label_processing));
                }
            });
            if (this.first_check != null) {
                try {
                    if (!this.prn.direct_address.startsWith("ptp://")) {
                        if (!this.prn.drv_name.startsWith("internal")) {
                            z = ActivityLocalPrinters.this.drvCheck(this.prn);
                            if (!z) {
                                ActivityLocalPrinters.this.setPrinter(this.prn);
                                if (this.prn.id.startsWith("smb://")) {
                                    int indexOf = this.prn.direct_address.indexOf("@");
                                    Editor edit = ActivityLocalPrinters.this.prefs.edit();
                                    if (indexOf < 0) {
                                        str = "";
                                    } else {
                                        str = this.prn.direct_address.substring(6, indexOf);
                                    }
                                    edit.putString("smb_auth", str);
                                    edit.commit();
                                }
                                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        if ("ActivityMain".equals(ActivityLocalPrinters.this.getIntent().getStringExtra("activity_name"))) {
                                            ActivityLocalPrinters.this.hideProgress();
                                            if (!ActivityLocalPrinters.this.isFinishing()) {
                                                new Builder(ActivityLocalPrinters.this).setIcon(R.drawable.icon_title).setTitle(SmbConstants.NATIVE_LANMAN).setMessage(R.string.dialog_install_printer_done).setCancelable(false).setPositiveButton(R.string.button_print_test_page, new OnClickListener() {
                                                    public void onClick(DialogInterface dialogInterface, int i) {
                                                        ActivityLocalPrinters.this.setResult(-1);
                                                        ActivityLocalPrinters.this.finish();
                                                        Intent intent = new Intent();
                                                        intent.setClass(ActivityLocalPrinters.this, ActivityPrintTestPage.class);
                                                        ActivityLocalPrinters.this.startActivity(intent);
                                                    }
                                                }).setNegativeButton(R.string.button_skip, new OnClickListener() {
                                                    public void onClick(DialogInterface dialogInterface, int i) {
                                                        ActivityLocalPrinters.this.setResult(-1);
                                                        ActivityLocalPrinters.this.finish();
                                                    }
                                                }).show();
                                                return;
                                            }
                                            return;
                                        }
                                        ActivityLocalPrinters.this.hideProgress();
                                        ActivityLocalPrinters.this.setResult(-1);
                                        ActivityLocalPrinters.this.finish();
                                    }
                                });
                            } else if (this.first_check.booleanValue()) {
                                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityLocalPrinters.this.hideProgress();
                                        if (!ActivityLocalPrinters.this.isFinishing()) {
                                            new Builder(ActivityLocalPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_user_action_title).setMessage(R.string.dialog_install_drivers_text).setPositiveButton(R.string.button_yes, new OnClickListener() {
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    ActivityLocalPrinters.this.wt = new InstallDriverThread(AddPrinterThread.this.prn);
                                                    ActivityLocalPrinters.this.wt.start();
                                                }
                                            }).setNegativeButton(R.string.button_no, new OnClickListener() {
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                }
                                            }).show();
                                        }
                                    }
                                });
                            } else {
                                ActivityLocalPrinters.this.last_error = "Cannot install driver pack. An unknown error has occurred.";
                                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityLocalPrinters.this.hideProgress();
                                        ActivityLocalPrinters.this.displayLastError(new OnClickListener() {
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                            }
                                        });
                                    }
                                });
                            }
                            ActivityLocalPrinters.this.wt = null;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                    z = false;
                }
            }
            z = true;
            if (!z) {
            }
            ActivityLocalPrinters.this.wt = null;
        }
    }

    class InstallDriverThread extends Thread {
        /* access modifiers changed from: private */
        public Printer prn;

        public InstallDriverThread(Printer printer) {
            this.prn = printer;
        }

        public void run() {
            ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityLocalPrinters.this.showProgress(ActivityLocalPrinters.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityLocalPrinters.this.last_error = null;
            try {
                ActivityLocalPrinters.this.installDrvLibPack("pack_drv", false, this.prn.drv_name, true, 0, 100);
            } catch (Exception e) {
                e.printStackTrace();
                ActivityLocalPrinters activityLocalPrinters = ActivityLocalPrinters.this;
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e.getMessage());
                activityLocalPrinters.last_error = sb.toString();
                App.reportThrowable(e);
            }
            ActivityLocalPrinters.this.wt = null;
            if (ActivityLocalPrinters.this.last_error == null) {
                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityLocalPrinters.this.wt = new AddPrinterThread(InstallDriverThread.this.prn, Boolean.valueOf(false));
                        ActivityLocalPrinters.this.wt.start();
                    }
                });
            } else {
                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityLocalPrinters.this.hideProgress();
                        ActivityLocalPrinters.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
            }
        }
    }

    class PrinterAdapter implements ListAdapter {
        public Context mContext;
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getViewTypeCount() {
            return 2;
        }

        public boolean hasStableIds() {
            return false;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        public PrinterAdapter(Context context) {
            this.mContext = context;
        }

        public int getCount() {
            int size;
            int size2;
            if (ActivityLocalPrinters.this.smb_stack.size() > 1) {
                size = ActivityLocalPrinters.this.smb_files.size() + 1;
                size2 = ActivityLocalPrinters.this.smb_printers.size();
            } else {
                size = ActivityLocalPrinters.this.smb_files.size();
                size2 = ActivityLocalPrinters.this.printers.size();
            }
            return size + size2;
        }

        public Object getItem(int i) {
            if (ActivityLocalPrinters.this.smb_stack.size() > 1) {
                if (i == 0) {
                    return null;
                }
                i--;
            }
            int size = ActivityLocalPrinters.this.smb_files.size();
            if (i < size) {
                return ActivityLocalPrinters.this.smb_files.elementAt(i);
            }
            return (Printer) (ActivityLocalPrinters.this.smb_stack.size() > 1 ? ActivityLocalPrinters.this.smb_printers : ActivityLocalPrinters.this.printers).elementAt(i - size);
        }

        public int getItemViewType(int i) {
            int size = ActivityLocalPrinters.this.smb_files.size();
            if (ActivityLocalPrinters.this.smb_stack.size() > 1) {
                size++;
            }
            return i < size ? 1 : 0;
        }

        /* JADX WARNING: Removed duplicated region for block: B:31:0x00ca  */
        /* JADX WARNING: Removed duplicated region for block: B:47:0x011b  */
        /* JADX WARNING: Removed duplicated region for block: B:48:0x011f  */
        /* JADX WARNING: Removed duplicated region for block: B:51:0x0131  */
        public View getView(int i, View view, ViewGroup viewGroup) {
            int i2;
            String name;
            LayoutInflater from = LayoutInflater.from(this.mContext);
            int i3 = 8;
            boolean z = true;
            if (getItemViewType(i) == 0) {
                Printer printer = (Printer) getItem(i);
                View inflate = from.inflate(R.layout.printer, null);
                ((TextView) inflate.findViewById(R.id.printer_name)).setText(printer.getInfoTitle());
                ((TextView) inflate.findViewById(R.id.printer_owner)).setText(printer.getInfoOwner());
                TextView textView = (TextView) inflate.findViewById(R.id.printer_location);
                String infoLocation = printer.getInfoLocation();
                textView.setText(infoLocation);
                textView.setVisibility("".equals(infoLocation) ? 8 : 0);
                ImageView imageView = (ImageView) inflate.findViewById(R.id.printer_status);
                int i4 = printer.online != null ? printer.online.booleanValue() ? R.drawable.printer_on : R.drawable.printer_off : R.drawable.printer;
                imageView.setBackgroundResource(i4);
                View findViewById = inflate.findViewById(R.id.printer_current);
                if (ActivityCore.printer != null) {
                    if (ActivityCore.printer.id == null || !ActivityCore.printer.id.equals(printer.id)) {
                        if (printer.otherServices != null) {
                            int i5 = 0;
                            while (true) {
                                if (i5 >= printer.otherServices.size()) {
                                    break;
                                }
                                Printer printer2 = (Printer) printer.otherServices.get(i5);
                                if (printer2.id != null && printer2.id.equals(ActivityCore.printer.id)) {
                                    break;
                                }
                                i5++;
                            }
                        }
                    }
                    if (z) {
                        i3 = 0;
                    }
                    findViewById.setVisibility(i3);
                    inflate.setTag(printer);
                    return inflate;
                }
                z = false;
                if (z) {
                }
                findViewById.setVisibility(i3);
                inflate.setTag(printer);
                return inflate;
            }
            SmbFile smbFile = (SmbFile) getItem(i);
            View inflate2 = from.inflate(R.layout.printer, null);
            ImageView imageView2 = (ImageView) inflate2.findViewById(R.id.printer_status);
            TextView textView2 = (TextView) inflate2.findViewById(R.id.printer_name);
            inflate2.findViewById(R.id.printer_location).setVisibility(8);
            if (smbFile != null) {
                try {
                    i2 = smbFile.getType();
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
                if (ActivityLocalPrinters.this.smb_stack.size() > 1 || i != 0) {
                    imageView2.setBackgroundResource(i2 != 4 ? R.drawable.smb_server : R.drawable.smb_domain);
                    name = smbFile.getName();
                    if (name.endsWith("/")) {
                        name = name.substring(0, name.length() - 1);
                    }
                    textView2.setText(name);
                } else {
                    imageView2.setBackgroundResource(R.drawable.smb_up);
                    textView2.setText("..");
                }
                inflate2.setTag(smbFile);
                return inflate2;
            }
            i2 = 0;
            if (ActivityLocalPrinters.this.smb_stack.size() > 1) {
            }
            imageView2.setBackgroundResource(i2 != 4 ? R.drawable.smb_server : R.drawable.smb_domain);
            name = smbFile.getName();
            if (name.endsWith("/")) {
            }
            textView2.setText(name);
            inflate2.setTag(smbFile);
            return inflate2;
        }

        public boolean isEmpty() {
            return ActivityLocalPrinters.this.printers == null || ActivityLocalPrinters.this.printers.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }
    }

    class SetupPrinterThread extends Thread {
        private boolean force_manual;
        /* access modifiers changed from: private */
        public String manual_model;
        private Printer sprn;

        public SetupPrinterThread(Printer printer, boolean z, String str) {
            this.sprn = printer;
            this.force_manual = z;
            this.manual_model = str;
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(6:65|66|67|68|(2:70|283)(4:71|(10:73|74|75|76|(1:78)|81|(1:83)(1:84)|85|(1:87)(1:88)|(1:(1:99)(1:98))(1:94))(7:80|81|(0)(0)|85|(0)(0)|(1:90)|(2:96|270)(1:276))|79|284)|281) */
        /* JADX WARNING: Code restructure failed: missing block: B:181:0x04ef, code lost:
            r3 = -1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:182:0x04f0, code lost:
            if (r14 == -1) goto L_0x04f3;
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:67:0x025b */
        /* JADX WARNING: Removed duplicated region for block: B:126:0x0387 A[Catch:{ Exception -> 0x0390 }] */
        /* JADX WARNING: Removed duplicated region for block: B:149:0x042e  */
        /* JADX WARNING: Removed duplicated region for block: B:171:0x048c  */
        /* JADX WARNING: Removed duplicated region for block: B:172:0x04bf  */
        /* JADX WARNING: Removed duplicated region for block: B:177:0x04d2  */
        /* JADX WARNING: Removed duplicated region for block: B:278:0x04cb A[SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:70:0x0269 A[Catch:{ Exception -> 0x046d }] */
        /* JADX WARNING: Removed duplicated region for block: B:71:0x026f A[Catch:{ Exception -> 0x046d }] */
        /* JADX WARNING: Removed duplicated region for block: B:83:0x02a4 A[Catch:{ Exception -> 0x0390 }] */
        /* JADX WARNING: Removed duplicated region for block: B:84:0x02b5 A[Catch:{ Exception -> 0x0390 }] */
        /* JADX WARNING: Removed duplicated region for block: B:87:0x02c3 A[Catch:{ Exception -> 0x0390 }] */
        /* JADX WARNING: Removed duplicated region for block: B:88:0x02d4 A[Catch:{ Exception -> 0x0390 }] */
        public void run() {
            int i;
            int i2;
            int i3;
            String str;
            int i4;
            final Printer printer;
            String str2;
            String str3;
            String str4;
            String message;
            boolean z;
            String server;
            String server2;
            String str5 = "\n";
            ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityLocalPrinters.this.showProgress(ActivityLocalPrinters.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityLocalPrinters.this.last_error = null;
            Vector vector = new Vector();
            vector.add(this.sprn);
            if (this.sprn.otherServices != null) {
                vector.addAll(this.sprn.otherServices);
            }
            int size = vector.size();
            int[] iArr = new int[size];
            String str6 = "bjnp";
            boolean z2 = true;
            if (!this.force_manual) {
                for (int i5 = 0; i5 < vector.size(); i5++) {
                    try {
                        iArr[i5] = -1;
                        Printer printer2 = (Printer) vector.get(i5);
                        if (printer2.direct_address.startsWith("ptp://")) {
                            iArr[i5] = 3;
                        } else {
                            if (this.manual_model != null) {
                                printer2.model = this.manual_model;
                                printer2.drv_manual = true;
                            }
                            iArr[i5] = ActivityLocalPrinters.this.findDriver(printer2);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
                int i6 = 3;
                i = -1;
                loop1:
                while (true) {
                    if (i6 < 0) {
                        i2 = -1;
                        break;
                    }
                    int i7 = 0;
                    while (true) {
                        if (i7 >= i3) {
                            str = str5;
                            i4 = i3;
                            break;
                        }
                        if (iArr[i7] == i6) {
                            printer = (Printer) vector.get(i7);
                            if (!printer.drv_manual) {
                                try {
                                    if (!printer.direct_address.startsWith("ipp://")) {
                                        if (!printer.direct_address.startsWith("ipps://")) {
                                            String str7 = "http";
                                            if (printer.direct_address.startsWith("bjnp://")) {
                                                URL url = new URL(printer.direct_address.replaceAll(str6, str7));
                                                if (!new BJNPSocket().check(new InetSocketAddress(url.getHost(), url.getPort()), NanoHTTPD.SOCKET_READ_TIMEOUT)) {
                                                    str4 = "Error: Can't add printer. Network or printer error.";
                                                    str = str5;
                                                    i4 = i3;
                                                    str2 = str4;
                                                }
                                            } else {
                                                if (printer.direct_address.startsWith("pdl://")) {
                                                    URL url2 = new URL(printer.direct_address.replaceAll("pdl", str7));
                                                    Socket socket = new Socket();
                                                    socket.connect(new InetSocketAddress(url2.getHost(), url2.getPort()), NanoHTTPD.SOCKET_READ_TIMEOUT);
                                                    socket.close();
                                                } else {
                                                    String str8 = "";
                                                    if (printer.direct_address.startsWith("wprt://")) {
                                                        String replaceAll = printer.direct_address.replaceAll("wprt", str7);
                                                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(replaceAll).openConnection();
                                                        httpURLConnection.setConnectTimeout(NanoHTTPD.SOCKET_READ_TIMEOUT);
                                                        httpURLConnection.setReadTimeout(NanoHTTPD.SOCKET_READ_TIMEOUT);
                                                        httpURLConnection.setDoInput(z2);
                                                        httpURLConnection.setDoOutput(z2);
                                                        httpURLConnection.setUseCaches(false);
                                                        httpURLConnection.setRequestMethod("POST");
                                                        httpURLConnection.setRequestProperty("Connection", "close");
                                                        httpURLConnection.setRequestProperty("User-Agent", App.getUserAgent());
                                                        httpURLConnection.setRequestProperty("Content-Type", "application/soap+xml");
                                                        OutputStream outputStream = httpURLConnection.getOutputStream();
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wsdp=\"http://schemas.xmlsoap.org/ws/2005/05/devprof\" xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" xmlns:wprt=\"http://schemas.microsoft.com/windows/2006/08/wdp/print\"><soap:Header><wsa:To>");
                                                        sb.append(replaceAll);
                                                        sb.append("</wsa:To><wsa:Action>http://schemas.microsoft.com/windows/2006/08/wdp/print/GetPrinterElements</wsa:Action><wsa:MessageID>urn:uuid:");
                                                        sb.append(UUID.randomUUID());
                                                        sb.append("</wsa:MessageID><wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo></soap:Header><soap:Body><wprt:GetPrinterElementsRequest><wprt:RequestedElements><wprt:Name>wprt:PrinterStatus</wprt:Name></wprt:RequestedElements></wprt:GetPrinterElementsRequest></soap:Body></soap:Envelope>");
                                                        outputStream.write(sb.toString().getBytes());
                                                        if (httpURLConnection.getResponseCode() != 200) {
                                                            String responseMessage = httpURLConnection.getResponseMessage();
                                                            StringBuilder sb2 = new StringBuilder();
                                                            sb2.append("Error: Can't add printer. HTTP error ");
                                                            sb2.append(httpURLConnection);
                                                            sb2.append(".");
                                                            if (responseMessage != null) {
                                                                StringBuilder sb3 = new StringBuilder();
                                                                sb3.append(" ");
                                                                sb3.append(responseMessage);
                                                                str8 = sb3.toString();
                                                            }
                                                            sb2.append(str8);
                                                            str4 = sb2.toString();
                                                            str = str5;
                                                            i4 = i3;
                                                            str2 = str4;
                                                        }
                                                    } else if (printer.direct_address.startsWith("lpd://")) {
                                                        URL url3 = new URL(printer.direct_address.replaceAll("lpd", str7));
                                                        Socket socket2 = new Socket();
                                                        socket2.connect(new InetSocketAddress(url3.getHost(), url3.getPort()), NanoHTTPD.SOCKET_READ_TIMEOUT);
                                                        socket2.setSoTimeout(NanoHTTPD.SOCKET_READ_TIMEOUT);
                                                        OutputStream outputStream2 = socket2.getOutputStream();
                                                        outputStream2.write(2);
                                                        StringBuilder sb4 = new StringBuilder();
                                                        sb4.append(url3.getPath().substring(1));
                                                        sb4.append(str5);
                                                        outputStream2.write(sb4.toString().getBytes());
                                                        outputStream2.flush();
                                                        int read = socket2.getInputStream().read();
                                                        outputStream2.write(1);
                                                        outputStream2.write(str5.getBytes());
                                                        socket2.close();
                                                        if (read != 0) {
                                                            StringBuilder sb5 = new StringBuilder();
                                                            sb5.append("Error: Can't add printer. LPD error ");
                                                            sb5.append(read);
                                                            str4 = sb5.toString();
                                                            str = str5;
                                                            i4 = i3;
                                                            str2 = str4;
                                                        }
                                                    } else if (printer.direct_address.startsWith("smb://")) {
                                                        SmbFile smbFile = new SmbFile(printer.direct_address);
                                                        while (true) {
                                                            smbFile.print_open(str8);
                                                            smbFile.print_close();
                                                            NtlmPasswordAuthentication ntlmPasswordAuthentication = (NtlmPasswordAuthentication) smbFile.getPrincipal();
                                                            if (!ntlmPasswordAuthentication.equals(NtlmPasswordAuthentication.ANONYMOUS)) {
                                                                smbFile.setAuth(NtlmPasswordAuthentication.DEFAULT);
                                                            } else {
                                                                if (!ntlmPasswordAuthentication.equals(NtlmPasswordAuthentication.DEFAULT)) {
                                                                    str = str5;
                                                                    if (ActivityLocalPrinters.this.smb_stack.size() <= 1) {
                                                                    }
                                                                    if (ActivityLocalPrinters.this.smb_stack.size() <= 2) {
                                                                    }
                                                                    if (server == null) {
                                                                    }
                                                                    if (server2 == null) {
                                                                        break loop1;
                                                                    }
                                                                    break loop1;
                                                                }
                                                                str = str5;
                                                                try {
                                                                    NtlmPasswordAuthentication ntlmPasswordAuthentication2 = new NtlmPasswordAuthentication(ActivityLocalPrinters.this.prefs.getString("smb_auth", null));
                                                                    if (!ntlmPasswordAuthentication.equals(ntlmPasswordAuthentication2)) {
                                                                        smbFile.setAuth(ntlmPasswordAuthentication2);
                                                                    }
                                                                    server = ActivityLocalPrinters.this.smb_stack.size() <= 1 ? ((SmbFile) ActivityLocalPrinters.this.smb_stack.get(1)).getServer() : null;
                                                                    server2 = ActivityLocalPrinters.this.smb_stack.size() <= 2 ? ((SmbFile) ActivityLocalPrinters.this.smb_stack.lastElement()).getServer() : null;
                                                                    if (server == null && !ntlmPasswordAuthentication.getDomain().equals(server) && !ntlmPasswordAuthentication.getDomain().equals(server2)) {
                                                                        smbFile.setAuth(new NtlmPasswordAuthentication(server, ntlmPasswordAuthentication.getUsername(), ntlmPasswordAuthentication.getPassword()));
                                                                    } else if (server2 == null || ntlmPasswordAuthentication.getDomain().equals(server2)) {
                                                                        ActivityLocalPrinters.this.wt = null;
                                                                        ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                                                            public void run() {
                                                                                ActivityLocalPrinters.this.hideProgress();
                                                                                ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).setText("");
                                                                                ActivityLocalPrinters.this.dialog_authorization.setButton(-1, ActivityLocalPrinters.this.getResources().getString(R.string.button_ok), new OnClickListener() {
                                                                                    public void onClick(DialogInterface dialogInterface, int i) {
                                                                                        String str;
                                                                                        String obj = ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.login_edit)).getText().toString();
                                                                                        int indexOf = obj.indexOf("\\");
                                                                                        if (indexOf >= 0) {
                                                                                            str = obj.substring(0, indexOf);
                                                                                            obj = obj.substring(indexOf + 1);
                                                                                        } else {
                                                                                            str = "?";
                                                                                        }
                                                                                        String obj2 = ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).getText().toString();
                                                                                        String str2 = "@";
                                                                                        int indexOf2 = printer.direct_address.indexOf(str2);
                                                                                        Printer printer = printer;
                                                                                        StringBuilder sb = new StringBuilder();
                                                                                        sb.append("smb://");
                                                                                        StringBuilder sb2 = new StringBuilder();
                                                                                        sb2.append(str);
                                                                                        sb2.append(";");
                                                                                        sb2.append(obj);
                                                                                        sb2.append(":");
                                                                                        sb2.append(obj2);
                                                                                        sb.append(URLEncoder.encode(sb2.toString()));
                                                                                        sb.append(str2);
                                                                                        String str3 = printer.direct_address;
                                                                                        sb.append(indexOf2 < 0 ? str3.substring(6) : str3.substring(indexOf2 + 1));
                                                                                        printer.direct_address = sb.toString();
                                                                                        ActivityLocalPrinters.this.wt = new SetupPrinterThread(printer, false, SetupPrinterThread.this.manual_model);
                                                                                        ActivityLocalPrinters.this.wt.start();
                                                                                    }
                                                                                });
                                                                                ActivityLocalPrinters.this.dialog_authorization.show();
                                                                            }
                                                                        });
                                                                    } else {
                                                                        smbFile.setAuth(new NtlmPasswordAuthentication(server2, ntlmPasswordAuthentication.getUsername(), ntlmPasswordAuthentication.getPassword()));
                                                                    }
                                                                } catch (Exception e2) {
                                                                    e = e2;
                                                                    i4 = i3;
                                                                    e.printStackTrace();
                                                                    StringBuilder sb6 = new StringBuilder();
                                                                    sb6.append("Internal Error: ");
                                                                    sb6.append(e.getMessage());
                                                                    str2 = sb6.toString();
                                                                    if (printer != null) {
                                                                        StringBuilder sb7 = new StringBuilder();
                                                                        sb7.append("Printer: [");
                                                                        sb7.append(printer.model);
                                                                        String str9 = "][";
                                                                        sb7.append(str9);
                                                                        sb7.append(printer.drv_name);
                                                                        sb7.append(str9);
                                                                        sb7.append(printer.direct_address);
                                                                        sb7.append(str9);
                                                                        sb7.append(printer.id);
                                                                        sb7.append("]");
                                                                        str3 = sb7.toString();
                                                                    } else {
                                                                        str3 = null;
                                                                    }
                                                                    App.reportThrowable(e, str3);
                                                                    if (str2 == null) {
                                                                    }
                                                                }
                                                                str5 = str;
                                                            }
                                                        }
                                                    } else {
                                                        str = str5;
                                                        if (printer.direct_address.startsWith("bluetooth://")) {
                                                            BTAdapter bTAdapter = BTAdapter.getDefault(ActivityLocalPrinters.this);
                                                            if (bTAdapter.isDiscovering()) {
                                                                bTAdapter.cancelDiscovery();
                                                            }
                                                            try {
                                                                BTDevice remoteDevice = bTAdapter.getRemoteDevice(printer.direct_address.substring(12));
                                                                BTSocket connectRfcommSocket = remoteDevice.connectRfcommSocket(ActivityLocalPrinters.this);
                                                                if (connectRfcommSocket != null) {
                                                                    try {
                                                                        Thread.sleep(3000);
                                                                        connectRfcommSocket.destroy();
                                                                        z = true;
                                                                    } catch (Exception e3) {
                                                                        e = e3;
                                                                        z = true;
                                                                        e.printStackTrace();
                                                                        App.reportThrowable(e);
                                                                        if (!z) {
                                                                        }
                                                                        i4 = i3;
                                                                        str4 = null;
                                                                        str2 = str4;
                                                                        if (str2 == null) {
                                                                        }
                                                                    }
                                                                } else {
                                                                    z = false;
                                                                }
                                                                try {
                                                                    if (str8.equals(printer.model)) {
                                                                        printer.model = ScanThreadBluetooth.recognizeModel(remoteDevice.getName());
                                                                    }
                                                                } catch (Exception e4) {
                                                                    e = e4;
                                                                    e.printStackTrace();
                                                                    App.reportThrowable(e);
                                                                    if (!z) {
                                                                    }
                                                                    i4 = i3;
                                                                    str4 = null;
                                                                    str2 = str4;
                                                                    if (str2 == null) {
                                                                    }
                                                                }
                                                            } catch (Exception e5) {
                                                                e = e5;
                                                                z = false;
                                                                e.printStackTrace();
                                                                App.reportThrowable(e);
                                                                if (!z) {
                                                                }
                                                                i4 = i3;
                                                                str4 = null;
                                                                str2 = str4;
                                                                if (str2 == null) {
                                                                }
                                                            }
                                                            if (!z) {
                                                                str4 = "Error: Can't connect to bluetooth device.";
                                                                i4 = i3;
                                                                str2 = str4;
                                                            }
                                                        }
                                                        i4 = i3;
                                                        str4 = null;
                                                        str2 = str4;
                                                    }
                                                }
                                                str = str5;
                                                i4 = i3;
                                                str4 = null;
                                                str2 = str4;
                                            }
                                            str4 = null;
                                            str = str5;
                                            i4 = i3;
                                            str2 = str4;
                                        }
                                    }
                                    str = str5;
                                    boolean z3 = false;
                                    while (true) {
                                        try {
                                            IppConnection ippConnection = new IppConnection(printer.direct_address, App.getUserAgent());
                                            if (z3) {
                                                ippConnection.setSecured(true);
                                            }
                                            printer.owner.login = ActivityLocalPrinters.this.prefs.getString("printer_login", null);
                                            printer.owner.password = ActivityLocalPrinters.this.prefs.getString("printer_password", null);
                                            IppMessage ippMessage = new IppMessage(IppMessage.OP_GET_PRINTER_ATTRIBUTES);
                                            i4 = i3;
                                            try {
                                                ippMessage.operation_attributes.add(new IppAttribute(71, "attributes-charset", "utf-8"));
                                                ippMessage.operation_attributes.add(new IppAttribute((byte) IppAttribute.TYPE_NATURAL_LANGUAGE, "attributes-natural-language", "en-us"));
                                                ippMessage.operation_attributes.add(new IppAttribute(69, "printer-uri", ippConnection.getUri()));
                                                ippConnection.sendRequest(ippMessage);
                                                IppMessage response = ippConnection.getResponse();
                                                if (response.code != 0) {
                                                    StringBuilder sb8 = new StringBuilder();
                                                    sb8.append("Error: Can't add printer. IPP error ");
                                                    sb8.append(response.code);
                                                    str4 = sb8.toString();
                                                }
                                            } catch (Exception e6) {
                                                e = e6;
                                                try {
                                                    message = e.getMessage();
                                                    String str10 = "/ipp/port1";
                                                    if (message != null) {
                                                        if (message.indexOf("/duerqxesz5090. HTTP error 404") > 0) {
                                                            printer.direct_address = printer.direct_address.replace("/duerqxesz5090", str10);
                                                            i3 = i4;
                                                        }
                                                    }
                                                    if (message == null && message.indexOf("/ipp/port1. HTTP error 404") > 0) {
                                                        printer.direct_address = printer.direct_address.replace(str10, "/ipp/printer");
                                                        i3 = i4;
                                                    } else if (message == null || message.indexOf("HTTP error 426") <= 0 || z3) {
                                                        throw e;
                                                    } else {
                                                        i3 = i4;
                                                        z3 = true;
                                                    }
                                                } catch (Exception e7) {
                                                    e = e7;
                                                    e.printStackTrace();
                                                    StringBuilder sb62 = new StringBuilder();
                                                    sb62.append("Internal Error: ");
                                                    sb62.append(e.getMessage());
                                                    str2 = sb62.toString();
                                                    if (printer != null) {
                                                    }
                                                    App.reportThrowable(e, str3);
                                                    if (str2 == null) {
                                                    }
                                                }
                                            }
                                        } catch (Exception e8) {
                                            e = e8;
                                            i4 = i3;
                                            message = e.getMessage();
                                            String str102 = "/ipp/port1";
                                            if (message != null) {
                                            }
                                            if (message == null) {
                                            }
                                            if (message == null) {
                                                break loop1;
                                            }
                                            break loop1;
                                            throw e;
                                        }
                                    }
                                } catch (Exception e9) {
                                    e = e9;
                                    str = str5;
                                    i4 = i3;
                                    e.printStackTrace();
                                    StringBuilder sb622 = new StringBuilder();
                                    sb622.append("Internal Error: ");
                                    sb622.append(e.getMessage());
                                    str2 = sb622.toString();
                                    if (printer != null) {
                                    }
                                    App.reportThrowable(e, str3);
                                    if (str2 == null) {
                                    }
                                }
                            } else {
                                str = str5;
                                i4 = i3;
                                str2 = null;
                            }
                            if (str2 == null) {
                                ActivityLocalPrinters.this.last_error = null;
                                i = i7;
                                break;
                            }
                            iArr[i7] = -1;
                            ActivityLocalPrinters.this.last_error = str2;
                        } else {
                            str = str5;
                            i4 = i3;
                        }
                        i7++;
                        str5 = str;
                        size = i4;
                        z2 = true;
                    }
                    i6--;
                    str5 = str;
                    size = i4;
                    z2 = true;
                }
                ActivityLocalPrinters.this.wt = null;
                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityLocalPrinters.this.hideProgress();
                        ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).setText("");
                        ActivityLocalPrinters.this.dialog_authorization.setButton(-1, ActivityLocalPrinters.this.getResources().getString(R.string.button_ok), new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String str;
                                String obj = ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.login_edit)).getText().toString();
                                int indexOf = obj.indexOf("\\");
                                if (indexOf >= 0) {
                                    str = obj.substring(0, indexOf);
                                    obj = obj.substring(indexOf + 1);
                                } else {
                                    str = "?";
                                }
                                String obj2 = ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).getText().toString();
                                String str2 = "@";
                                int indexOf2 = printer.direct_address.indexOf(str2);
                                Printer printer = printer;
                                StringBuilder sb = new StringBuilder();
                                sb.append("smb://");
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append(str);
                                sb2.append(";");
                                sb2.append(obj);
                                sb2.append(":");
                                sb2.append(obj2);
                                sb.append(URLEncoder.encode(sb2.toString()));
                                sb.append(str2);
                                String str3 = printer.direct_address;
                                sb.append(indexOf2 < 0 ? str3.substring(6) : str3.substring(indexOf2 + 1));
                                printer.direct_address = sb.toString();
                                ActivityLocalPrinters.this.wt = new SetupPrinterThread(printer, false, SetupPrinterThread.this.manual_model);
                                ActivityLocalPrinters.this.wt.start();
                            }
                        });
                        ActivityLocalPrinters.this.dialog_authorization.show();
                    }
                });
                return;
            }
            i2 = -1;
            i = 0;
            ActivityLocalPrinters.this.wt = null;
            if (i != i2) {
                int i8 = iArr[i];
                final Printer printer3 = (Printer) vector.get(i);
                if (i8 > 0 && (printer3.drv_manual || (printer3.model != null && printer3.model.toLowerCase().contains("mx920")))) {
                    i8 = 3;
                }
                if (i8 == 0) {
                    ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityLocalPrinters.this.hideProgress();
                            if (!ActivityLocalPrinters.this.isFinishing()) {
                                Resources resources = ActivityLocalPrinters.this.getResources();
                                Builder title = new Builder(ActivityLocalPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_user_action_title);
                                StringBuilder sb = new StringBuilder();
                                sb.append(resources.getString(R.string.dialog_driver_not_found_text));
                                sb.append("\n\n");
                                sb.append(resources.getString(R.string.dialog_driver_note));
                                title.setMessage(sb.toString()).setPositiveButton(R.string.button_select_manually, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                            public void run() {
                                                ActivityLocalPrinters.this.showProgress(ActivityLocalPrinters.this.getResources().getString(R.string.label_processing));
                                            }
                                        });
                                        ActivityLocalPrinters.xprn = printer3;
                                        Intent intent = new Intent();
                                        intent.setClass(ActivityLocalPrinters.this, ActivityDriversBrowser.class);
                                        ActivityLocalPrinters.this.startActivityForResult(intent, 10);
                                    }
                                }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                }).show();
                            }
                        }
                    });
                } else if (i8 < 3) {
                    ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityLocalPrinters.this.hideProgress();
                            if (!ActivityLocalPrinters.this.isFinishing()) {
                                Resources resources = ActivityLocalPrinters.this.getResources();
                                Builder title = new Builder(ActivityLocalPrinters.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_user_action_title);
                                StringBuilder sb = new StringBuilder();
                                sb.append(resources.getString(R.string.dialog_generic_driver_found_text));
                                sb.append("\n\n");
                                sb.append(resources.getString(R.string.dialog_driver_note));
                                title.setMessage(sb.toString()).setPositiveButton(R.string.button_use_generic, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        ActivityLocalPrinters.this.wt = new AddPrinterThread(printer3, Boolean.valueOf(true));
                                        ActivityLocalPrinters.this.wt.start();
                                    }
                                }).setNeutralButton(R.string.button_select_manually, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                            public void run() {
                                                ActivityLocalPrinters.this.showProgress(ActivityLocalPrinters.this.getResources().getString(R.string.label_processing));
                                            }
                                        });
                                        ActivityLocalPrinters.xprn = printer3;
                                        Intent intent = new Intent();
                                        intent.setClass(ActivityLocalPrinters.this, ActivityDriversBrowser.class);
                                        ActivityLocalPrinters.this.startActivityForResult(intent, 10);
                                    }
                                }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                }).show();
                            }
                        }
                    });
                } else {
                    ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityLocalPrinters.this.wt = new AddPrinterThread(printer3, Boolean.valueOf(true));
                            ActivityLocalPrinters.this.wt.start();
                        }
                    });
                }
                if (!this.force_manual) {
                    try {
                        Hashtable hashtable = new Hashtable();
                        hashtable.put("prn_id", printer3.id);
                        hashtable.put("prn_model", printer3.model);
                        hashtable.put("prn_title", printer3.title);
                        String str11 = "bonjour";
                        if (printer3.id.startsWith("snmp_")) {
                            str11 = "snmp";
                        }
                        if (!printer3.id.startsWith("bjnp_")) {
                            str6 = str11;
                        }
                        if (printer3.id.startsWith("smb:")) {
                            str6 = "smb";
                        }
                        if (printer3.id.indexOf("_wprt.") > 0) {
                            str6 = "wsd";
                        }
                        if (printer3.id.indexOf("_tpl.") > 0) {
                            str6 = "tpl";
                        }
                        if (printer3.id.indexOf("_bluetooth.") > 0) {
                            str6 = "bluetooth";
                        }
                        if (printer3.id.indexOf("_usb.") > 0) {
                            str6 = "usb";
                        }
                        hashtable.put("prn_discovery", str6);
                        if (printer3.direct_address != null) {
                            int indexOf = printer3.direct_address.indexOf("://");
                            if (indexOf > 0) {
                                hashtable.put("prn_type", printer3.direct_address.substring(0, indexOf));
                            }
                        }
                        if (printer3.drv_name != null) {
                            String[] split = printer3.drv_name.split("\\|");
                            StringBuilder sb9 = new StringBuilder();
                            sb9.append(split[0]);
                            sb9.append("-");
                            sb9.append(split[3]);
                            hashtable.put("prn_drv", sb9.toString());
                        }
                        String[] strArr = {"usb_MFG", "usb_MDL", "usb_CMD", "product", "pdl", "ty", "rp", "URF"};
                        if (printer3.capabilities != null) {
                            Enumeration keys = printer3.capabilities.keys();
                            while (keys.hasMoreElements()) {
                                String str12 = (String) keys.nextElement();
                                String str13 = (String) printer3.capabilities.get(str12);
                                int i9 = 0;
                                while (true) {
                                    if (i9 >= 8) {
                                        break;
                                    } else if (strArr[i9].equalsIgnoreCase(str12)) {
                                        hashtable.put(str12, str13);
                                        break;
                                    } else {
                                        i9++;
                                    }
                                }
                            }
                        }
                        hashtable.put("country", App.getUserCountry());
                        String str14 = i8 == 0 ? "printer_unknown" : i8 == 1 ? "printer_generic" : i8 == 2 ? "printer_compatible" : "printer_supported";
                        FlurryAgent.logEvent(str14, (Map<String, String>) hashtable);
                    } catch (Exception e10) {
                        e10.printStackTrace();
                        App.reportThrowable(e10);
                    }
                }
            } else {
                if (ActivityLocalPrinters.this.last_error == null) {
                    ActivityLocalPrinters.this.last_error = "Error: Uknown error";
                }
                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityLocalPrinters.this.hideProgress();
                        ActivityLocalPrinters.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.header_local_printers);
        String action = getIntent().getAction();
        if ("BT".equals(action)) {
            this.scan_type = 1;
        } else if ("USB".equals(action)) {
            this.scan_type = 2;
        } else {
            this.scan_type = 0;
        }
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.button_scan);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivityLocalPrinters.this.start_scan();
            }
        });
        if (this.scan_type == 0) {
            this.view_dialog_authorization = LayoutInflater.from(this).inflate(R.layout.dialog_authorization, null);
            this.dialog_authorization = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_authorization_title).setView(this.view_dialog_authorization).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create();
        }
        this.smb_stack = new Stack<>();
        this.smb_files = new Vector<>();
        this.smb_printers = new Vector<>();
        this.printers = new Vector<>();
        ListView listView = (ListView) findViewById(R.id.list);
        PrinterAdapter printerAdapter = new PrinterAdapter(this);
        this.adapter = printerAdapter;
        listView.setAdapter(printerAdapter);
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Object tag = view.getTag();
                if (tag == null || !(tag instanceof Printer)) {
                    ActivityLocalPrinters.this.proceedSmb((SmbFile) tag);
                    return;
                }
                ActivityLocalPrinters.this.wt = new SetupPrinterThread((Printer) view.getTag(), false, null);
                ActivityLocalPrinters.this.wt.start();
            }
        });
        listView.setOnItemLongClickListener(new OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j) {
                Object tag = view.getTag();
                if (tag == null || !(tag instanceof Printer)) {
                    return false;
                }
                Printer printer = (Printer) view.getTag();
                ActivityLocalPrinters.this.wt = new SetupPrinterThread(printer, !printer.direct_address.startsWith("ptp://"), null);
                ActivityLocalPrinters.this.wt.start();
                return true;
            }
        });
        start_scan();
    }

    public void update() {
        if (npc_pid != null && this.scan_type == 2 && findViewById(R.id.button_print).isEnabled()) {
            npc_pid = null;
            AlertDialog alertDialog = this.error_dialog;
            if (alertDialog != null) {
                alertDialog.dismiss();
            }
            start_scan();
        }
        super.update();
    }

    /* access modifiers changed from: private */
    public void start_scan() {
        boolean z;
        synchronized (this) {
            z = true;
            try {
                if (this.wl == null || !this.wl.isHeld()) {
                    WakeLock newWakeLock = ((PowerManager) getSystemService("power")).newWakeLock(1, "PrinterShare:WakeLock");
                    this.wl = newWakeLock;
                    newWakeLock.acquire();
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
        int i = this.scan_type;
        if (i == 2) {
            this.stf_usb = true;
            ScanThreadUSB scanThreadUSB = new ScanThreadUSB(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_usb = scanThreadUSB;
            scanThreadUSB.start();
        } else if (i == 1) {
            this.stf_bluetooth = true;
            this.st_bluetooth = new ScanThreadBluetooth(getApplicationContext(), 15000, null, this.scanProgressHandler);
            boolean z2 = false;
            try {
                if (VERSION.class.getField("SDK_INT").getInt(null) < 23) {
                    z = false;
                }
                z2 = z;
            } catch (NoSuchFieldException unused) {
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
            if (z2) {
                new Object() {
                    {
                        String str = "android.permission.ACCESS_COARSE_LOCATION";
                        if (ActivityLocalPrinters.this.checkSelfPermission(str) != 0) {
                            ActivityLocalPrinters.this.requestPermissions(new String[]{str}, 444555);
                        } else {
                            ActivityLocalPrinters.this.st_bluetooth.start();
                        }
                    }
                };
            } else {
                this.st_bluetooth.start();
            }
        } else {
            try {
                this.smb_stack.clear();
                proceedSmb(new SmbFile("smb://", NtlmPasswordAuthentication.ANONYMOUS));
            } catch (Exception e3) {
                e3.printStackTrace();
                App.reportThrowable(e3);
            }
            this.stf_bonjour = true;
            ScanThreadBonjour scanThreadBonjour = new ScanThreadBonjour(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_bonjour = scanThreadBonjour;
            scanThreadBonjour.start();
            this.stf_snmp = true;
            ScanThreadSNMP scanThreadSNMP = new ScanThreadSNMP(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_snmp = scanThreadSNMP;
            scanThreadSNMP.start();
            this.stf_bjnp = true;
            ScanThreadBJNP scanThreadBJNP = new ScanThreadBJNP(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_bjnp = scanThreadBJNP;
            scanThreadBJNP.start();
            this.stf_wsd = true;
            ScanThreadWSD scanThreadWSD = new ScanThreadWSD(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_wsd = scanThreadWSD;
            scanThreadWSD.start();
            this.stf_tpl = true;
            ScanThreadTPL scanThreadTPL = new ScanThreadTPL(getApplicationContext(), 15000, null, this.scanProgressHandler);
            this.st_tpl = scanThreadTPL;
            scanThreadTPL.start();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.st_bluetooth.start();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || this.smb_stack.size() <= 1) {
            return super.onKeyDown(i, keyEvent);
        }
        proceedSmb(null);
        return true;
    }

    /* access modifiers changed from: private */
    public void proceedSmb(SmbFile smbFile) {
        if (smbFile == null) {
            SmbFile smbFile2 = (SmbFile) this.smb_stack.pop();
        } else if (this.smb_stack.size() == 0 || smbFile != this.smb_stack.lastElement()) {
            this.smb_stack.add(smbFile);
        }
        this.smb_printers.clear();
        this.smb_files.clear();
        this.adapter.fireOnChanged();
        if (this.smb_stack.size() > 1) {
            String str = "";
            String str2 = str;
            int i = 1;
            while (i < this.smb_stack.size()) {
                StringBuilder sb = new StringBuilder();
                sb.append(str2);
                sb.append(i > 1 ? " | " : str);
                sb.append(((SmbFile) this.smb_stack.get(i)).getServer());
                str2 = sb.toString();
                i++;
            }
            ((TextView) findViewById(R.id.hint1)).setText(getResources().getString(R.string.label_scanning));
            ((TextView) findViewById(R.id.hint2)).setText(str2);
            showProgress(getResources().getString(R.string.label_processing));
        }
        AnonymousClass7 r5 = new Thread() {
            /* JADX WARNING: Code restructure failed: missing block: B:18:0x0042, code lost:
                r7 = move-exception;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
                r7.printStackTrace();
                com.dynamixsoftware.printershare.App.reportThrowable(r7);
             */
            /* JADX WARNING: Code restructure failed: missing block: B:21:0x0049, code lost:
                r7 = null;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:43:0x0127, code lost:
                r7 = move-exception;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
                r7.printStackTrace();
                com.dynamixsoftware.printershare.App.reportThrowable(r7);
             */
            /* JADX WARNING: Code restructure failed: missing block: B:49:0x013b, code lost:
                r4 = (com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication) r0.getPrincipal();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:51:0x0144, code lost:
                if (r4 == com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication.ANONYMOUS) goto L_0x0146;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:52:0x0146, code lost:
                r0.setAuth(com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication.DEFAULT);
             */
            /* JADX WARNING: Code restructure failed: missing block: B:54:0x014f, code lost:
                if (r4 == com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication.DEFAULT) goto L_0x0151;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:55:0x0151, code lost:
                r5 = new com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication(r15.this$0.prefs.getString("smb_auth", null));
             */
            /* JADX WARNING: Code restructure failed: missing block: B:56:0x0164, code lost:
                if (r4.equals(r5) == false) goto L_0x0166;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:57:0x0166, code lost:
                r0.setAuth(r5);
             */
            /* JADX WARNING: Code restructure failed: missing block: B:59:0x0175, code lost:
                if (com.dynamixsoftware.printershare.ActivityLocalPrinters.access$400(r15.this$0).size() > 1) goto L_0x0177;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:60:0x0177, code lost:
                r2 = ((com.dynamixsoftware.printershare.smb.SmbFile) com.dynamixsoftware.printershare.ActivityLocalPrinters.access$400(r15.this$0).get(1)).getServer();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:61:0x0188, code lost:
                r2 = null;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:63:0x0193, code lost:
                if (com.dynamixsoftware.printershare.ActivityLocalPrinters.access$400(r15.this$0).size() > 2) goto L_0x0195;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:64:0x0195, code lost:
                r1 = ((com.dynamixsoftware.printershare.smb.SmbFile) com.dynamixsoftware.printershare.ActivityLocalPrinters.access$400(r15.this$0).lastElement()).getServer();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:65:0x01a6, code lost:
                r1 = null;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:66:0x01a7, code lost:
                if (r2 == null) goto L_0x01cf;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:71:0x01bd, code lost:
                r0.setAuth(new com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication(r2, r4.getUsername(), r4.getPassword()));
             */
            /* JADX WARNING: Code restructure failed: missing block: B:72:0x01cf, code lost:
                if (r1 == null) goto L_0x01ed;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:75:0x01db, code lost:
                r0.setAuth(new com.dynamixsoftware.printershare.smb.NtlmPasswordAuthentication(r1, r4.getUsername(), r4.getPassword()));
             */
            /* JADX WARNING: Failed to process nested try/catch */
            /* JADX WARNING: Removed duplicated region for block: B:50:? A[ExcHandler: SmbAuthException (unused com.dynamixsoftware.printershare.smb.SmbAuthException), SYNTHETIC, Splitter:B:2:0x000f] */
            public void run() {
                final SmbFile smbFile = (SmbFile) ActivityLocalPrinters.this.smb_stack.lastElement();
                loop0:
                while (true) {
                    try {
                        SmbFile[] listFiles = smbFile.listFiles();
                        int i = 0;
                        while (true) {
                            if (i >= listFiles.length) {
                                break loop0;
                            }
                            final SmbFile smbFile2 = listFiles[i];
                            int type = smbFile2.getType();
                            if (type == 2 || type == 4) {
                                if (ActivityLocalPrinters.this.st_smb != this) {
                                    break loop0;
                                }
                                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityLocalPrinters.this.hideProgress();
                                        ActivityLocalPrinters.this.smb_files.add(smbFile2);
                                        ActivityLocalPrinters.this.adapter.fireOnChanged();
                                    }
                                });
                            }
                            if (type == 32) {
                                String[] strArr = listFiles[i].printerGetInfo();
                                final Printer printer = new Printer();
                                printer.owner = new User();
                                printer.capabilities = new Hashtable<>();
                                String name = listFiles[i].getName();
                                if (name.endsWith("/")) {
                                    name = name.substring(0, name.length() - 1);
                                }
                                String path = listFiles[i].getPath();
                                printer.id = path;
                                printer.title = name;
                                String str = "";
                                NtlmPasswordAuthentication ntlmPasswordAuthentication = (NtlmPasswordAuthentication) smbFile.getPrincipal();
                                String domain = ntlmPasswordAuthentication.getDomain();
                                if (domain != null) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(str);
                                    sb.append(domain);
                                    sb.append(";");
                                    str = sb.toString();
                                }
                                String username = ntlmPasswordAuthentication.getUsername();
                                if (username != null) {
                                    StringBuilder sb2 = new StringBuilder();
                                    sb2.append(str);
                                    sb2.append(username);
                                    str = sb2.toString();
                                }
                                String password = ntlmPasswordAuthentication.getPassword();
                                if (password != null) {
                                    StringBuilder sb3 = new StringBuilder();
                                    sb3.append(str);
                                    sb3.append(":");
                                    sb3.append(password);
                                    str = sb3.toString();
                                }
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append("smb://");
                                sb4.append(URLEncoder.encode(str));
                                sb4.append("@");
                                sb4.append(path.substring(6));
                                printer.direct_address = sb4.toString();
                                printer.owner.name = listFiles[i].getServer();
                                if (strArr != null) {
                                    printer.model = App.clearPrinterModelName(strArr[1]);
                                    printer.location = strArr[2];
                                } else {
                                    printer.model = App.clearPrinterModelName(name);
                                }
                                if (ActivityLocalPrinters.this.st_smb != this) {
                                    break loop0;
                                }
                                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityLocalPrinters.this.hideProgress();
                                        ActivityLocalPrinters.this.smb_printers.add(printer);
                                        ActivityLocalPrinters.this.adapter.fireOnChanged();
                                    }
                                });
                            }
                            i++;
                        }
                    } catch (SmbAuthException unused) {
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                }
                ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityLocalPrinters.this.hideProgress();
                        if (!ActivityLocalPrinters.this.isFinishing()) {
                            ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).setText("");
                            ActivityLocalPrinters.this.dialog_authorization.setButton(-1, ActivityLocalPrinters.this.getResources().getString(R.string.button_ok), new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    String str;
                                    String obj = ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.login_edit)).getText().toString();
                                    int indexOf = obj.indexOf("\\");
                                    if (indexOf >= 0) {
                                        str = obj.substring(0, indexOf);
                                        obj = obj.substring(indexOf + 1);
                                    } else {
                                        str = "?";
                                    }
                                    smbFile.setAuth(new NtlmPasswordAuthentication(str, obj, ((EditText) ActivityLocalPrinters.this.view_dialog_authorization.findViewById(R.id.password_edit)).getText().toString()));
                                    ActivityLocalPrinters.this.proceedSmb((SmbFile) ActivityLocalPrinters.this.smb_stack.lastElement());
                                }
                            });
                            ActivityLocalPrinters.this.dialog_authorization.show();
                        }
                    }
                });
                if (ActivityLocalPrinters.this.st_smb == this && isAlive()) {
                    ActivityLocalPrinters.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityLocalPrinters.this.hideProgress();
                            Button button = (Button) ActivityLocalPrinters.this.findViewById(R.id.button_print);
                            TextView textView = (TextView) ActivityLocalPrinters.this.findViewById(R.id.hint1);
                            if (ActivityLocalPrinters.this.smb_stack.size() > 1) {
                                String str = "";
                                String str2 = str;
                                int i = 1;
                                while (i < ActivityLocalPrinters.this.smb_stack.size()) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(str2);
                                    sb.append(i > 1 ? " | " : str);
                                    sb.append(((SmbFile) ActivityLocalPrinters.this.smb_stack.get(i)).getServer());
                                    str2 = sb.toString();
                                    i++;
                                }
                                textView.setText(String.format(ActivityLocalPrinters.this.getResources().getString(R.string.label_found_printers), new Object[]{Integer.valueOf(ActivityLocalPrinters.this.smb_printers.size())}));
                                ((TextView) ActivityLocalPrinters.this.findViewById(R.id.hint2)).setText(str2);
                                return;
                            }
                            if (button.isEnabled()) {
                                textView.setText(String.format(ActivityLocalPrinters.this.getResources().getString(R.string.label_found_printers), new Object[]{Integer.valueOf(ActivityLocalPrinters.this.printers.size())}));
                            } else {
                                textView.setText(ActivityLocalPrinters.this.getResources().getString(R.string.label_scanning));
                            }
                            TextView textView2 = (TextView) ActivityLocalPrinters.this.findViewById(R.id.hint2);
                            if (ActivityLocalPrinters.this.scan_type == 1) {
                                textView2.setText(R.string.menu_nearby_bt);
                            } else if (ActivityLocalPrinters.this.scan_type == 2) {
                                textView2.setText(R.string.menu_nearby_usb);
                            } else {
                                textView2.setText(R.string.menu_nearby_wifi);
                            }
                        }
                    });
                }
                ActivityLocalPrinters.this.st_smb = null;
            }
        };
        this.st_smb = r5;
        r5.start();
    }

    public void onDestroy() {
        if (this.stf_bluetooth) {
            this.st_bluetooth.destroy();
        }
        if (this.stf_bonjour) {
            this.st_bonjour.destroy();
        }
        if (this.stf_snmp) {
            this.st_snmp.destroy();
        }
        if (this.stf_bjnp) {
            this.st_bjnp.destroy();
        }
        if (this.stf_wsd) {
            this.st_wsd.destroy();
        }
        if (this.stf_tpl) {
            this.st_tpl.destroy();
        }
        synchronized (this) {
            try {
                if (this.wl != null && this.wl.isHeld()) {
                    this.wl.release();
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            this.wl = null;
        }
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 10) {
            if (i2 != -1 || xprn == null) {
                hideProgress();
            } else {
                SetupPrinterThread setupPrinterThread = new SetupPrinterThread(xprn, false, intent.getExtras().getString("model"));
                this.wt = setupPrinterThread;
                setupPrinterThread.start();
            }
            xprn = null;
        }
    }
}
