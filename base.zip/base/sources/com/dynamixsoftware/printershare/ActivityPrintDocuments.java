package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Picture;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.widget.EditText;
import com.dynamixsoftware.printershare.ActivityPrint.Page;
import com.dynamixsoftware.printershare.App.PCanvas;
import com.dynamixsoftware.printershare.App.XPicture;
import com.dynamixsoftware.printershare.K2render.ReadingCallback;
import com.flurry.android.FlurryAgent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public class ActivityPrintDocuments extends ActivityPrint {
    private static final int DPI = 300;
    private static volatile boolean docs_lib_loaded = false;
    private static volatile Object docs_lib_obj = null;
    private static final String docs_render_lib = "libdocsrenderJNI.so";
    private static final String docs_render_pkg = "lib_docsrender";
    private static final String docs_render_ver = "3.8.1";
    private static final String fonts_pkg = "lib_extra_fonts";
    private static final String fonts_ver = "1.0.2";
    /* access modifiers changed from: private */
    public File doc_file;
    /* access modifiers changed from: private */
    public Vector<DocPicture> doc_pages;
    /* access modifiers changed from: private */
    public String doc_password;
    /* access modifiers changed from: private */
    public String doc_type;
    /* access modifiers changed from: private */
    public Uri doc_uri;
    protected CharSequence[] printSizeOptions;
    protected int print_size = 1;
    protected int sel_print_size;
    /* access modifiers changed from: private */
    public Thread ut;
    /* access modifiers changed from: private */
    public Thread wt;

    class CheckRenderThread extends Thread {
        private Boolean first_check;

        public CheckRenderThread(Boolean bool) {
            this.first_check = bool;
        }

        public void run() {
            boolean z;
            ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintDocuments.this.showProgress(ActivityPrintDocuments.this.getResources().getString(R.string.label_processing));
                }
            });
            if (this.first_check == null) {
                z = true;
            } else {
                try {
                    z = ActivityPrintDocuments.this.checkRender();
                } catch (Throwable th) {
                    th.printStackTrace();
                    App.reportThrowable(th);
                    z = false;
                }
            }
            if (!z) {
                if (this.first_check.booleanValue()) {
                    ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintDocuments.this.hideProgress();
                            new Builder(ActivityPrintDocuments.this.getActivity()).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_user_action_title).setMessage(R.string.dialog_install_docs_render_text).setPositiveButton(R.string.button_yes, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrintDocuments.this.wt = new InstallRenderThread();
                                    ActivityPrintDocuments.this.wt.start();
                                }
                            }).setNegativeButton(R.string.button_no, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            }).show();
                        }
                    });
                } else {
                    ActivityPrintDocuments.this.last_error = "Cannot install Docs Render library. An unknown error has ccurred.";
                    ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintDocuments.this.hideProgress();
                            ActivityPrintDocuments.this.displayLastError(new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            });
                        }
                    });
                }
                ActivityPrintDocuments.this.wt = null;
                return;
            }
            ActivityPrintDocuments.this.startConvertPages();
        }
    }

    class ConvertPagesThread extends Thread {
        ConvertPagesThread() {
        }

        public void run() {
            ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintDocuments.this.showProgress(ActivityPrintDocuments.this.getResources().getString(R.string.label_loading));
                }
            });
            ActivityPrintDocuments.this.last_error = null;
            try {
                if (ActivityPrintDocuments.this.doc_file == null) {
                    try {
                        String path = ActivityPrintDocuments.this.doc_uri.getPath();
                        int indexOf = !"file".equals(ActivityPrintDocuments.this.doc_uri.getScheme()) ? path.indexOf(App.ext_storage_root) : 0;
                        if (indexOf >= 0) {
                            ActivityPrintDocuments.this.doc_file = new File(path.substring(indexOf));
                            if (!ActivityPrintDocuments.this.doc_file.isFile() || !ActivityPrintDocuments.this.doc_file.exists() || !ActivityPrintDocuments.this.doc_file.canRead()) {
                                ActivityPrintDocuments.this.doc_file = null;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        App.reportThrowable(e);
                    }
                    if (ActivityPrintDocuments.this.doc_file == null) {
                        ActivityPrintDocuments activityPrintDocuments = ActivityPrintDocuments.this;
                        File tempDir = App.getTempDir();
                        StringBuilder sb = new StringBuilder();
                        sb.append("printershare_temp_doc");
                        sb.append(App.getExtByMimeType(ActivityPrintDocuments.this.doc_type));
                        activityPrintDocuments.doc_file = new File(tempDir, sb.toString());
                        InputStream openInputStream = ActivityPrintDocuments.this.getContentResolver().openInputStream(ActivityPrintDocuments.this.doc_uri);
                        FileOutputStream fileOutputStream = new FileOutputStream(ActivityPrintDocuments.this.doc_file);
                        byte[] bArr = new byte[4096];
                        while (true) {
                            int read = openInputStream.read(bArr);
                            if (read == -1) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, read);
                        }
                        fileOutputStream.close();
                        openInputStream.close();
                    }
                }
                int dpi = K2render.setDPI(ActivityPrintDocuments.DPI);
                String str = ".";
                String str2 = "Docs Render error ";
                if (dpi == 0) {
                    int openFile = K2render.openFile(ActivityPrintDocuments.this.doc_file.getAbsolutePath(), 0, ActivityPrintDocuments.this.doc_password, new ReadingCallback() {
                        public void on_reading(final int i) {
                            ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    ActivityPrintDocuments activityPrintDocuments = ActivityPrintDocuments.this;
                                    String string = ActivityPrintDocuments.this.getResources().getString(R.string.label_loading_progress);
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(i);
                                    sb.append("%");
                                    activityPrintDocuments.showProgress(String.format(string, new Object[]{sb.toString()}));
                                }
                            });
                        }
                    });
                    if (openFile != 1024) {
                        if (openFile != 8192) {
                            int pageCount = K2render.getPageCount();
                            if (openFile != 0) {
                                if (pageCount < 1) {
                                    StringBuilder sb2 = new StringBuilder();
                                    sb2.append(str2);
                                    sb2.append(openFile);
                                    sb2.append(str);
                                    throw new Exception(sb2.toString());
                                }
                            }
                            ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    ActivityPrintDocuments.this.showProgress(ActivityPrintDocuments.this.getResources().getString(R.string.label_processing));
                                }
                            });
                            int i = 0;
                            while (i < pageCount) {
                                int[] iArr = new int[2];
                                i++;
                                K2render.getPageSize(i, 100, iArr);
                                ActivityPrintDocuments.this.doc_pages.add(new DocPicture(i, (iArr[0] * 100) / ActivityPrintDocuments.DPI, (iArr[1] * 100) / ActivityPrintDocuments.DPI));
                            }
                            if (ActivityPrintDocuments.this.last_error == null) {
                                ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityPrintDocuments.this.need_update_pages = true;
                                        ActivityPrintDocuments.this.update();
                                    }
                                });
                            } else {
                                ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        ActivityPrintDocuments.this.hideProgress();
                                        ActivityPrintDocuments.this.displayLastError(new OnClickListener() {
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                            }
                                        });
                                    }
                                });
                            }
                            ActivityPrintDocuments.this.wt = null;
                            return;
                        }
                    }
                    ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintDocuments.this.hideProgress();
                            LayoutInflater from = LayoutInflater.from(ActivityPrintDocuments.this);
                            ActivityPrintDocuments.this.view_dialog_authorization = from.inflate(R.layout.dialog_authorization, null);
                            ActivityPrintDocuments.this.view_dialog_authorization.findViewById(R.id.login_label).setVisibility(8);
                            ActivityPrintDocuments.this.view_dialog_authorization.findViewById(R.id.login_edit).setVisibility(8);
                            new Builder(ActivityPrintDocuments.this).setIcon(R.drawable.icon_title).setTitle(R.string.label_password_required).setView(ActivityPrintDocuments.this.view_dialog_authorization).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrintDocuments.this.doc_password = ((EditText) ActivityPrintDocuments.this.view_dialog_authorization.findViewById(R.id.password_edit)).getText().toString();
                                    ActivityPrintDocuments.this.startConvertPages();
                                }
                            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            }).create().show();
                        }
                    });
                    ActivityPrintDocuments.this.wt = null;
                    return;
                }
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str2);
                sb3.append(dpi);
                sb3.append(str);
                throw new Exception(sb3.toString());
            } catch (Exception e2) {
                e2.printStackTrace();
                ActivityPrintDocuments activityPrintDocuments2 = ActivityPrintDocuments.this;
                StringBuilder sb4 = new StringBuilder();
                sb4.append("Internal Error: ");
                sb4.append(e2.getMessage());
                activityPrintDocuments2.last_error = sb4.toString();
                App.reportThrowable(e2, ActivityPrintDocuments.this.doc_uri != null ? ActivityPrintDocuments.this.doc_uri.toString() : null);
            }
        }
    }

    class DocPicture extends XPicture {
        int height;
        boolean landscape;
        int num;
        int width;

        public DocPicture(int i, int i2, int i3) {
            this.num = i;
            this.width = i2;
            this.height = i3;
            this.landscape = i2 > i3;
        }

        public int getWidth() {
            if (this.landscape ^ (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height)) {
                return (ActivityPrintDocuments.this.paper.height * 100) / 254;
            }
            return (ActivityPrintDocuments.this.paper.width * 100) / 254;
        }

        public int getHeight() {
            if (this.landscape ^ (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height)) {
                return (ActivityPrintDocuments.this.paper.width * 100) / 254;
            }
            return (ActivityPrintDocuments.this.paper.height * 100) / 254;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:86:0x035f, code lost:
            r11 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:87:0x0360, code lost:
            if (r11 >= r3) goto L_0x0435;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:88:0x0362, code lost:
            r15 = r8 + r11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:89:0x0366, code lost:
            if ((r11 + r10) <= r3) goto L_0x036c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:90:0x0368, code lost:
            r14 = r3 - r11;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:91:0x036c, code lost:
            r14 = r10;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:93:?, code lost:
            r22 = r14;
            r23 = r15;
            r13 = com.dynamixsoftware.printershare.K2render.drawPage(r1.num, r6, r5, r4, r23, r7, r22, r28, r0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:94:0x0385, code lost:
            if (r13 != 0) goto L_0x03ae;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:95:0x0387, code lost:
            r14 = r22;
            r17 = r5;
            r18 = r6;
            r5 = r23;
            r19 = r8;
            r2.drawBitmap(r0, new android.graphics.Rect(r12, r12, r7, r14), new android.graphics.RectF((float) r4, (float) r5, (float) (r4 + r7), (float) (r5 + r14)), r9);
            r11 = r11 + r14;
            r5 = r17;
            r6 = r18;
            r8 = r19;
            r12 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:96:0x03ae, code lost:
            r3 = new java.lang.StringBuilder();
            r3.append("Docs Render error ");
            r3.append(r13);
            r3.append(".");
         */
        /* JADX WARNING: Code restructure failed: missing block: B:97:0x03c9, code lost:
            throw new java.lang.Exception(r3.toString());
         */
        public void draw(Canvas canvas, boolean z) {
            Canvas canvas2 = canvas;
            String str = " / ";
            canvas.save();
            canvas2.drawColor(-1);
            int i = (ActivityPrintDocuments.this.paper.width * 100) / 254;
            int i2 = (ActivityPrintDocuments.this.paper.height * 100) / 254;
            int i3 = (((ActivityPrintDocuments.this.paper.width - ActivityPrintDocuments.this.paper.margin_left) - ActivityPrintDocuments.this.paper.margin_right) * 100) / 254;
            int i4 = (((ActivityPrintDocuments.this.paper.height - ActivityPrintDocuments.this.paper.margin_top) - ActivityPrintDocuments.this.paper.margin_bottom) * 100) / 254;
            if (ActivityPrintDocuments.this.print_size == 2) {
                i = i3;
                i2 = i4;
            }
            boolean z2 = true;
            int i5 = 0;
            if (this.landscape ^ (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height)) {
                int i6 = i2;
                i2 = i;
                i = i6;
                int i7 = i4;
                i4 = i3;
                i3 = i7;
            }
            if (!(this.landscape ^ (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height))) {
                canvas2.clipRect(new Rect((ActivityPrintDocuments.this.paper.margin_left * 100) / 254, (ActivityPrintDocuments.this.paper.margin_top * 100) / 254, ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254) + i3, ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254) + i4));
            } else if (ActivityPrintDocuments.this.paper.isLandscape270) {
                if (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height) {
                    canvas2.clipRect(new Rect((ActivityPrintDocuments.this.paper.margin_top * 100) / 254, (ActivityPrintDocuments.this.paper.margin_right * 100) / 254, ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254) + i3, ((ActivityPrintDocuments.this.paper.margin_right * 100) / 254) + i4));
                } else {
                    canvas2.clipRect(new Rect((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254, (ActivityPrintDocuments.this.paper.margin_left * 100) / 254, ((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254) + i3, ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254) + i4));
                }
            } else if (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height) {
                canvas2.clipRect(new Rect((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254, (ActivityPrintDocuments.this.paper.margin_left * 100) / 254, ((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254) + i3, ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254) + i4));
            } else {
                canvas2.clipRect(new Rect((ActivityPrintDocuments.this.paper.margin_top * 100) / 254, (ActivityPrintDocuments.this.paper.margin_right * 100) / 254, ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254) + i3, ((ActivityPrintDocuments.this.paper.margin_right * 100) / 254) + i4));
            }
            int i8 = this.width;
            int i9 = this.height;
            if (ActivityPrintDocuments.this.print_size == 2) {
                boolean z3 = this.landscape;
                if (ActivityPrintDocuments.this.paper.width <= ActivityPrintDocuments.this.paper.height) {
                    z2 = false;
                }
                if (!(z3 ^ z2)) {
                    canvas2.translate((float) ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254), (float) ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254));
                } else if (ActivityPrintDocuments.this.paper.isLandscape270) {
                    if (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height) {
                        canvas2.translate((float) ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254), (float) ((ActivityPrintDocuments.this.paper.margin_right * 100) / 254));
                    } else {
                        canvas2.translate((float) ((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254), (float) ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254));
                    }
                } else if (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height) {
                    canvas2.translate((float) ((ActivityPrintDocuments.this.paper.margin_bottom * 100) / 254), (float) ((ActivityPrintDocuments.this.paper.margin_left * 100) / 254));
                } else {
                    canvas2.translate((float) ((ActivityPrintDocuments.this.paper.margin_top * 100) / 254), (float) ((ActivityPrintDocuments.this.paper.margin_right * 100) / 254));
                }
            }
            if (ActivityPrintDocuments.this.print_size > 0) {
                RectF rectF = new RectF(0.0f, 0.0f, (float) i, (float) ((i * i9) / i8));
                float f = (float) i2;
                RectF rectF2 = new RectF(0.0f, 0.0f, (float) ((i8 * i2) / i9), f);
                if (rectF.height() > f) {
                    rectF = rectF2;
                }
                canvas2.scale(rectF.width() / ((float) i8), rectF.height() / ((float) i9));
            }
            canvas2.clipRect(new Rect(0, 0, this.width, this.height));
            RectF rectF3 = new RectF();
            Matrix matrix = canvas.getMatrix();
            matrix.mapRect(rectF3, new RectF(0.0f, 0.0f, (float) this.width, (float) this.height));
            float width2 = rectF3.width() / ((float) this.width);
            float height2 = rectF3.height() / ((float) this.height);
            if (height2 > width2) {
                width2 = height2;
            }
            float f2 = 1.0f / width2;
            canvas2.scale(f2, f2);
            int round = Math.round(((float) this.width) * width2);
            int round2 = Math.round(((float) this.height) * width2);
            canvas.getMatrix().invert(matrix);
            matrix.mapRect(rectF3, new RectF(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight()));
            int round3 = Math.round(rectF3.left);
            int round4 = Math.round(rectF3.right);
            int round5 = Math.round(rectF3.top);
            int round6 = Math.round(rectF3.bottom);
            if (round3 < round && round5 < round2 && round4 > 0 && round6 > 0 && round4 - round3 > 0 && round6 - round5 > 0) {
                if (round3 <= 0) {
                    round3 = 0;
                }
                if (round5 <= 0) {
                    round5 = 0;
                }
                if (round4 >= round) {
                    round4 = round;
                }
                int i10 = round4 - round3;
                if (round6 >= round2) {
                    round6 = round2;
                }
                int i11 = round6 - round5;
                if (i10 <= 0 || i11 <= 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Bad w or h: ");
                    sb.append(i10);
                    sb.append(str);
                    sb.append(i11);
                    sb.append(" (");
                    sb.append(this.width);
                    sb.append(str);
                    sb.append(this.height);
                    sb.append(") (");
                    sb.append(canvas.getWidth());
                    sb.append(str);
                    sb.append(canvas.getHeight());
                    sb.append(")");
                    throw new IllegalArgumentException(sb.toString());
                }
                Paint newPaint = App.newPaint();
                int i12 = i11;
                while (true) {
                    try {
                        Bitmap createBitmap = Bitmap.createBitmap(i10, i12, Config.ARGB_8888);
                        break;
                    } catch (OutOfMemoryError e) {
                        int i13 = round2;
                        int i14 = round;
                        int i15 = round5;
                        if (i12 > 64) {
                            i12 = (i12 % 2) + (i12 / 2);
                            round2 = i13;
                            round = i14;
                            round5 = i15;
                            i5 = 0;
                        } else {
                            throw e;
                        }
                    } catch (Throwable th) {
                        try {
                            th.printStackTrace();
                            App.reportThrowable(th);
                        } catch (Throwable th2) {
                            canvas.restore();
                            throw th2;
                        }
                    }
                }
            }
            canvas.restore();
        }
    }

    class InstallRenderThread extends Thread {
        InstallRenderThread() {
        }

        public void run() {
            ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintDocuments.this.showProgress(ActivityPrintDocuments.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityPrintDocuments.this.last_error = null;
            try {
                ActivityPrintDocuments.this.installDrvLibPack("pack_lib", false, "lib_docsrender|3.8.1", true, 0, 50);
                ActivityPrintDocuments.this.installDrvLibPack("pack_lib", true, "lib_extra_fonts|1.0.2", false, 50, 100);
                if (!new File("/system/lib/libskia.so").exists() && new File("/system/lib/libsgl.so").exists()) {
                    File file = new File(App.getFilesDirInt(ActivityPrintDocuments.docs_render_pkg), ActivityPrintDocuments.docs_render_lib);
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file), 4096);
                    byte[] bArr = {108, 105, 98, 115, 107, 105, 97, 46, 115, 111};
                    int i = 0;
                    int i2 = 0;
                    int i3 = -1;
                    while (true) {
                        int read = bufferedInputStream.read();
                        if (read == -1) {
                            break;
                        }
                        if (bArr[i] == read) {
                            if (i == 0) {
                                i3 = i2;
                            }
                            int i4 = i + 1;
                            if (i4 == 10) {
                                break;
                            }
                            i = i4;
                        } else {
                            i = 0;
                            i3 = -1;
                        }
                        i2++;
                    }
                    int i5 = i3;
                    bufferedInputStream.close();
                    if (i5 != -1) {
                        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
                        randomAccessFile.seek((long) (i5 + 4));
                        randomAccessFile.write(new byte[]{103, 108, 46, 115, 111, 0});
                        randomAccessFile.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityPrintDocuments activityPrintDocuments = ActivityPrintDocuments.this;
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e.getMessage());
                activityPrintDocuments.last_error = sb.toString();
                App.reportThrowable(e);
            }
            if (ActivityPrintDocuments.this.last_error != null) {
                ActivityPrintDocuments.this.wt = null;
                ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrintDocuments.this.hideProgress();
                        ActivityPrintDocuments.this.displayLastError(new OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        });
                    }
                });
                return;
            }
            ActivityPrintDocuments.this.startCheckRender(Boolean.valueOf(false));
        }
    }

    public void onCreate(Bundle bundle) {
        String str = "file";
        super.onCreate(bundle);
        boolean z = false;
        this.printSizeOptions = new CharSequence[]{getResources().getString(R.string.label_page_scaling_original), getResources().getString(R.string.label_page_scaling_fit_paper), getResources().getString(R.string.label_page_scaling_fit_printable_area)};
        SharedPreferences sharedPreferences = this.prefs;
        StringBuilder sb = new StringBuilder();
        sb.append(getActivityClassName());
        sb.append("#print_size");
        this.print_size = sharedPreferences.getInt(sb.toString(), this.print_size);
        Intent intent = getIntent();
        Uri data = "android.intent.action.SEND".equals(intent.getAction()) ? (Uri) intent.getExtras().get("android.intent.extra.STREAM") : intent.getData();
        this.doc_uri = data;
        if (data == null) {
            try {
                Hashtable hashtable = new Hashtable();
                hashtable.put("intent", intent.toString());
                FlurryAgent.logEvent("unknown_intent_docs", (Map<String, String>) hashtable);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            setResult(0);
            finish();
            return;
        }
        String type = intent.getType();
        this.doc_type = type;
        if ("message/rfc822".equals(type)) {
            this.doc_type = null;
        }
        if (this.doc_type == null) {
            this.doc_type = App.getMimeTypeByName(this.doc_uri.getPath());
        }
        try {
            if ((str.equals(this.doc_uri.getScheme()) && !new File(this.doc_uri.getPath()).canRead()) || (!str.equals(this.doc_uri.getScheme()) && checkCallingOrSelfUriPermission(this.doc_uri, 1) != 0)) {
                try {
                    if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                        z = true;
                    }
                } catch (NoSuchFieldException unused) {
                } catch (Exception e2) {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                }
                if (z) {
                    new Object() {
                        {
                            String str = "android.permission.READ_EXTERNAL_STORAGE";
                            if (ActivityPrintDocuments.this.checkSelfPermission(str) != 0) {
                                ActivityPrintDocuments.this.doc_pages = new Vector();
                                ActivityPrintDocuments.this.need_update_pages = false;
                                ActivityPrintDocuments.this.requestPermissions(new String[]{str}, 444555);
                            }
                        }
                    };
                }
            }
        } catch (Exception e3) {
            e3.printStackTrace();
            App.reportThrowable(e3);
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.doc_pages = null;
        this.need_update_pages = true;
        update();
    }

    public void onDestroy() {
        super.onDestroy();
        destroyLibViewer();
        String stringExtra = getIntent().getStringExtra("temp_file");
        if (stringExtra != null && stringExtra.indexOf("printershare_temp_") > 0) {
            new File(stringExtra).delete();
        }
    }

    /* access modifiers changed from: protected */
    public void destroyLibViewer() {
        if (this == docs_lib_obj) {
            try {
                int closeFile = K2render.closeFile();
                String str = ".";
                String str2 = "Docs Render error ";
                if (closeFile == 0) {
                    int deleteViewer = K2render.deleteViewer();
                    if (deleteViewer == 0) {
                        docs_lib_obj = null;
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(str2);
                    sb.append(deleteViewer);
                    sb.append(str);
                    throw new Exception(sb.toString());
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str2);
                sb2.append(closeFile);
                sb2.append(str);
                throw new Exception(sb2.toString());
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
    }

    public void onCreateOptionsMenu(ContextMenu contextMenu) {
        contextMenu.add(0, 100, 0, R.string.label_page_scaling);
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (menuItem.getItemId() != 100) {
            return super.onMenuItemSelected(i, menuItem);
        }
        Builder singleChoiceItems = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_page_scaling).setPositiveButton(R.string.button_ok, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityPrintDocuments activityPrintDocuments = ActivityPrintDocuments.this;
                activityPrintDocuments.print_size = activityPrintDocuments.sel_print_size;
                Editor edit = ActivityPrintDocuments.this.prefs.edit();
                StringBuilder sb = new StringBuilder();
                sb.append(ActivityPrintDocuments.this.getActivityClassName());
                sb.append("#print_size");
                edit.putInt(sb.toString(), ActivityPrintDocuments.this.print_size);
                edit.commit();
                ActivityPrintDocuments.this.need_update_pages = true;
                ActivityPrintDocuments.this.update();
            }
        }).setNegativeButton(R.string.button_cancel, null).setSingleChoiceItems(this.printSizeOptions, this.print_size, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                ActivityPrintDocuments.this.sel_print_size = i;
            }
        });
        this.sel_print_size = this.print_size;
        singleChoiceItems.show();
        return true;
    }

    /* access modifiers changed from: protected */
    public void update() {
        updatePages();
        super.update();
    }

    /* access modifiers changed from: protected */
    public void updatePages() {
        if (this.doc_pages == null) {
            this.doc_pages = new Vector<>();
            this.need_update_pages = false;
            if (docs_lib_obj != null) {
                destroyLibViewer();
                startCheckRender(null);
            } else {
                startCheckRender(Boolean.valueOf(true));
            }
        }
        if (this.need_update_pages && this.paper.roll && this.doc_pages.size() > 0) {
            DocPicture docPicture = (DocPicture) this.doc_pages.get(0);
            if (this.print_size == 2) {
                if (docPicture.width > docPicture.height) {
                    this.paper.height = ((docPicture.width * ((this.paper.width - this.paper.margin_left) - this.paper.margin_right)) / docPicture.height) + this.paper.margin_top + this.paper.margin_bottom;
                    return;
                }
                this.paper.height = ((docPicture.height * ((this.paper.width - this.paper.margin_left) - this.paper.margin_right)) / docPicture.width) + this.paper.margin_top + this.paper.margin_bottom;
            } else if (docPicture.width > docPicture.height) {
                this.paper.height = (docPicture.width * this.paper.width) / docPicture.height;
            } else {
                this.paper.height = (docPicture.height * this.paper.width) / docPicture.width;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        this.pages = new Vector();
        for (int i = 0; i < this.doc_pages.size(); i++) {
            this.pages.add(new Page((Picture) this.doc_pages.get(i)));
        }
    }

    /* access modifiers changed from: protected */
    public void showPreview(final Page page) {
        showProgress(getResources().getString(R.string.label_processing));
        AnonymousClass4 r0 = new Thread() {
            public void run() {
                final Bitmap bitmap;
                int i = 200;
                Bitmap bitmap2 = null;
                boolean z = false;
                while (true) {
                    App.freeMem();
                    try {
                        if (page.landscape ^ (ActivityPrintDocuments.this.paper.width > ActivityPrintDocuments.this.paper.height)) {
                            bitmap = Bitmap.createBitmap((ActivityPrintDocuments.this.paper.height * i) / 254, (ActivityPrintDocuments.this.paper.width * i) / 254, Config.ARGB_8888);
                        } else {
                            bitmap = Bitmap.createBitmap((ActivityPrintDocuments.this.paper.width * i) / 254, (ActivityPrintDocuments.this.paper.height * i) / 254, Config.ARGB_8888);
                        }
                    } catch (OutOfMemoryError unused) {
                        if (bitmap2 != null) {
                            bitmap2.recycle();
                            bitmap2 = null;
                        } else if (!z) {
                            App.clearExternalBytesAllocated();
                            z = true;
                        }
                        if (i == 100) {
                            bitmap = bitmap2;
                            break;
                        }
                        i -= 50;
                    }
                }
                if (bitmap != null) {
                    AnonymousClass1 r3 = new Picture() {
                        Bitmap cbmp = bitmap;

                        /* access modifiers changed from: protected */
                        public void finalize() throws Throwable {
                            super.finalize();
                            if (this.cbmp != null) {
                                this.cbmp = null;
                            }
                        }
                    };
                    new PCanvas(bitmap, true).drawPicture(page.getPicture(), new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()));
                    r3.beginRecording(bitmap.getWidth(), bitmap.getHeight()).drawBitmap(bitmap, 0.0f, 0.0f, App.newPaint());
                    r3.endRecording();
                    ActivityPrint.pp = r3;
                } else {
                    ActivityPrint.pp = page.getPicture();
                }
                Intent intent = new Intent();
                intent.setClass(ActivityPrintDocuments.this, ActivityPreview.class);
                ActivityPrintDocuments.this.startActivityForResult(intent, 10);
                ActivityPrintDocuments.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrintDocuments.this.hideProgress();
                    }
                });
                ActivityPrintDocuments.this.ut = null;
            }
        };
        this.ut = r0;
        r0.start();
    }

    /* access modifiers changed from: protected */
    public boolean checkRender() throws Exception {
        SharedPreferences sharedPreferences = this.prefs;
        String str = docs_render_pkg;
        String str2 = "";
        int i = 0;
        if (!docs_render_ver.equals(sharedPreferences.getString(str, str2))) {
            return false;
        }
        SharedPreferences sharedPreferences2 = this.prefs;
        String str3 = fonts_pkg;
        if (!fonts_ver.equals(sharedPreferences2.getString(str3, str2))) {
            return false;
        }
        File file = new File(App.getFilesDirInt(str), docs_render_lib);
        if (!file.exists()) {
            return false;
        }
        File filesDirExt = App.getFilesDirExt(str3);
        if (!filesDirExt.exists()) {
            return false;
        }
        String str4 = "DroidSansFull.ttf";
        if (!new File(App.getFilesDirExt(str), str4).exists()) {
            return false;
        }
        String str5 = ".";
        String str6 = "Docs Render error ";
        if (!docs_lib_loaded) {
            System.load(file.getAbsolutePath());
            File[] listFiles = filesDirExt.listFiles();
            String[] strArr = new String[(listFiles.length + 1)];
            strArr[0] = new File(App.getFilesDirExt(str), str4).getAbsolutePath();
            while (i < listFiles.length) {
                int i2 = i + 1;
                strArr[i2] = listFiles[i].getAbsolutePath();
                i = i2;
            }
            int init = K2render.init(strArr);
            if (init == 0) {
                docs_lib_loaded = true;
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append(str6);
                sb.append(init);
                sb.append(str5);
                throw new Exception(sb.toString());
            }
        }
        if (docs_lib_obj == null) {
            int createViewer = K2render.createViewer(App.getTempDir().getAbsolutePath(), App.getTotalMemory() * 1024);
            if (createViewer == 0) {
                docs_lib_obj = this;
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str6);
                sb2.append(createViewer);
                sb2.append(str5);
                throw new Exception(sb2.toString());
            }
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void startCheckRender(Boolean bool) {
        CheckRenderThread checkRenderThread = new CheckRenderThread(bool);
        this.wt = checkRenderThread;
        checkRenderThread.start();
    }

    /* access modifiers changed from: protected */
    public void startConvertPages() {
        ConvertPagesThread convertPagesThread = new ConvertPagesThread();
        this.wt = convertPagesThread;
        convertPagesThread.start();
    }
}
