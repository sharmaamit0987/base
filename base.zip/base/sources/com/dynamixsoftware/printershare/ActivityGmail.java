package com.dynamixsoftware.printershare;

import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableStringBuilder;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.dynamixsoftware.printershare.gmail.GmsProtos;
import com.dynamixsoftware.printershare.gmail.ProtoBuf;
import com.google.android.collect.Maps;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

public class ActivityGmail extends ActivityRoot {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final SimpleDateFormat df1 = new SimpleDateFormat("h:mm a", new DateFormatSymbols(Locale.US));
    public static final SimpleDateFormat df2 = new SimpleDateFormat("MMM d", new DateFormatSymbols(Locale.US));
    public static final SimpleDateFormat df3 = new SimpleDateFormat("M/d/yyyy", new DateFormatSymbols(Locale.US));
    private static int requesting_credentials;
    private static final Map<Integer, Integer> sPriorityToLength = Maps.newHashMap();
    /* access modifiers changed from: private */
    public AlertDialog accounts_menu;
    /* access modifiers changed from: private */
    public MyAdapter adapter;
    /* access modifiers changed from: private */
    public String[] al;
    private Object[] al_objs;
    /* access modifiers changed from: private */
    public long client_id;
    /* access modifiers changed from: private */
    public volatile Hashtable<String, String> cn_labels;
    /* access modifiers changed from: private */
    public String[] credentials;
    /* access modifiers changed from: private */
    public volatile Vector<ProtoBuf> data;
    private boolean ftoken;
    private Handler handler;
    /* access modifiers changed from: private */
    public volatile Hashtable<Long, String> id_labels;
    /* access modifiers changed from: private */
    public volatile String label;
    /* access modifiers changed from: private */
    public volatile Vector<String> labels;
    /* access modifiers changed from: private */
    public AlertDialog labels_menu;
    /* access modifiers changed from: private */
    public ListView mList;
    /* access modifiers changed from: private */
    public TextView mLoading;
    boolean new_am;
    /* access modifiers changed from: private */
    public volatile Thread wt;

    class MyAdapter implements ListAdapter {
        private List<DataSetObserver> observers = null;

        public boolean areAllItemsEnabled() {
            return true;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return true;
        }

        public boolean isEnabled(int i) {
            return true;
        }

        MyAdapter() {
        }

        public int getCount() {
            int i = 0;
            for (int i2 = 0; i2 < ActivityGmail.this.data.size(); i2++) {
                i += ((ProtoBuf) ActivityGmail.this.data.get(i2)).getCount(3);
            }
            return i;
        }

        public Object getItem(int i) {
            int i2 = 0;
            int i3 = 0;
            while (i2 < ActivityGmail.this.data.size()) {
                ProtoBuf protoBuf = (ProtoBuf) ActivityGmail.this.data.get(i2);
                int count = protoBuf.getCount(3) + i3;
                if (i < count) {
                    return protoBuf.getProtoBuf(3, i - i3);
                }
                i2++;
                i3 = count;
            }
            return null;
        }

        public long getItemId(int i) {
            return ((ProtoBuf) getItem(i)).getLong(1);
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            String str;
            if (i == getCount() - 1) {
                long j = ((ProtoBuf) ActivityGmail.this.data.lastElement()).getLong(2);
                if (j != 0 && ActivityGmail.this.wt == null) {
                    ActivityGmail.this.mLoading.setText(R.string.label_loading);
                    if (ActivityGmail.this.mList.getFooterViewsCount() == 1) {
                        ActivityGmail.this.mList.addFooterView(ActivityGmail.this.mLoading);
                    }
                    ActivityGmail.this.loadConversations(j);
                }
            }
            int i2 = 0;
            View inflate = view == null ? ActivityGmail.this.getLayoutInflater().inflate(R.layout.list_item_gmail, viewGroup, false) : view;
            ProtoBuf protoBuf = (ProtoBuf) getItem(i);
            HashSet hashSet = new HashSet();
            int count = protoBuf.getCount(11);
            for (int i3 = 0; i3 < count; i3++) {
                String str2 = (String) ActivityGmail.this.id_labels.get(Long.valueOf(protoBuf.getLong(11, i3)));
                if (str2 != null) {
                    hashSet.add(str2);
                }
            }
            ImageView imageView = (ImageView) inflate.findViewById(R.id.star);
            StringBuilder sb = new StringBuilder();
            StringBuffer stringBuffer = new StringBuffer();
            Iterator it = hashSet.iterator();
            boolean z = false;
            boolean z2 = false;
            while (it.hasNext()) {
                String str3 = (String) it.next();
                if (GmsProtos.LABEL_STARRED.equals(str3)) {
                    z = true;
                }
                if (GmsProtos.LABEL_UNREAD.equals(str3)) {
                    z2 = true;
                }
                String str4 = (String) ActivityGmail.this.cn_labels.get(str3);
                if (str4 != null && !ActivityGmail.this.label.equals(str3) && (!str3.startsWith("^") || GmsProtos.LABEL_INBOX.equals(str3))) {
                    if (stringBuffer.length() > 0) {
                        stringBuffer.append(", ");
                    }
                    stringBuffer.append(str4);
                }
                if (str4 != null) {
                    sb.append(str4);
                    sb.append(0);
                }
            }
            inflate.setTag(new String[]{String.valueOf(protoBuf.getLong(1)), String.valueOf(protoBuf.getInt(8)), sb.toString()});
            if (z) {
                imageView.setImageResource(R.drawable.star_on);
            } else {
                imageView.setImageResource(R.drawable.star_off);
            }
            TextView textView = (TextView) inflate.findViewById(R.id.labels);
            textView.setText(stringBuffer);
            textView.setVisibility(stringBuffer.length() > 0 ? 0 : 8);
            TextView textView2 = (TextView) inflate.findViewById(R.id.snippet);
            String string = protoBuf.getString(4);
            String string2 = protoBuf.getString(5);
            StringBuilder sb2 = new StringBuilder();
            sb2.append(string);
            String str5 = "";
            sb2.append((string.length() <= 0 || string2.length() <= 0) ? str5 : " - ");
            sb2.append(string2);
            textView2.setText(sb2.toString());
            int i4 = protoBuf.getInt(6);
            if (i4 == 2) {
                str5 = "» ";
            }
            if (i4 == 1) {
                str5 = "› ";
            }
            ProtoBuf protoBuf2 = protoBuf.getProtoBuf(10);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            try {
                ActivityGmail.getSenderSnippet(protoBuf2, spannableStringBuilder, 64, new StyleSpan(1), new ForegroundColorSpan(-65536), "Me", "Draft", "Drafts", false, false);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            spannableStringBuilder.insert(0, str5);
            ((TextView) inflate.findViewById(R.id.from)).setText(spannableStringBuilder);
            if (z2) {
                textView2.setTypeface(Typeface.DEFAULT_BOLD, 1);
            } else {
                textView2.setTypeface(Typeface.DEFAULT, 0);
            }
            Date date = new Date(protoBuf.getLong(3));
            Date date2 = new Date();
            if (date2.getYear() != date.getYear()) {
                str = ActivityGmail.df3.format(date);
            } else if (date2.getMonth() == date.getMonth() && date2.getDate() == date.getDate()) {
                str = ActivityGmail.df1.format(date);
            } else {
                str = ActivityGmail.df2.format(date);
            }
            ((TextView) inflate.findViewById(R.id.date)).setText(str);
            View findViewById = inflate.findViewById(R.id.paperclip);
            if (!protoBuf.getBool(9)) {
                i2 = 8;
            }
            findViewById.setVisibility(i2);
            return inflate;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0106  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    public void onCreate(Bundle bundle) {
        boolean z;
        String str = "SDK_INT";
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_gmail);
        try {
            if (VERSION.class.getField(str).getInt(null) >= 26) {
                this.new_am = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        ((TextView) findViewById(R.id.empty)).setText(R.string.label_no_conversations);
        Button button = (Button) findViewById(R.id.button_print);
        button.setText(R.string.menu_labels);
        button.setEnabled(false);
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (ActivityGmail.this.labels_menu != null) {
                    ActivityGmail.this.labels_menu.show();
                }
            }
        });
        this.client_id = System.currentTimeMillis();
        this.handler = new Handler();
        this.data = new Vector<>();
        this.labels = new Vector<>();
        this.id_labels = new Hashtable<>();
        this.cn_labels = new Hashtable<>();
        this.mList = (ListView) findViewById(R.id.list);
        TextView textView = new TextView(this);
        this.mLoading = textView;
        textView.setTextColor(-16777216);
        this.mLoading.setText(R.string.label_loading);
        int i = (int) (getResources().getDisplayMetrics().density * 5.0f);
        this.mLoading.setPadding(i, i, i, i);
        this.mList.addFooterView(new View(this));
        this.mList.setFooterDividersEnabled(false);
        this.mList.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String[] strArr = (String[]) view.getTag();
                if (strArr != null) {
                    Intent intent = new Intent();
                    StringBuilder sb = new StringBuilder();
                    sb.append(ActivityGmail.this.credentials[0]);
                    sb.append("\u0000");
                    sb.append(ActivityGmail.this.credentials[1]);
                    intent.putExtra("credentials", sb.toString());
                    intent.putExtra("client_id", ActivityGmail.this.client_id);
                    intent.putExtra("conversation_id", strArr[0]);
                    intent.putExtra("messages_count", strArr[1]);
                    intent.putExtra("labels", strArr[2]);
                    Enumeration keys = ActivityGmail.this.id_labels.keys();
                    while (keys.hasMoreElements()) {
                        Long l = (Long) keys.nextElement();
                        String str = (String) ActivityGmail.this.id_labels.get(l);
                        if (GmsProtos.LABEL_STARRED.equals(str)) {
                            intent.putExtra("s_label_id", l);
                        } else if (GmsProtos.LABEL_UNREAD.equals(str)) {
                            intent.putExtra("u_label_id", l);
                        }
                    }
                    intent.setClass(ActivityGmail.this, ActivityGmailConversation.class);
                    ActivityGmail.this.startActivity(intent);
                }
            }
        });
        MyAdapter myAdapter = new MyAdapter();
        this.adapter = myAdapter;
        this.mList.setAdapter(myAdapter);
        this.mList.setVisibility(8);
        findViewById(R.id.empty).setVisibility(0);
        this.ftoken = false;
        if (!this.new_am) {
            try {
                if (VERSION.class.getField(str).getInt(null) >= 23) {
                    z = true;
                    if (!z) {
                        final boolean[] zArr = new boolean[1];
                        new Object() {
                            {
                                String str = "android.permission.GET_ACCOUNTS";
                                if (ActivityGmail.this.checkSelfPermission(str) != 0) {
                                    ActivityGmail.this.al = new String[0];
                                    ActivityGmail.this.requestPermissions(new String[]{str}, 444555);
                                    zArr[0] = true;
                                }
                            }
                        };
                        if (zArr[0]) {
                        }
                        return;
                    }
                    return;
                }
            } catch (NoSuchFieldException unused2) {
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
            z = false;
            if (!z) {
            }
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.al = null;
        xinit();
    }

    /* access modifiers changed from: private */
    public void chooseAccount() {
        if (this.new_am) {
            new Object() {
                {
                    ActivityGmail.this.startActivityForResult(AccountManager.newChooseAccountIntent(null, null, new String[]{"com.google"}, null, null, null, null), 444555);
                }
            };
        } else {
            this.accounts_menu.show();
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1 && i == 444555) {
            String stringExtra = intent.getStringExtra("authAccount");
            if (stringExtra != null) {
                Object systemService = getSystemService("account");
                try {
                    Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
                    this.al_objs = objArr;
                    if (objArr != null) {
                        this.al = new String[objArr.length];
                        if (objArr.length > 0) {
                            Field field = objArr[0].getClass().getField("name");
                            for (int i3 = 0; i3 < objArr.length; i3++) {
                                this.al[i3] = (String) field.get(objArr[i3]);
                            }
                        }
                    }
                    showAccount(stringExtra);
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
        }
        super.onActivityResult(i, i2, intent);
    }

    /* access modifiers changed from: private */
    public void showAccount(final String str) {
        showProgress(getResources().getString(R.string.label_processing));
        Editor edit = this.prefs.edit();
        edit.putString("gmail_account", str);
        edit.commit();
        this.labels_menu = null;
        findViewById(R.id.button_print).setEnabled(false);
        String str2 = "";
        ((TextView) findViewById(R.id.hint1)).setText(str2);
        ((TextView) findViewById(R.id.hint2)).setText(str2);
        this.label = null;
        this.labels.clear();
        Vector<String> vector = this.labels;
        String str3 = GmsProtos.LABEL_INBOX;
        vector.add(str3);
        Vector<String> vector2 = this.labels;
        String str4 = GmsProtos.LABEL_STARRED;
        vector2.add(str4);
        Vector<String> vector3 = this.labels;
        String str5 = GmsProtos.LABEL_CHATS;
        vector3.add(str5);
        Vector<String> vector4 = this.labels;
        String str6 = GmsProtos.LABEL_SENT;
        vector4.add(str6);
        Vector<String> vector5 = this.labels;
        String str7 = GmsProtos.LABEL_DRAFTS;
        vector5.add(str7);
        Vector<String> vector6 = this.labels;
        String str8 = GmsProtos.LABEL_ALL;
        vector6.add(str8);
        Vector<String> vector7 = this.labels;
        String str9 = GmsProtos.LABEL_SPAM;
        vector7.add(str9);
        Vector<String> vector8 = this.labels;
        String str10 = GmsProtos.LABEL_TRASH;
        vector8.add(str10);
        Resources resources = getResources();
        this.cn_labels.clear();
        this.cn_labels.put(str3, resources.getString(R.string.label_inbox));
        this.cn_labels.put(str4, resources.getString(R.string.label_starred));
        this.cn_labels.put(str5, resources.getString(R.string.label_chats));
        this.cn_labels.put(str6, resources.getString(R.string.label_sent));
        this.cn_labels.put(str7, resources.getString(R.string.label_drafts));
        this.cn_labels.put(str8, resources.getString(R.string.label_all));
        this.cn_labels.put(str9, resources.getString(R.string.label_spam));
        this.cn_labels.put(str10, resources.getString(R.string.label_trash));
        this.id_labels.clear();
        this.mList.setVisibility(8);
        findViewById(R.id.empty).setVisibility(0);
        this.data.clear();
        this.adapter.fireOnChanged();
        this.wt = new Thread() {
            public void run() {
                ActivityGmail.this.authorize(str);
            }
        };
        this.wt.start();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.al == null || requesting_credentials != 0) {
            showProgress(getResources().getString(R.string.label_processing));
            this.wt = new Thread() {
                public void run() {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException unused) {
                    }
                    ActivityGmail.this.xinit();
                }
            };
            this.wt.start();
        }
    }

    /* access modifiers changed from: private */
    public void xinit() {
        Object systemService = getSystemService("account");
        try {
            Object[] objArr = (Object[]) systemService.getClass().getMethod("getAccountsByType", new Class[]{String.class}).invoke(systemService, new Object[]{"com.google"});
            this.al_objs = objArr;
            if (objArr != null) {
                this.al = new String[objArr.length];
                if (objArr.length > 0) {
                    Field field = objArr[0].getClass().getField("name");
                    for (int i = 0; i < objArr.length; i++) {
                        this.al[i] = (String) field.get(objArr[i]);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        xinit_done();
    }

    private void xinit_done() {
        this.wt = null;
        runOnUiThread(new Runnable() {
            public void run() {
                String str = null;
                String string = ActivityGmail.this.prefs.getString("gmail_account", null);
                int length = (ActivityGmail.this.al != null ? ActivityGmail.this.al.length : 0) + 1;
                CharSequence[] charSequenceArr = new CharSequence[length];
                if (ActivityGmail.this.al != null && ActivityGmail.this.al.length > 0) {
                    for (int i = 0; i < ActivityGmail.this.al.length; i++) {
                        charSequenceArr[i] = ActivityGmail.this.al[i];
                        if (ActivityGmail.this.al[i].equals(string)) {
                            str = string;
                        }
                    }
                }
                charSequenceArr[length - 1] = ActivityGmail.this.getResources().getString(R.string.menu_add_account);
                ActivityGmail.this.accounts_menu = new Builder(ActivityGmail.this).setIcon(R.drawable.icon_title).setTitle(R.string.menu_accounts).setItems(charSequenceArr, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ActivityGmail.this.al == null || i >= ActivityGmail.this.al.length) {
                            final Object systemService = ActivityGmail.this.getSystemService("account");
                            ActivityGmail.this.wt = new Thread() {
                                public void run() {
                                    Method method;
                                    try {
                                        Method[] methods = systemService.getClass().getMethods();
                                        int i = 0;
                                        while (true) {
                                            if (i >= methods.length) {
                                                method = null;
                                                break;
                                            } else if ("addAccount".equals(methods[i].getName())) {
                                                method = methods[i];
                                                break;
                                            } else {
                                                i++;
                                            }
                                        }
                                        Object invoke = method.invoke(systemService, new Object[]{"com.google", null, null, null, ActivityGmail.this, null, null});
                                        String string = ((Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0])).getString("authAccount");
                                        if (string != null) {
                                            Editor edit = ActivityGmail.this.prefs.edit();
                                            edit.putString("gmail_account", string);
                                            edit.commit();
                                            ActivityGmail.this.xinit();
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                }
                            };
                            ActivityGmail.this.wt.start();
                            return;
                        }
                        ActivityGmail.this.showAccount(ActivityGmail.this.al[i]);
                    }
                }).create();
                if (str != null) {
                    ActivityGmail.this.showAccount(str);
                    return;
                }
                ActivityGmail.this.hideProgress();
                if (!ActivityGmail.this.isFinishing()) {
                    ActivityGmail.this.chooseAccount();
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void authorize(String str) {
        Method method;
        this.last_error = null;
        String[] strArr = new String[2];
        this.credentials = strArr;
        strArr[0] = str;
        Object systemService = getSystemService("account");
        Object[] objArr = this.al_objs;
        if (objArr != null && objArr.length > 0) {
            int i = 0;
            while (true) {
                try {
                    if (i >= this.al.length) {
                        i = 0;
                        break;
                    } else if (this.al[i].equals(str)) {
                        break;
                    } else {
                        i++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            Method[] methods = systemService.getClass().getMethods();
            int i2 = 0;
            while (true) {
                if (i2 < methods.length) {
                    if ("getAuthToken".equals(methods[i2].getName()) && methods[i2].getParameterTypes().length == 5) {
                        method = methods[i2];
                        break;
                    }
                    i2++;
                } else {
                    method = null;
                    break;
                }
            }
            Object invoke = method.invoke(systemService, new Object[]{this.al_objs[i], "mail", Boolean.valueOf(false), null, this.handler});
            Bundle bundle = (Bundle) invoke.getClass().getMethod("getResult", new Class[0]).invoke(invoke, new Object[0]);
            Intent intent = (Intent) bundle.getParcelable("intent");
            if (intent == null) {
                this.credentials[1] = bundle.getString("authtoken");
            } else if (requesting_credentials == 0) {
                requesting_credentials = 1;
                startActivity(intent);
                this.wt = null;
                return;
            }
        }
        requesting_credentials = 0;
        authorize_done();
    }

    private void authorize_done() {
        if (this.credentials[1] != null) {
            int loadLabels = loadLabels();
            if (loadLabels != 0) {
                this.wt = null;
                String str = "gmail_account";
                if (this.prefs.getString(str, null) == null) {
                    Editor edit = this.prefs.edit();
                    edit.putString(str, this.credentials[0]);
                    edit.commit();
                }
                if (loadLabels > 0) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            CharSequence[] charSequenceArr = new CharSequence[ActivityGmail.this.labels.size()];
                            for (int i = 0; i < ActivityGmail.this.labels.size(); i++) {
                                charSequenceArr[i] = (CharSequence) ActivityGmail.this.cn_labels.get(ActivityGmail.this.labels.get(i));
                            }
                            ActivityGmail.this.labels_menu = new Builder(ActivityGmail.this).setIcon(R.drawable.icon_title).setTitle(R.string.menu_labels).setItems(charSequenceArr, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityGmail.this.showConversations((String) ActivityGmail.this.labels.get(i));
                                }
                            }).create();
                            ActivityGmail.this.findViewById(R.id.button_print).setEnabled(true);
                            ActivityGmail.this.hideProgress();
                            ActivityGmail.this.showConversations(GmsProtos.LABEL_INBOX);
                        }
                    });
                    return;
                }
                return;
            }
        }
        this.wt = null;
        runOnUiThread(new Runnable() {
            public void run() {
                ActivityGmail.this.hideProgress();
                if (ActivityGmail.this.prefs.getString("gmail_account", null) != null) {
                    ActivityGmail.this.last_error = "Error: Authorization failed or network error has occured";
                    ActivityGmail.this.displayLastError(new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityGmail.this.chooseAccount();
                        }
                    });
                }
            }
        });
    }

    private int loadLabels() {
        Method method;
        ProtoBuf protoBuf = null;
        try {
            ProtoBuf protoBuf2 = new ProtoBuf(GmsProtos.REQUEST);
            protoBuf2.setLong(1, this.client_id);
            ProtoBuf newProtoBuf = protoBuf2.setNewProtoBuf(2);
            newProtoBuf.setInt(1, 4);
            newProtoBuf.addString(2, GmsProtos.LABEL_DRAFTS);
            newProtoBuf.addString(3, GmsProtos.LABEL_INBOX);
            newProtoBuf.addString(3, GmsProtos.LABEL_SENT);
            newProtoBuf.addString(3, "^iim");
            GmsProtos.doRequest(this.credentials, protoBuf2);
            ProtoBuf protoBuf3 = new ProtoBuf(GmsProtos.REQUEST);
            protoBuf3.setLong(1, this.client_id);
            ProtoBuf newProtoBuf2 = protoBuf3.setNewProtoBuf(6);
            newProtoBuf2.setLong(1, 0);
            newProtoBuf2.setLong(2, 0);
            newProtoBuf2.setLong(3, 0);
            newProtoBuf2.setLong(4, 0);
            newProtoBuf2.setBool(5, true);
            newProtoBuf2.setBool(6, true);
            newProtoBuf2.setBool(7, true);
            protoBuf = GmsProtos.doRequest(this.credentials, protoBuf3).getProtoBuf(4);
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
            if (e.getMessage() != null && ((e.getMessage().indexOf("HTTP error 401") >= 0 || e.getMessage().indexOf("No authentication challenges found") >= 0) && !this.ftoken)) {
                this.ftoken = true;
                Object systemService = getSystemService("account");
                try {
                    Method[] methods = systemService.getClass().getMethods();
                    int i = 0;
                    while (true) {
                        if (i < methods.length) {
                            if ("invalidateAuthToken".equals(methods[i].getName()) && methods[i].getParameterTypes().length == 2) {
                                method = methods[i];
                                break;
                            }
                            i++;
                        } else {
                            method = null;
                            break;
                        }
                    }
                    method.invoke(systemService, new Object[]{"com.google", this.credentials[1]});
                    this.wt = new Thread() {
                        public void run() {
                            ActivityGmail activityGmail = ActivityGmail.this;
                            activityGmail.authorize(activityGmail.credentials[0]);
                        }
                    };
                    this.wt.start();
                    return -1;
                } catch (Exception e2) {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                }
            }
        }
        if (protoBuf != null) {
            int count = protoBuf.getCount(4);
            for (int i2 = 0; i2 < count; i2++) {
                ProtoBuf protoBuf4 = protoBuf.getProtoBuf(4, i2);
                long j = protoBuf4.getLong(1);
                String string = protoBuf4.getString(2);
                String string2 = protoBuf4.getString(3);
                if (!string.startsWith("^")) {
                    this.labels.add(string);
                    this.cn_labels.put(string, string2);
                }
                this.id_labels.put(Long.valueOf(j), string);
            }
            if (count > 0) {
                return 1;
            }
        }
        return 0;
    }

    /* access modifiers changed from: private */
    public void loadConversations(final long j) {
        this.wt = new Thread() {
            public void run() {
                try {
                    ProtoBuf protoBuf = new ProtoBuf(GmsProtos.REQUEST);
                    protoBuf.setLong(1, ActivityGmail.this.client_id);
                    ProtoBuf newProtoBuf = protoBuf.setNewProtoBuf(5);
                    StringBuilder sb = new StringBuilder();
                    sb.append("label:");
                    sb.append(ActivityGmail.this.label);
                    newProtoBuf.setString(1, sb.toString());
                    newProtoBuf.setLong(2, j);
                    newProtoBuf.setInt(3, 22);
                    newProtoBuf.setInt(4, 5);
                    final ProtoBuf protoBuf2 = GmsProtos.doRequest(ActivityGmail.this.credentials, protoBuf).getProtoBuf(15);
                    if (ActivityGmail.this.wt == this) {
                        ActivityGmail.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityGmail.this.mList.removeFooterView(ActivityGmail.this.mLoading);
                                ActivityGmail.this.data.add(protoBuf2);
                                ActivityGmail.this.adapter.fireOnChanged();
                                if (ActivityGmail.this.adapter.getCount() == 0) {
                                    ActivityGmail.this.mList.setVisibility(8);
                                    ActivityGmail.this.findViewById(R.id.empty).setVisibility(0);
                                    return;
                                }
                                ActivityGmail.this.mList.setVisibility(0);
                                ActivityGmail.this.findViewById(R.id.empty).setVisibility(8);
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                    if (ActivityGmail.this.wt == this) {
                        ActivityGmail.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityGmail.this.mLoading.setText("Error loading conversations");
                            }
                        });
                    }
                }
                ActivityGmail.this.wt = null;
            }
        };
        this.wt.start();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1000, 0, R.string.menu_refresh);
        menu.add(0, 1001, 0, R.string.menu_accounts);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        boolean z = false;
        MenuItem item = menu.getItem(0);
        if (this.labels_menu != null) {
            z = true;
        }
        item.setEnabled(z);
        return true;
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 1000) {
            if (this.label != null) {
                showConversations(this.label);
            }
            return true;
        } else if (itemId != 1001) {
            return false;
        } else {
            chooseAccount();
            return true;
        }
    }

    /* access modifiers changed from: private */
    public void showConversations(String str) {
        this.label = str;
        ((TextView) findViewById(R.id.hint1)).setText((CharSequence) this.cn_labels.get(str));
        ((TextView) findViewById(R.id.hint2)).setText(this.credentials[0]);
        this.mList.setVisibility(0);
        findViewById(R.id.empty).setVisibility(8);
        this.mLoading.setText(R.string.label_loading);
        if (this.mList.getFooterViewsCount() == 1) {
            this.mList.addFooterView(this.mLoading);
        }
        this.data.clear();
        this.adapter.fireOnChanged();
        loadConversations(Long.MAX_VALUE);
    }

    /* JADX WARNING: type inference failed for: r13v0, types: [java.lang.CharSequence] */
    /* JADX WARNING: type inference failed for: r13v1, types: [java.lang.CharSequence, java.lang.String] */
    /* JADX WARNING: type inference failed for: r4v6, types: [java.lang.CharSequence] */
    /* JADX WARNING: type inference failed for: r4v7 */
    /* JADX WARNING: type inference failed for: r4v8, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r3v21, types: [java.lang.CharSequence, java.lang.String] */
    /* JADX WARNING: type inference failed for: r3v22, types: [java.lang.CharSequence] */
    /* JADX WARNING: type inference failed for: r3v25 */
    /* JADX WARNING: type inference failed for: r3v26 */
    /* JADX WARNING: type inference failed for: r13v3 */
    /* JADX WARNING: type inference failed for: r13v5, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r13v6 */
    /* JADX WARNING: type inference failed for: r4v11 */
    /* JADX WARNING: type inference failed for: r13v7 */
    /* access modifiers changed from: private */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 6 */
    public static void getSenderSnippet(ProtoBuf protoBuf, SpannableStringBuilder spannableStringBuilder, int i, CharacterStyle characterStyle, CharacterStyle characterStyle2, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, boolean z, boolean z2) {
        ? r13;
        String str;
        boolean z3;
        ProtoBuf protoBuf2 = protoBuf;
        SpannableStringBuilder spannableStringBuilder2 = spannableStringBuilder;
        int i2 = i;
        int i3 = 0;
        boolean z4 = z || z2;
        Map<Integer, Integer> map = sPriorityToLength;
        map.clear();
        int i4 = protoBuf2.getInt(1);
        int i5 = protoBuf2.getInt(2);
        String str2 = ")";
        String str3 = " (";
        String str4 = "";
        if (i5 <= 0) {
            r13 = str4;
        } else if (i5 == 1) {
            r13 = charSequence2;
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(charSequence3);
            sb.append(str3);
            sb.append(i5);
            sb.append(str2);
            r13 = sb.toString();
        }
        int i6 = i4 + i5;
        if (i6 > 1) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str3);
            sb2.append(Integer.toString(i6));
            sb2.append(str2);
            str = sb2.toString();
        } else {
            str = str4;
        }
        int i7 = 3;
        int count = protoBuf2.getCount(3);
        int i8 = 0;
        int i9 = SmbConstants.CAP_EXTENDED_SECURITY;
        while (i8 < count) {
            ProtoBuf protoBuf3 = protoBuf2.getProtoBuf(i7, i8);
            ? string = protoBuf3.getString(4);
            if (string == 0) {
                string = str4;
            } else if (string.length() == 0) {
                string = charSequence;
            }
            int i10 = protoBuf3.getCount(i7) > 0 ? protoBuf3.getInt(i7) : 0;
            map.put(Integer.valueOf(i10), Integer.valueOf(string.length()));
            i9 = Math.max(i9, i10);
            i8++;
            i7 = 3;
        }
        SpannableStringBuilder spannableStringBuilder3 = null;
        if (r13.length() != 0) {
            spannableStringBuilder3 = new SpannableStringBuilder();
            spannableStringBuilder3.append(r13);
            if (characterStyle2 != null) {
                spannableStringBuilder3.setSpan(CharacterStyle.wrap(characterStyle2), 0, spannableStringBuilder3.length(), 33);
            }
        }
        ? r132 = ", ";
        if (str4.length() != 0) {
            if (spannableStringBuilder3 == null) {
                spannableStringBuilder3 = new SpannableStringBuilder();
            }
            if (spannableStringBuilder3.length() != 0) {
                spannableStringBuilder3.append(r132);
            }
            spannableStringBuilder3.append(str4);
        }
        if (str4.length() != 0) {
            if (spannableStringBuilder3 == null) {
                spannableStringBuilder3 = new SpannableStringBuilder();
            }
            if (spannableStringBuilder3.length() != 0) {
                spannableStringBuilder3.append(r132);
            }
            spannableStringBuilder3.append(str4);
        }
        int length = spannableStringBuilder3 != null ? spannableStringBuilder3.length() : 0;
        if (((str.length() == 0 && i9 == Integer.MIN_VALUE) ? false : true) && length != 0) {
            str4 = r132;
        }
        int i11 = -1;
        int length2 = str.length() + str4.length() + length;
        while (i11 < i9) {
            int i12 = i11 + 1;
            if (map.containsKey(Integer.valueOf(i12))) {
                int intValue = ((Integer) map.get(Integer.valueOf(i12))).intValue() + length2;
                if (length2 > 0) {
                    intValue += 2;
                }
                int i13 = intValue;
                if (intValue > i2 && i3 >= 2) {
                    break;
                }
                i3++;
                length2 = i13;
            }
            i11 = i12;
        }
        int i14 = length2 > i2 ? (length2 - i2) / i3 : 0;
        int i15 = 0;
        while (i15 < count) {
            ProtoBuf protoBuf4 = protoBuf2.getProtoBuf(3, i15);
            boolean bool = protoBuf4.getBool(1);
            String string2 = protoBuf4.getString(4);
            if (string2 != null && string2.length() == 0) {
                string2 = charSequence.toString();
            }
            String str5 = string2;
            String substring = i14 != 0 ? str5.substring(0, Math.max(str5.length() - i14, 0)) : str5;
            if (z4) {
                z3 = z;
            } else {
                z3 = protoBuf4.getBool(2);
            }
            if (protoBuf4.getInt(3) <= i11) {
                if (spannableStringBuilder.length() != 0) {
                    spannableStringBuilder2.append(bool ? " .. " : r132);
                }
                int length3 = spannableStringBuilder.length();
                spannableStringBuilder2.append(substring);
                if (z3 && characterStyle != null) {
                    spannableStringBuilder2.setSpan(CharacterStyle.wrap(characterStyle), length3, spannableStringBuilder.length(), 33);
                    i15++;
                    protoBuf2 = protoBuf;
                }
            }
            i15++;
            protoBuf2 = protoBuf;
        }
        spannableStringBuilder2.append(str);
        if (length != 0) {
            spannableStringBuilder2.append(str4);
            spannableStringBuilder2.append(spannableStringBuilder3);
        }
    }
}
