package com.dynamixsoftware.printershare;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.Contacts.ContactMethods;
import android.provider.Contacts.Phones;
import android.provider.ContactsContract.Data;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.google.android.mms.util.SqliteWrapper;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ContactInfoCache {
    private static final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[a-zA-Z0-9\\+\\.\\_\\%\\-]{1,256}\\@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25})+");
    private static final Pattern NAME_ADDR_EMAIL_PATTERN = Pattern.compile("\\s*(\"[^\"]*\"|[^<>\"]+)\\s*<([^<>]+)>\\s*");
    private static final String PHONE_NUMBER_SEPARATORS = " ()-./";
    private static final Pattern QUOTED_STRING_PATTERN = Pattern.compile("\\s*\"([^\"]*)\"\\s*");
    private static final String SEPARATOR = ";";
    private final HashMap<String, CacheEntry> mCache = new HashMap<>();
    private String[] mContactInfoSelectionArgs = new String[1];
    private Context mContext;
    private String sLocalNumber;

    static class CacheEntry {
        public String name;
        public long person_id;
        public String phoneLabel;
        public String phoneNumber;

        CacheEntry() {
        }
    }

    static abstract class Impl {
        static Uri CALLER_ID_CONTENT_URI = null;
        static String[] CALLER_ID_PROJECTION = null;
        static String CALLER_ID_SELECTION = null;
        static final int CONTACT_ID_COLUMN = 3;
        static Uri CONTACT_METHOD_CONTENT_URI = null;
        static final int CONTACT_METHOD_ID_COLUMN = 1;
        static final int CONTACT_METHOD_NAME_COLUMN = 0;
        static String[] CONTACT_METHOD_PROJECTION = null;
        static String CONTACT_METHOD_SELECTION = null;
        static final int CONTACT_NAME_COLUMN = 2;
        static final int PHONE_LABEL_COLUMN = 1;
        static final int PHONE_NUMBER_COLUMN = 0;

        Impl() {
        }

        static {
            if (Integer.parseInt(VERSION.SDK) < 5) {
                ImplOld.init();
            } else {
                ImplNew.init();
            }
        }
    }

    private static class ImplNew extends Impl {
        private ImplNew() {
        }

        static void init() {
            CONTACT_METHOD_CONTENT_URI = Data.CONTENT_URI;
            String str = "contact_id";
            CONTACT_METHOD_PROJECTION = new String[]{"data4", str};
            CONTACT_METHOD_SELECTION = "data1=? AND mimetype='vnd.android.cursor.item/email_v2'";
            CALLER_ID_CONTENT_URI = Data.CONTENT_URI;
            CALLER_ID_PROJECTION = new String[]{"data1", "data3", "display_name", str};
            CALLER_ID_SELECTION = "PHONE_NUMBERS_EQUAL(data1,?) AND mimetype='vnd.android.cursor.item/phone_v2'";
        }
    }

    private static class ImplOld extends Impl {
        private ImplOld() {
        }

        static void init() {
            CONTACT_METHOD_CONTENT_URI = ContactMethods.CONTENT_URI;
            String str = "person";
            CONTACT_METHOD_PROJECTION = new String[]{"display_name", str};
            CONTACT_METHOD_SELECTION = "data=?";
            CALLER_ID_CONTENT_URI = Phones.CONTENT_URI;
            CALLER_ID_PROJECTION = new String[]{"number", "label", "name", str};
            CALLER_ID_SELECTION = "PHONE_NUMBERS_EQUAL(number,?)";
        }
    }

    public ContactInfoCache(Context context) {
        this.mContext = context;
    }

    public String getContactName(String str) {
        String[] split;
        String str2 = "";
        if (TextUtils.isEmpty(str)) {
            return str2;
        }
        StringBuilder sb = new StringBuilder();
        String str3 = SEPARATOR;
        for (String str4 : str.split(str3)) {
            if (str4.length() > 0) {
                sb.append(str3);
                if (isLocalNumber(str4)) {
                    sb.append("Me");
                } else if (isEmailAddress(str4)) {
                    sb.append(getDisplayName(str4));
                } else {
                    sb.append(getCallerId(str4));
                }
            }
        }
        return sb.length() > 0 ? sb.substring(1) : str2;
    }

    public String getDisplayName(String str) {
        Matcher matcher = NAME_ADDR_EMAIL_PATTERN.matcher(str);
        if (matcher.matches()) {
            return getEmailDisplayName(matcher.group(1));
        }
        CacheEntry contactInfoForEmailAddress = getContactInfoForEmailAddress(str);
        if (!(contactInfoForEmailAddress == null || contactInfoForEmailAddress.name == null)) {
            str = contactInfoForEmailAddress.name;
        }
        return str;
    }

    private static String getEmailDisplayName(String str) {
        Matcher matcher = QUOTED_STRING_PATTERN.matcher(str);
        return matcher.matches() ? matcher.group(1) : str;
    }

    private String getCallerId(String str) {
        CacheEntry contactInfo = getContactInfo(str);
        return (contactInfo == null || TextUtils.isEmpty(contactInfo.name)) ? str : contactInfo.name;
    }

    public CacheEntry getContactInfo(String str) {
        if (isEmailAddress(str)) {
            return getContactInfoForEmailAddress(str);
        }
        return getContactInfoForPhoneNumber(str);
    }

    public CacheEntry getContactInfoForEmailAddress(String str) {
        synchronized (this.mCache) {
            if (this.mCache.containsKey(str)) {
                CacheEntry cacheEntry = (CacheEntry) this.mCache.get(str);
                return cacheEntry;
            }
            CacheEntry queryEmailDisplayName = queryEmailDisplayName(str);
            this.mCache.put(str, queryEmailDisplayName);
            return queryEmailDisplayName;
        }
    }

    public CacheEntry getContactInfoForPhoneNumber(String str) {
        String filterPhoneNumber = filterPhoneNumber(str);
        synchronized (this.mCache) {
            if (this.mCache.containsKey(filterPhoneNumber)) {
                CacheEntry cacheEntry = (CacheEntry) this.mCache.get(filterPhoneNumber);
                return cacheEntry;
            }
            CacheEntry queryContactInfoByNumber = queryContactInfoByNumber(filterPhoneNumber);
            this.mCache.put(filterPhoneNumber, queryContactInfoByNumber);
            return queryContactInfoByNumber;
        }
    }

    private CacheEntry queryEmailDisplayName(String str) {
        CacheEntry cacheEntry = new CacheEntry();
        this.mContactInfoSelectionArgs[0] = str;
        Context context = this.mContext;
        Cursor query = SqliteWrapper.query(context, context.getContentResolver(), Impl.CONTACT_METHOD_CONTENT_URI, Impl.CONTACT_METHOD_PROJECTION, Impl.CONTACT_METHOD_SELECTION, this.mContactInfoSelectionArgs, null);
        if (query != null) {
            while (query.moveToNext()) {
                try {
                    cacheEntry.person_id = query.getLong(1);
                    String string = query.getString(0);
                    if (!TextUtils.isEmpty(string)) {
                        cacheEntry.name = string;
                    }
                } finally {
                    query.close();
                }
            }
        }
        return cacheEntry;
    }

    private CacheEntry queryContactInfoByNumber(String str) {
        CacheEntry cacheEntry = new CacheEntry();
        cacheEntry.phoneNumber = str;
        this.mContactInfoSelectionArgs[0] = str;
        Cursor query = this.mContext.getContentResolver().query(Impl.CALLER_ID_CONTENT_URI, Impl.CALLER_ID_PROJECTION, Impl.CALLER_ID_SELECTION, this.mContactInfoSelectionArgs, null);
        if (query != null) {
            try {
                if (query.moveToFirst()) {
                    cacheEntry.phoneNumber = query.getString(0);
                    cacheEntry.phoneLabel = query.getString(1);
                    cacheEntry.name = query.getString(2);
                    cacheEntry.person_id = query.getLong(3);
                }
            } finally {
                query.close();
            }
        }
        return cacheEntry;
    }

    private boolean isLocalNumber(String str) {
        return PhoneNumberUtils.compare(str, getLocalNumber());
    }

    private String getLocalNumber() {
        if (this.sLocalNumber == null) {
            this.sLocalNumber = ((TelephonyManager) this.mContext.getSystemService("phone")).getLine1Number();
        }
        return this.sLocalNumber;
    }

    private static String filterPhoneNumber(String str) {
        if (str == null) {
            return null;
        }
        int length = str.length();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (PHONE_NUMBER_SEPARATORS.indexOf(charAt) == -1) {
                sb.append(charAt);
            }
        }
        return sb.toString();
    }

    private static String extractAddrSpec(String str) {
        Matcher matcher = NAME_ADDR_EMAIL_PATTERN.matcher(str);
        return matcher.matches() ? matcher.group(2) : str;
    }

    private static boolean isEmailAddress(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        return EMAIL_ADDRESS_PATTERN.matcher(extractAddrSpec(str)).matches();
    }
}
