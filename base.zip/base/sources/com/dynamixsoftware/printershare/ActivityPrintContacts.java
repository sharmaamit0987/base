package com.dynamixsoftware.printershare;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Contacts.ContactMethods;
import android.provider.Contacts.Organizations;
import android.provider.Contacts.People;
import android.provider.Contacts.Phones;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Im;
import android.provider.ContactsContract.CommonDataKinds.Organization;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.CommonDataKinds.StructuredPostal;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import java.util.StringTokenizer;
import java.util.Vector;

public class ActivityPrintContacts extends ActivityPrintText {
    private String dat;
    private Vector<Object[]> data;
    private Impl impl = Impl.getImpl();

    static abstract class Impl {
        static Uri CONTACTS_CONTENT_URI;
        static String[] CONTACTS_PROJECTION;
        static String EMAILS_DIRECTORY;
        static String[] EMAILS_PROJECTION;
        static String EMAILS_SELECTION;
        static String IMS_DIRECTORY;
        static String[] IMS_PROJECTION;
        static String IMS_SELECTION;
        static String NOTES_DIRECTORY;
        static String[] NOTES_PROJECTION;
        static String NOTES_SELECTION;
        static String ORGANIZATIONS_DIRECTORY;
        static String[] ORGANIZATIONS_PROJECTION;
        static String ORGANIZATIONS_SELECTION;
        static String PHONES_DIRECTORY;
        static String[] PHONES_PROJECTION;
        static String PHONES_SELECTION;
        static String POSTALS_DIRECTORY;
        static String[] POSTALS_PROJECTION;
        static String POSTALS_SELECTION;

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getEmailTypeLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getImProtocolLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getImTypeLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getOrganizationTypeLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getPhoneTypeLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract CharSequence getPostalTypeLabel(Context context, int i, String str);

        /* access modifiers changed from: 0000 */
        public abstract Bitmap loadContactPhoto(Context context, long j, Options options);

        Impl() {
        }

        static Impl getImpl() {
            if (Integer.parseInt(VERSION.SDK) < 5) {
                return new ImplOld();
            }
            return new ImplNew();
        }
    }

    private static class ImplNew extends Impl {
        private ImplNew() {
        }

        static {
            CONTACTS_CONTENT_URI = Contacts.CONTENT_URI;
            CONTACTS_PROJECTION = new String[]{"display_name", "starred", "photo_id"};
            String str = "data";
            PHONES_DIRECTORY = str;
            PHONES_SELECTION = "mimetype='vnd.android.cursor.item/phone_v2'";
            String str2 = "data2";
            String str3 = "data3";
            String str4 = "data1";
            PHONES_PROJECTION = new String[]{str2, str3, str4};
            EMAILS_DIRECTORY = str;
            EMAILS_SELECTION = "mimetype='vnd.android.cursor.item/email_v2'";
            EMAILS_PROJECTION = new String[]{str2, str3, str4};
            IMS_DIRECTORY = str;
            IMS_SELECTION = "mimetype='vnd.android.cursor.item/im'";
            IMS_PROJECTION = new String[]{str2, str3, str4, "data5", "data6"};
            POSTALS_DIRECTORY = str;
            POSTALS_SELECTION = "mimetype='vnd.android.cursor.item/postal-address_v2'";
            POSTALS_PROJECTION = new String[]{str2, str3, str4};
            ORGANIZATIONS_DIRECTORY = str;
            ORGANIZATIONS_SELECTION = "mimetype='vnd.android.cursor.item/organization'";
            ORGANIZATIONS_PROJECTION = new String[]{str2, str3, str4, "data4"};
            NOTES_DIRECTORY = str;
            NOTES_SELECTION = "mimetype='vnd.android.cursor.item/note'";
            NOTES_PROJECTION = new String[]{str4};
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getPhoneTypeLabel(Context context, int i, String str) {
            return Phone.getTypeLabel(context.getResources(), i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getEmailTypeLabel(Context context, int i, String str) {
            return Email.getTypeLabel(context.getResources(), i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getImTypeLabel(Context context, int i, String str) {
            return Im.getTypeLabel(context.getResources(), i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getImProtocolLabel(Context context, int i, String str) {
            return Im.getProtocolLabel(context.getResources(), i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getPostalTypeLabel(Context context, int i, String str) {
            return StructuredPostal.getTypeLabel(context.getResources(), i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getOrganizationTypeLabel(Context context, int i, String str) {
            return Organization.getTypeLabel(context.getResources(), i, str);
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [android.database.Cursor] */
        /* JADX WARNING: type inference failed for: r0v2 */
        /* JADX WARNING: type inference failed for: r0v6 */
        /* access modifiers changed from: 0000 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x003a  */
        /* JADX WARNING: Unknown variable types count: 1 */
        public Bitmap loadContactPhoto(Context context, long j, Options options) {
            ? r0;
            Bitmap bitmap = 0;
            try {
                Cursor query = context.getContentResolver().query(ContentUris.withAppendedId(Data.CONTENT_URI, j), new String[]{"data15"}, null, null, null);
                try {
                    if (query.moveToFirst() && !query.isNull(0)) {
                        byte[] blob = query.getBlob(0);
                        bitmap = BitmapFactory.decodeByteArray(blob, 0, blob.length, options);
                    }
                    if (query != 0) {
                        query.close();
                    }
                    return bitmap;
                } catch (Throwable th) {
                    th = th;
                    r0 = query;
                    if (r0 != 0) {
                        r0.close();
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                r0 = bitmap;
                if (r0 != 0) {
                }
                throw th;
            }
        }
    }

    private static class ImplOld extends Impl {
        private ImplOld() {
        }

        static {
            CONTACTS_CONTENT_URI = People.CONTENT_URI;
            String str = "notes";
            CONTACTS_PROJECTION = new String[]{"display_name", "starred", "_id", str};
            PHONES_DIRECTORY = "phones";
            PHONES_SELECTION = null;
            String str2 = "type";
            String str3 = "label";
            PHONES_PROJECTION = new String[]{str2, str3, "number"};
            String str4 = "contact_methods";
            EMAILS_DIRECTORY = str4;
            EMAILS_SELECTION = "kind=1";
            String str5 = "data";
            EMAILS_PROJECTION = new String[]{str2, str3, str5};
            IMS_DIRECTORY = str4;
            IMS_SELECTION = "kind=3";
            IMS_PROJECTION = new String[]{str2, str3, str5, str2, "aux_data"};
            POSTALS_DIRECTORY = str4;
            POSTALS_SELECTION = "kind=2";
            POSTALS_PROJECTION = new String[]{str2, str3, str5};
            ORGANIZATIONS_DIRECTORY = "organizations";
            ORGANIZATIONS_SELECTION = null;
            ORGANIZATIONS_PROJECTION = new String[]{str2, str3, "company", "title"};
            NOTES_DIRECTORY = "";
            NOTES_SELECTION = null;
            NOTES_PROJECTION = new String[]{str};
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getPhoneTypeLabel(Context context, int i, String str) {
            return Phones.getDisplayLabel(context, i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getEmailTypeLabel(Context context, int i, String str) {
            return ContactMethods.getDisplayLabel(context, 1, i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getImTypeLabel(Context context, int i, String str) {
            return ContactMethods.getDisplayLabel(context, 3, i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getImProtocolLabel(Context context, int i, String str) {
            String str2 = "";
            if (str == null) {
                str = str2;
            }
            if (!str.startsWith("pre:")) {
                return str.startsWith("custom:") ? str.substring(7) : str2;
            }
            switch (Integer.parseInt(str.substring(4))) {
                case 0:
                    return "AIM";
                case 1:
                    return "MSN";
                case 2:
                    return "Yahoo";
                case 3:
                    return "Skype";
                case 4:
                    return "QQ";
                case 5:
                    return "Google Talk";
                case 6:
                    return "ICQ";
                case 7:
                    return "Jabber";
                default:
                    return str2;
            }
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getPostalTypeLabel(Context context, int i, String str) {
            return ContactMethods.getDisplayLabel(context, 2, i, str);
        }

        /* access modifiers changed from: 0000 */
        public CharSequence getOrganizationTypeLabel(Context context, int i, String str) {
            return Organizations.getDisplayLabel(context, i, str);
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [android.database.Cursor] */
        /* JADX WARNING: type inference failed for: r0v2 */
        /* JADX WARNING: type inference failed for: r0v6 */
        /* access modifiers changed from: 0000 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x0044  */
        /* JADX WARNING: Unknown variable types count: 1 */
        public Bitmap loadContactPhoto(Context context, long j, Options options) {
            ? r0;
            Bitmap bitmap = 0;
            try {
                Cursor query = context.getContentResolver().query(Uri.withAppendedPath(Uri.withAppendedPath(People.CONTENT_URI, String.valueOf(j)), "photo"), new String[]{"data"}, null, null, null);
                try {
                    if (query.moveToFirst() && !query.isNull(0)) {
                        byte[] blob = query.getBlob(0);
                        bitmap = BitmapFactory.decodeByteArray(blob, 0, blob.length, options);
                    }
                    if (query != 0) {
                        query.close();
                    }
                    return bitmap;
                } catch (Throwable th) {
                    th = th;
                    r0 = query;
                    if (r0 != 0) {
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                r0 = bitmap;
                if (r0 != 0) {
                    r0.close();
                }
                throw th;
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String string = getIntent().getExtras().getString("data");
        this.dat = string;
        if (string == null) {
            setResult(0);
            finish();
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x0346  */
    /* JADX WARNING: Removed duplicated region for block: B:176:0x0032 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0083  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00b8  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0130  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x01a7  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0216  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x028d  */
    public void createPages() {
        Paint paint;
        String str;
        Bitmap bitmap;
        Cursor query;
        Cursor query2;
        Cursor query3;
        Cursor query4;
        Cursor query5;
        Cursor query6;
        if (checkPermission("android.permission.READ_CONTACTS")) {
            initPage();
            String str2 = "";
            if (this.data == null) {
                this.data = new Vector<>();
                StringTokenizer stringTokenizer = new StringTokenizer(this.dat, ",");
                Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.contact);
                while (stringTokenizer.hasMoreTokens()) {
                    Uri withAppendedPath = Uri.withAppendedPath(Impl.CONTACTS_CONTENT_URI, stringTokenizer.nextToken());
                    Cursor query7 = getContentResolver().query(withAppendedPath, Impl.CONTACTS_PROJECTION, null, null, null);
                    if (query7 != null) {
                        query7.moveToNext();
                        String string = query7.getString(0);
                        if (string == null) {
                            str = str2;
                        } else {
                            str = string.trim();
                        }
                        int i = query7.getInt(1);
                        if (!query7.isNull(2)) {
                            try {
                                bitmap = this.impl.loadContactPhoto(this, query7.getLong(2), null);
                            } catch (Exception e) {
                                e.printStackTrace();
                                App.reportThrowable(e);
                            }
                            if (bitmap == null) {
                                bitmap = decodeResource;
                            }
                            this.data.add(new Object[]{Integer.valueOf(0), str, bitmap, Integer.valueOf(i)});
                            query7.close();
                            query = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.PHONES_DIRECTORY), Impl.PHONES_PROJECTION, Impl.PHONES_SELECTION, null, null);
                            if (query != null) {
                                boolean z = false;
                                while (query.moveToNext()) {
                                    if (!z) {
                                        this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_phone_numbers)});
                                        z = true;
                                    }
                                    String charSequence = this.impl.getPhoneTypeLabel(this, query.getInt(0), query.getString(1)).toString();
                                    String trim = charSequence != null ? charSequence.trim() : str2;
                                    String string2 = query.getString(2);
                                    this.data.add(new Object[]{Integer.valueOf(2), trim, string2 != null ? string2.trim() : str2});
                                }
                                query.close();
                            }
                            query2 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.EMAILS_DIRECTORY), Impl.EMAILS_PROJECTION, Impl.EMAILS_SELECTION, null, null);
                            if (query2 != null) {
                                boolean z2 = false;
                                while (query2.moveToNext()) {
                                    if (!z2) {
                                        this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_email_addresses)});
                                        z2 = true;
                                    }
                                    String charSequence2 = this.impl.getEmailTypeLabel(this, query2.getInt(0), query2.getString(1)).toString();
                                    String trim2 = charSequence2 != null ? charSequence2.trim() : str2;
                                    String string3 = query2.getString(2);
                                    this.data.add(new Object[]{Integer.valueOf(2), trim2, string3 != null ? string3.trim() : str2});
                                }
                                query2.close();
                            }
                            query3 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.IMS_DIRECTORY), Impl.IMS_PROJECTION, Impl.IMS_SELECTION, null, null);
                            if (query3 != null) {
                                boolean z3 = false;
                                while (query3.moveToNext()) {
                                    if (!z3) {
                                        this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_chat_addresses)});
                                        z3 = true;
                                    }
                                    String string4 = query3.getString(2);
                                    this.data.add(new Object[]{Integer.valueOf(2), this.impl.getImProtocolLabel(this, query3.getInt(3), query3.getString(4)).toString(), string4 != null ? string4.trim() : str2});
                                }
                                query3.close();
                            }
                            query4 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.POSTALS_DIRECTORY), Impl.POSTALS_PROJECTION, Impl.POSTALS_SELECTION, null, null);
                            if (query4 != null) {
                                boolean z4 = false;
                                while (query4.moveToNext()) {
                                    if (!z4) {
                                        this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_postal_addresses)});
                                        z4 = true;
                                    }
                                    String charSequence3 = this.impl.getPostalTypeLabel(this, query4.getInt(0), query4.getString(1)).toString();
                                    String trim3 = charSequence3 != null ? charSequence3.trim() : str2;
                                    String string5 = query4.getString(2);
                                    this.data.add(new Object[]{Integer.valueOf(2), trim3, string5 != null ? string5.trim() : str2});
                                }
                                query4.close();
                            }
                            query5 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.ORGANIZATIONS_DIRECTORY), Impl.ORGANIZATIONS_PROJECTION, Impl.ORGANIZATIONS_SELECTION, null, null);
                            if (query5 != null) {
                                boolean z5 = false;
                                while (query5.moveToNext()) {
                                    if (!z5) {
                                        this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_organizations)});
                                        z5 = true;
                                    }
                                    String charSequence4 = this.impl.getOrganizationTypeLabel(this, query5.getInt(0), query5.getString(1)).toString();
                                    String trim4 = charSequence4 != null ? charSequence4.trim() : str2;
                                    String string6 = query5.getString(2);
                                    String string7 = query5.getString(3);
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(string6 != null ? string6.trim() : str2);
                                    String str3 = ", ";
                                    sb.append(str3);
                                    sb.append(string7 != null ? string7.trim() : str2);
                                    String sb2 = sb.toString();
                                    if (sb2.startsWith(str3)) {
                                        sb2 = sb2.substring(2).trim();
                                    }
                                    if (sb2.endsWith(str3)) {
                                        sb2 = sb2.substring(0, sb2.length() - 2).trim();
                                    }
                                    this.data.add(new Object[]{Integer.valueOf(2), trim4, sb2});
                                }
                                query5.close();
                            }
                            query6 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.NOTES_DIRECTORY), Impl.NOTES_PROJECTION, Impl.NOTES_SELECTION, null, null);
                            if (query6 == null) {
                                boolean z6 = false;
                                while (query6.moveToNext()) {
                                    String string8 = query6.getString(0);
                                    if (string8 != null && string8.length() != 0) {
                                        if (!z6) {
                                            this.data.add(new Object[]{Integer.valueOf(1), getResources().getString(R.string.label_notes)});
                                            z6 = true;
                                        }
                                        this.data.add(new Object[]{Integer.valueOf(2), null, string8});
                                    }
                                }
                                query6.close();
                            }
                        }
                        bitmap = null;
                        if (bitmap == null) {
                        }
                        this.data.add(new Object[]{Integer.valueOf(0), str, bitmap, Integer.valueOf(i)});
                        query7.close();
                        query = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.PHONES_DIRECTORY), Impl.PHONES_PROJECTION, Impl.PHONES_SELECTION, null, null);
                        if (query != null) {
                        }
                        query2 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.EMAILS_DIRECTORY), Impl.EMAILS_PROJECTION, Impl.EMAILS_SELECTION, null, null);
                        if (query2 != null) {
                        }
                        query3 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.IMS_DIRECTORY), Impl.IMS_PROJECTION, Impl.IMS_SELECTION, null, null);
                        if (query3 != null) {
                        }
                        query4 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.POSTALS_DIRECTORY), Impl.POSTALS_PROJECTION, Impl.POSTALS_SELECTION, null, null);
                        if (query4 != null) {
                        }
                        query5 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.ORGANIZATIONS_DIRECTORY), Impl.ORGANIZATIONS_PROJECTION, Impl.ORGANIZATIONS_SELECTION, null, null);
                        if (query5 != null) {
                        }
                        query6 = getContentResolver().query(Uri.withAppendedPath(withAppendedPath, Impl.NOTES_DIRECTORY), Impl.NOTES_PROJECTION, Impl.NOTES_SELECTION, null, null);
                        if (query6 == null) {
                        }
                    }
                }
            }
            int i2 = 0;
            while (i2 < this.data.size()) {
                newPage();
                Object[] objArr = (Object[]) this.data.elementAt(i2);
                if (((Integer) objArr[0]).intValue() == 0) {
                    if (!needNew(40, 200)) {
                        Bitmap bitmap2 = (Bitmap) objArr[2];
                        this.canvas.drawBitmap(bitmap2, new Rect(0, 0, bitmap2.getWidth(), bitmap2.getHeight()), new Rect(0, 0, (int) (this.fontSizeCoef * 150.0f), (int) (this.fontSizeCoef * 150.0f)), App.newPaint());
                        String str4 = (String) objArr[1];
                        Paint newPaint = App.newPaint();
                        newPaint.setStyle(Style.FILL);
                        newPaint.setColor(-16777216);
                        int i3 = this.th;
                        printText(str4 != null ? str4 : str2, 65, false, 0.0f, 190, 95, 160, newPaint);
                        if (this.th - i3 > 150) {
                            this.canvas.translate(0.0f, this.fontSizeCoef * 20.0f);
                            this.th = (int) (((float) this.th) + (this.fontSizeCoef * 20.0f));
                        }
                        i2++;
                    }
                } else if (((Integer) objArr[0]).intValue() == 1) {
                    if (!needNew(20, 50)) {
                        String str5 = (String) objArr[1];
                        Paint newPaint2 = App.newPaint();
                        newPaint2.setStyle(Style.FILL);
                        newPaint2.setColor(-16777216);
                        printText(str5, 50, true, 0.0f, 0, 40, 50, newPaint2);
                        i2++;
                    }
                } else if (!needNew(20, 50)) {
                    String str6 = (String) objArr[1];
                    String[] split = ((String) objArr[2]).split("\n");
                    Paint newPaint3 = App.newPaint();
                    newPaint3.setStyle(Style.FILL);
                    newPaint3.setColor(-16777216);
                    if (str6 == null) {
                        paint = newPaint3;
                        printText((split == null || split.length <= 0) ? str2 : split[0], 50, false, 0.0f, 0, 40, 50, newPaint3);
                    } else {
                        paint = newPaint3;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(str6);
                        sb3.append(": ");
                        sb3.append((split == null || split.length <= 0) ? str2 : split[0]);
                        printText(sb3.toString(), 50, false, 0.0f, 0, 40, 50, paint);
                    }
                    if (split != null) {
                        int i4 = 1;
                        while (i4 < split.length) {
                            int i5 = i4;
                            printText(split[i4], 50, false, 0.0f, 0, 40, 50, paint);
                            i4 = i5 + 1;
                        }
                    }
                    i2++;
                }
                i2--;
                i2++;
            }
            addPage();
        }
    }
}
