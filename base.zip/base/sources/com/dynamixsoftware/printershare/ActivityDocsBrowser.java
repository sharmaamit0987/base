package com.dynamixsoftware.printershare;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class ActivityDocsBrowser extends ActivityRoot {
    /* access modifiers changed from: private */
    public DirAdapter adapter;
    /* access modifiers changed from: private */
    public Button btn;
    private ListView list;

    class DirAdapter implements ListAdapter {
        /* access modifiers changed from: private */
        public File curr;
        private Vector<File> files = new Vector<>();
        private List<DataSetObserver> observers = null;
        /* access modifiers changed from: private */
        public Vector<Volume> roots = new Vector<>();

        public boolean areAllItemsEnabled() {
            return true;
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return false;
        }

        DirAdapter() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:41:0x012d, code lost:
            r0 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x012e, code lost:
            r0.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r0);
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x009f */
        /* JADX WARNING: Removed duplicated region for block: B:41:0x012d A[ExcHandler: Exception (r0v22 'e' java.lang.Exception A[CUSTOM_DECLARE]), Splitter:B:8:0x003a] */
        /* JADX WARNING: Removed duplicated region for block: B:46:0x0144  */
        /* JADX WARNING: Removed duplicated region for block: B:55:0x0175  */
        /* JADX WARNING: Removed duplicated region for block: B:87:0x020f  */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x003a A[SYNTHETIC, Splitter:B:8:0x003a] */
        /* JADX WARNING: Removed duplicated region for block: B:91:0x022e A[LOOP:3: B:89:0x0226->B:91:0x022e, LOOP_END] */
        /* JADX WARNING: Removed duplicated region for block: B:94:0x0280  */
        /* JADX WARNING: Removed duplicated region for block: B:95:0x028c  */
        public void init() {
            String str;
            boolean z;
            int i;
            Object[] objArr;
            int i2;
            String str2 = "usb";
            str = "getDescription";
            this.roots.clear();
            try {
                z = ((Boolean) PackageManager.class.getMethod("hasSystemFeature", new Class[]{String.class}).invoke(ActivityDocsBrowser.this.getPackageManager(), new Object[]{"com.google.android.tv"})).booleanValue();
            } catch (NoSuchMethodException unused) {
                z = false;
                if (!z) {
                }
                if ("qnx".equals(System.getProperty("os.name"))) {
                }
                if (this.roots.size() == 0) {
                }
                if (this.roots.size() == 0) {
                }
                CharSequence[] charSequenceArr = new CharSequence[this.roots.size()];
                while (i < this.roots.size()) {
                }
                final AlertDialog create = new Builder(ActivityDocsBrowser.this).setIcon(R.drawable.icon_title).setTitle(R.string.button_storages).setItems(charSequenceArr, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityDocsBrowser.this.adapter.changeDir((File) DirAdapter.this.roots.get(i));
                    }
                }).create();
                ActivityDocsBrowser.this.btn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        create.show();
                    }
                });
                ActivityDocsBrowser.this.btn.setEnabled(true);
                if (this.roots.size() == 1) {
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
                z = false;
                if (!z) {
                }
                if ("qnx".equals(System.getProperty("os.name"))) {
                }
                if (this.roots.size() == 0) {
                }
                if (this.roots.size() == 0) {
                }
                CharSequence[] charSequenceArr2 = new CharSequence[this.roots.size()];
                while (i < this.roots.size()) {
                }
                final AlertDialog create2 = new Builder(ActivityDocsBrowser.this).setIcon(R.drawable.icon_title).setTitle(R.string.button_storages).setItems(charSequenceArr2, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityDocsBrowser.this.adapter.changeDir((File) DirAdapter.this.roots.get(i));
                    }
                }).create();
                ActivityDocsBrowser.this.btn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        create2.show();
                    }
                });
                ActivityDocsBrowser.this.btn.setEnabled(true);
                if (this.roots.size() == 1) {
                }
            }
            if (!z) {
                try {
                    Object systemService = ActivityDocsBrowser.this.getSystemService("storage");
                    if (systemService != null) {
                        Method method = systemService.getClass().getMethod("getVolumeList", new Class[0]);
                        Method method2 = systemService.getClass().getMethod("getVolumeState", new Class[]{String.class});
                        objArr = (Object[]) method.invoke(systemService, new Object[0]);
                        for (i2 = 0; i2 < objArr.length; i2++) {
                            Class cls = objArr[i2].getClass();
                            String str3 = (String) cls.getMethod("getPath", new Class[0]).invoke(objArr[i2], new Object[0]);
                            String str4 = (String) cls.getMethod(str, new Class[]{Context.class}).invoke(objArr[i2], new Object[]{ActivityDocsBrowser.this});
                            str4 = (String) cls.getMethod(str, new Class[0]).invoke(objArr[i2], new Object[0]);
                            String str5 = (String) method2.invoke(systemService, new Object[]{str3});
                            if (str5 != null && str5.indexOf("mounted") >= 0 && str5.indexOf("unmounted") < 0) {
                                if (str4.toLowerCase().indexOf(str2) >= 0 || str3.toLowerCase().indexOf(str2) >= 0) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(str3);
                                    sb.append("/part0");
                                    String sb2 = sb.toString();
                                    if (new File(sb2).isDirectory() && new File(str3).list().length == 1) {
                                        str3 = sb2;
                                    }
                                }
                                if (App.ext_storage_root.equals(str3) && str4.toLowerCase().indexOf("usb storage") >= 0) {
                                    str4 = "Internal storage";
                                }
                                this.roots.add(new Volume(str4, str3));
                            }
                        }
                    }
                } catch (NoSuchMethodException ) {
                    str4 = (String) cls.getMethod(str, new Class[0]).invoke(objArr[i2], new Object[0]);
                } catch (Exception e2) {
                }
            }
            if ("qnx".equals(System.getProperty("os.name"))) {
                File file = new File("/accounts/1000/shared");
                if (file.exists() && file.isDirectory() && file.canRead()) {
                    this.roots.add(new Volume("Media", file.getAbsolutePath()));
                }
            }
            if (this.roots.size() == 0) {
                final Vector vector = new Vector();
                try {
                    File file2 = new File("/etc/vold.fstab");
                    if (!file2.exists()) {
                        file2 = new File("/system/etc/vold.fstab");
                    }
                    if (file2.exists()) {
                        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file2));
                        while (true) {
                            String readLine = dataInputStream.readLine();
                            if (readLine == null) {
                                break;
                            }
                            String trim = readLine.trim();
                            if (trim.length() > 0 && !trim.startsWith("#")) {
                                vector.add(trim);
                            }
                        }
                        dataInputStream.close();
                    }
                } catch (Exception e3) {
                    e3.printStackTrace();
                    App.reportThrowable(e3);
                }
                try {
                    File file3 = new File("/bin/mount");
                    if (!file3.exists()) {
                        file3 = new File("/system/bin/mount");
                    }
                    if (file3.exists()) {
                        final Process exec = Runtime.getRuntime().exec(file3.getAbsolutePath());
                        AnonymousClass1 r4 = new Thread() {
                            public void run() {
                                String str = " ";
                                try {
                                    DataInputStream dataInputStream = new DataInputStream(exec.getInputStream());
                                    while (true) {
                                        String readLine = dataInputStream.readLine();
                                        if (readLine == null) {
                                            dataInputStream.close();
                                            return;
                                        } else if (readLine.startsWith("/dev") && ((readLine.indexOf("uid=") > 0 || readLine.indexOf("user_id=") > 0) && (readLine.indexOf("gid=") > 0 || readLine.indexOf("group_id=") > 0))) {
                                            String str2 = readLine.split(str)[1];
                                            String str3 = null;
                                            if (Environment.getExternalStorageDirectory().getAbsolutePath().equals(str2)) {
                                                str3 = "Internal Storage";
                                            }
                                            if (str3 == null) {
                                                int i = 0;
                                                while (true) {
                                                    if (i >= vector.size()) {
                                                        break;
                                                    }
                                                    String str4 = (String) vector.elementAt(i);
                                                    if (str4.indexOf("mmc_host") > 0) {
                                                        String[] split = str4.split(str);
                                                        if (split.length > 2 && split[2].equals(str2)) {
                                                            str3 = "SD Card";
                                                            break;
                                                        }
                                                    }
                                                    i++;
                                                }
                                            }
                                            if (str3 == null) {
                                                str3 = readLine.toLowerCase().indexOf("usb") >= 0 ? "USB Storage" : "External Storage";
                                            }
                                            if (new File(str2).canRead()) {
                                                DirAdapter.this.roots.add(new Volume(str3, str2));
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    App.reportThrowable(e);
                                }
                            }
                        };
                        r4.start();
                        exec.waitFor();
                        while (r4.isAlive()) {
                            Thread.yield();
                        }
                    }
                } catch (Exception e4) {
                    e4.printStackTrace();
                    App.reportThrowable(e4);
                }
            }
            if (this.roots.size() == 0) {
                this.roots.add(new Volume("SD Card", "/sdcard"));
            }
            CharSequence[] charSequenceArr22 = new CharSequence[this.roots.size()];
            for (i = 0; i < this.roots.size(); i++) {
                charSequenceArr22[i] = ((Volume) this.roots.get(i)).getVolumeName();
            }
            final AlertDialog create22 = new Builder(ActivityDocsBrowser.this).setIcon(R.drawable.icon_title).setTitle(R.string.button_storages).setItems(charSequenceArr22, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityDocsBrowser.this.adapter.changeDir((File) DirAdapter.this.roots.get(i));
                }
            }).create();
            ActivityDocsBrowser.this.btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    create22.show();
                }
            });
            ActivityDocsBrowser.this.btn.setEnabled(true);
            if (this.roots.size() == 1) {
                changeDir((File) this.roots.elementAt(0));
            } else {
                create22.show();
            }
        }

        public void changeDir(File file) {
            boolean z;
            this.curr = file;
            int i = 0;
            while (true) {
                if (i >= this.roots.size()) {
                    z = false;
                    break;
                } else if (((Volume) this.roots.elementAt(i)).equals(file)) {
                    ((TextView) ActivityDocsBrowser.this.findViewById(R.id.hint1)).setText(((Volume) this.roots.elementAt(i)).getVolumeName());
                    ((TextView) ActivityDocsBrowser.this.findViewById(R.id.hint2)).setText(file.getAbsolutePath());
                    z = true;
                    break;
                } else {
                    i++;
                }
            }
            Vector vector = new Vector();
            Vector vector2 = new Vector();
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (int i2 = 0; i2 < listFiles.length; i2++) {
                    if (listFiles[i2].isDirectory() && listFiles[i2].canRead()) {
                        vector.add(listFiles[i2]);
                    }
                }
                for (int i3 = 0; i3 < listFiles.length; i3++) {
                    if (!listFiles[i3].isDirectory() && listFiles[i3].canRead()) {
                        vector2.add(listFiles[i3]);
                    }
                }
            }
            AnonymousClass4 r4 = new Comparator<File>() {
                public int compare(File file, File file2) {
                    return file.getName().compareToIgnoreCase(file2.getName());
                }
            };
            Collections.sort(vector, r4);
            Collections.sort(vector2, r4);
            this.files.clear();
            if (!z) {
                File parentFile = file.getParentFile();
                for (int i4 = 0; i4 < this.roots.size(); i4++) {
                    if (((Volume) this.roots.elementAt(i4)).equals(parentFile)) {
                        parentFile = (File) this.roots.elementAt(i4);
                    }
                }
                this.files.add(parentFile);
            }
            this.files.addAll(vector);
            this.files.addAll(vector2);
            fireOnInvalidated();
        }

        public boolean isEnabled(int i) {
            boolean z = false;
            if (i >= this.files.size()) {
                return false;
            }
            File file = (File) this.files.get(i);
            String lowerCase = file.getName().toLowerCase();
            if (file.isDirectory() || lowerCase.endsWith(".jpg") || lowerCase.endsWith(".png") || lowerCase.endsWith(".txt") || lowerCase.endsWith(".pdf") || lowerCase.endsWith(".doc") || lowerCase.endsWith(".docx") || lowerCase.endsWith(".xls") || lowerCase.endsWith(".xlsx") || lowerCase.endsWith(".ppt") || lowerCase.endsWith(".pptx") || lowerCase.endsWith(".hwp") || lowerCase.endsWith(".htm") || lowerCase.endsWith(".html")) {
                z = true;
            }
            return z;
        }

        public int getCount() {
            return this.files.size();
        }

        public Object getItem(int i) {
            return this.files.get(i);
        }

        public long getItemId(int i) {
            return (long) (((File) this.files.get(i)).getAbsolutePath().hashCode() << (i + 16));
        }

        /* JADX WARNING: Code restructure failed: missing block: B:31:0x00b4, code lost:
            if (r3.endsWith(".html") == false) goto L_0x00c6;
         */
        /* JADX WARNING: Removed duplicated region for block: B:38:0x00cc  */
        /* JADX WARNING: Removed duplicated region for block: B:52:0x0104  */
        /* JADX WARNING: Removed duplicated region for block: B:57:0x0112  */
        public View getView(int i, View view, ViewGroup viewGroup) {
            LinearLayout linearLayout = (LinearLayout) view;
            if (linearLayout == null) {
                linearLayout = (LinearLayout) ActivityDocsBrowser.this.getLayoutInflater().inflate(R.layout.list_item_docs, viewGroup, false);
            }
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.image);
            TextView textView = (TextView) linearLayout.findViewById(R.id.name);
            int i2 = R.drawable.icn_empty;
            File file = (File) this.files.get(i);
            String lowerCase = file.getName().toLowerCase();
            if (!lowerCase.endsWith(".txt")) {
                if (lowerCase.endsWith(".pdf")) {
                    i2 = R.drawable.icn_pdf;
                } else if (lowerCase.endsWith(".png") || lowerCase.endsWith(".jpg")) {
                    i2 = R.drawable.icn_img;
                } else if (lowerCase.endsWith(".doc") || lowerCase.endsWith(".docx")) {
                    i2 = R.drawable.icn_doc;
                } else if (lowerCase.endsWith(".xls") || lowerCase.endsWith(".xlsx")) {
                    i2 = R.drawable.icn_xls;
                } else if (lowerCase.endsWith(".ppt") || lowerCase.endsWith(".pptx")) {
                    i2 = R.drawable.icn_ppt;
                } else if (lowerCase.endsWith(".hwp")) {
                    i2 = R.drawable.icn_hwp;
                } else if (!lowerCase.endsWith(".htm")) {
                }
                if (file.isDirectory()) {
                    File file2 = this.curr;
                    i2 = (file2 == null || i != 0 || (file2 instanceof Volume)) ? R.drawable.icn_folder : R.drawable.icn_up;
                }
                if (imageView.getTag() == null || i2 != ((Integer) imageView.getTag()).intValue()) {
                    imageView.setTag(Integer.valueOf(i2));
                    imageView.setImageResource(i2);
                }
                linearLayout.setTag(Integer.valueOf(i));
                File file3 = this.curr;
                String str = file3 == null ? (i != 0 || (file3 instanceof Volume)) ? file.getName() : ".." : ((Volume) file).getVolumeName();
                textView.setText(str);
                textView.setEnabled(isEnabled(i));
                return linearLayout;
            }
            i2 = R.drawable.icn_txt;
            if (file.isDirectory()) {
            }
            imageView.setTag(Integer.valueOf(i2));
            imageView.setImageResource(i2);
            linearLayout.setTag(Integer.valueOf(i));
            File file32 = this.curr;
            if (file32 == null) {
            }
            textView.setText(str);
            textView.setEnabled(isEnabled(i));
            return linearLayout;
        }

        public boolean isEmpty() {
            return this.files.size() == 0;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.observers == null) {
                this.observers = new ArrayList();
            }
            if (!this.observers.contains(dataSetObserver)) {
                this.observers.add(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                list.remove(dataSetObserver);
            }
        }

        public void fireOnChanged() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onChanged();
                }
            }
        }

        public void fireOnInvalidated() {
            List<DataSetObserver> list = this.observers;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    ((DataSetObserver) this.observers.get(i)).onInvalidated();
                }
            }
        }
    }

    static class Volume extends File {
        public String name;

        public Volume(String str, String str2) {
            super(str2);
            this.name = str;
        }

        public String getVolumeName() {
            String str = this.name;
            return str != null ? str : getAbsolutePath();
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.list);
        setTitle((int) R.string.button_main_docs);
        Button button = (Button) findViewById(R.id.button_print);
        this.btn = button;
        button.setText(R.string.button_storages);
        boolean z = false;
        this.btn.setEnabled(false);
        ListView listView = (ListView) findViewById(R.id.list);
        this.list = listView;
        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                int intValue = ((Integer) view.getTag()).intValue();
                if (intValue <= ActivityDocsBrowser.this.adapter.getCount()) {
                    File file = (File) ActivityDocsBrowser.this.adapter.getItem(intValue);
                    if (file.isDirectory()) {
                        ActivityDocsBrowser.this.adapter.changeDir(file);
                    } else {
                        Uri fromFile = Uri.fromFile(file);
                        Intent intent = new Intent("android.intent.action.VIEW");
                        String mimeTypeByName = App.getMimeTypeByName(file.getName());
                        if (mimeTypeByName.startsWith("image/")) {
                            intent.setClass(ActivityDocsBrowser.this, ActivityPrintPictures.class);
                        } else if (mimeTypeByName.equals(NanoHTTPD.MIME_HTML)) {
                            intent.setClass(ActivityDocsBrowser.this, ActivityWeb.class);
                        } else if (mimeTypeByName.equals("application/pdf")) {
                            intent.setClass(ActivityDocsBrowser.this, ActivityPrintPDF.class);
                        } else {
                            intent.setClass(ActivityDocsBrowser.this, ActivityPrintDocuments.class);
                        }
                        intent.setDataAndType(fromFile, mimeTypeByName);
                        ActivityDocsBrowser.this.startActivity(intent);
                    }
                }
            }
        });
        DirAdapter dirAdapter = new DirAdapter();
        this.adapter = dirAdapter;
        this.list.setAdapter(dirAdapter);
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                z = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        if (z) {
            new Object() {
                {
                    String str = "android.permission.READ_EXTERNAL_STORAGE";
                    if (ActivityDocsBrowser.this.checkSelfPermission(str) != 0) {
                        ActivityDocsBrowser.this.requestPermissions(new String[]{str}, 444555);
                    } else {
                        ActivityDocsBrowser.this.adapter.init();
                    }
                }
            };
        } else {
            this.adapter.init();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.adapter.init();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || this.adapter.getCount() <= 0 || this.adapter.curr == null || (this.adapter.curr instanceof Volume)) {
            return super.onKeyDown(i, keyEvent);
        }
        DirAdapter dirAdapter = this.adapter;
        dirAdapter.changeDir((File) dirAdapter.getItem(0));
        return true;
    }
}
