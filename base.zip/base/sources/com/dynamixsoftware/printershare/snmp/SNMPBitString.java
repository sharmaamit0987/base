package com.dynamixsoftware.printershare.snmp;

public class SNMPBitString extends SNMPOctetString {
    protected byte tag;

    public SNMPBitString() {
        this.tag = 3;
        this.data = new byte[0];
    }

    public SNMPBitString(String str) {
        this.tag = 3;
        this.data = str.getBytes();
    }

    public SNMPBitString(byte[] bArr) {
        this.tag = 3;
        extractFromBEREncoding(bArr);
    }
}
