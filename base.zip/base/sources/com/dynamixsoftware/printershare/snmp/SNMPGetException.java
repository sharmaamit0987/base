package com.dynamixsoftware.printershare.snmp;

public class SNMPGetException extends SNMPRequestException {
    public SNMPGetException(int i, int i2) {
        super(i, i2);
    }

    public SNMPGetException(String str, int i, int i2) {
        super(str, i, i2);
    }
}
