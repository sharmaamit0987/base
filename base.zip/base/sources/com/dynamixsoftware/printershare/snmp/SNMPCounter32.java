package com.dynamixsoftware.printershare.snmp;

import java.math.BigInteger;

public class SNMPCounter32 extends SNMPInteger {
    private static BigInteger maxValue = new BigInteger("4294967295");

    public SNMPCounter32() {
        this(0);
    }

    public SNMPCounter32(long j) {
        this.tag = SNMPBERCodec.SNMPCOUNTER32;
        this.value = new BigInteger(new Long(j).toString());
        this.value = this.value.mod(maxValue);
    }

    protected SNMPCounter32(byte[] bArr) throws SNMPBadValueException {
        this.tag = SNMPBERCodec.SNMPCOUNTER32;
        extractValueFromBEREncoding(bArr);
        this.value = this.value.mod(maxValue);
    }

    public void setValue(Object obj) throws SNMPBadValueException {
        if (obj instanceof BigInteger) {
            this.value = (BigInteger) obj;
            this.value = this.value.mod(maxValue);
        } else if (obj instanceof Integer) {
            this.value = new BigInteger(obj.toString());
            this.value = this.value.mod(maxValue);
        } else if (obj instanceof String) {
            this.value = new BigInteger((String) obj);
            this.value = this.value.mod(maxValue);
        } else {
            throw new SNMPBadValueException(" Counter32: bad object supplied to set value ");
        }
    }
}
