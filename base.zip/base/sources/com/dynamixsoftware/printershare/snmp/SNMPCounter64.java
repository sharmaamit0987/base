package com.dynamixsoftware.printershare.snmp;

import java.math.BigInteger;

public class SNMPCounter64 extends SNMPInteger {
    private static BigInteger maxValue = new BigInteger("18446744070000000000");

    public SNMPCounter64() {
        this(0);
    }

    public SNMPCounter64(long j) {
        this.tag = SNMPBERCodec.SNMPCOUNTER64;
        this.value = new BigInteger(new Long(j).toString());
        this.value = this.value.mod(maxValue);
    }

    protected SNMPCounter64(byte[] bArr) throws SNMPBadValueException {
        this.tag = SNMPBERCodec.SNMPCOUNTER64;
        extractValueFromBEREncoding(bArr);
        this.value = this.value.mod(maxValue);
    }

    public void setValue(Object obj) throws SNMPBadValueException {
        if (obj instanceof BigInteger) {
            this.value = (BigInteger) obj;
            this.value = this.value.mod(maxValue);
        } else if (obj instanceof Integer) {
            this.value = new BigInteger(obj.toString());
            this.value = this.value.mod(maxValue);
        } else if (obj instanceof String) {
            this.value = new BigInteger((String) obj);
            this.value = this.value.mod(maxValue);
        } else {
            throw new SNMPBadValueException(" Counter64: bad object supplied to set value ");
        }
    }
}
