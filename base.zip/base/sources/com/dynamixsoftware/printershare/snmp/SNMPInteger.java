package com.dynamixsoftware.printershare.snmp;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;

public class SNMPInteger extends SNMPObject {
    protected byte tag;
    protected BigInteger value;

    public SNMPInteger() {
        this(0);
    }

    public SNMPInteger(long j) {
        this.tag = 2;
        this.value = new BigInteger(new Long(j).toString());
    }

    public SNMPInteger(BigInteger bigInteger) {
        this.tag = 2;
        this.value = bigInteger;
    }

    protected SNMPInteger(byte[] bArr) throws SNMPBadValueException {
        this.tag = 2;
        extractValueFromBEREncoding(bArr);
    }

    public Object getValue() {
        return this.value;
    }

    public void setValue(Object obj) throws SNMPBadValueException {
        if (obj instanceof BigInteger) {
            this.value = (BigInteger) obj;
        } else if (obj instanceof Integer) {
            this.value = new BigInteger(((Integer) obj).toString());
        } else if (obj instanceof String) {
            this.value = new BigInteger((String) obj);
        } else {
            throw new SNMPBadValueException(" Integer: bad object supplied to set value ");
        }
    }

    /* access modifiers changed from: protected */
    public byte[] getBEREncoding() {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] byteArray = this.value.toByteArray();
        byte[] encodeLength = SNMPBERCodec.encodeLength(byteArray.length);
        byteArrayOutputStream.write(this.tag);
        byteArrayOutputStream.write(encodeLength, 0, encodeLength.length);
        byteArrayOutputStream.write(byteArray, 0, byteArray.length);
        return byteArrayOutputStream.toByteArray();
    }

    public void extractValueFromBEREncoding(byte[] bArr) throws SNMPBadValueException {
        try {
            this.value = new BigInteger(bArr);
        } catch (NumberFormatException unused) {
            throw new SNMPBadValueException(" Integer: bad BER encoding supplied to set value ");
        }
    }

    public String toString() {
        return this.value.toString();
    }

    public String toString(int i) {
        return this.value.toString(i);
    }
}
