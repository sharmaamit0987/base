package com.dynamixsoftware.printershare.snmp;

import com.dynamixsoftware.printershare.smb.WinError;
import java.io.ByteArrayOutputStream;

public class SNMPBERCodec {
    public static final byte SNMPBITSTRING = 3;
    public static final byte SNMPCOUNTER32 = 65;
    public static final byte SNMPCOUNTER64 = 70;
    public static final byte SNMPGAUGE32 = 66;
    public static final byte SNMPGETNEXTREQUEST = -95;
    public static final byte SNMPGETREQUEST = -96;
    public static final byte SNMPGETRESPONSE = -94;
    public static final byte SNMPINTEGER = 2;
    public static final byte SNMPIPADDRESS = 64;
    public static final byte SNMPNSAPADDRESS = 69;
    public static final byte SNMPNULL = 5;
    public static final byte SNMPOBJECTIDENTIFIER = 6;
    public static final byte SNMPOCTETSTRING = 4;
    public static final byte SNMPOPAQUE = 68;
    public static final byte SNMPSEQUENCE = 48;
    public static final byte SNMPSETREQUEST = -93;
    public static final byte SNMPTIMETICKS = 67;
    public static final byte SNMPTRAP = -92;
    public static final byte SNMPUINTEGER32 = 71;
    public static final byte SNMPUNKNOWNOBJECT = 0;
    public static final byte SNMPv2BULKREQUEST = -91;
    public static final byte SNMPv2INFORMREQUEST = -90;
    public static final byte SNMPv2TRAP = -89;
    public static final byte SNMPv2pAUTHORIZEDMESSAGE = -95;
    public static final byte SNMPv2pCOMMUNICATION = -94;
    public static final byte SNMPv2pENCRYPTEDDATA = -95;
    public static final byte SNMPv2pENCRYPTEDMESSAGE = -95;

    public static SNMPObject extractEncoding(SNMPTLV snmptlv) throws SNMPBadValueException {
        byte b = snmptlv.tag;
        if (b == 2) {
            return new SNMPInteger(snmptlv.value);
        }
        if (b == 3) {
            return new SNMPBitString(snmptlv.value);
        }
        if (b == 4) {
            return new SNMPOctetString(snmptlv.value);
        }
        if (b != 5) {
            if (b == 6) {
                return new SNMPObjectIdentifier(snmptlv.value);
            }
            if (b == 48) {
                return new SNMPSequence(snmptlv.value);
            }
            switch (b) {
                case -96:
                case -95:
                case -94:
                case -93:
                    return new SNMPPDU(snmptlv.value, snmptlv.tag);
                default:
                    switch (b) {
                        case 64:
                            return new SNMPIPAddress(snmptlv.value);
                        case 65:
                            return new SNMPCounter32(snmptlv.value);
                        case 66:
                            return new SNMPGauge32(snmptlv.value);
                        case 67:
                            return new SNMPTimeTicks(snmptlv.value);
                        case 68:
                            break;
                        case 69:
                            return new SNMPNSAPAddress(snmptlv.value);
                        case 70:
                            return new SNMPCounter64(snmptlv.value);
                        case WinError.ERROR_REQ_NOT_ACCEP /*71*/:
                            return new SNMPUInteger32(snmptlv.value);
                        default:
                            return new SNMPUnknownObject(snmptlv.value);
                    }
            }
        }
        return new SNMPNull();
    }

    /* JADX WARNING: type inference failed for: r2v7 */
    /* JADX WARNING: Incorrect type for immutable var: ssa=byte, code=int, for r2v0, types: [int, byte] */
    /* JADX WARNING: Multi-variable type inference failed */
    public static SNMPTLV extractNextTLV(byte[] bArr, int i) throws SNMPBadValueException {
        int i2;
        SNMPTLV snmptlv = new SNMPTLV();
        try {
            snmptlv.tag = bArr[i];
            int i3 = i + 1;
            int i4 = bArr[i3];
            if (i4 < 0) {
                i4 += 256;
            }
            if (i4 / 128 < 1) {
                i2 = i4;
            } else {
                int i5 = i4 % 128;
                int i6 = 0;
                for (int i7 = 0; i7 < i5; i7++) {
                    i3++;
                    byte b = bArr[i3];
                    i6 = (i6 * 256) + (b < 0 ? b + 256 : b);
                }
                i2 = i6;
            }
            int i8 = i3 + 1;
            snmptlv.totalLength = (i8 - i) + i2;
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byteArrayOutputStream.write(bArr, i8, i2);
            snmptlv.value = byteArrayOutputStream.toByteArray();
            return snmptlv;
        } catch (IndexOutOfBoundsException unused) {
            throw new SNMPBadValueException("Problem while decoding SNMP: packet truncated or corrupt");
        } catch (Exception unused2) {
            throw new SNMPBadValueException("Problem while decoding SNMP");
        }
    }

    public static byte[] encodeLength(int i) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (i < 128) {
            byteArrayOutputStream.write(new byte[]{(byte) i}, 0, 1);
        } else {
            int i2 = 0;
            for (int i3 = i; i3 > 0; i3 = (int) Math.floor((double) (i3 / 256))) {
                i2++;
            }
            byteArrayOutputStream.write((byte) (((byte) i2) + 128));
            byte[] bArr = new byte[i2];
            for (int i4 = i2 - 1; i4 >= 0; i4--) {
                bArr[i4] = (byte) (i % 256);
                i = (int) Math.floor((double) (i / 256));
            }
            byteArrayOutputStream.write(bArr, 0, i2);
        }
        return byteArrayOutputStream.toByteArray();
    }
}
