package com.dynamixsoftware.printershare.snmp;

public class SNMPException extends Exception {
    public SNMPException() {
    }

    public SNMPException(String str) {
        super(str);
    }
}
