package com.dynamixsoftware.printershare.snmp;

import java.math.BigInteger;

public class SNMPGauge32 extends SNMPInteger {
    private static BigInteger maxValue = new BigInteger("4294967295");

    public SNMPGauge32() {
        this(0);
    }

    public SNMPGauge32(long j) {
        this.tag = 66;
        this.value = new BigInteger(new Long(j).toString());
        this.value = this.value.min(maxValue);
    }

    protected SNMPGauge32(byte[] bArr) throws SNMPBadValueException {
        this.tag = 66;
        extractValueFromBEREncoding(bArr);
        this.value = this.value.min(maxValue);
    }

    public void setValue(Object obj) throws SNMPBadValueException {
        if (obj instanceof BigInteger) {
            this.value = (BigInteger) obj;
            this.value = this.value.min(maxValue);
        } else if (obj instanceof Integer) {
            this.value = new BigInteger(obj.toString());
            this.value = this.value.min(maxValue);
        } else if (obj instanceof String) {
            this.value = new BigInteger((String) obj);
            this.value = this.value.min(maxValue);
        } else {
            throw new SNMPBadValueException(" Gauge32: bad object supplied to set value ");
        }
    }
}
