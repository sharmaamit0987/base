package com.dynamixsoftware.printershare.snmp;

public class SNMPBadValueException extends Exception {
    public SNMPBadValueException() {
    }

    public SNMPBadValueException(String str) {
        super(str);
    }
}
