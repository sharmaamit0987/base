package com.dynamixsoftware.printershare;

import com.flurry.android.Constants;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Hashtable;

public final class Json {
    static final char[][] amps = {new char[]{'&', 'a', 'm', 'p'}, new char[]{'<', 'l', 't'}, new char[]{'>', 'g', 't'}, new char[]{'\"', 'q', 'u', 'o', 't'}, new char[]{'\'', 'a', 'p', 'o', 's'}};
    private static final Hashtable<Class<?>, XField[]> flds_cache = new Hashtable<>();
    private static final String shab = "0123456789abcdef";

    static class SpecialInputStream {
        final byte[] buf = new byte[4096];
        final InputStream is;
        int l = -1;
        int s = -1;
        final char[] tmp_buffer = new char[4096];

        SpecialInputStream(InputStream inputStream) {
            this.is = inputStream;
        }

        /* access modifiers changed from: 0000 */
        public final void fill() throws IOException {
            int i;
            while (true) {
                int i2 = this.s;
                i = this.l;
                if (i2 != i) {
                    break;
                }
                this.s = 0;
                this.l = this.is.read(this.buf);
            }
            if (i == -1) {
                throw new IOException("Unexpected end of stream");
            }
        }
    }

    static class XField {
        final Field field;
        final String name;

        XField(Field field2) {
            String name2 = field2.getName();
            if (name2.endsWith("_")) {
                name2 = name2.substring(0, name2.length() - 1);
            }
            field2.setAccessible(true);
            this.name = name2;
            this.field = field2;
        }
    }

    private static Hashtable<String, String> getOtherHolder(Object obj) {
        Hashtable<String, String> hashtable = null;
        try {
            Field field = obj.getClass().getField("$other");
            if (field == null) {
                return null;
            }
            Hashtable hashtable2 = (Hashtable) field.get(obj);
            if (hashtable2 == null) {
                try {
                    hashtable = new Hashtable<>();
                    field.set(obj, hashtable);
                    return hashtable;
                } catch (IllegalAccessException | NoSuchFieldException unused) {
                }
            }
            return hashtable2;
        } catch (IllegalAccessException | NoSuchFieldException unused2) {
            return hashtable;
        }
    }

    private static XField[] getObjectFields(Object obj) {
        Class cls = obj.getClass();
        XField[] xFieldArr = (XField[]) flds_cache.get(cls);
        if (xFieldArr != null) {
            return xFieldArr;
        }
        Field[] fields = cls.getFields();
        XField[] xFieldArr2 = new XField[fields.length];
        for (int i = 0; i < fields.length; i++) {
            xFieldArr2[i] = new XField(fields[i]);
        }
        flds_cache.put(cls, xFieldArr2);
        return xFieldArr2;
    }

    private static Class<?> getFieldClass(Field field) {
        Class<?> type = field != null ? field.getType() : null;
        if (!ArrayList.class.equals(type)) {
            return type;
        }
        Type genericType = field.getGenericType();
        return genericType instanceof ParameterizedType ? (Class) ((ParameterizedType) genericType).getActualTypeArguments()[0] : type;
    }

    public static Object read(String str, Class<?> cls) throws IOException {
        return read(new BufferedInputStream(new ByteArrayInputStream(str.getBytes()), 4096), cls);
    }

    public static Object read(BufferedInputStream bufferedInputStream, Class<?> cls) throws IOException {
        SpecialInputStream specialInputStream = new SpecialInputStream(bufferedInputStream);
        while (true) {
            if (specialInputStream.s == specialInputStream.l) {
                specialInputStream.fill();
            }
            byte[] bArr = specialInputStream.buf;
            int i = specialInputStream.s;
            specialInputStream.s = i + 1;
            char c = (char) bArr[i];
            if (c == '{') {
                return readObject(specialInputStream, cls);
            }
            if (c == '[') {
                return readArray(specialInputStream, cls);
            }
            if (c != ' ' && c != 9 && c != 13 && c != 10) {
                throw new IOException("Unexpected character in stream");
            }
        }
    }

    public static String write(Object obj) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(8192);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream, 4096);
        write(obj, bufferedOutputStream);
        bufferedOutputStream.flush();
        return byteArrayOutputStream.toString();
    }

    public static void write(Object obj, BufferedOutputStream bufferedOutputStream) throws IOException {
        char[] cArr = new char[4096];
        if (obj instanceof ArrayList) {
            writeArray((ArrayList) obj, bufferedOutputStream, cArr);
        } else {
            writeObject(obj, bufferedOutputStream, cArr);
        }
    }

    private static void writeObject(Object obj, BufferedOutputStream bufferedOutputStream, char[] cArr) throws IOException {
        char[] cArr2;
        if (obj == null) {
            bufferedOutputStream.write("null".getBytes());
            return;
        }
        bufferedOutputStream.write(123);
        XField[] objectFields = getObjectFields(obj);
        boolean z = true;
        for (int i = 0; i < objectFields.length; i++) {
            String str = objectFields[i].name;
            Field field = objectFields[i].field;
            if (!z) {
                bufferedOutputStream.write(44);
            }
            if (z) {
                z = false;
            }
            Class<ArrayList> type = field.getType();
            try {
                int length = str.length();
                if (cArr.length < length) {
                    cArr2 = str.toCharArray();
                } else {
                    str.getChars(0, length, cArr, 0);
                    cArr2 = cArr;
                }
                for (int i2 = 0; i2 < length; i2++) {
                    bufferedOutputStream.write((byte) cArr2[i2]);
                }
                bufferedOutputStream.write(58);
                if (String.class == type) {
                    writeQuotedString((String) field.get(obj), bufferedOutputStream, cArr);
                } else if (ArrayList.class == type) {
                    writeArray((ArrayList) obj, bufferedOutputStream, cArr);
                } else {
                    writeObject(field.get(obj), bufferedOutputStream, cArr);
                }
            } catch (IllegalAccessException unused) {
            }
        }
        bufferedOutputStream.write(125);
    }

    private static void writeArray(ArrayList arrayList, BufferedOutputStream bufferedOutputStream, char[] cArr) throws IOException {
        if (arrayList == null) {
            bufferedOutputStream.write("null".getBytes());
            return;
        }
        bufferedOutputStream.write(91);
        for (int i = 0; i < arrayList.size(); i++) {
            if (i > 0) {
                bufferedOutputStream.write(",".getBytes());
            }
            Object obj = arrayList.get(i);
            if (obj instanceof String) {
                writeQuotedString((String) obj, bufferedOutputStream, cArr);
            } else if (obj instanceof ArrayList) {
                writeArray((ArrayList) obj, bufferedOutputStream, cArr);
            } else {
                writeObject(obj, bufferedOutputStream, cArr);
            }
        }
        bufferedOutputStream.write(93);
    }

    private static void writeQuotedString(String str, BufferedOutputStream bufferedOutputStream, char[] cArr) throws IOException {
        if (str == null) {
            bufferedOutputStream.write("null".getBytes());
            return;
        }
        bufferedOutputStream.write(34);
        int length = str.length();
        if (cArr.length < length) {
            cArr = str.toCharArray();
        } else {
            str.getChars(0, length, cArr, 0);
        }
        for (int i = 0; i < length; i++) {
            char c = cArr[i];
            if (c == '\"') {
                bufferedOutputStream.write("\\\"".getBytes());
            } else if (c == '\\') {
                bufferedOutputStream.write("\\\\".getBytes());
            } else if (c > 255) {
                int i2 = (c >> 12) & 15;
                int i3 = (c >> 8) & 15;
                int i4 = (c >> 4) & 15;
                char c2 = c & 15;
                bufferedOutputStream.write(92);
                bufferedOutputStream.write(117);
                String str2 = shab;
                bufferedOutputStream.write((byte) str2.charAt(i2));
                bufferedOutputStream.write((byte) str2.charAt(i3));
                bufferedOutputStream.write((byte) str2.charAt(i4));
                bufferedOutputStream.write((byte) str2.charAt(c2));
            } else {
                bufferedOutputStream.write((byte) (c & 255));
            }
        }
        bufferedOutputStream.write(34);
    }

    public static void copy(Object obj, Object obj2) {
        if (obj.getClass().equals(obj2.getClass())) {
            XField[] objectFields = getObjectFields(obj);
            for (XField xField : objectFields) {
                Field field = xField.field;
                try {
                    field.set(obj2, field.get(obj));
                } catch (IllegalAccessException unused) {
                }
            }
            return;
        }
        throw new IllegalArgumentException();
    }

    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r5v1 */
    /* JADX WARNING: type inference failed for: r5v2 */
    /* JADX WARNING: type inference failed for: r5v3, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v4 */
    /* JADX WARNING: type inference failed for: r5v6, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v7 */
    /* JADX WARNING: type inference failed for: r5v8, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r5v9 */
    /* JADX WARNING: type inference failed for: r5v10, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r5v11, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r5v13 */
    /* JADX WARNING: type inference failed for: r5v23, types: [java.util.ArrayList] */
    /* JADX WARNING: type inference failed for: r5v27, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v29 */
    /* JADX WARNING: type inference failed for: r5v30 */
    /* JADX WARNING: type inference failed for: r5v31 */
    /* JADX WARNING: type inference failed for: r5v32 */
    /* JADX WARNING: type inference failed for: r5v33 */
    /* JADX WARNING: type inference failed for: r5v34 */
    /* JADX WARNING: type inference failed for: r5v35 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r5v2
  assigns: []
  uses: []
  mth insns count: 144
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 8 */
    private static Object readObject(SpecialInputStream specialInputStream, Class<?> cls) throws IOException {
        Object obj;
        ? r5;
        try {
            obj = cls.newInstance();
        } catch (IllegalAccessException | InstantiationException unused) {
            obj = null;
        }
        if (obj != null) {
            XField[] xFieldArr = (XField[]) getObjectFields(obj).clone();
            String str = null;
            Field field = null;
            ? r52 = 0;
            StringBuffer stringBuffer = null;
            int i = 0;
            while (true) {
                if (specialInputStream.s == specialInputStream.l) {
                    specialInputStream.fill();
                }
                byte[] bArr = specialInputStream.buf;
                int i2 = specialInputStream.s;
                specialInputStream.s = i2 + 1;
                char c = (char) bArr[i2];
                String str2 = "Unexpected character in stream";
                if (c == '{') {
                    if (str != null) {
                        Class<Object> fieldClass = getFieldClass(field);
                        if (fieldClass == null) {
                            fieldClass = Object.class;
                        }
                        r5 = readObject(specialInputStream, fieldClass);
                    } else {
                        throw new IOException(str2);
                    }
                } else if (c == '[') {
                    if (str != null) {
                        Class<Object> fieldClass2 = getFieldClass(field);
                        if (fieldClass2 == null) {
                            fieldClass2 = Object.class;
                        }
                        r5 = readArray(specialInputStream, fieldClass2);
                    } else {
                        throw new IOException(str2);
                    }
                } else if (c == ',' || c == '}') {
                    if (r5 != 0 || i > 0 || stringBuffer != null) {
                        if (r5 == 0) {
                            ? str3 = new String(specialInputStream.tmp_buffer, 0, i);
                            if (stringBuffer != null) {
                                stringBuffer.append(str3);
                                str3 = stringBuffer.toString();
                            }
                            stringBuffer = null;
                            i = 0;
                            r5 = str3;
                        }
                        String str4 = "null";
                        if (field != null) {
                            try {
                                field.set(obj, !str4.equals(r5) ? r5 : 0);
                            } catch (IllegalAccessException unused2) {
                            }
                        } else if ((r5 instanceof String) && !str4.equals(r5)) {
                            Hashtable otherHolder = getOtherHolder(obj);
                            if (otherHolder != null) {
                                otherHolder.put(str, (String) r5);
                            }
                        }
                        if (c != ',') {
                            return obj;
                        }
                        str = null;
                        field = null;
                        r5 = 0;
                    } else if (c == '}') {
                        return obj;
                    } else {
                        throw new IOException(str2);
                    }
                } else if (str == null && c == ':') {
                    if (r5 == 0 && i <= 0 && stringBuffer == null) {
                        throw new IOException(str2);
                    }
                    if (r5 == 0) {
                        str = new String(specialInputStream.tmp_buffer, 0, i);
                        if (stringBuffer != null) {
                            stringBuffer.append(str);
                            str = stringBuffer.toString();
                        }
                        stringBuffer = null;
                        i = 0;
                    } else {
                        str = (String) r5;
                    }
                    int i3 = 0;
                    while (true) {
                        if (i3 < xFieldArr.length) {
                            if (xFieldArr[i3] != null && xFieldArr[i3].name.equals(str)) {
                                Field field2 = xFieldArr[i3].field;
                                xFieldArr[i3] = null;
                                field = field2;
                                break;
                            }
                            i3++;
                        } else {
                            field = null;
                            break;
                        }
                    }
                    r5 = 0;
                } else if (c == '\"') {
                    r5 = readQuotedString(specialInputStream);
                } else if (!(c == ' ' || c == 9 || c == 13 || c == 10)) {
                    if (i == specialInputStream.tmp_buffer.length) {
                        if (stringBuffer == null) {
                            stringBuffer = new StringBuffer(specialInputStream.tmp_buffer.length * 2);
                        }
                        stringBuffer.append(specialInputStream.tmp_buffer);
                        i = 0;
                    }
                    int i4 = i + 1;
                    specialInputStream.tmp_buffer[i] = c;
                    i = i4;
                }
                r52 = r5;
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Can't create object ");
            sb.append(cls);
            throw new IOException(sb.toString());
        }
    }

    /* JADX WARNING: type inference failed for: r3v0 */
    /* JADX WARNING: type inference failed for: r3v1 */
    /* JADX WARNING: type inference failed for: r3v2 */
    /* JADX WARNING: type inference failed for: r3v3, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v4 */
    /* JADX WARNING: type inference failed for: r3v5, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r3v6 */
    /* JADX WARNING: type inference failed for: r3v7, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r3v8, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r3v9, types: [java.util.ArrayList] */
    /* JADX WARNING: type inference failed for: r3v10, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v11 */
    /* JADX WARNING: type inference failed for: r3v12 */
    /* JADX WARNING: type inference failed for: r3v13 */
    /* JADX WARNING: type inference failed for: r3v14 */
    /* JADX WARNING: type inference failed for: r3v15 */
    /* JADX WARNING: type inference failed for: r3v16 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r3v2
  assigns: []
  uses: []
  mth insns count: 67
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 7 */
    private static ArrayList<Object> readArray(SpecialInputStream specialInputStream, Class<?> cls) throws IOException {
        ? r3;
        ArrayList<Object> arrayList = new ArrayList<>();
        ? r32 = 0;
        StringBuffer stringBuffer = null;
        int i = 0;
        while (true) {
            if (specialInputStream.s == specialInputStream.l) {
                specialInputStream.fill();
            }
            byte[] bArr = specialInputStream.buf;
            int i2 = specialInputStream.s;
            specialInputStream.s = i2 + 1;
            char c = (char) bArr[i2];
            if (c == '{') {
                r3 = readObject(specialInputStream, cls);
            } else if (c == '[') {
                r3 = readArray(specialInputStream, cls);
            } else if (c == ',' || c == ']') {
                if (r3 != 0 || i > 0 || stringBuffer != null) {
                    if (r3 == 0) {
                        ? str = new String(specialInputStream.tmp_buffer, 0, i);
                        if (stringBuffer != null) {
                            stringBuffer.append(str);
                            str = stringBuffer.toString();
                        }
                        stringBuffer = null;
                        i = 0;
                        r3 = str;
                    }
                    arrayList.add(r3);
                    if (c != ',') {
                        return arrayList;
                    }
                    r3 = 0;
                } else if (c == ']') {
                    return arrayList;
                } else {
                    throw new IOException("Unexpected character in stream");
                }
            } else if (c == '\"') {
                r3 = readQuotedString(specialInputStream);
            } else if (!(c == ' ' || c == 9 || c == 13 || c == 10)) {
                if (i == specialInputStream.tmp_buffer.length) {
                    if (stringBuffer == null) {
                        stringBuffer = new StringBuffer(specialInputStream.tmp_buffer.length * 2);
                    }
                    stringBuffer.append(specialInputStream.tmp_buffer);
                    i = 0;
                }
                int i3 = i + 1;
                specialInputStream.tmp_buffer[i] = c;
                i = i3;
            }
            r32 = r3;
        }
    }

    private static String readQuotedString(SpecialInputStream specialInputStream) throws IOException {
        int i;
        int i2;
        StringBuffer stringBuffer = null;
        char[] cArr = null;
        int i3 = 0;
        loop0:
        while (true) {
            int i4 = 0;
            while (true) {
                if (specialInputStream.s == specialInputStream.l) {
                    specialInputStream.fill();
                }
                byte[] bArr = specialInputStream.buf;
                int i5 = specialInputStream.s;
                specialInputStream.s = i5 + 1;
                char c = (char) (bArr[i5] & Constants.UNKNOWN);
                if (c == '\"') {
                    String str = new String(specialInputStream.tmp_buffer, 0, i);
                    if (stringBuffer == null) {
                        return str;
                    }
                    stringBuffer.append(str);
                    return stringBuffer.toString();
                }
                if (c == '\\') {
                    if (specialInputStream.s == specialInputStream.l) {
                        specialInputStream.fill();
                    }
                    byte[] bArr2 = specialInputStream.buf;
                    int i6 = specialInputStream.s;
                    specialInputStream.s = i6 + 1;
                    c = (char) bArr2[i6];
                    if (c == 'u') {
                        if (specialInputStream.s == specialInputStream.l) {
                            specialInputStream.fill();
                        }
                        byte[] bArr3 = specialInputStream.buf;
                        int i7 = specialInputStream.s;
                        specialInputStream.s = i7 + 1;
                        byte b = bArr3[i7];
                        if (specialInputStream.s == specialInputStream.l) {
                            specialInputStream.fill();
                        }
                        byte[] bArr4 = specialInputStream.buf;
                        int i8 = specialInputStream.s;
                        specialInputStream.s = i8 + 1;
                        byte b2 = bArr4[i8];
                        if (specialInputStream.s == specialInputStream.l) {
                            specialInputStream.fill();
                        }
                        byte[] bArr5 = specialInputStream.buf;
                        int i9 = specialInputStream.s;
                        specialInputStream.s = i9 + 1;
                        byte b3 = bArr5[i9];
                        if (specialInputStream.s == specialInputStream.l) {
                            specialInputStream.fill();
                        }
                        byte[] bArr6 = specialInputStream.buf;
                        int i10 = specialInputStream.s;
                        specialInputStream.s = i10 + 1;
                        byte b4 = bArr6[i10];
                        if (b >= 48 && ((b <= 57 || b >= 97) && b <= 102 && b2 >= 48 && ((b2 <= 57 || b2 >= 97) && b2 <= 102 && b3 >= 48 && ((b3 <= 57 || b3 >= 97) && b3 <= 102 && b4 >= 48 && ((b4 <= 57 || b4 >= 97) && b4 <= 102))))) {
                            c = (char) (((b > 96 ? b - 87 : b - 48) << 12) + ((b2 > 96 ? b2 - 87 : b2 - 48) << 8) + ((b3 > 96 ? b3 - 87 : b3 - 48) << 4) + (b4 > 96 ? b4 - 87 : b4 - 48));
                        }
                    } else if (c == 'n') {
                        c = 10;
                    } else if (c == 'r') {
                        c = 13;
                    } else if (c == 't') {
                        c = 9;
                    }
                }
                if (i == specialInputStream.tmp_buffer.length) {
                    if (stringBuffer == null) {
                        stringBuffer = new StringBuffer(specialInputStream.tmp_buffer.length * 2);
                    }
                    stringBuffer.append(specialInputStream.tmp_buffer);
                    i = 0;
                }
                i2 = i + 1;
                specialInputStream.tmp_buffer[i] = c;
                if (i4 > 0 && c != '&') {
                    if (c != ';') {
                        int i11 = i4 - 1;
                        if (i11 >= 15) {
                            break;
                        }
                        cArr[i11] = c;
                        i4++;
                    } else {
                        int i12 = 0;
                        boolean z = true;
                        while (true) {
                            char[][] cArr2 = amps;
                            if (i12 >= cArr2.length) {
                                break;
                            }
                            if (cArr2[i12].length == i4) {
                                int i13 = 1;
                                while (true) {
                                    char[][] cArr3 = amps;
                                    if (i13 >= cArr3[i12].length) {
                                        z = true;
                                        break;
                                    } else if (cArr3[i12][i13] != cArr[i13 - 1]) {
                                        z = false;
                                        break;
                                    } else {
                                        i13++;
                                    }
                                }
                                if (z) {
                                    c = amps[i12][0];
                                    break;
                                }
                            }
                            i12++;
                        }
                        if (z) {
                            int i14 = (i2 - i4) - 1;
                            if (i14 < 0) {
                                stringBuffer.delete(stringBuffer.length() - i14, stringBuffer.length());
                                i14 = 0;
                            }
                            int i15 = i14 + 1;
                            specialInputStream.tmp_buffer[i14] = c;
                            i2 = i15;
                        }
                    }
                } else if (c == '&') {
                    if (cArr == null) {
                        cArr = new char[16];
                    }
                    i = i2;
                    i4 = 1;
                }
                i = i2;
            }
            i3 = i2;
        }
        throw new IOException("Unexpected char in stream");
    }
}
