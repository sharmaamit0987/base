package com.dynamixsoftware.printershare;

public class PDFrender {
    public static native synchronized int create(String str, String str2, String str3, String str4);

    public static native synchronized int destroy();

    public static native synchronized void drawPage(int i, int i2);

    public static native synchronized int getPageCount();

    public static native synchronized double[] getPageSize(int i);
}
