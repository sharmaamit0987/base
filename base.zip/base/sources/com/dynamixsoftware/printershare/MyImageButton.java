package com.dynamixsoftware.printershare;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.ImageButton;
import android.widget.ImageView.ScaleType;

public class MyImageButton extends ImageButton {
    private int h;
    private int s;
    private int w;

    public MyImageButton(Context context) {
        this(context, null, 0);
    }

    public MyImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public MyImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setBackgroundResource(R.drawable.btn_main);
        setScaleType(ScaleType.FIT_CENTER);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.w = i;
        this.h = i2;
        int i5 = (i * 6) / 13;
        this.s = i5;
        while (true) {
            if (i5 % 4 == 0 && i5 % 5 != 0) {
                break;
            }
            i5--;
        }
        int i6 = this.s;
        while (true) {
            if (i6 % 4 == 0 && i6 % 5 != 0) {
                break;
            }
            i6++;
        }
        int i7 = this.s;
        if (i6 - i7 < i7 - i5) {
            i5 = i6;
        }
        this.s = i5;
        setPadding((i - i5) / 2, (i2 - i5) / 2, (i - i5) / 2, (i2 - i5) / 2);
    }

    public void setEnabled(boolean z) {
        super.setEnabled(z);
        if (!z) {
            setAlpha(128);
        } else {
            setAlpha(255);
        }
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        canvas.save();
        canvas.translate(0.0f, (float) ((-this.h) / 10));
        super.onDraw(canvas);
        canvas.restore();
        Object tag = getTag();
        if (tag != null && (tag instanceof String)) {
            String str = (String) tag;
            Paint newPaint = App.newPaint();
            newPaint.setAntiAlias(true);
            newPaint.setStyle(Style.FILL);
            newPaint.setTextAlign(Align.CENTER);
            newPaint.setColor(-16777216);
            newPaint.setAlpha(isEnabled() ? 255 : 128);
            for (int round = Math.round((float) (this.s / 3)); round > 8; round--) {
                newPaint.setTextSize((float) round);
                Rect rect = new Rect();
                newPaint.getTextBounds(str, 0, str.length(), rect);
                int width = rect.width();
                int i = this.w;
                if (width < i - ((i * 2) / 10)) {
                    break;
                }
            }
            float f = (float) (this.w / 2);
            int i2 = this.h;
            canvas.drawText(str, f, (float) (i2 - ((i2 * 3) / 20)), newPaint);
        }
    }
}
