package com.dynamixsoftware.printershare.ipp;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class IppConnection {
    private HttpURLConnection con;
    private String connect_url;
    private String login;
    private String password;
    private String service_url;
    private String user_agent;

    public IppConnection(String str, String str2) {
        int indexOf = str.indexOf("://");
        StringBuilder sb = new StringBuilder();
        sb.append(str.startsWith("ipps") ? "https://" : "http://");
        sb.append(str.substring(indexOf + 3));
        this.connect_url = sb.toString();
        this.service_url = str;
        this.user_agent = str2;
    }

    public void setAuthorization(String str, String str2) {
        this.login = str;
        this.password = str2;
    }

    public boolean isAuthorization() {
        return this.login != null;
    }

    public void setSecured(boolean z) {
        int indexOf = this.connect_url.indexOf("://");
        StringBuilder sb = new StringBuilder();
        sb.append(z ? "https" : "http");
        sb.append(this.connect_url.substring(indexOf));
        this.connect_url = sb.toString();
    }

    public boolean isSecured() {
        return this.connect_url.startsWith("https://");
    }

    public String getUri() {
        return this.service_url;
    }

    public OutputStream sendRequest(IppMessage ippMessage) throws Exception {
        URL url = new URL(this.connect_url);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        this.con = httpURLConnection;
        httpURLConnection.setConnectTimeout(15000);
        this.con.setReadTimeout(15000);
        this.con.setDoInput(true);
        this.con.setDoOutput(true);
        this.con.setUseCaches(false);
        this.con.setRequestMethod("POST");
        this.con.setRequestProperty("Connection", "close");
        this.con.setRequestProperty("User-Agent", this.user_agent);
        String host = url.getHost();
        if (host.startsWith("[")) {
            int indexOf = host.indexOf("%");
            if (indexOf > 0) {
                StringBuilder sb = new StringBuilder();
                sb.append(host.substring(0, indexOf));
                sb.append("]");
                host = sb.toString();
            }
        }
        this.con.setRequestProperty("Host", host);
        if (this.login != null) {
            HttpURLConnection httpURLConnection2 = this.con;
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Basic ");
            StringBuilder sb3 = new StringBuilder();
            sb3.append(this.login);
            sb3.append(":");
            sb3.append(this.password);
            sb2.append(Base64.encodeString(sb3.toString()));
            httpURLConnection2.setRequestProperty("Authorization", sb2.toString());
        }
        this.con.setRequestProperty("Content-Type", "application/ipp");
        this.con.setChunkedStreamingMode(32768);
        OutputStream outputStream = this.con.getOutputStream();
        ippMessage.writeToStream(outputStream);
        return outputStream;
    }

    /* JADX INFO: finally extract failed */
    public IppMessage getResponse() throws Exception {
        String str;
        try {
            int responseCode = this.con.getResponseCode();
            if (responseCode != 200) {
                String responseMessage = this.con.getResponseMessage();
                StringBuilder sb = new StringBuilder();
                sb.append("Can't connect to ");
                sb.append(this.service_url);
                sb.append(". HTTP error ");
                sb.append(responseCode);
                if (responseMessage != null) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(". ");
                    sb2.append(responseMessage);
                    str = sb2.toString();
                } else {
                    str = "";
                }
                sb.append(str);
                throw new Exception(sb.toString());
            }
            InputStream inputStream = this.con.getInputStream();
            IppMessage ippMessage = new IppMessage();
            ippMessage.readFromStream(inputStream);
            try {
                if (this.con != null) {
                    this.con.disconnect();
                }
                this.con = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ippMessage;
        } catch (Throwable th) {
            try {
                if (this.con != null) {
                    this.con.disconnect();
                }
                this.con = null;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            throw th;
        }
    }

    public void disconnect() {
        HttpURLConnection httpURLConnection = this.con;
        if (httpURLConnection != null) {
            httpURLConnection.disconnect();
        }
    }
}
