package com.dynamixsoftware.printershare.ipp;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class IppAttribute {
    public static final byte TYPE_BOOLEAN = 34;
    public static final byte TYPE_CHARSET = 71;
    public static final byte TYPE_ENUM = 35;
    public static final byte TYPE_INTEGER = 33;
    public static final byte TYPE_KEYWORD = 68;
    public static final byte TYPE_MIME_MEDIA_TYPE = 73;
    public static final byte TYPE_NAME_WITHOUT_LANGUAGE = 66;
    public static final byte TYPE_NATURAL_LANGUAGE = 72;
    public static final byte TYPE_URI = 69;
    public byte[] name;
    public byte tag;
    public byte[] value;

    public IppAttribute(byte b) {
        this.tag = b;
    }

    public IppAttribute(byte b, String str, boolean z) throws Exception {
        this.tag = b;
        this.name = str.getBytes("ASCII");
        byte[] bArr = new byte[1];
        this.value = bArr;
        bArr[0] = z ? (byte) 1 : 0;
    }

    public IppAttribute(byte b, String str, int i) throws Exception {
        this.tag = b;
        this.name = str.getBytes("ASCII");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        new DataOutputStream(byteArrayOutputStream).writeInt(i);
        this.value = byteArrayOutputStream.toByteArray();
    }

    public IppAttribute(byte b, String str, String str2) throws Exception {
        this(b, str, str2, null);
    }

    public IppAttribute(byte b, String str, String str2, String str3) throws Exception {
        this.tag = b;
        String str4 = "ASCII";
        this.name = str.getBytes(str4);
        if (str3 == null) {
            str3 = str4;
        }
        this.value = str2.getBytes(str3);
    }

    /* access modifiers changed from: 0000 */
    public void readFromStream(DataInputStream dataInputStream) throws IOException {
        short readShort = dataInputStream.readShort();
        if (readShort > 0) {
            byte[] bArr = new byte[readShort];
            this.name = bArr;
            dataInputStream.readFully(bArr);
        } else {
            this.name = null;
        }
        short readShort2 = dataInputStream.readShort();
        if (readShort2 > 0) {
            byte[] bArr2 = new byte[readShort2];
            this.value = bArr2;
            dataInputStream.readFully(bArr2);
            return;
        }
        this.value = null;
    }

    /* access modifiers changed from: 0000 */
    public void writeToStream(DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.writeShort(this.name.length);
        dataOutputStream.write(this.name);
        dataOutputStream.writeShort(this.value.length);
        dataOutputStream.write(this.value);
    }
}
