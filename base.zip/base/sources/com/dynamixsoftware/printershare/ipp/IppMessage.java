package com.dynamixsoftware.printershare.ipp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

public class IppMessage {
    public static short OP_GET_JOBS = 10;
    public static short OP_GET_JOB_ATTRIBUTES = 9;
    public static short OP_GET_PRINTER_ATTRIBUTES = 11;
    public static short OP_GET_PRINTER_SUPPORTED_VALUES = 21;
    public static short OP_PRINT_JOB = 2;
    public static short OP_VALIDATE_JOB = 4;
    private static int last_sid;
    public short code;
    public Vector<IppAttribute> job_attributes;
    public Vector<IppAttribute> operation_attributes;
    public Vector<IppAttribute> printer_attributes;
    public int sid;
    public Vector<IppAttribute> unsupported_attributes;
    public short version;

    public IppMessage(short s) {
        this.version = 257;
        this.code = s;
        int i = last_sid + 1;
        last_sid = i;
        this.sid = i;
        this.operation_attributes = new Vector<>();
        this.job_attributes = new Vector<>();
        this.printer_attributes = new Vector<>();
        this.unsupported_attributes = new Vector<>();
    }

    IppMessage() {
    }

    /* access modifiers changed from: 0000 */
    public void readFromStream(InputStream inputStream) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        this.version = dataInputStream.readShort();
        this.code = dataInputStream.readShort();
        this.sid = dataInputStream.readInt();
        this.operation_attributes = new Vector<>();
        this.job_attributes = new Vector<>();
        this.printer_attributes = new Vector<>();
        this.unsupported_attributes = new Vector<>();
        while (true) {
            Vector vector = null;
            while (true) {
                byte readByte = dataInputStream.readByte();
                if ((readByte & 240) != 0) {
                    IppAttribute ippAttribute = new IppAttribute(readByte);
                    ippAttribute.readFromStream(dataInputStream);
                    if (vector != null) {
                        vector.add(ippAttribute);
                    }
                } else if (readByte == 1) {
                    vector = this.operation_attributes;
                } else if (readByte == 2) {
                    vector = this.job_attributes;
                } else if (readByte != 3) {
                    if (readByte == 4) {
                        vector = this.printer_attributes;
                    } else if (readByte == 5) {
                        vector = this.unsupported_attributes;
                    }
                } else {
                    return;
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void writeToStream(OutputStream outputStream) throws IOException {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
        dataOutputStream.writeShort(this.version);
        dataOutputStream.writeShort(this.code);
        dataOutputStream.writeInt(this.sid);
        if (this.operation_attributes.size() > 0) {
            dataOutputStream.writeByte(1);
            for (int i = 0; i < this.operation_attributes.size(); i++) {
                IppAttribute ippAttribute = (IppAttribute) this.operation_attributes.get(i);
                dataOutputStream.writeByte(ippAttribute.tag);
                ippAttribute.writeToStream(dataOutputStream);
            }
        }
        if (this.job_attributes.size() > 0) {
            dataOutputStream.writeByte(2);
            for (int i2 = 0; i2 < this.job_attributes.size(); i2++) {
                IppAttribute ippAttribute2 = (IppAttribute) this.job_attributes.get(i2);
                dataOutputStream.writeByte(ippAttribute2.tag);
                ippAttribute2.writeToStream(dataOutputStream);
            }
        }
        if (this.printer_attributes.size() > 0) {
            dataOutputStream.writeByte(4);
            for (int i3 = 0; i3 < this.printer_attributes.size(); i3++) {
                IppAttribute ippAttribute3 = (IppAttribute) this.printer_attributes.get(i3);
                dataOutputStream.writeByte(ippAttribute3.tag);
                ippAttribute3.writeToStream(dataOutputStream);
            }
        }
        if (this.unsupported_attributes.size() > 0) {
            dataOutputStream.writeByte(5);
            for (int i4 = 0; i4 < this.unsupported_attributes.size(); i4++) {
                IppAttribute ippAttribute4 = (IppAttribute) this.unsupported_attributes.get(i4);
                dataOutputStream.writeByte(ippAttribute4.tag);
                ippAttribute4.writeToStream(dataOutputStream);
            }
        }
        dataOutputStream.writeByte(3);
    }
}
