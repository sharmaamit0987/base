package com.dynamixsoftware.printershare;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.App.NetworkInterfaceData;
import com.dynamixsoftware.printershare.data.Printer;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

public class ScanThreadBJNP extends Thread {
    /* access modifiers changed from: private */
    public boolean[] destroyed = new boolean[1];
    /* access modifiers changed from: private */
    public List<DatagramPacket> packets = new ArrayList();
    private Vector<Printer> printers;
    private String rq_pid;
    private Thread sender = new Thread() {
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0023, code lost:
            r4 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x002e, code lost:
            if (r4 >= com.dynamixsoftware.printershare.ScanThreadBJNP.access$300(r13.this$0).size()) goto L_0x00be;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0030, code lost:
            r5 = com.dynamixsoftware.printershare.ScanThreadBJNP.access$000(r13.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0036, code lost:
            monitor-enter(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x003f, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBJNP.access$000(r13.this$0)[0] == false) goto L_0x0043;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0041, code lost:
            monitor-exit(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x0042, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0043, code lost:
            monitor-exit(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
            r5 = (com.dynamixsoftware.printershare.ScanThreadBJNP.SocketThread) com.dynamixsoftware.printershare.ScanThreadBJNP.access$300(r13.this$0).get(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0055, code lost:
            if (r5.ia == null) goto L_0x0074;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x0057, code lost:
            r6 = new com.dynamixsoftware.printershare.bjnp.BJNPCommand();
            r6.dev_type = 1;
            r6.cmd_code = 1;
            r6.seq_no = com.dynamixsoftware.printershare.bjnp.BJNPMain.get_packet_id();
            r6 = r6.toPacket();
            r5.send(new java.net.DatagramPacket(r6, r6.length, r1, com.dynamixsoftware.printershare.bjnp.BJNPMain.BJNP_PORT_PRINT));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0074, code lost:
            r6 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x0079, code lost:
            if (r6 >= r0.size()) goto L_0x00b7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x007b, code lost:
            r9 = com.dynamixsoftware.printershare.ScanThreadBJNP.access$000(r13.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x0081, code lost:
            monitor-enter(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:0x008a, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBJNP.access$000(r13.this$0)[0] == false) goto L_0x008e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x008c, code lost:
            monitor-exit(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:37:0x008d, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x008e, code lost:
            monitor-exit(r9);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:?, code lost:
            r9 = new com.dynamixsoftware.printershare.bjnp.BJNPCommand();
            r9.dev_type = 1;
            r9.cmd_code = 1;
            r9.seq_no = com.dynamixsoftware.printershare.bjnp.BJNPMain.get_packet_id();
            r9 = r9.toPacket();
            r5.send(new java.net.DatagramPacket(r9, r9.length, (java.net.InetAddress) r0.get(r6), com.dynamixsoftware.printershare.bjnp.BJNPMain.BJNP_PORT_PRINT));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x00b1, code lost:
            r6 = r6 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x00b7, code lost:
            r4 = r4 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:?, code lost:
            java.lang.Thread.sleep(1000);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x00c3, code lost:
            r3 = r3 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x00c7, code lost:
            return;
         */
        public void run() {
            try {
                Vector broadcastAdrresses = App.getBroadcastAdrresses();
                InetAddress byName = InetAddress.getByName("FF02::1");
                int i = 0;
                while (i < 3) {
                    synchronized (ScanThreadBJNP.this.destroyed) {
                        if (ScanThreadBJNP.this.destroyed[0]) {
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }
    };
    /* access modifiers changed from: private */
    public ArrayList<SocketThread> sockets = new ArrayList<>();
    private Handler status;
    /* access modifiers changed from: private */
    public int timeout;

    class SocketThread extends Thread {
        InetAddress ia;
        DatagramSocket socket;

        SocketThread(InetAddress inetAddress) throws IOException {
            this.ia = inetAddress;
            DatagramSocket datagramSocket = new DatagramSocket(new InetSocketAddress(inetAddress, 0));
            this.socket = datagramSocket;
            try {
                datagramSocket.setBroadcast(true);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
        }

        public void run() {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                while (true) {
                    synchronized (ScanThreadBJNP.this.destroyed) {
                        if (ScanThreadBJNP.this.destroyed[0]) {
                            break;
                        }
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        if (currentTimeMillis2 >= ((long) ScanThreadBJNP.this.timeout)) {
                            break;
                        }
                        this.socket.setSoTimeout((int) (((long) ScanThreadBJNP.this.timeout) - currentTimeMillis2));
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[4096], 4096);
                        try {
                            this.socket.receive(datagramPacket);
                            synchronized (ScanThreadBJNP.this.packets) {
                                ScanThreadBJNP.this.packets.add(datagramPacket);
                                ScanThreadBJNP.this.packets.notifyAll();
                            }
                        } catch (SocketTimeoutException unused) {
                        } catch (IOException e) {
                            synchronized (ScanThreadBJNP.this.destroyed) {
                                if (!ScanThreadBJNP.this.destroyed[0]) {
                                    throw e;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                } catch (Throwable th) {
                    this.socket.close();
                    throw th;
                }
            }
            this.socket.close();
            synchronized (ScanThreadBJNP.this.packets) {
                ScanThreadBJNP.this.packets.notifyAll();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
            if (r3.socket.isClosed() == false) goto L_0x0021;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0020, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r3.socket.send(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
            java.lang.Thread.sleep(100);
         */
        public synchronized void send(DatagramPacket datagramPacket) {
            try {
                synchronized (ScanThreadBJNP.this.destroyed) {
                    if (ScanThreadBJNP.this.destroyed[0]) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("src: ");
                sb.append(this.socket.getLocalAddress());
                sb.append(" dst: ");
                sb.append(datagramPacket.getAddress());
                sb.append(" | ");
                sb.append(this.ia);
                App.reportThrowable(e, sb.toString());
            }
            return;
        }

        public void interrupt() {
            super.interrupt();
            this.socket.close();
        }
    }

    public ScanThreadBJNP(Context context, int i, String str, Handler handler) {
        this.timeout = i;
        this.status = handler;
        this.rq_pid = str;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        int i;
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        for (i = 0; i < this.sockets.size(); i++) {
            ((SocketThread) this.sockets.get(i)).interrupt();
        }
        interrupt();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0199, code lost:
        r9.add(r0);
        r4 = new java.lang.String(r12.data, r3, (((r12.data[0] & com.flurry.android.Constants.UNKNOWN) * 256) + (r12.data[1] & com.flurry.android.Constants.UNKNOWN)) - r3).split(";");
        r6 = 0;
        r12 = null;
        r14 = null;
        r16 = null;
        r17 = null;
        r18 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x01c3, code lost:
        if (r6 >= r4.length) goto L_0x024e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x01c5, code lost:
        r5 = r4[r6].split(":");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x01ce, code lost:
        if (r5.length >= r3) goto L_0x01d2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x01da, code lost:
        if ("MFG".equals(r5[0]) != false) goto L_0x0246;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x01e4, code lost:
        if ("MFR".equals(r5[0]) != false) goto L_0x0246;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x01ee, code lost:
        if ("MANUFACTURER".equals(r5[0]) == false) goto L_0x01f1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x01f9, code lost:
        if ("MDL".equals(r5[0]) != false) goto L_0x0243;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0203, code lost:
        if ("MODEL".equals(r5[0]) == false) goto L_0x0206;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x020e, code lost:
        if ("CMD".equals(r5[0]) != false) goto L_0x0240;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x0218, code lost:
        if ("COMMAND SET".equals(r5[0]) == false) goto L_0x021b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x0223, code lost:
        if ("DES".equals(r5[0]) != false) goto L_0x023d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x022d, code lost:
        if ("DESCRIPTION".equals(r5[0]) == false) goto L_0x0230;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x0238, code lost:
        if ("URF".equals(r5[0]) == false) goto L_0x0248;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x023a, code lost:
        r18 = r5[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:132:0x023d, code lost:
        r16 = r5[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x0240, code lost:
        r17 = r5[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x0243, code lost:
        r14 = r5[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x0246, code lost:
        r12 = r5[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:136:0x0248, code lost:
        r6 = r6 + 1;
        r3 = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x024e, code lost:
        r3 = com.dynamixsoftware.printershare.App.getFullModelName(r12, r14);
        r4 = new java.lang.StringBuilder();
        r4.append("bjnp_");
        r4.append(r13);
        r4.append("_");
        r4.append(r3);
        r4.append("._canon-bjnp1._tcp.local.");
        r4 = r4.toString();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:138:0x0272, code lost:
        if (r1.rq_pid == null) goto L_0x027e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x027a, code lost:
        if (r4.equals(r1.rq_pid) != false) goto L_0x027e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:142:0x027e, code lost:
        r5 = r0.getHostAddress();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:143:0x0288, code lost:
        if (r0.getAddress().length == 4) goto L_0x02a0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:144:0x028a, code lost:
        r0 = new java.lang.StringBuilder();
        r0.append("[");
        r0.append(r5);
        r0.append("]");
        r5 = r0.toString();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:145:0x02a0, code lost:
        r0 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:147:0x02a7, code lost:
        if (r0 >= r1.printers.size()) goto L_0x02ce;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:0x02b7, code lost:
        if (((com.dynamixsoftware.printershare.data.Printer) r1.printers.get(r0)).direct_address.indexOf(r5) <= 0) goto L_0x02cb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x02c7, code lost:
        if (r4.equals(((com.dynamixsoftware.printershare.data.Printer) r1.printers.get(r0)).id) == false) goto L_0x02cb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x02c9, code lost:
        r0 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:153:0x02cb, code lost:
        r0 = r0 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x02ce, code lost:
        r0 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:155:0x02cf, code lost:
        if (r0 == false) goto L_0x02d3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:157:0x02d3, code lost:
        r0 = new java.lang.StringBuilder();
        r0.append("bjnp://");
        r0.append(r5);
        r0.append(":");
        r0.append(com.dynamixsoftware.printershare.bjnp.BJNPMain.BJNP_PORT_PRINT);
        r0 = r0.toString();
        r5 = new com.dynamixsoftware.printershare.data.Printer();
        r5.owner = new com.dynamixsoftware.printershare.data.User();
        r5.owner.name = r13;
        r5.id = r4;
        r5.direct_address = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x0302, code lost:
        if (r16 == null) goto L_0x0307;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:159:0x0304, code lost:
        r0 = r16;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x0307, code lost:
        if (r3 == null) goto L_0x030b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:0x0309, code lost:
        r0 = r3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:162:0x030b, code lost:
        r16 = "Network Printer";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:0x030e, code lost:
        r5.title = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:164:0x0310, code lost:
        if (r3 == null) goto L_0x0313;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:166:0x0313, code lost:
        r3 = "";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:167:0x0315, code lost:
        r5.model = r3;
        r5.capabilities = new java.util.Hashtable<>();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:168:0x031e, code lost:
        if (r12 == null) goto L_0x0327;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x0320, code lost:
        r5.capabilities.put("usb_MFG", r12);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:170:0x0327, code lost:
        if (r14 == null) goto L_0x0330;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x0329, code lost:
        r5.capabilities.put("usb_MDL", r14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:172:0x0330, code lost:
        r0 = r17;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:173:0x0332, code lost:
        if (r0 == null) goto L_0x033b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:174:0x0334, code lost:
        r5.capabilities.put("usb_CMD", r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x033b, code lost:
        if (r18 == null) goto L_0x0344;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:176:0x033d, code lost:
        r5.capabilities.put("URF", r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x0344, code lost:
        r3 = r1.printers;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x0346, code lost:
        monitor-enter(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:180:?, code lost:
        r1.printers.add(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x034c, code lost:
        monitor-exit(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:?, code lost:
        r0 = new android.os.Message();
        r0.what = 2;
        r0.arg1 = 2;
        r1.status.sendMessage(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x035e, code lost:
        if (r1.rq_pid == null) goto L_0x037b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x0368, code lost:
        if (r1.rq_pid.equals(r5.id) == false) goto L_0x037b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:187:0x036a, code lost:
        destroy();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:?, code lost:
        r0 = ((java.net.DatagramPacket) r10[r11]).getAddress();
        r12 = com.dynamixsoftware.printershare.bjnp.BJNPCommand.fromPacket(((java.net.DatagramPacket) r10[r11]).getData(), 0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x0123, code lost:
        if (r12.cmd_code != 1) goto L_0x037b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x0129, code lost:
        if (r9.contains(r0) == false) goto L_0x012d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x012d, code lost:
        r13 = new java.lang.StringBuilder();
        r13.append(java.lang.Integer.toHexString(r12.data[9] & com.flurry.android.Constants.UNKNOWN));
        r13.append(java.lang.Integer.toHexString(r12.data[10] & com.flurry.android.Constants.UNKNOWN));
        r13.append(java.lang.Integer.toHexString(r12.data[11] & com.flurry.android.Constants.UNKNOWN));
        r13.append("000000");
        r13 = r13.toString().toUpperCase();
        r14 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x016f, code lost:
        if (r14 >= r4) goto L_0x0194;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:0x0171, code lost:
        r12 = new com.dynamixsoftware.printershare.bjnp.BJNPCommand();
        r12.dev_type = 1;
        r12.cmd_code = com.dynamixsoftware.printershare.snmp.SNMPBERCodec.SNMPSEQUENCE;
        r12 = com.dynamixsoftware.printershare.bjnp.BJNPMain.sendUDPCommand(r12, new java.net.InetSocketAddress(r0, com.dynamixsoftware.printershare.bjnp.BJNPMain.BJNP_PORT_PRINT), 1000);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x0187, code lost:
        if (r12 == null) goto L_0x018f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x018b, code lost:
        if (r12.data == null) goto L_0x018f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x018d, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x018f, code lost:
        r14 = r14 + 1;
        r4 = 3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0194, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0195, code lost:
        if (r4 != false) goto L_0x0199;
     */
    /* JADX WARNING: Removed duplicated region for block: B:236:0x038f A[EDGE_INSN: B:236:0x038f->B:210:0x038f ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x00fc  */
    public void run() {
        String str;
        int i;
        Object[] array;
        int i2;
        Message message = new Message();
        message.what = 1;
        int i3 = 2;
        message.arg1 = 2;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            try {
                Vector activeNetworkInterfaces = App.getActiveNetworkInterfaces();
                if (activeNetworkInterfaces == null || activeNetworkInterfaces.size() != 0) {
                    SocketThread socketThread = new SocketThread(null);
                    socketThread.start();
                    this.sockets.add(socketThread);
                    if (activeNetworkInterfaces != null) {
                        for (int i4 = 0; i4 < activeNetworkInterfaces.size(); i4++) {
                            NetworkInterfaceData networkInterfaceData = (NetworkInterfaceData) activeNetworkInterfaces.get(i4);
                            if (networkInterfaceData.is_multicast && networkInterfaceData.ipv6_linklocal_address != null) {
                                try {
                                    SocketThread socketThread2 = new SocketThread(networkInterfaceData.ipv6_linklocal_address);
                                    socketThread2.start();
                                    this.sockets.add(socketThread2);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    App.reportThrowable(e);
                                }
                            }
                        }
                    }
                    str = null;
                } else {
                    Message message2 = new Message();
                    message2.what = 4;
                    message2.arg1 = 2;
                    this.status.sendMessage(message2);
                    return;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("Internal Error: ");
                sb.append(e2.getMessage());
                str = sb.toString();
                App.reportThrowable(e2);
            }
        }
        i = 3;
        if (str == null) {
            HashSet hashSet = new HashSet();
            this.sender.start();
            while (true) {
                synchronized (this.destroyed) {
                    if (this.destroyed[0]) {
                        break;
                    }
                    while (true) {
                        synchronized (this.packets) {
                            if (this.packets.size() != 0) {
                                break;
                            }
                            int i5 = 0;
                            for (int i6 = 0; i6 < this.sockets.size(); i6++) {
                                if (((SocketThread) this.sockets.get(i6)).isAlive()) {
                                    i5++;
                                }
                            }
                            if (i5 != this.sockets.size()) {
                                if (i5 <= 0) {
                                    break;
                                }
                                Thread.yield();
                            } else {
                                try {
                                    this.packets.wait();
                                    break;
                                } catch (InterruptedException unused) {
                                }
                            }
                        }
                    }
                    array = this.packets.toArray();
                    this.packets.clear();
                    if (array.length != 0) {
                        break;
                    }
                    i2 = 0;
                    while (true) {
                        if (i2 >= array.length) {
                            break;
                        }
                        try {
                            synchronized (this.destroyed) {
                                if (this.destroyed[0]) {
                                }
                            }
                        } catch (Exception e3) {
                            e3.printStackTrace();
                            App.reportThrowable(e3);
                        }
                        i2++;
                        i3 = 2;
                        i = 3;
                    }
                    i3 = 2;
                    i = 3;
                }
            }
        }
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        if (str != null) {
            Message message3 = new Message();
            message3.what = 3;
            message3.arg1 = 2;
            Bundle bundle = new Bundle();
            bundle.putString("message", str);
            message3.setData(bundle);
            this.status.sendMessage(message3);
        } else {
            Message message4 = new Message();
            message4.what = 4;
            message4.arg1 = 2;
            this.status.sendMessage(message4);
        }
        return;
        array = this.packets.toArray();
        this.packets.clear();
        if (array.length != 0) {
        }
        i2++;
        i3 = 2;
        i = 3;
    }
}
