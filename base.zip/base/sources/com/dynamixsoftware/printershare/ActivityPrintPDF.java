package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Picture;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;
import com.dynamixsoftware.printershare.ActivityPrint.Page;
import com.dynamixsoftware.printershare.App.XPicture;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.util.Vector;

public class ActivityPrintPDF extends ActivityPrintDocuments {
    private static volatile boolean pdf_lib_loaded = false;
    private static final String pdf_render5_ver = "5.0.2";
    private static final String pdf_render6_ver = "6.0.2";
    private static final String pdf_render7_ver = "7.0.2";
    private static final String pdf_render_lib = "libpdfrenderJNI.so";
    private static final String pdf_render_pkg = "lib_pdfrender";
    private static final String pdf_render_ver = "3.5.6";
    /* access modifiers changed from: private */
    public boolean is_lollipop_and_up;
    /* access modifiers changed from: private */
    public boolean is_marshmallow_and_up;
    /* access modifiers changed from: private */
    public boolean is_nougat_and_up;
    private boolean is_o_and_up;
    /* access modifiers changed from: private */
    public File pdf_file = null;
    /* access modifiers changed from: private */
    public Vector<PdfPicture> pdf_pages;
    /* access modifiers changed from: private */
    public String pdf_password = null;
    /* access modifiers changed from: private */
    public Thread ut;
    /* access modifiers changed from: private */
    public Thread wt;

    class CheckRenderThread extends Thread {
        private Boolean first_check;

        public CheckRenderThread(Boolean bool) {
            this.first_check = bool;
        }

        public void run() {
            boolean z;
            ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintPDF.this.showProgress(ActivityPrintPDF.this.getResources().getString(R.string.label_processing));
                }
            });
            if (this.first_check == null) {
                z = true;
            } else {
                try {
                    z = ActivityPrintPDF.this.checkRender();
                } catch (Throwable th) {
                    th.printStackTrace();
                    App.reportThrowable(th);
                    z = false;
                }
            }
            if (!z) {
                ActivityPrintPDF.this.wt = null;
                if (!this.first_check.booleanValue()) {
                    ActivityPrintPDF.this.last_error = "Cannot install PDF Render library. An unknown error has occurred.";
                    ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintPDF.this.hideProgress();
                            ActivityPrintPDF.this.displayLastError(new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            });
                        }
                    });
                } else if (ActivityPrintPDF.this.is_lollipop_and_up) {
                    ActivityPrintPDF.this.wt = new InstallRenderThread();
                    ActivityPrintPDF.this.wt.start();
                } else {
                    ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintPDF.this.hideProgress();
                            if (!ActivityPrintPDF.this.isFinishing()) {
                                new Builder(ActivityPrintPDF.this).setIcon(R.drawable.icon_title).setTitle(R.string.dialog_user_action_title).setMessage(R.string.dialog_install_pdf_render_text).setPositiveButton(R.string.button_yes, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        ActivityPrintPDF.this.wt = new InstallRenderThread();
                                        ActivityPrintPDF.this.wt.start();
                                    }
                                }).setNegativeButton(R.string.button_no, new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                }).show();
                            }
                        }
                    });
                }
            } else {
                ActivityPrintPDF.this.wt = new ConvertPagesThread();
                ActivityPrintPDF.this.wt.start();
            }
        }
    }

    class ConvertPagesThread extends Thread {
        ConvertPagesThread() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:89:0x0265  */
        /* JADX WARNING: Removed duplicated region for block: B:90:0x026a  */
        /* JADX WARNING: Removed duplicated region for block: B:94:0x0274  */
        /* JADX WARNING: Removed duplicated region for block: B:95:0x027f  */
        public void run() {
            Intent intent;
            int i;
            int i2;
            ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintPDF.this.showProgress(ActivityPrintPDF.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityPrintPDF.this.last_error = null;
            try {
                char c = 0;
                if (ActivityPrintPDF.this.pdf_file == null) {
                    try {
                        intent = ActivityPrintPDF.this.getIntent();
                        try {
                            Uri data = "android.intent.action.SEND".equals(intent.getAction()) ? (Uri) intent.getExtras().get("android.intent.extra.STREAM") : intent.getData();
                            if (data != null) {
                                try {
                                    String path = data.getPath();
                                    int indexOf = !"file".equals(data.getScheme()) ? path.indexOf(App.ext_storage_root) : 0;
                                    if (indexOf >= 0) {
                                        ActivityPrintPDF.this.pdf_file = new File(path.substring(indexOf));
                                        if (!ActivityPrintPDF.this.pdf_file.isFile() || !ActivityPrintPDF.this.pdf_file.exists() || !ActivityPrintPDF.this.pdf_file.canRead()) {
                                            ActivityPrintPDF.this.pdf_file = null;
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    App.reportThrowable(e);
                                }
                                if (ActivityPrintPDF.this.pdf_file == null) {
                                    String type = intent.getType();
                                    if (type == null) {
                                        type = App.getMimeTypeByName(data.getPath());
                                    }
                                    ActivityPrintPDF activityPrintPDF = ActivityPrintPDF.this;
                                    File tempDir = App.getTempDir();
                                    StringBuilder sb = new StringBuilder();
                                    sb.append("printershare_temp_doc");
                                    sb.append(App.getExtByMimeType(type));
                                    activityPrintPDF.pdf_file = new File(tempDir, sb.toString());
                                    InputStream openInputStream = ActivityPrintPDF.this.getContentResolver().openInputStream(data);
                                    FileOutputStream fileOutputStream = new FileOutputStream(ActivityPrintPDF.this.pdf_file);
                                    byte[] bArr = new byte[4096];
                                    while (true) {
                                        int read = openInputStream.read(bArr);
                                        if (read == -1) {
                                            break;
                                        }
                                        fileOutputStream.write(bArr, 0, read);
                                    }
                                    fileOutputStream.close();
                                    openInputStream.close();
                                }
                            } else {
                                throw new Exception("File is not specified");
                            }
                        } catch (Exception e2) {
                            e = e2;
                            e.printStackTrace();
                            ActivityPrintPDF activityPrintPDF2 = ActivityPrintPDF.this;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Internal Error: ");
                            sb2.append(e.getMessage());
                            activityPrintPDF2.last_error = sb2.toString();
                            App.reportThrowable(e, intent != null ? intent.toString() : null);
                            if (ActivityPrintPDF.this.last_error != null) {
                            }
                            ActivityPrintPDF.this.wt = null;
                        }
                    } catch (Exception e3) {
                        e = e3;
                        intent = null;
                        e.printStackTrace();
                        ActivityPrintPDF activityPrintPDF22 = ActivityPrintPDF.this;
                        StringBuilder sb22 = new StringBuilder();
                        sb22.append("Internal Error: ");
                        sb22.append(e.getMessage());
                        activityPrintPDF22.last_error = sb22.toString();
                        App.reportThrowable(e, intent != null ? intent.toString() : null);
                        if (ActivityPrintPDF.this.last_error != null) {
                        }
                        ActivityPrintPDF.this.wt = null;
                    }
                }
                ActivityPrintPDF.this.pdf_pages.clear();
                if (ActivityPrintPDF.this.is_lollipop_and_up) {
                    i = PDFrender5.create(ActivityPrintPDF.this.pdf_file.getAbsolutePath(), ActivityPrintPDF.this.pdf_password);
                } else {
                    i = PDFrender.create(ActivityPrintPDF.this.pdf_file.getAbsolutePath(), ActivityPrintPDF.this.pdf_password, App.getFilesDirExt(ActivityPrintPDF.pdf_render_pkg).getAbsolutePath(), App.getTempDir().getAbsolutePath());
                }
                if (i == 4) {
                    ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintPDF.this.hideProgress();
                            LayoutInflater from = LayoutInflater.from(ActivityPrintPDF.this);
                            ActivityPrintPDF.this.view_dialog_authorization = from.inflate(R.layout.dialog_authorization, null);
                            ActivityPrintPDF.this.view_dialog_authorization.findViewById(R.id.login_label).setVisibility(8);
                            ActivityPrintPDF.this.view_dialog_authorization.findViewById(R.id.login_edit).setVisibility(8);
                            new Builder(ActivityPrintPDF.this).setIcon(R.drawable.icon_title).setTitle(R.string.label_password_required).setView(ActivityPrintPDF.this.view_dialog_authorization).setInverseBackgroundForced(true).setPositiveButton(R.string.button_ok, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    ActivityPrintPDF.this.pdf_password = ((EditText) ActivityPrintPDF.this.view_dialog_authorization.findViewById(R.id.password_edit)).getText().toString();
                                    ActivityPrintPDF.this.wt = new ConvertPagesThread();
                                    ActivityPrintPDF.this.wt.start();
                                }
                            }).setNegativeButton(R.string.button_cancel, new OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                }
                            }).create().show();
                        }
                    });
                    ActivityPrintPDF.this.wt = null;
                } else if (i == 0) {
                    if (ActivityPrintPDF.this.is_lollipop_and_up) {
                        i2 = PDFrender5.getPageCount();
                    } else {
                        i2 = PDFrender.getPageCount();
                    }
                    int i3 = 0;
                    while (i3 < i2) {
                        if (ActivityPrintPDF.this.is_lollipop_and_up) {
                            double[] dArr = new double[2];
                            PDFrender5.getPageSize(i3, dArr);
                            ActivityPrintPDF.this.pdf_pages.add(new PdfPicture(i3, (int) ((dArr[c] * 100.0d) / 72.0d), (int) ((dArr[1] * 100.0d) / 72.0d)));
                        } else {
                            int i4 = i3 + 1;
                            double[] pageSize = PDFrender.getPageSize(i4);
                            int i5 = (int) ((pageSize[0] * 100.0d) / 72.0d);
                            int i6 = (int) ((pageSize[1] * 100.0d) / 72.0d);
                            if (pageSize[2] > 0.0d) {
                                if (pageSize[2] < pageSize[0]) {
                                    i5 = (int) ((pageSize[2] * 100.0d) / 72.0d);
                                }
                            }
                            if (pageSize[3] > 0.0d && pageSize[3] < pageSize[1]) {
                                i6 = (int) ((pageSize[3] * 100.0d) / 72.0d);
                            }
                            if (pageSize[4] == 90.0d || pageSize[4] == 270.0d) {
                                int i7 = i6;
                                i6 = i5;
                                i5 = i7;
                            }
                            ActivityPrintPDF.this.pdf_pages.add(new PdfPicture(i4, i5, i6));
                        }
                        i3++;
                        c = 0;
                    }
                    if (ActivityPrintPDF.this.last_error != null) {
                        ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityPrintPDF.this.need_update_pages = true;
                                ActivityPrintPDF.this.update();
                            }
                        });
                    } else {
                        ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityPrintPDF.this.hideProgress();
                                ActivityPrintPDF.this.displayLastError(new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                });
                            }
                        });
                    }
                    ActivityPrintPDF.this.wt = null;
                } else {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("PDF Render error ");
                    sb3.append(i);
                    sb3.append(".");
                    throw new Exception(sb3.toString());
                }
            } catch (Exception e4) {
                e = e4;
                intent = null;
                e.printStackTrace();
                ActivityPrintPDF activityPrintPDF222 = ActivityPrintPDF.this;
                StringBuilder sb222 = new StringBuilder();
                sb222.append("Internal Error: ");
                sb222.append(e.getMessage());
                activityPrintPDF222.last_error = sb222.toString();
                App.reportThrowable(e, intent != null ? intent.toString() : null);
                if (ActivityPrintPDF.this.last_error != null) {
                }
                ActivityPrintPDF.this.wt = null;
            }
        }
    }

    class InstallRenderThread extends Thread {
        InstallRenderThread() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:69:0x0306  */
        /* JADX WARNING: Removed duplicated region for block: B:70:0x0311  */
        public void run() {
            String str = "/libpng.so";
            String str2 = "/system/";
            ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                public void run() {
                    ActivityPrintPDF.this.showProgress(ActivityPrintPDF.this.getResources().getString(R.string.label_processing));
                }
            });
            ActivityPrintPDF.this.last_error = null;
            try {
                boolean access$600 = ActivityPrintPDF.this.is_nougat_and_up;
                String str3 = ActivityPrintPDF.pdf_render_pkg;
                if (access$600) {
                    ActivityPrintPDF.this.installDrvLibPack(null, false, "lib_pdfrender|7.0.2|libpdfrenderJNI.so", true, 0, 0);
                    String str4 = App.getCPUABI(ActivityPrintPDF.this, true, false).indexOf("_64") < 0 ? "lib" : "lib64";
                    StringBuilder sb = new StringBuilder();
                    sb.append(str2);
                    sb.append(str4);
                    sb.append("/libpdfium.so");
                    File file = new File(sb.toString());
                    File file2 = new File(App.getFilesDirInt(str3), "libpdfium.so");
                    FileInputStream fileInputStream = new FileInputStream(file);
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    byte[] bArr = new byte[32768];
                    while (true) {
                        int read = fileInputStream.read(bArr);
                        if (read < 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                    }
                    fileOutputStream.close();
                    fileInputStream.close();
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(str2);
                    sb2.append(str4);
                    sb2.append("/libft2.so");
                    File file3 = new File(sb2.toString());
                    File file4 = new File(App.getFilesDirInt(str3), "libft2.so");
                    FileInputStream fileInputStream2 = new FileInputStream(file3);
                    FileOutputStream fileOutputStream2 = new FileOutputStream(file4);
                    while (true) {
                        int read2 = fileInputStream2.read(bArr);
                        if (read2 < 0) {
                            break;
                        }
                        fileOutputStream2.write(bArr, 0, read2);
                    }
                    fileOutputStream2.close();
                    fileInputStream2.close();
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(str2);
                    sb3.append(str4);
                    sb3.append(str);
                    File file5 = new File(sb3.toString());
                    File file6 = new File(App.getFilesDirInt(str3), "libpng.so");
                    FileInputStream fileInputStream3 = new FileInputStream(file5);
                    FileOutputStream fileOutputStream3 = new FileOutputStream(file6);
                    while (true) {
                        int read3 = fileInputStream3.read(bArr);
                        if (read3 < 0) {
                            break;
                        }
                        fileOutputStream3.write(bArr, 0, read3);
                    }
                    fileOutputStream3.close();
                    fileInputStream3.close();
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(str2);
                    sb4.append(str4);
                    sb4.append(str);
                    File file7 = new File(sb4.toString());
                    File file8 = new File(App.getFilesDirInt(str3), "libcutils.so");
                    FileInputStream fileInputStream4 = new FileInputStream(file7);
                    FileOutputStream fileOutputStream4 = new FileOutputStream(file8);
                    while (true) {
                        int read4 = fileInputStream4.read(bArr);
                        if (read4 < 0) {
                            break;
                        }
                        fileOutputStream4.write(bArr, 0, read4);
                    }
                    fileOutputStream4.close();
                    fileInputStream4.close();
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(str2);
                    sb5.append(str4);
                    sb5.append("/libc++.so");
                    File file9 = new File(sb5.toString());
                    File file10 = new File(App.getFilesDirInt(str3), "libc++.so");
                    FileInputStream fileInputStream5 = new FileInputStream(file9);
                    FileOutputStream fileOutputStream5 = new FileOutputStream(file10);
                    while (true) {
                        int read5 = fileInputStream5.read(bArr);
                        if (read5 < 0) {
                            break;
                        }
                        fileOutputStream5.write(bArr, 0, read5);
                    }
                    fileOutputStream5.close();
                    fileInputStream5.close();
                    ActivityPrintPDF.this.wt = null;
                    if (ActivityPrintPDF.this.last_error != null) {
                        ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityPrintPDF.this.wt = new CheckRenderThread(Boolean.valueOf(false));
                                ActivityPrintPDF.this.wt.start();
                            }
                        });
                    } else {
                        ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                            public void run() {
                                ActivityPrintPDF.this.hideProgress();
                                ActivityPrintPDF.this.displayLastError(new OnClickListener() {
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                });
                            }
                        });
                    }
                } else {
                    if (ActivityPrintPDF.this.is_marshmallow_and_up) {
                        ActivityPrintPDF.this.installDrvLibPack(null, false, "lib_pdfrender|6.0.2|libpdfrenderJNI.so", true, 0, 0);
                    } else if (ActivityPrintPDF.this.is_lollipop_and_up) {
                        ActivityPrintPDF.this.installDrvLibPack(null, false, "lib_pdfrender|5.0.2|libpdfrenderJNI.so", true, 0, 0);
                    } else {
                        ActivityPrintPDF.this.installDrvLibPack(null, false, "lib_pdfrender|3.5.6|libpdfrenderJNI.so", true, 0, 100);
                        File file11 = new File(App.getFilesDirInt(str3), ActivityPrintPDF.pdf_render_lib);
                        File file12 = new File("/system/lib/libskia.so");
                        String str5 = "rw";
                        if (!file12.exists()) {
                            file12 = new File("/system/lib/libsgl.so");
                            if (file12.exists()) {
                                int access$800 = ActivityPrintPDF.this.findCode(file11, new byte[]{108, 105, 98, 115, 107, 105, 97, 46, 115, 111});
                                if (access$800 != -1) {
                                    RandomAccessFile randomAccessFile = new RandomAccessFile(file11, str5);
                                    randomAccessFile.seek((long) (access$800 + 4));
                                    randomAccessFile.write(new byte[]{103, 108, 46, 115, 111, 0});
                                    randomAccessFile.close();
                                }
                            }
                        }
                        byte[] bytes = "_ZN15SkPictureRecord8clipPathERK6SkPathN8SkRegion2OpEb".getBytes();
                        if (ActivityPrintPDF.this.findCode(file12, bytes) == -1) {
                            int access$8002 = ActivityPrintPDF.this.findCode(file11, bytes);
                            if (access$8002 != -1) {
                                RandomAccessFile randomAccessFile2 = new RandomAccessFile(file11, str5);
                                randomAccessFile2.seek((long) ((access$8002 + bytes.length) - 1));
                                randomAccessFile2.write(0);
                                randomAccessFile2.close();
                            }
                        }
                        byte[] bytes2 = "_ZN8SkBitmap9setConfigENS_6ConfigEiij11SkAlphaType".getBytes();
                        if (ActivityPrintPDF.this.findCode(file12, bytes2) == -1) {
                            int access$8003 = ActivityPrintPDF.this.findCode(file11, bytes2);
                            if (access$8003 != -1) {
                                RandomAccessFile randomAccessFile3 = new RandomAccessFile(file11, str5);
                                randomAccessFile3.seek((long) ((bytes2.length + access$8003) - 13));
                                randomAccessFile3.write(0);
                                randomAccessFile3.close();
                            }
                            byte[] bytes3 = "_ZN8SkBitmap9setConfigENS_6ConfigEiij".getBytes();
                            if (ActivityPrintPDF.this.findCode(file12, bytes3) == -1 && access$8003 != -1) {
                                RandomAccessFile randomAccessFile4 = new RandomAccessFile(file11, str5);
                                randomAccessFile4.seek((long) ((access$8003 + bytes3.length) - 1));
                                randomAccessFile4.write(105);
                                randomAccessFile4.close();
                            }
                        }
                        byte[] bytes4 = "_ZN12SkColorTableC1EPKji11SkAlphaType".getBytes();
                        if (ActivityPrintPDF.this.findCode(file12, bytes4) == -1) {
                            int access$8004 = ActivityPrintPDF.this.findCode(file11, bytes4);
                            if (access$8004 != -1) {
                                RandomAccessFile randomAccessFile5 = new RandomAccessFile(file11, str5);
                                randomAccessFile5.seek((long) ((access$8004 + bytes4.length) - 13));
                                randomAccessFile5.write(0);
                                randomAccessFile5.close();
                            }
                        }
                    }
                    ActivityPrintPDF.this.wt = null;
                    if (ActivityPrintPDF.this.last_error != null) {
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                ActivityPrintPDF activityPrintPDF = ActivityPrintPDF.this;
                StringBuilder sb6 = new StringBuilder();
                sb6.append("Internal Error: ");
                sb6.append(e.getMessage());
                activityPrintPDF.last_error = sb6.toString();
                App.reportThrowable(e);
            }
        }
    }

    class PdfPicture extends XPicture {
        int height;
        boolean landscape;
        int num;
        int width;

        public PdfPicture(int i, int i2, int i3) {
            this.num = i;
            this.width = i2;
            this.height = i3;
            this.landscape = i2 > i3;
        }

        public int getWidth() {
            if (this.landscape ^ (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height)) {
                return (ActivityPrintPDF.this.paper.height * 100) / 254;
            }
            return (ActivityPrintPDF.this.paper.width * 100) / 254;
        }

        public int getHeight() {
            if (this.landscape ^ (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height)) {
                return (ActivityPrintPDF.this.paper.width * 100) / 254;
            }
            return (ActivityPrintPDF.this.paper.height * 100) / 254;
        }

        public void draw(Canvas canvas, boolean z) {
            canvas.save();
            try {
                canvas.drawColor(-1);
                int i = (ActivityPrintPDF.this.paper.width * 100) / 254;
                int i2 = (ActivityPrintPDF.this.paper.height * 100) / 254;
                int i3 = (((ActivityPrintPDF.this.paper.width - ActivityPrintPDF.this.paper.margin_left) - ActivityPrintPDF.this.paper.margin_right) * 100) / 254;
                int i4 = (((ActivityPrintPDF.this.paper.height - ActivityPrintPDF.this.paper.margin_top) - ActivityPrintPDF.this.paper.margin_bottom) * 100) / 254;
                if (ActivityPrintPDF.this.print_size == 2) {
                    i = i3;
                    i2 = i4;
                }
                int i5 = 1;
                if (this.landscape ^ (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height)) {
                    int i6 = i2;
                    i2 = i;
                    i = i6;
                    int i7 = i4;
                    i4 = i3;
                    i3 = i7;
                }
                if (!(this.landscape ^ (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height))) {
                    canvas.clipRect(new Rect((ActivityPrintPDF.this.paper.margin_left * 100) / 254, (ActivityPrintPDF.this.paper.margin_top * 100) / 254, ((ActivityPrintPDF.this.paper.margin_left * 100) / 254) + i3, ((ActivityPrintPDF.this.paper.margin_top * 100) / 254) + i4));
                } else if (ActivityPrintPDF.this.paper.isLandscape270) {
                    if (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height) {
                        canvas.clipRect(new Rect((ActivityPrintPDF.this.paper.margin_top * 100) / 254, (ActivityPrintPDF.this.paper.margin_right * 100) / 254, ((ActivityPrintPDF.this.paper.margin_top * 100) / 254) + i3, ((ActivityPrintPDF.this.paper.margin_right * 100) / 254) + i4));
                    } else {
                        canvas.clipRect(new Rect((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254, (ActivityPrintPDF.this.paper.margin_left * 100) / 254, ((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254) + i3, ((ActivityPrintPDF.this.paper.margin_left * 100) / 254) + i4));
                    }
                } else if (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height) {
                    canvas.clipRect(new Rect((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254, (ActivityPrintPDF.this.paper.margin_left * 100) / 254, ((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254) + i3, ((ActivityPrintPDF.this.paper.margin_left * 100) / 254) + i4));
                } else {
                    canvas.clipRect(new Rect((ActivityPrintPDF.this.paper.margin_top * 100) / 254, (ActivityPrintPDF.this.paper.margin_right * 100) / 254, ((ActivityPrintPDF.this.paper.margin_top * 100) / 254) + i3, ((ActivityPrintPDF.this.paper.margin_right * 100) / 254) + i4));
                }
                int i8 = this.width;
                int i9 = this.height;
                if (ActivityPrintPDF.this.print_size == 2) {
                    if (!(this.landscape ^ (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height))) {
                        canvas.translate((float) ((ActivityPrintPDF.this.paper.margin_left * 100) / 254), (float) ((ActivityPrintPDF.this.paper.margin_top * 100) / 254));
                    } else if (ActivityPrintPDF.this.paper.isLandscape270) {
                        if (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height) {
                            canvas.translate((float) ((ActivityPrintPDF.this.paper.margin_top * 100) / 254), (float) ((ActivityPrintPDF.this.paper.margin_right * 100) / 254));
                        } else {
                            canvas.translate((float) ((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254), (float) ((ActivityPrintPDF.this.paper.margin_left * 100) / 254));
                        }
                    } else if (ActivityPrintPDF.this.paper.width > ActivityPrintPDF.this.paper.height) {
                        canvas.translate((float) ((ActivityPrintPDF.this.paper.margin_bottom * 100) / 254), (float) ((ActivityPrintPDF.this.paper.margin_left * 100) / 254));
                    } else {
                        canvas.translate((float) ((ActivityPrintPDF.this.paper.margin_top * 100) / 254), (float) ((ActivityPrintPDF.this.paper.margin_right * 100) / 254));
                    }
                }
                if (ActivityPrintPDF.this.print_size > 0) {
                    RectF rectF = new RectF(0.0f, 0.0f, (float) i, (float) ((i * i9) / i8));
                    float f = (float) i2;
                    RectF rectF2 = new RectF(0.0f, 0.0f, (float) ((i8 * i2) / i9), f);
                    if (rectF.height() > f) {
                        rectF = rectF2;
                    }
                    canvas.scale(rectF.width() / ((float) i8), rectF.height() / ((float) i9));
                }
                canvas.clipRect(new Rect(0, 0, this.width, this.height));
                if (ActivityPrintPDF.this.is_lollipop_and_up) {
                    Field declaredField = Canvas.class.getDeclaredField("mBitmap");
                    declaredField.setAccessible(true);
                    Bitmap bitmap = (Bitmap) declaredField.get(canvas);
                    if (bitmap != null) {
                        Matrix matrix = canvas.getMatrix();
                        int[] iArr = new int[4];
                        if (canvas.getClipBounds(new Rect())) {
                            RectF rectF3 = new RectF(canvas.getClipBounds());
                            matrix.mapRect(rectF3);
                            iArr[0] = (int) rectF3.left;
                            iArr[1] = (int) rectF3.top;
                            iArr[2] = (int) rectF3.right;
                            iArr[3] = ((int) rectF3.bottom) + 1;
                        } else {
                            iArr[2] = bitmap.getWidth();
                            iArr[3] = bitmap.getHeight();
                        }
                        float[] fArr = new float[9];
                        matrix.preScale(1.3888888f, 1.3888888f);
                        matrix.getValues(fArr);
                        float[] fArr2 = {fArr[0], fArr[3], fArr[1], fArr[4], fArr[2], fArr[5]};
                        if (!z) {
                            i5 = 1879048193;
                        }
                        int drawPage = PDFrender5.drawPage(this.num, iArr, fArr2, i5, bitmap);
                        if (drawPage != 0) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("PDF Render error ");
                            sb.append(drawPage);
                            sb.append(".");
                            throw new Exception(sb.toString());
                        }
                    } else {
                        throw new Exception("Canvas type is not supported");
                    }
                } else {
                    Field declaredField2 = Canvas.class.getDeclaredField("mNativeCanvas");
                    declaredField2.setAccessible(true);
                    PDFrender.drawPage(this.num, declaredField2.getInt(canvas));
                }
            } catch (Throwable th) {
                canvas.restore();
                throw th;
            }
            canvas.restore();
        }
    }

    public void onCreate(Bundle bundle) {
        String str = "SDK_INT";
        super.onCreate(bundle);
        try {
            if (VERSION.class.getField(str).getInt(null) >= 21) {
                this.is_lollipop_and_up = true;
            }
            if (VERSION.class.getField(str).getInt(null) >= 23) {
                this.is_marshmallow_and_up = true;
            }
            if (VERSION.class.getField(str).getInt(null) >= 24) {
                this.is_o_and_up = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
    }

    /* access modifiers changed from: protected */
    public void destroyLibViewer() {
        if (this.is_o_and_up) {
            super.destroyLibViewer();
            return;
        }
        if (pdf_lib_loaded) {
            if (this.is_lollipop_and_up) {
                PDFrender5.destroy();
            } else {
                PDFrender.destroy();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void showPreview(final Page page) {
        if (this.is_lollipop_and_up) {
            super.showPreview(page);
            return;
        }
        showProgress(getResources().getString(R.string.label_processing));
        AnonymousClass1 r0 = new Thread() {
            public void run() {
                ActivityPrint.pp = page.getPicture();
                Intent intent = new Intent();
                intent.setClass(ActivityPrintPDF.this, ActivityPreview.class);
                ActivityPrintPDF.this.startActivityForResult(intent, 10);
                ActivityPrintPDF.this.runOnUiThread(new Runnable() {
                    public void run() {
                        ActivityPrintPDF.this.hideProgress();
                    }
                });
                ActivityPrintPDF.this.ut = null;
            }
        };
        this.ut = r0;
        r0.start();
    }

    /* access modifiers changed from: protected */
    public void updatePages() {
        if (this.is_o_and_up) {
            super.updatePages();
            return;
        }
        if (this.pdf_pages == null) {
            this.pdf_pages = new Vector<>();
            this.need_update_pages = false;
            CheckRenderThread checkRenderThread = new CheckRenderThread(Boolean.valueOf(true));
            this.wt = checkRenderThread;
            checkRenderThread.start();
        }
        if (this.need_update_pages && this.paper.roll && this.pdf_pages.size() > 0) {
            PdfPicture pdfPicture = (PdfPicture) this.pdf_pages.get(0);
            if (this.print_size == 2) {
                if (pdfPicture.width > pdfPicture.height) {
                    this.paper.height = ((pdfPicture.width * ((this.paper.width - this.paper.margin_left) - this.paper.margin_right)) / pdfPicture.height) + this.paper.margin_top + this.paper.margin_bottom;
                } else {
                    this.paper.height = ((pdfPicture.height * ((this.paper.width - this.paper.margin_left) - this.paper.margin_right)) / pdfPicture.width) + this.paper.margin_top + this.paper.margin_bottom;
                }
            } else if (pdfPicture.width > pdfPicture.height) {
                this.paper.height = (pdfPicture.width * this.paper.width) / pdfPicture.height;
            } else {
                this.paper.height = (pdfPicture.height * this.paper.width) / pdfPicture.width;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        if (this.is_o_and_up) {
            super.createPages();
            return;
        }
        this.pages = new Vector();
        for (int i = 0; i < this.pdf_pages.size(); i++) {
            this.pages.add(new Page((Picture) this.pdf_pages.get(i)) {
                public Picture getPicture() {
                    PdfPicture pdfPicture = (PdfPicture) super.getPicture();
                    if (ActivityPrintPDF.this.is_lollipop_and_up) {
                        PDFrender5.drawPage(pdfPicture.num, null, null, 0, null);
                    } else {
                        PDFrender.drawPage(pdfPicture.num, 0);
                    }
                    return pdfPicture;
                }
            });
        }
    }

    /* access modifiers changed from: private */
    public int findCode(File file, byte[] bArr) throws Exception {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file), 4096);
        int i = 0;
        int i2 = 0;
        int i3 = -1;
        while (true) {
            int read = bufferedInputStream.read();
            if (read == -1) {
                break;
            }
            if (bArr[i] == read) {
                if (i == 0) {
                    i3 = i2;
                }
                i++;
                if (i == bArr.length) {
                    break;
                }
            } else {
                i = 0;
                i3 = -1;
            }
            i2++;
        }
        bufferedInputStream.close();
        return i3;
    }

    /* access modifiers changed from: protected */
    public boolean checkRender() throws Exception {
        int i;
        if (this.is_o_and_up) {
            return super.checkRender();
        }
        boolean z = this.is_nougat_and_up;
        String str = "";
        String str2 = pdf_render_pkg;
        if (z) {
            if (!pdf_render7_ver.equals(this.prefs.getString(str2, str))) {
                return false;
            }
        } else if (this.is_marshmallow_and_up) {
            if (!pdf_render6_ver.equals(this.prefs.getString(str2, str))) {
                return false;
            }
        } else if (this.is_lollipop_and_up) {
            if (!pdf_render5_ver.equals(this.prefs.getString(str2, str))) {
                return false;
            }
        } else {
            if (!pdf_render_ver.equals(this.prefs.getString(str2, str))) {
                return false;
            }
        }
        File filesDirInt = App.getFilesDirInt(str2);
        if (!pdf_lib_loaded) {
            File file = new File(filesDirInt, pdf_render_lib);
            if (!file.exists()) {
                return false;
            }
            if (this.is_nougat_and_up) {
                System.load(new File(filesDirInt, "libc++.so").getAbsolutePath());
                System.load(new File(filesDirInt, "libpng.so").getAbsolutePath());
                System.load(new File(filesDirInt, "libcutils.so").getAbsolutePath());
                System.load(new File(filesDirInt, "libft2.so").getAbsolutePath());
                System.load(new File(filesDirInt, "libpdfium.so").getAbsolutePath());
            }
            System.load(file.getAbsolutePath());
            pdf_lib_loaded = true;
        }
        if (this.is_lollipop_and_up) {
            i = PDFrender5.create(null, null);
        } else {
            i = PDFrender.create(null, null, App.getFilesDirExt(str2).getAbsolutePath(), App.getTempDir().getAbsolutePath());
            if (i == 100) {
                return false;
            }
        }
        if (i == 0) {
            return true;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("PDF Render error ");
        sb.append(i);
        sb.append(".");
        throw new Exception(sb.toString());
    }
}
