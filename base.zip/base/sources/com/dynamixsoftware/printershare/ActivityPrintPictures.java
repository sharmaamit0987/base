package com.dynamixsoftware.printershare;

import android.app.AlertDialog.Builder;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Picture;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.ContextMenu;
import android.view.MenuItem;
import com.dynamixsoftware.printershare.ActivityPrint.Page;
import com.dynamixsoftware.printershare.mdns.DnsConstants;
import com.flurry.android.FlurryAgent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

public class ActivityPrintPictures extends ActivityPrint {
    protected int align = 1;
    private CharSequence[] alignOptions;
    /* access modifiers changed from: private */
    public ArrayList<ImgDat> data = new ArrayList<>();
    private boolean fp_mode;
    private boolean is_jelly_bean = false;
    protected int scaling = 0;
    private CharSequence[] scalingOptions;
    /* access modifiers changed from: private */
    public int sel_align;
    /* access modifiers changed from: private */
    public int sel_scaling;
    /* access modifiers changed from: private */
    public int sel_size;
    protected int size = 3;
    private CharSequence[] sizeOptions;
    private double[] sizeOptionsWH = {0.0d, 0.0d, 0.0d, 0.0d, 3.5d, 5.0d, 4.0d, 6.0d, 5.0d, 7.0d, 8.0d, 10.0d, 8.0d, 12.0d, 11.0d, 14.0d};

    static final class ImgDat {
        File dat;
        Rect size;
        File tmp;
        Uri uri;

        public ImgDat(Uri uri2) {
            this.uri = uri2;
        }

        public ImgDat(File file) {
            this.dat = file;
        }

        public void prepare(Context context) {
            if (this.dat == null) {
                try {
                    String scheme = this.uri.getScheme();
                    if (!"http".equals(scheme)) {
                        if (!"https".equals(scheme)) {
                            if ("file".equals(scheme)) {
                                this.dat = new File(this.uri.getPath());
                            }
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(App.getTempDir());
                    sb.append("/img_");
                    sb.append(Integer.toHexString(this.uri.hashCode()));
                    sb.append(".tmp");
                    this.tmp = new File(sb.toString());
                    InputStream inputStream = new URL(this.uri.toString()).openConnection().getInputStream();
                    FileOutputStream fileOutputStream = new FileOutputStream(this.dat);
                    byte[] bArr = new byte[4096];
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read == -1) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                    }
                    inputStream.close();
                    fileOutputStream.close();
                    this.dat = this.tmp;
                } catch (IOException e) {
                    e.printStackTrace();
                    App.reportThrowable(e);
                }
            }
            try {
                Options options = new Options();
                options.inJustDecodeBounds = true;
                InputStream fileInputStream = this.dat != null ? new FileInputStream(this.dat) : context.getContentResolver().openInputStream(this.uri);
                if (fileInputStream != null) {
                    BitmapFactory.decodeStream(fileInputStream, null, options);
                    this.size = new Rect(0, 0, options.outWidth, options.outHeight);
                    fileInputStream.close();
                }
            } catch (IOException e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }
    }

    class PicturePage extends Page {
        private ImgDat imgDat;

        PicturePage(ImgDat imgDat2) {
            super(ActivityPrintPictures.this.orientation == 2 || (ActivityPrintPictures.this.orientation == 0 && imgDat2.size != null && imgDat2.size.width() > imgDat2.size.height()));
            this.imgDat = imgDat2;
        }

        public Picture getPicture() {
            final Bitmap access$400 = ActivityPrintPictures.this.decodeBitmap(this.imgDat);
            AnonymousClass1 r1 = new Picture() {
                Bitmap cbmp = access$400;

                /* access modifiers changed from: protected */
                public void finalize() throws Throwable {
                    super.finalize();
                    if (this.cbmp != null) {
                        this.cbmp = null;
                    }
                }
            };
            ActivityPrintPictures.this.drawBitmap(r1, access$400);
            return r1;
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        boolean z = true;
        try {
            if (VERSION.class.getField("SDK_INT").getInt(null) >= 18) {
                this.is_jelly_bean = true;
            }
        } catch (NoSuchFieldException unused) {
        } catch (Exception e) {
            e.printStackTrace();
            App.reportThrowable(e);
        }
        this.sizeOptions = new CharSequence[]{getResources().getString(R.string.label_picture_size_original), getResources().getString(R.string.label_picture_size_fit), "3½\"×5\" (9×13 cm)", "4\"×6\" (10×15 cm)", "5\"×7\" (13×18 cm)", "8\"×10\" (20×25 cm)", "8\"×12\" (20×30 cm)", "11\"×14\" (28×36 cm)"};
        SharedPreferences sharedPreferences = this.prefs;
        StringBuilder sb = new StringBuilder();
        sb.append(getActivityClassName());
        sb.append("#size");
        this.size = sharedPreferences.getInt(sb.toString(), this.size);
        this.scalingOptions = new CharSequence[]{getResources().getString(R.string.label_picture_scaling_crop), getResources().getString(R.string.label_picture_scaling_inside)};
        SharedPreferences sharedPreferences2 = this.prefs;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getActivityClassName());
        sb2.append("#scaling");
        this.scaling = sharedPreferences2.getInt(sb2.toString(), this.scaling);
        this.alignOptions = new CharSequence[]{getResources().getString(R.string.label_picture_align_center), getResources().getString(R.string.label_picture_align_top_left), getResources().getString(R.string.label_picture_align_top_right), getResources().getString(R.string.label_picture_align_bottom_left), getResources().getString(R.string.label_picture_align_bottom_right)};
        SharedPreferences sharedPreferences3 = this.prefs;
        StringBuilder sb3 = new StringBuilder();
        sb3.append(getActivityClassName());
        sb3.append("#align");
        this.align = sharedPreferences3.getInt(sb3.toString(), this.align);
        Intent intent = getIntent();
        if (intent.getAction() == null) {
            z = false;
        }
        prepareDataFromIntent(intent, z);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 444555 || iArr == null || iArr.length <= 0 || iArr[0] != 0) {
            setResult(0);
            finish();
            return;
        }
        this.need_update_pages = true;
        update();
    }

    /* JADX WARNING: Removed duplicated region for block: B:56:0x0112 A[SYNTHETIC, Splitter:B:56:0x0112] */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0186  */
    private void prepareDataFromIntent(final Intent intent, boolean z) {
        boolean z2;
        String str = "file";
        String action = intent.getAction();
        String str2 = "android.intent.extra.STREAM";
        boolean z3 = false;
        if ("android.intent.action.SEND".equals(action)) {
            Uri uri = (Uri) intent.getExtras().get(str2);
            if (uri != null) {
                this.data.add(new ImgDat(uri));
                z2 = true;
                if (z2) {
                    try {
                        Iterator it = this.data.iterator();
                        while (it.hasNext()) {
                            ImgDat imgDat = (ImgDat) it.next();
                            if (imgDat.uri != null) {
                                if ((str.equals(imgDat.uri.getScheme()) && !new File(imgDat.uri.getPath()).canRead()) || (!str.equals(imgDat.uri.getScheme()) && checkCallingOrSelfUriPermission(imgDat.uri, 1) != 0)) {
                                    try {
                                        if (VERSION.class.getField("SDK_INT").getInt(null) >= 23) {
                                            z3 = true;
                                        }
                                    } catch (NoSuchFieldException unused) {
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        App.reportThrowable(e);
                                    }
                                    if (z3) {
                                        new Object() {
                                            {
                                                String str = "android.permission.READ_EXTERNAL_STORAGE";
                                                if (ActivityPrintPictures.this.checkSelfPermission(str) != 0) {
                                                    ActivityPrintPictures.this.need_update_pages = false;
                                                    ActivityPrintPictures.this.requestPermissions(new String[]{str}, 444555);
                                                }
                                            }
                                        };
                                        return;
                                    }
                                    return;
                                }
                            }
                        }
                        return;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        App.reportThrowable(e2);
                        return;
                    }
                } else if (z) {
                    try {
                        Hashtable hashtable = new Hashtable();
                        hashtable.put("intent", intent.toString());
                        FlurryAgent.logEvent("unknown_intent_images", (Map<String, String>) hashtable);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                        App.reportThrowable(e3);
                    }
                    setResult(0);
                    finish();
                    return;
                } else {
                    return;
                }
            }
        } else if ("android.intent.action.SEND_MULTIPLE".equals(action)) {
            ArrayList parcelableArrayListExtra = intent.getParcelableArrayListExtra(str2);
            if (parcelableArrayListExtra != null) {
                Iterator it2 = parcelableArrayListExtra.iterator();
                while (it2.hasNext()) {
                    this.data.add(new ImgDat((Uri) ((Parcelable) it2.next())));
                }
                z2 = true;
                if (z2) {
                }
            }
        } else if (action == null || !action.startsWith("com.sec.android.app.mobileprint")) {
            final boolean[] zArr = new boolean[1];
            if (this.is_jelly_bean) {
                try {
                    new Object() {
                        {
                            if (intent.getClipData() != null) {
                                ClipData clipData = intent.getClipData();
                                for (int i = 0; i < clipData.getItemCount(); i++) {
                                    ActivityPrintPictures.this.data.add(new ImgDat(clipData.getItemAt(i).getUri()));
                                    zArr[0] = true;
                                }
                            }
                        }
                    };
                } catch (Exception e4) {
                    e4.printStackTrace();
                    App.reportThrowable(e4);
                }
            }
            if (!zArr[0]) {
                Uri data2 = intent.getData();
                if (data2 != null) {
                    this.data.add(new ImgDat(data2));
                }
            }
            z2 = true;
            if (z2) {
            }
        } else {
            this.orientation = 0;
            this.size = 1;
            Uri uri2 = (Uri) intent.getParcelableExtra(str2);
            if (uri2 != null) {
                try {
                    String decode = URLDecoder.decode(uri2.toString(), "UTF-8");
                    if (decode.startsWith("file:")) {
                        decode = decode.substring(5);
                    }
                    int i = 0;
                    while (decode.charAt(i) == '/') {
                        i++;
                    }
                    if (i > 0) {
                        File file = new File(decode.substring(i - 1));
                        if (file.isDirectory()) {
                            this.fp_mode = true;
                            File[] listFiles = file.listFiles();
                            if (listFiles != null) {
                                for (int length = listFiles.length - 1; length >= 0; length--) {
                                    if (listFiles[length].isFile()) {
                                        this.data.add(new ImgDat(listFiles[length]));
                                    }
                                }
                            }
                        } else {
                            this.data.add(new ImgDat(file));
                        }
                    } else {
                        this.data.add(new ImgDat(uri2));
                    }
                } catch (Exception e5) {
                    e5.printStackTrace();
                    App.reportThrowable(e5, uri2.toString());
                }
                z2 = true;
                if (z2) {
                }
            }
        }
        z2 = false;
        if (z2) {
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        if (getIntent().getAction() == null && this.data.size() == 0) {
            Intent intent = new Intent();
            if (this.is_jelly_bean) {
                intent.setAction("android.intent.action.GET_CONTENT");
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
            } else {
                intent.setAction("android.intent.action.PICK");
            }
            intent.setType("image/*");
            if (getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                startActivityForResult(intent, 3);
            } else {
                startActivityForResult(Intent.createChooser(intent, null), 3);
            }
            this.need_update_pages = false;
        }
        super.onResume();
    }

    public void onDestroy() {
        super.onDestroy();
        Iterator it = this.data.iterator();
        while (it.hasNext()) {
            ImgDat imgDat = (ImgDat) it.next();
            if (imgDat.tmp != null) {
                imgDat.tmp.delete();
            }
        }
        String stringExtra = getIntent().getStringExtra("temp_file");
        if (stringExtra != null && stringExtra.indexOf("printershare_temp_") > 0) {
            new File(stringExtra).delete();
        }
    }

    public void onCreateOptionsMenu(ContextMenu contextMenu) {
        if (!this.fp_mode) {
            contextMenu.add(0, 100, 0, R.string.label_picture_size);
            contextMenu.add(0, DnsConstants.TYPE_UID, 0, R.string.label_picture_scaling);
            contextMenu.add(0, DnsConstants.TYPE_GID, 0, R.string.label_picture_align);
        }
        contextMenu.add(0, 30, 0, R.string.label_page_margins);
        if (!this.fp_mode) {
            contextMenu.add(0, 23, 0, R.string.label_page_orientation);
        }
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case DnsConstants.TYPE_UINFO /*100*/:
                Builder singleChoiceItems = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_picture_size).setPositiveButton(R.string.button_ok, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures activityPrintPictures = ActivityPrintPictures.this;
                        activityPrintPictures.size = activityPrintPictures.sel_size;
                        Editor edit = ActivityPrintPictures.this.prefs.edit();
                        StringBuilder sb = new StringBuilder();
                        sb.append(ActivityPrintPictures.this.getActivityClassName());
                        sb.append("#size");
                        edit.putInt(sb.toString(), ActivityPrintPictures.this.size);
                        edit.commit();
                        ActivityPrintPictures.this.need_update_pages = true;
                        ActivityPrintPictures.this.update();
                    }
                }).setNegativeButton(R.string.button_cancel, null).setSingleChoiceItems(this.sizeOptions, this.size, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures.this.sel_size = i;
                    }
                });
                this.sel_size = this.size;
                singleChoiceItems.show();
                return true;
            case DnsConstants.TYPE_UID /*101*/:
                Builder singleChoiceItems2 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_picture_scaling).setPositiveButton(R.string.button_ok, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures activityPrintPictures = ActivityPrintPictures.this;
                        activityPrintPictures.scaling = activityPrintPictures.sel_scaling;
                        Editor edit = ActivityPrintPictures.this.prefs.edit();
                        StringBuilder sb = new StringBuilder();
                        sb.append(ActivityPrintPictures.this.getActivityClassName());
                        sb.append("#scaling");
                        edit.putInt(sb.toString(), ActivityPrintPictures.this.scaling);
                        edit.commit();
                        ActivityPrintPictures.this.need_update_pages = true;
                        ActivityPrintPictures.this.update();
                    }
                }).setNegativeButton(R.string.button_cancel, null).setSingleChoiceItems(this.scalingOptions, this.scaling, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures.this.sel_scaling = i;
                    }
                });
                this.sel_scaling = this.scaling;
                singleChoiceItems2.show();
                return true;
            case DnsConstants.TYPE_GID /*102*/:
                Builder singleChoiceItems3 = new Builder(this).setIcon(R.drawable.icon_title).setTitle(R.string.label_picture_align).setPositiveButton(R.string.button_ok, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures activityPrintPictures = ActivityPrintPictures.this;
                        activityPrintPictures.align = activityPrintPictures.sel_align;
                        Editor edit = ActivityPrintPictures.this.prefs.edit();
                        StringBuilder sb = new StringBuilder();
                        sb.append(ActivityPrintPictures.this.getActivityClassName());
                        sb.append("#align");
                        edit.putInt(sb.toString(), ActivityPrintPictures.this.align);
                        edit.commit();
                        ActivityPrintPictures.this.need_update_pages = true;
                        ActivityPrintPictures.this.update();
                    }
                }).setNegativeButton(R.string.button_cancel, null).setSingleChoiceItems(this.alignOptions, this.align, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityPrintPictures.this.sel_align = i;
                    }
                });
                this.sel_align = this.align;
                singleChoiceItems3.show();
                return true;
            default:
                return super.onMenuItemSelected(i, menuItem);
        }
    }

    /* access modifiers changed from: protected */
    public void createPages() {
        if (this.data.size() != 0) {
            this.pages = new Vector();
            int i = 0;
            for (int i2 = 0; i2 < this.data.size(); i2++) {
                ImgDat imgDat = (ImgDat) this.data.get(i2);
                if (imgDat.size == null) {
                    imgDat.prepare(this);
                }
                if (this.pages == null) {
                    break;
                }
                this.pages.add(new PicturePage(imgDat));
                final int size2 = (i2 * 100) / this.data.size();
                if (size2 > i) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ActivityPrintPictures activityPrintPictures = ActivityPrintPictures.this;
                            String string = activityPrintPictures.getResources().getString(R.string.label_processing_progress);
                            StringBuilder sb = new StringBuilder();
                            sb.append(size2);
                            sb.append("%");
                            activityPrintPictures.showProgress(String.format(string, new Object[]{sb.toString()}));
                        }
                    });
                    i = size2;
                }
            }
        }
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0114  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x0163  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0168  */
    public void drawBitmap(Picture picture, Bitmap bitmap) {
        int i;
        int i2;
        int i3;
        Picture picture2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        Bitmap bitmap2 = bitmap;
        int i19 = this.paper.width;
        int i20 = this.paper.height;
        int i21 = (this.paper.width < this.paper.height ? this.paper.width : this.paper.height) / 15;
        if (this.margins == 0) {
            i21 = 0;
        } else if (this.margins == 1) {
            i21 /= 2;
        } else if (this.margins == 3) {
            i21 = (i21 * 3) / 2;
        }
        int i22 = this.paper.margin_left > i21 ? this.paper.margin_left : i21;
        int i23 = this.paper.margin_right > i21 ? this.paper.margin_right : i21;
        int i24 = this.paper.margin_top > i21 ? this.paper.margin_top : i21;
        if (this.paper.margin_bottom > i21) {
            i21 = this.paper.margin_bottom;
        }
        if (bitmap2 != null) {
            i3 = bitmap.getWidth();
            i2 = bitmap.getHeight();
            if ((this.paper.width > this.paper.height) ^ (this.orientation == 2 || (this.orientation == 0 && i3 > i2))) {
                if (!this.paper.isLandscape270 ? this.paper.width <= this.paper.height : this.paper.width > this.paper.height) {
                    picture2 = picture;
                    int i25 = i20;
                    i20 = i19;
                    i19 = i25;
                    i16 = i23;
                    i17 = i;
                    i = i22;
                    i18 = i24;
                } else {
                    picture2 = picture;
                    int i26 = i20;
                    i20 = i19;
                    i19 = i26;
                    i16 = i22;
                    i18 = i;
                    i = i23;
                    i17 = i24;
                }
                i24 = i16;
            } else {
                picture2 = picture;
            }
        } else {
            picture2 = picture;
            i3 = 0;
            i2 = 0;
        }
        Canvas beginRecording = picture2.beginRecording(i19, i20);
        beginRecording.drawColor(-1);
        if (bitmap2 != null) {
            int i27 = this.size;
            if (i27 == 0) {
                i14 = (i3 * 254) / 96;
                i15 = (i2 * 254) / 96;
            } else if (i27 == 1) {
                i14 = i19 - (i22 + i23);
                i15 = i20 - (i24 + i);
            } else {
                double[] dArr = this.sizeOptionsWH;
                i6 = (int) (dArr[i27 * 2] * 254.0d);
                i5 = i23;
                i4 = (int) (dArr[(i27 * 2) + 1] * 254.0d);
                if (i3 > i2) {
                    int i28 = i4;
                    i4 = i6;
                    i6 = i28;
                }
                if (!this.fp_mode) {
                    if (i6 > i4) {
                        i4 = ((i19 - (i22 + i5)) * i2) / i3;
                    } else {
                        i6 = ((i20 - (i24 + i)) * i3) / i2;
                    }
                    i11 = i22;
                    i7 = i5;
                    i10 = i24;
                    i9 = 0;
                    i8 = 0;
                } else {
                    if (this.scaling == 1) {
                        int i29 = (i2 * i6) / i3;
                        if (i29 < i4) {
                            i4 = i29;
                        } else {
                            i6 = (i3 * i4) / i2;
                        }
                        i9 = 0;
                    } else {
                        int i30 = (i2 * i6) / i3;
                        if (i30 < i4) {
                            i9 = (((((i3 * i4) / i2) - i6) * i2) / i4) / 2;
                            i3 -= i9 * 2;
                        } else {
                            int i31 = (((i30 - i4) * i3) / i6) / 2;
                            i2 -= i31 * 2;
                            i8 = i31;
                            i9 = 0;
                            i12 = this.align;
                            if (i12 != 1) {
                                i11 = i22;
                            } else if (i12 == 2) {
                                i11 = (i19 - i5) - i6;
                            } else {
                                if (i12 == 3) {
                                    i10 = (i20 - i) - i4;
                                    i13 = i22;
                                } else if (i12 == 4) {
                                    i13 = (i19 - i5) - i6;
                                    i10 = (i20 - i) - i4;
                                } else {
                                    i13 = (((i19 - (i22 + i5)) / 2) + i22) - (i6 / 2);
                                    i10 = (i24 + ((i20 - (i24 + i)) / 2)) - (i4 / 2);
                                }
                                i7 = i5;
                            }
                            i7 = i5;
                            i10 = i24;
                        }
                    }
                    i8 = 0;
                    i12 = this.align;
                    if (i12 != 1) {
                    }
                    i7 = i5;
                    i10 = i24;
                }
                int i32 = i22;
                beginRecording.drawBitmap(bitmap2, new Rect(i9, i8, i3 + i9, i2 + i8), new Rect(i11, i10, i6 + i11, i4 + i10), App.newPaint());
                Paint newPaint = App.newPaint();
                newPaint.setColor(-1);
                newPaint.setStyle(Style.FILL);
                beginRecording.drawRect(new Rect(0, 0, i19, i24), newPaint);
                beginRecording.drawRect(new Rect(0, i20 - i, i19, i20), newPaint);
                beginRecording.drawRect(new Rect(0, 0, i32, i20), newPaint);
                beginRecording.drawRect(new Rect(i19 - i7, 0, i19, i20), newPaint);
            }
            i5 = i23;
            i6 = i14;
            i4 = i15;
            if (!this.fp_mode) {
            }
            int i322 = i22;
            beginRecording.drawBitmap(bitmap2, new Rect(i9, i8, i3 + i9, i2 + i8), new Rect(i11, i10, i6 + i11, i4 + i10), App.newPaint());
            Paint newPaint2 = App.newPaint();
            newPaint2.setColor(-1);
            newPaint2.setStyle(Style.FILL);
            beginRecording.drawRect(new Rect(0, 0, i19, i24), newPaint2);
            beginRecording.drawRect(new Rect(0, i20 - i, i19, i20), newPaint2);
            beginRecording.drawRect(new Rect(0, 0, i322, i20), newPaint2);
            beginRecording.drawRect(new Rect(i19 - i7, 0, i19, i20), newPaint2);
        }
        picture.endRecording();
    }

    /* access modifiers changed from: private */
    public Bitmap decodeBitmap(ImgDat imgDat) {
        Bitmap bitmap = null;
        int i = 0;
        boolean z = false;
        while (true) {
            if (i >= 3) {
                break;
            }
            try {
                App.freeMem();
                Options options = new Options();
                options.inPreferredConfig = Config.ARGB_8888;
                options.inDither = false;
                if (i > 0) {
                    options.inSampleSize = 1 << i;
                }
                InputStream fileInputStream = imgDat.dat != null ? new FileInputStream(imgDat.dat) : getContentResolver().openInputStream(imgDat.uri);
                if (fileInputStream != null) {
                    bitmap = BitmapFactory.decodeStream(fileInputStream, null, options);
                    fileInputStream.close();
                }
                tryAllocateBitmap();
            } catch (IOException e) {
                e.printStackTrace();
                App.reportThrowable(e);
            } catch (OutOfMemoryError unused) {
                if (bitmap != null) {
                    bitmap.recycle();
                    bitmap = null;
                }
                if (!z && i > 0) {
                    App.clearExternalBytesAllocated();
                    z = true;
                }
                i++;
            }
        }
        return bitmap;
    }

    private void tryAllocateBitmap() {
        Bitmap createBitmap = Bitmap.createBitmap(512, 512, Config.ARGB_8888);
        if (createBitmap != null) {
            createBitmap.recycle();
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != 3) {
            return;
        }
        if (i2 == -1) {
            this.need_update_pages = true;
            prepareDataFromIntent(intent, false);
            return;
        }
        setResult(0);
        finish();
    }
}
