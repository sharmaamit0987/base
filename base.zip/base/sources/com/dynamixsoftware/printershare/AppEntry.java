package com.dynamixsoftware.printershare;

import com.android.mms.layout.LayoutManager;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.ipp.Base64;
import com.flurry.android.FlurryAgent;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import org.nanohttpd.protocols.http.IHTTPSession;
import org.nanohttpd.protocols.http.NanoHTTPD;
import org.nanohttpd.protocols.http.response.IStatus;
import org.nanohttpd.protocols.http.response.Response;
import org.nanohttpd.protocols.http.response.Status;

public class AppEntry extends App {
    private static NanoHTTPD nanoHTTPD;

    public void onCreate() {
        super.onCreate();
        LayoutManager.init(this);
    }

    /* access modifiers changed from: protected */
    public void onPrinterChanged() {
        Printer printer = ActivityCore.getPrinter();
        if (printer != null) {
            try {
                if (printer.drv_name != null && (printer.drv_name.indexOf("_zpl") > 0 || printer.drv_name.indexOf("_epl") > 0)) {
                    startUPS();
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
                return;
            }
        }
        stopUPS();
    }

    private static void startUPS() {
        NanoHTTPD nanoHTTPD2 = nanoHTTPD;
        if (nanoHTTPD2 == null || !nanoHTTPD2.isAlive()) {
            final MessageFormat messageFormat = new MessageFormat("<!DOCTYPE html>\n<html>\n<head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n    <script>\n        function requestPcl() '{\n            var pclType = document.getElementById(\"thermalPrinterType\").value;\n            var printer = document.getElementById(\"thermalPrinterName\").value;\n            if (pclType) {\n                 var message = {};\n                 message.requestType = \"request\";\n                 message.labelType = pclType;\n                 message.printer = printer;\n                 message.windowName = window.name;\n                 message.version = \"2.0.0\";\n                 window.opener.postMessage(message, \"'{8}'\");\n            }\n        '}\n        function waitForButtonClick() '{\n            var message = {};\n            message.requestType = \"wait\";\n            window.opener.postMessage(message, \"'{8}'\");\n        '}\n        function selectPrinter() '{\n            var selectedPrinter = document.getElementById(\"thermalPrinters\");\n            var printerType = selectedPrinter.value;\n            var printerName = selectedPrinter.options[selectedPrinter.selectedIndex].innerHTML;\n            document.getElementById(\"thermalPrinterType\").value=printerType;\n            document.getElementById(\"thermalPrinterName\").value=printerName;\n            console.log(\"thermalPrinterName selected: \"+ printerName);\n            requestPcl();\n        '}\n        function receiveMessage(event) '{\n            var printRequest = new XMLHttpRequest();\n            var printerName = document.getElementById(\"thermalPrinterName\").value;\n            console.log(\"thermalPrinterName requested: \"+ printerName);\n            var query = \"printerName=\"+ printerName +\"&labelBytes=\"+ event.data;\n            printRequest.onreadystatechange = function () {\n                if (this.readyState === 4) {\n                    var message = {};\n                    message.requestType = \"response\";\n                    message.query = this.response;\n                    window.opener.postMessage(message, \"'{8}'\");\n                }\n            }\n            printRequest.open(\"POST\", \"http://127.0.0.1:'{1}'/print\", true);\n            printRequest.responseType = \"text\";\n            printRequest.setRequestHeader(\"Access-Control-Allow-Origin\", \"http://127.0.0.1:'{1}'\"); \n            printRequest.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\"); \n            printRequest.send(query);\n        '}\n    </script>\n    <title>{7}</title>\n</head>\n<body>\n  <div style=\"font-family:Arial, sans-serif; font-weight:bold; font-size:11px\">\n    {2}<br/><br/>\n    {3} {4}<ul>\n    <li>{5}</li>\n    <li>{6}</li>\n    </ul>\n    <div id=\"thermalPrintersDiv\">\n    <p align=\"right\"><a href=\"javascript:window.close()\"><b>{11}</b></a></p>{0}\n    </div>\n  <div id=\"footerDiv\" style=\"text-align:center; position:fixed; bottom:2%\">\n{10}\n  </div>\n  </div>\n    <script>\n         window.addEventListener(\"message\", receiveMessage, false);\n         {9};\n    </script>\n</body>\n</html>\n");
            AnonymousClass1 r1 = new NanoHTTPD("localhost", 4349) {
                /* JADX WARNING: Removed duplicated region for block: B:26:0x00e2  */
                /* JADX WARNING: Removed duplicated region for block: B:27:0x00e5  */
                /* JADX WARNING: Removed duplicated region for block: B:29:0x00e9  */
                /* JADX WARNING: Removed duplicated region for block: B:30:0x00ec  */
                /* JADX WARNING: Removed duplicated region for block: B:33:0x0145  */
                /* JADX WARNING: Removed duplicated region for block: B:34:0x0148  */
                /* JADX WARNING: Removed duplicated region for block: B:60:0x01fb A[Catch:{ Exception -> 0x0226 }] */
                public Response serve(IHTTPSession iHTTPSession) {
                    Printer printer;
                    boolean z;
                    String name = iHTTPSession.getMethod().name();
                    String uri = iHTTPSession.getUri();
                    String str = "\\ ";
                    if (!"GET".equals(name) || !"/listPrinters".equals(uri)) {
                        if (!"POST".equals(name) || !"/print".equals(uri)) {
                            IHTTPSession iHTTPSession2 = iHTTPSession;
                            return super.serve(iHTTPSession);
                        }
                        try {
                            try {
                                iHTTPSession.parseBody(new HashMap());
                            } catch (Exception e) {
                                e = e;
                            }
                        } catch (Exception e2) {
                            e = e2;
                            IHTTPSession iHTTPSession3 = iHTTPSession;
                            e.printStackTrace();
                            App.reportThrowable(e);
                            Map parms = iHTTPSession.getParms();
                            String str2 = (String) parms.get("printerName");
                            byte[] decode = Base64.decode(((String) parms.get("labelBytes")).replaceAll(str, "+"));
                            printer = ActivityCore.getPrinter();
                            new PrintThread(App.self, printer, new ByteArrayInputStream(decode)).start();
                            Hashtable hashtable = new Hashtable();
                            String str3 = "printer";
                            StringBuilder sb = new StringBuilder();
                            sb.append("[");
                            sb.append((printer.model != null || printer.model.length() <= 0) ? printer.title : printer.model);
                            sb.append("][");
                            sb.append(printer.drv_name);
                            sb.append("]");
                            hashtable.put(str3, sb.toString());
                            if (printer.drv_name != null) {
                            }
                            hashtable.put("country", App.getUserCountry());
                            FlurryAgent.logEvent("print_ups", (Map<String, String>) hashtable);
                            StringBuffer stringBuffer = new StringBuffer();
                            stringBuffer.append("status=");
                            stringBuffer.append("SUCCESS");
                            stringBuffer.append("&name=");
                            stringBuffer.append(URLEncoder.encode(str2));
                            stringBuffer.append("&target=HttpApp");
                            stringBuffer.append("&version=");
                            stringBuffer.append("2.0.0");
                            return Response.newFixedLengthResponse((IStatus) Status.OK, NanoHTTPD.MIME_PLAINTEXT, stringBuffer.toString());
                        }
                        Map parms2 = iHTTPSession.getParms();
                        String str22 = (String) parms2.get("printerName");
                        byte[] decode2 = Base64.decode(((String) parms2.get("labelBytes")).replaceAll(str, "+"));
                        printer = ActivityCore.getPrinter();
                        new PrintThread(App.self, printer, new ByteArrayInputStream(decode2)).start();
                        try {
                            Hashtable hashtable2 = new Hashtable();
                            String str32 = "printer";
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("[");
                            sb2.append((printer.model != null || printer.model.length() <= 0) ? printer.title : printer.model);
                            sb2.append("][");
                            sb2.append(printer.drv_name);
                            sb2.append("]");
                            hashtable2.put(str32, sb2.toString());
                            if (printer.drv_name != null) {
                                String[] split = printer.drv_name.split("\\|");
                                hashtable2.put("driver", "internal".equals(split[0]) ? split[3] : split[0]);
                            }
                            hashtable2.put("country", App.getUserCountry());
                            FlurryAgent.logEvent("print_ups", (Map<String, String>) hashtable2);
                        } catch (Exception e3) {
                            e3.printStackTrace();
                            App.reportThrowable(e3);
                        }
                        StringBuffer stringBuffer2 = new StringBuffer();
                        stringBuffer2.append("status=");
                        stringBuffer2.append("SUCCESS");
                        stringBuffer2.append("&name=");
                        stringBuffer2.append(URLEncoder.encode(str22));
                        stringBuffer2.append("&target=HttpApp");
                        stringBuffer2.append("&version=");
                        stringBuffer2.append("2.0.0");
                        return Response.newFixedLengthResponse((IStatus) Status.OK, NanoHTTPD.MIME_PLAINTEXT, stringBuffer2.toString());
                    }
                    Map parms3 = iHTTPSession.getParms();
                    Locale locale = Locale.US;
                    String str4 = (String) parms3.get("loc");
                    if (str4 != null) {
                        new Locale(str4.substring(0, 2), str4.substring(3));
                    }
                    String str5 = (String) parms3.get("app");
                    if (str5 == null) {
                        str5 = "www";
                    }
                    String str6 = (String) parms3.get("name");
                    String str7 = "labelWindow";
                    if (str6 == null) {
                        str6 = str7;
                    }
                    String str8 = (String) parms3.get("pref");
                    String str9 = (String) parms3.get("edge");
                    StringBuffer stringBuffer3 = new StringBuffer();
                    Printer printer2 = ActivityCore.getPrinter();
                    String str10 = "<input type='hidden' id='thermalPrinterName' value='";
                    String str11 = "<input type='hidden' id='thermalPrinterType' value='";
                    String str12 = "";
                    String str13 = "'></input>\n";
                    if (printer2 != null && printer2.drv_name.indexOf("_zpl") > 0) {
                        stringBuffer3.append(str11);
                        stringBuffer3.append("zpl");
                        stringBuffer3.append(str13);
                        stringBuffer3.append(str10);
                        stringBuffer3.append(printer2.model.replaceAll(str, str12));
                        stringBuffer3.append(str13);
                    } else if (printer2 == null || printer2.drv_name.indexOf("_epl") <= 0) {
                        stringBuffer3.append("No supported thermal printers found.");
                        z = false;
                        boolean equals = str7.equals(str6);
                        String format = MessageFormat.format("Copyright &copy; {0} United Parcel Service of America, Inc. All rights reserved.", new Object[]{"2016"});
                        String str14 = !equals ? "Your labels have been printed to your UPS thermal printer." : "Your documents have been printed to your UPS Thermal Printer.";
                        String str15 = !equals ? "UPS Shipping Label" : "Shipment Receipt";
                        MessageFormat messageFormat = messageFormat;
                        Object[] objArr = new Object[12];
                        objArr[0] = stringBuffer3.toString();
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(str12);
                        sb3.append(4349);
                        objArr[1] = sb3.toString();
                        objArr[2] = "Thanks for shipping with UPS.";
                        objArr[3] = str14;
                        objArr[4] = "If nothing has printed:";
                        objArr[5] = "Confirm you have selected your UPS thermal printer in your printing preferences(see bottom of Complete Shipment page)";
                        objArr[6] = "OR select the Install UPS Thermal Printer Link from Printing Preferences to learn more about installing the thermal printer driver and plugin.";
                        objArr[7] = str15;
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append("https://");
                        sb4.append(str5);
                        sb4.append(".ups.com/*");
                        objArr[8] = sb4.toString();
                        objArr[9] = !z ? "requestPcl()" : "waitForButtonClick()";
                        objArr[10] = format;
                        objArr[11] = "Close Window";
                        return Response.newFixedLengthResponse((IStatus) Status.OK, NanoHTTPD.MIME_HTML, messageFormat.format(objArr));
                    } else {
                        stringBuffer3.append(str11);
                        stringBuffer3.append("epl");
                        stringBuffer3.append(str13);
                        stringBuffer3.append(str10);
                        stringBuffer3.append(printer2.model.replaceAll(str, str12));
                        stringBuffer3.append(str13);
                    }
                    z = true;
                    boolean equals2 = str7.equals(str6);
                    String format2 = MessageFormat.format("Copyright &copy; {0} United Parcel Service of America, Inc. All rights reserved.", new Object[]{"2016"});
                    if (!equals2) {
                    }
                    if (!equals2) {
                    }
                    MessageFormat messageFormat2 = messageFormat;
                    Object[] objArr2 = new Object[12];
                    objArr2[0] = stringBuffer3.toString();
                    StringBuilder sb32 = new StringBuilder();
                    sb32.append(str12);
                    sb32.append(4349);
                    objArr2[1] = sb32.toString();
                    objArr2[2] = "Thanks for shipping with UPS.";
                    objArr2[3] = str14;
                    objArr2[4] = "If nothing has printed:";
                    objArr2[5] = "Confirm you have selected your UPS thermal printer in your printing preferences(see bottom of Complete Shipment page)";
                    objArr2[6] = "OR select the Install UPS Thermal Printer Link from Printing Preferences to learn more about installing the thermal printer driver and plugin.";
                    objArr2[7] = str15;
                    StringBuilder sb42 = new StringBuilder();
                    sb42.append("https://");
                    sb42.append(str5);
                    sb42.append(".ups.com/*");
                    objArr2[8] = sb42.toString();
                    objArr2[9] = !z ? "requestPcl()" : "waitForButtonClick()";
                    objArr2[10] = format2;
                    objArr2[11] = "Close Window";
                    return Response.newFixedLengthResponse((IStatus) Status.OK, NanoHTTPD.MIME_HTML, messageFormat2.format(objArr2));
                }
            };
            nanoHTTPD = r1;
            try {
                r1.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true);
            } catch (IOException e) {
                e.printStackTrace();
                App.reportThrowable(e);
                nanoHTTPD = null;
            }
        }
    }

    private static void stopUPS() {
        NanoHTTPD nanoHTTPD2 = nanoHTTPD;
        if (nanoHTTPD2 != null) {
            nanoHTTPD2.stop();
            nanoHTTPD = null;
        }
    }
}
