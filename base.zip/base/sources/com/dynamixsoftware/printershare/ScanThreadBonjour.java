package com.dynamixsoftware.printershare;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dynamixsoftware.printershare.App.NetworkInterfaceData;
import com.dynamixsoftware.printershare.data.Printer;
import com.dynamixsoftware.printershare.data.User;
import com.dynamixsoftware.printershare.data.XmlUtil;
import com.dynamixsoftware.printershare.mdns.DnsRecordService;
import com.dynamixsoftware.printershare.mdns.DnsRecordText;
import com.flurry.android.Constants;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ScanThreadBonjour extends Thread {
    /* access modifiers changed from: private */
    public static final String[] SRV_LST = {"_pdl-datastream._tcp.local.", "_canon-bjnp1._tcp.local.", "_printer._tcp.local.", "_ipp._tcp.local.", "_ipps._tcp.local.", "_printershare._tcp.local."};
    /* access modifiers changed from: private */
    public boolean[] destroyed = new boolean[1];
    /* access modifiers changed from: private */
    public ArrayList<DatagramPacket> packets = new ArrayList<>();
    private Vector<Printer> printers;
    /* access modifiers changed from: private */
    public String rq_pid;
    private Thread sender = new Thread() {
        /* JADX WARNING: Code restructure failed: missing block: B:112:0x00d1, code lost:
            continue;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x002c, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$400(r12.this$0) == null) goto L_0x0042;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x003e, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$400(r12.this$0).indexOf(com.dynamixsoftware.printershare.ScanThreadBonjour.access$300()[r2]) >= 0) goto L_0x0042;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x0042, code lost:
            r3 = new com.dynamixsoftware.printershare.mdns.DnsPacketOut(0, false);
            r3.addQuestion(new com.dynamixsoftware.printershare.mdns.DnsQuestion(com.dynamixsoftware.printershare.ScanThreadBonjour.access$300()[r2], 12, 1));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x005f, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$500(r12.this$0).size() <= 1) goto L_0x0062;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x0062, code lost:
            r6 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x006d, code lost:
            if (r6 >= com.dynamixsoftware.printershare.ScanThreadBonjour.access$500(r12.this$0).size()) goto L_0x00d1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x006f, code lost:
            r4 = com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x0075, code lost:
            monitor-enter(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x007e, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0)[0] == false) goto L_0x0082;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x0080, code lost:
            monitor-exit(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x0081, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x0082, code lost:
            monitor-exit(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
            r4 = (com.dynamixsoftware.printershare.ScanThreadBonjour.SocketThread) com.dynamixsoftware.printershare.ScanThreadBonjour.access$500(r12.this$0).get(r6);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x0091, code lost:
            if (r4.ia == null) goto L_0x00b1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:38:0x009b, code lost:
            if (r4.ia.getAddress().length == 4) goto L_0x00b1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:39:0x009d, code lost:
            r7 = r3.createPacket();
            r7.setAddress(java.net.InetAddress.getByName(com.dynamixsoftware.printershare.mdns.DnsConstants.MDNS_GROUP_IPV6));
            r7.setPort(com.dynamixsoftware.printershare.mdns.DnsConstants.MDNS_PORT);
            r4.send(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:0x00b1, code lost:
            r7 = r3.createPacket();
            r7.setAddress(java.net.InetAddress.getByName(com.dynamixsoftware.printershare.mdns.DnsConstants.MDNS_GROUP));
            r7.setPort(com.dynamixsoftware.printershare.mdns.DnsConstants.MDNS_PORT);
            r4.send(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x00c4, code lost:
            r6 = r6 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x00ca, code lost:
            r3 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:48:0x00cb, code lost:
            r3.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r3);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x00d8, code lost:
            r2 = com.dynamixsoftware.printershare.App.getBroadcastAdrresses();
            r3 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x00e2, code lost:
            if (r3 >= com.dynamixsoftware.printershare.ScanThreadBonjour.access$300().length) goto L_0x0174;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x00e4, code lost:
            r7 = com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:0x00ea, code lost:
            monitor-enter(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:61:0x00f3, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0)[0] == false) goto L_0x00f7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:62:0x00f5, code lost:
            monitor-exit(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:63:0x00f6, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:64:0x00f7, code lost:
            monitor-exit(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:67:0x00fe, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$400(r12.this$0) == null) goto L_0x0113;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:69:0x0110, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$400(r12.this$0).indexOf(com.dynamixsoftware.printershare.ScanThreadBonjour.access$300()[r3]) >= 0) goto L_0x0113;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:71:0x0113, code lost:
            r7 = (com.dynamixsoftware.printershare.ScanThreadBonjour.SocketThread) com.dynamixsoftware.printershare.ScanThreadBonjour.access$500(r12.this$0).get(0);
            r8 = new com.dynamixsoftware.printershare.mdns.DnsPacketOut(0, false);
            r8.addQuestion(new com.dynamixsoftware.printershare.mdns.DnsQuestion(com.dynamixsoftware.printershare.ScanThreadBonjour.access$300()[r3], 12, 1));
            r9 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:73:0x0137, code lost:
            if (r9 >= r2.size()) goto L_0x016d;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:74:0x0139, code lost:
            r10 = com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:75:0x013f, code lost:
            monitor-enter(r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:78:0x0148, code lost:
            if (com.dynamixsoftware.printershare.ScanThreadBonjour.access$000(r12.this$0)[0] == false) goto L_0x014c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:79:0x014a, code lost:
            monitor-exit(r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:80:0x014b, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:81:0x014c, code lost:
            monitor-exit(r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:83:?, code lost:
            r10 = r8.createPacket();
            r10.setAddress((java.net.InetAddress) r2.get(r9));
            r10.setPort(com.dynamixsoftware.printershare.mdns.DnsConstants.MDNS_PORT);
            r7.send(r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:84:0x0160, code lost:
            r9 = r9 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:90:0x0166, code lost:
            r7 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:91:0x0167, code lost:
            r7.printStackTrace();
            com.dynamixsoftware.printershare.App.reportThrowable(r7);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:99:?, code lost:
            java.lang.Thread.sleep(1000);
         */
        public void run() {
            int i = 0;
            while (i < 3) {
                int i2 = 0;
                while (true) {
                    int i3 = 1;
                    if (i2 >= ScanThreadBonjour.SRV_LST.length) {
                        break;
                    }
                    synchronized (ScanThreadBonjour.this.destroyed) {
                        if (ScanThreadBonjour.this.destroyed[0]) {
                            return;
                        }
                    }
                    i2++;
                }
                while (true) {
                }
            }
            return;
            i++;
            int i4 = i4 + 1;
        }
    };
    /* access modifiers changed from: private */
    public ArrayList<SocketThread> sockets = new ArrayList<>();
    private Handler status;
    /* access modifiers changed from: private */
    public int timeout;

    class SocketThread extends Thread {
        InetAddress ia;
        NetworkInterface ni;
        MulticastSocket socket;

        SocketThread(InetAddress inetAddress, NetworkInterface networkInterface) throws IOException {
            this.ia = inetAddress;
            this.ni = networkInterface;
            MulticastSocket multicastSocket = new MulticastSocket(new InetSocketAddress(inetAddress, 0));
            this.socket = multicastSocket;
            if (networkInterface != null) {
                multicastSocket.setNetworkInterface(networkInterface);
            }
            try {
                this.socket.setTimeToLive(255);
            } catch (Exception e) {
                e.printStackTrace();
                App.reportThrowable(e);
            }
            try {
                this.socket.setLoopbackMode(true);
            } catch (Exception e2) {
                e2.printStackTrace();
                App.reportThrowable(e2);
            }
        }

        public void run() {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                while (true) {
                    synchronized (ScanThreadBonjour.this.destroyed) {
                        if (ScanThreadBonjour.this.destroyed[0]) {
                            break;
                        }
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        if (currentTimeMillis2 >= ((long) ScanThreadBonjour.this.timeout)) {
                            break;
                        }
                        this.socket.setSoTimeout((int) (((long) ScanThreadBonjour.this.timeout) - currentTimeMillis2));
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[4096], 4096);
                        try {
                            this.socket.receive(datagramPacket);
                            synchronized (ScanThreadBonjour.this.packets) {
                                ScanThreadBonjour.this.packets.add(datagramPacket);
                                ScanThreadBonjour.this.packets.notifyAll();
                            }
                        } catch (SocketTimeoutException unused) {
                        } catch (IOException e) {
                            synchronized (ScanThreadBonjour.this.destroyed) {
                                if (!ScanThreadBonjour.this.destroyed[0]) {
                                    throw e;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    App.reportThrowable(e2);
                } catch (Throwable th) {
                    this.socket.close();
                    throw th;
                }
            }
            this.socket.close();
            synchronized (ScanThreadBonjour.this.packets) {
                ScanThreadBonjour.this.packets.notifyAll();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x001d, code lost:
            if (r3.socket.isClosed() == false) goto L_0x0021;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0020, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
            r3.socket.send(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
            java.lang.Thread.sleep(100);
         */
        public synchronized void send(DatagramPacket datagramPacket) {
            try {
                synchronized (ScanThreadBonjour.this.destroyed) {
                    if (ScanThreadBonjour.this.destroyed[0]) {
                        return;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                StringBuilder sb = new StringBuilder();
                sb.append("src: ");
                sb.append(this.socket.getLocalAddress());
                sb.append(" dst: ");
                sb.append(datagramPacket.getAddress());
                sb.append(" | ");
                sb.append(this.ia);
                sb.append(" | ");
                sb.append(this.ni);
                App.reportThrowable(e, sb.toString());
            }
            return;
        }

        public void interrupt() {
            super.interrupt();
            this.socket.close();
        }
    }

    public ScanThreadBonjour(Context context, int i, String str, Handler handler) {
        this.timeout = i;
        this.status = handler;
        this.rq_pid = str;
        this.printers = new Vector<>();
    }

    public Vector<Printer> getPrinters() {
        return this.printers;
    }

    public void destroy() {
        int i;
        synchronized (this.destroyed) {
            this.destroyed[0] = true;
        }
        for (i = 0; i < this.sockets.size(); i++) {
            ((SocketThread) this.sockets.get(i)).interrupt();
        }
        interrupt();
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: type inference failed for: r5v1, types: [java.net.InetAddress, java.net.NetworkInterface] */
    /* JADX WARNING: type inference failed for: r8v0 */
    /* JADX WARNING: type inference failed for: r8v1 */
    /* JADX WARNING: type inference failed for: r19v0 */
    /* JADX WARNING: type inference failed for: r5v3, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r2v6, types: [java.util.Hashtable] */
    /* JADX WARNING: type inference failed for: r8v2 */
    /* JADX WARNING: type inference failed for: r5v4 */
    /* JADX WARNING: type inference failed for: r2v7, types: [java.util.Hashtable] */
    /* JADX WARNING: type inference failed for: r12v5, types: [java.lang.Object[]] */
    /* JADX WARNING: type inference failed for: r19v2 */
    /* JADX WARNING: type inference failed for: r18v1 */
    /* JADX WARNING: type inference failed for: r12v6 */
    /* JADX WARNING: type inference failed for: r8v3 */
    /* JADX WARNING: type inference failed for: r5v5 */
    /* JADX WARNING: type inference failed for: r6v1 */
    /* JADX WARNING: type inference failed for: r19v3 */
    /* JADX WARNING: type inference failed for: r2v10 */
    /* JADX WARNING: type inference failed for: r18v2 */
    /* JADX WARNING: type inference failed for: r2v11 */
    /* JADX WARNING: type inference failed for: r8v4 */
    /* JADX WARNING: type inference failed for: r5v6 */
    /* JADX WARNING: type inference failed for: r2v13 */
    /* JADX WARNING: type inference failed for: r2v14 */
    /* JADX WARNING: type inference failed for: r18v3 */
    /* JADX WARNING: type inference failed for: r2v15 */
    /* JADX WARNING: type inference failed for: r18v4 */
    /* JADX WARNING: type inference failed for: r18v5 */
    /* JADX WARNING: type inference failed for: r18v6 */
    /* JADX WARNING: type inference failed for: r18v7 */
    /* JADX WARNING: type inference failed for: r18v8 */
    /* JADX WARNING: type inference failed for: r18v9 */
    /* JADX WARNING: type inference failed for: r18v10 */
    /* JADX WARNING: type inference failed for: r18v11 */
    /* JADX WARNING: type inference failed for: r19v4 */
    /* JADX WARNING: type inference failed for: r18v12 */
    /* JADX WARNING: type inference failed for: r6v13 */
    /* JADX WARNING: type inference failed for: r5v62 */
    /* JADX WARNING: type inference failed for: r12v13 */
    /* JADX WARNING: type inference failed for: r8v74 */
    /* JADX WARNING: type inference failed for: r19v5 */
    /* JADX WARNING: type inference failed for: r18v13 */
    /* JADX WARNING: type inference failed for: r6v15 */
    /* JADX WARNING: type inference failed for: r19v6 */
    /* JADX WARNING: type inference failed for: r18v14 */
    /* JADX WARNING: type inference failed for: r6v16 */
    /* JADX WARNING: type inference failed for: r6v17 */
    /* JADX WARNING: type inference failed for: r19v7 */
    /* JADX WARNING: type inference failed for: r18v15 */
    /* JADX WARNING: type inference failed for: r14v8 */
    /* JADX WARNING: type inference failed for: r16v8 */
    /* JADX WARNING: type inference failed for: r4v76 */
    /* JADX WARNING: type inference failed for: r19v8 */
    /* JADX WARNING: type inference failed for: r18v16 */
    /* JADX WARNING: type inference failed for: r12v14 */
    /* JADX WARNING: type inference failed for: r8v75 */
    /* JADX WARNING: type inference failed for: r19v9 */
    /* JADX WARNING: type inference failed for: r18v17 */
    /* JADX WARNING: type inference failed for: r6v18 */
    /* JADX WARNING: type inference failed for: r19v10 */
    /* JADX WARNING: type inference failed for: r18v18 */
    /* JADX WARNING: type inference failed for: r19v11 */
    /* JADX WARNING: type inference failed for: r18v19 */
    /* JADX WARNING: type inference failed for: r6v19 */
    /* JADX WARNING: type inference failed for: r19v12 */
    /* JADX WARNING: type inference failed for: r18v20 */
    /* JADX WARNING: type inference failed for: r12v15 */
    /* JADX WARNING: type inference failed for: r8v76 */
    /* JADX WARNING: type inference failed for: r19v13 */
    /* JADX WARNING: type inference failed for: r18v21 */
    /* JADX WARNING: type inference failed for: r6v27 */
    /* JADX WARNING: type inference failed for: r19v14 */
    /* JADX WARNING: type inference failed for: r18v22 */
    /* JADX WARNING: type inference failed for: r19v15 */
    /* JADX WARNING: type inference failed for: r18v23 */
    /* JADX WARNING: type inference failed for: r19v16 */
    /* JADX WARNING: type inference failed for: r18v24 */
    /* JADX WARNING: type inference failed for: r19v17 */
    /* JADX WARNING: type inference failed for: r18v25 */
    /* JADX WARNING: type inference failed for: r6v55 */
    /* JADX WARNING: type inference failed for: r19v18 */
    /* JADX WARNING: type inference failed for: r18v26 */
    /* JADX WARNING: type inference failed for: r19v19 */
    /* JADX WARNING: type inference failed for: r18v27 */
    /* JADX WARNING: type inference failed for: r18v28 */
    /* JADX WARNING: type inference failed for: r19v20 */
    /* JADX WARNING: type inference failed for: r19v21 */
    /* JADX WARNING: type inference failed for: r19v22 */
    /* JADX WARNING: type inference failed for: r19v23 */
    /* JADX WARNING: type inference failed for: r19v24 */
    /* JADX WARNING: type inference failed for: r19v25 */
    /* JADX WARNING: type inference failed for: r19v26 */
    /* JADX WARNING: type inference failed for: r19v27 */
    /* JADX WARNING: type inference failed for: r18v29 */
    /* JADX WARNING: type inference failed for: r6v70 */
    /* JADX WARNING: type inference failed for: r19v28 */
    /* JADX WARNING: type inference failed for: r18v30 */
    /* JADX WARNING: type inference failed for: r8v102, types: [java.lang.String] */
    /* JADX WARNING: type inference failed for: r8v104 */
    /* JADX WARNING: type inference failed for: r5v82 */
    /* JADX WARNING: type inference failed for: r2v63 */
    /* JADX WARNING: type inference failed for: r8v110 */
    /* JADX WARNING: type inference failed for: r8v111 */
    /* JADX WARNING: type inference failed for: r8v112 */
    /* JADX WARNING: type inference failed for: r5v83 */
    /* JADX WARNING: type inference failed for: r2v64 */
    /* JADX WARNING: type inference failed for: r12v44 */
    /* JADX WARNING: type inference failed for: r19v29 */
    /* JADX WARNING: type inference failed for: r18v31 */
    /* JADX WARNING: type inference failed for: r12v45 */
    /* JADX WARNING: type inference failed for: r8v113 */
    /* JADX WARNING: type inference failed for: r19v30 */
    /* JADX WARNING: type inference failed for: r2v65 */
    /* JADX WARNING: type inference failed for: r2v66 */
    /* JADX WARNING: type inference failed for: r2v67 */
    /* JADX WARNING: type inference failed for: r2v68 */
    /* JADX WARNING: type inference failed for: r2v69 */
    /* JADX WARNING: type inference failed for: r18v32 */
    /* JADX WARNING: type inference failed for: r5v84 */
    /* JADX WARNING: type inference failed for: r2v70 */
    /* JADX WARNING: type inference failed for: r2v71 */
    /* JADX WARNING: type inference failed for: r18v33 */
    /* JADX WARNING: type inference failed for: r18v34 */
    /* JADX WARNING: type inference failed for: r18v35 */
    /* JADX WARNING: type inference failed for: r18v36 */
    /* JADX WARNING: type inference failed for: r18v37 */
    /* JADX WARNING: type inference failed for: r18v38 */
    /* JADX WARNING: type inference failed for: r18v39 */
    /* JADX WARNING: type inference failed for: r18v40 */
    /* JADX WARNING: type inference failed for: r18v41 */
    /* JADX WARNING: type inference failed for: r18v42 */
    /* JADX WARNING: type inference failed for: r18v43 */
    /* JADX WARNING: type inference failed for: r18v44 */
    /* JADX WARNING: type inference failed for: r18v45 */
    /* JADX WARNING: type inference failed for: r18v46 */
    /* JADX WARNING: type inference failed for: r18v47 */
    /* JADX WARNING: type inference failed for: r18v48 */
    /* JADX WARNING: type inference failed for: r18v49 */
    /* JADX WARNING: type inference failed for: r18v50 */
    /* JADX WARNING: type inference failed for: r19v31 */
    /* JADX WARNING: type inference failed for: r18v51 */
    /* JADX WARNING: type inference failed for: r19v32 */
    /* JADX WARNING: type inference failed for: r18v52 */
    /* JADX WARNING: type inference failed for: r6v71 */
    /* JADX WARNING: type inference failed for: r19v33 */
    /* JADX WARNING: type inference failed for: r18v53 */
    /* JADX WARNING: type inference failed for: r6v72 */
    /* JADX WARNING: type inference failed for: r19v34 */
    /* JADX WARNING: type inference failed for: r19v35 */
    /* JADX WARNING: type inference failed for: r18v54 */
    /* JADX WARNING: type inference failed for: r19v36 */
    /* JADX WARNING: type inference failed for: r18v55 */
    /* JADX WARNING: type inference failed for: r6v73 */
    /* JADX WARNING: type inference failed for: r6v74 */
    /* JADX WARNING: type inference failed for: r19v37 */
    /* JADX WARNING: type inference failed for: r18v56 */
    /* JADX WARNING: type inference failed for: r19v38 */
    /* JADX WARNING: type inference failed for: r19v39 */
    /* JADX WARNING: type inference failed for: r19v40 */
    /* JADX WARNING: type inference failed for: r19v41 */
    /* JADX WARNING: type inference failed for: r19v42 */
    /* JADX WARNING: type inference failed for: r18v57 */
    /* JADX WARNING: type inference failed for: r18v58 */
    /* JADX WARNING: type inference failed for: r18v59 */
    /* JADX WARNING: type inference failed for: r18v60 */
    /* JADX WARNING: type inference failed for: r18v61 */
    /* JADX WARNING: type inference failed for: r6v75 */
    /* JADX WARNING: type inference failed for: r19v43 */
    /* JADX WARNING: type inference failed for: r18v62 */
    /* JADX WARNING: type inference failed for: r19v44 */
    /* JADX WARNING: type inference failed for: r18v63 */
    /* JADX WARNING: type inference failed for: r19v45 */
    /* JADX WARNING: type inference failed for: r18v64 */
    /* JADX WARNING: type inference failed for: r19v46 */
    /* JADX WARNING: type inference failed for: r18v65 */
    /* JADX WARNING: type inference failed for: r6v76 */
    /* JADX WARNING: type inference failed for: r19v47 */
    /* JADX WARNING: type inference failed for: r18v66 */
    /* JADX WARNING: type inference failed for: r18v67 */
    /* JADX WARNING: type inference failed for: r18v68 */
    /* JADX WARNING: type inference failed for: r18v69 */
    /* JADX WARNING: type inference failed for: r19v48 */
    /* JADX WARNING: type inference failed for: r19v49 */
    /* JADX WARNING: type inference failed for: r8v114 */
    /* JADX WARNING: Code restructure failed: missing block: B:100:0x01ae, code lost:
        r6 = r5;
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x01b5, code lost:
        r4 = r15.getAnswers();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x01b9, code lost:
        r15 = 0;
        r19 = r19;
        r18 = r18;
        r12 = r12;
        r8 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x01be, code lost:
        if (r15 >= r4.size()) goto L_0x03e3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x01c0, code lost:
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecord) r4.get(r15);
        r6 = r5.getType();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:0x01ca, code lost:
        if (r6 == r3) goto L_0x0270;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x01ce, code lost:
        if (r6 == 12) goto L_0x02e7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x01d2, code lost:
        if (r6 == 16) goto L_0x0278;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:113:0x01d6, code lost:
        if (r6 == 28) goto L_0x0270;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x01da, code lost:
        if (r6 == 33) goto L_0x01e5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x01dc, code lost:
        r17 = r4;
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:0x01e5, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:?, code lost:
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecordService) r5;
        r3 = r5.getName();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x01f0, code lost:
        r17 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x01f3, code lost:
        if (r14.getAddress().length != 4) goto L_0x0200;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x01f5, code lost:
        r4 = "4:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:123:0x0200, code lost:
        r4 = "6:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:?, code lost:
        r4 = r4.concat(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x0206, code lost:
        r18 = r12;
        r6 = 0;
        r19 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x0209, code lost:
        r18 = r18;
        r19 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x020c, code lost:
        if (r6 >= SRV_LST.length) goto L_0x0260;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x0216, code lost:
        if (r3.endsWith(SRV_LST[r6]) == false) goto L_0x025b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x021a, code lost:
        if (r1.rq_pid == null) goto L_0x024f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x0222, code lost:
        if (r3.equals(r1.rq_pid) != false) goto L_0x024f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x022a, code lost:
        if (r3.endsWith("_printershare._tcp.local.") == false) goto L_0x0260;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:139:0x0234, code lost:
        if (r1.rq_pid.endsWith("_printershare._tcp.local.") == false) goto L_0x0260;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:141:0x023a, code lost:
        r19 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:142:0x023e, code lost:
        r19 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:144:0x024c, code lost:
        if (r3.equals(r1.rq_pid.substring(r1.rq_pid.indexOf("@") + 1)) == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:146:0x024f, code lost:
        r19 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:148:0x0255, code lost:
        if (r7.get(r4) != null) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:0x0257, code lost:
        r7.put(r4, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:150:0x025b, code lost:
        r19 = r8;
        r6 = r6 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x0260, code lost:
        r19 = r8;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x0264, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:153:0x0265, code lost:
        r19 = r8;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x0269, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:155:0x026a, code lost:
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x0270, code lost:
        r17 = r4;
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:157:0x0278, code lost:
        r17 = r4;
        r19 = r8;
        r18 = r12;
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecordText) r5;
        r3 = r5.getName();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x028a, code lost:
        if (r14.getAddress().length != 4) goto L_0x028f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:159:0x028c, code lost:
        r4 = "4:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x028f, code lost:
        r4 = "6:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:0x0291, code lost:
        r4 = r4.concat(r3);
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:0x0299, code lost:
        if (r6 >= SRV_LST.length) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:165:0x02a3, code lost:
        if (r3.endsWith(SRV_LST[r6]) == false) goto L_0x02e4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:167:0x02a7, code lost:
        if (r1.rq_pid == null) goto L_0x02d9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x02af, code lost:
        if (r3.equals(r1.rq_pid) != false) goto L_0x02d9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x02b7, code lost:
        if (r3.endsWith("_printershare._tcp.local.") == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:173:0x02c1, code lost:
        if (r1.rq_pid.endsWith("_printershare._tcp.local.") == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x02d7, code lost:
        if (r3.equals(r1.rq_pid.substring(r1.rq_pid.indexOf("@") + 1)) == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x02dd, code lost:
        if (r9.get(r4) != null) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x02df, code lost:
        r9.put(r4, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:179:0x02e4, code lost:
        r6 = r6 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:180:0x02e7, code lost:
        r17 = r4;
        r19 = r8;
        r18 = r12;
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecordPointer) r5;
        r3 = r5.getAlias();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x02f9, code lost:
        if (r14.getAddress().length != 4) goto L_0x02fe;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:182:0x02fb, code lost:
        r4 = "4:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:0x02fe, code lost:
        r4 = "6:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x0300, code lost:
        r4 = r4.concat(r3);
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x0308, code lost:
        if (r6 >= SRV_LST.length) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:188:0x0312, code lost:
        if (r3.endsWith(SRV_LST[r6]) == false) goto L_0x0353;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:190:0x0316, code lost:
        if (r1.rq_pid == null) goto L_0x0348;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:192:0x031e, code lost:
        if (r3.equals(r1.rq_pid) != false) goto L_0x0348;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:194:0x0326, code lost:
        if (r3.endsWith("_printershare._tcp.local.") == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:196:0x0330, code lost:
        if (r1.rq_pid.endsWith("_printershare._tcp.local.") == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:198:0x0346, code lost:
        if (r3.equals(r1.rq_pid.substring(r1.rq_pid.indexOf("@") + 1)) == false) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:200:0x034c, code lost:
        if (r2.get(r4) != null) goto L_0x01e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:201:0x034e, code lost:
        r2.put(r4, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:202:0x0353, code lost:
        r6 = r6 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:0x0356, code lost:
        r0 = e;
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:204:0x0357, code lost:
        r3 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:205:0x0358, code lost:
        r19 = r19;
        r18 = r18;
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:208:?, code lost:
        r3 = ((com.dynamixsoftware.printershare.mdns.DnsRecordAddress) r5).getName();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:210:0x0368, code lost:
        if (r14.getAddress().length != 4) goto L_0x036d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:211:0x036a, code lost:
        r4 = "4:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:212:0x036d, code lost:
        r4 = "6:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:214:?, code lost:
        r3 = r4.concat(r3);
        r4 = ((com.dynamixsoftware.printershare.mdns.DnsRecordAddress) r5).getAddress();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:215:0x0383, code lost:
        if (r14.getAddress().length == r4.getAddress().length) goto L_0x0387;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:216:0x0385, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:218:0x038d, code lost:
        if (r4.getAddress().length == 4) goto L_0x03a6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:220:0x0393, code lost:
        if (r4.isLinkLocalAddress() == false) goto L_0x03a6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:224:?, code lost:
        r4 = java.net.Inet6Address.getByAddress(null, r4.getAddress(), ((java.net.Inet6Address) r14).getScopeId());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:226:0x03a7, code lost:
        r5 = (java.util.Vector) r10.get(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:227:0x03ad, code lost:
        if (r5 != null) goto L_0x03b7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:228:0x03af, code lost:
        r5 = new java.util.Vector();
        r10.put(r3, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:229:0x03b7, code lost:
        r3 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:231:0x03bc, code lost:
        if (r3 >= r5.size()) goto L_0x03cd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:233:0x03c6, code lost:
        if (r4.equals(r5.get(r3)) == false) goto L_0x03ca;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:234:0x03c8, code lost:
        r3 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:235:0x03ca, code lost:
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:236:0x03cd, code lost:
        r3 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:237:0x03ce, code lost:
        if (r3 == false) goto L_0x03d3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:238:0x03d0, code lost:
        r5.add(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:239:0x03d3, code lost:
        r15 = r15 + 1;
        r4 = r17;
        r12 = r18;
        r8 = r19;
        r3 = 1;
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:240:0x03df, code lost:
        r0 = e;
        r19 = r19;
        r18 = r18;
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:241:0x03e1, code lost:
        r0 = e;
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:242:0x03e3, code lost:
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:243:0x03e9, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:244:0x03ea, code lost:
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:245:0x03ee, code lost:
        r19 = r19;
        r18 = r18;
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:246:0x03f0, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:247:0x03f1, code lost:
        r6 = r5;
        r19 = r8;
        r18 = r12;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:248:0x03f6, code lost:
        r3 = r0;
        r19 = r19;
        r18 = r18;
        r6 = r6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:249:0x03f7, code lost:
        r3.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:268:?, code lost:
        r4 = (java.lang.String) r3.nextElement();
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecordService) r7.get(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:269:0x0434, code lost:
        if (r5 != null) goto L_0x0453;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:271:0x0440, code lost:
        if (r11.contains("srv:".concat(r4)) != false) goto L_0x0453;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:272:0x0442, code lost:
        r11.add("srv:".concat(r4));
        new com.dynamixsoftware.printershare.ScanThreadBonjour.AnonymousClass2(r1).start();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:274:0x0459, code lost:
        if (((com.dynamixsoftware.printershare.mdns.DnsRecordText) r9.get(r4)) != null) goto L_0x0478;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:276:0x0465, code lost:
        if (r11.contains("txt:".concat(r4)) != false) goto L_0x0478;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:277:0x0467, code lost:
        r11.add("txt:".concat(r4));
        new com.dynamixsoftware.printershare.ScanThreadBonjour.AnonymousClass3(r1).start();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:278:0x0478, code lost:
        if (r5 == null) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:280:0x0480, code lost:
        if (r4.startsWith("4:") == false) goto L_0x04b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:281:0x0482, code lost:
        r4 = "4:".concat(r5.getServer());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:282:0x0492, code lost:
        if (((java.util.Vector) r10.get(r4)) != null) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:284:0x049e, code lost:
        if (r11.contains("adl:".concat(r4)) != false) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:285:0x04a0, code lost:
        r11.add("adl:".concat(r4));
        new com.dynamixsoftware.printershare.ScanThreadBonjour.AnonymousClass4(r1).start();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:286:0x04b3, code lost:
        r4 = "6:".concat(r5.getServer());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:287:0x04c3, code lost:
        if (((java.util.Vector) r10.get(r4)) != null) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:289:0x04cf, code lost:
        if (r11.contains("adl:".concat(r4)) != false) goto L_0x0414;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:290:0x04d1, code lost:
        r11.add("adl:".concat(r4));
        new com.dynamixsoftware.printershare.ScanThreadBonjour.AnonymousClass5(r1).start();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:291:0x04e4, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:292:0x04e5, code lost:
        r4 = r0;
        r4.printStackTrace();
        com.dynamixsoftware.printershare.App.reportThrowable(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:309:0x050a, code lost:
        r4 = (java.lang.String) r3.nextElement();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:310:0x0516, code lost:
        if (r4.endsWith(" (2)._printershare._tcp.local.") == false) goto L_0x0519;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:311:0x0519, code lost:
        r5 = (com.dynamixsoftware.printershare.mdns.DnsRecordService) r7.get(r4);
        r8 = (com.dynamixsoftware.printershare.mdns.DnsRecordText) r9.get(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:312:0x0525, code lost:
        if (r8 != null) goto L_0x0528;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:314:0x052e, code lost:
        if (r4.startsWith("4:") == false) goto L_0x0533;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:315:0x0530, code lost:
        r4 = "4:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:316:0x0533, code lost:
        r4 = "6:";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:317:0x0535, code lost:
        r4 = (java.util.Vector) r10.get(r4.concat(r5.getServer()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:318:0x0543, code lost:
        if (r4 == null) goto L_0x04f6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:320:0x0549, code lost:
        if (r4.size() != 0) goto L_0x054c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:321:0x054c, code lost:
        r12 = 0;
        r2 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:640:0x03fd, code lost:
        r19 = r19;
        r18 = r18;
        r6 = r6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:642:0x03fd, code lost:
        r6 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:644:0x03d3, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:645:0x03d3, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:646:0x03d3, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:650:0x01e2, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:652:0x01e2, code lost:
        r19 = r19;
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:674:0x04f6, code lost:
        r2 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:675:0x04f6, code lost:
        r2 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:676:0x04f6, code lost:
        r2 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:677:0x04f6, code lost:
        r2 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:684:0x0a59, code lost:
        r18 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:?, code lost:
        r14 = ((java.net.DatagramPacket) r12[r13]).getAddress();
        r15 = new com.dynamixsoftware.printershare.mdns.DnsPacketIn((java.net.DatagramPacket) r12[r13]);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x01ac, code lost:
        if (r15.isResponse() != false) goto L_0x01b5;
     */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r5v1, types: [java.net.InetAddress, java.net.NetworkInterface]
  assigns: [?[int, float, boolean, short, byte, char, OBJECT, ARRAY]]
  uses: [?[OBJECT, ARRAY], java.net.InetAddress, java.net.NetworkInterface]
  mth insns count: 1188
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Removed duplicated region for block: B:259:0x041a  */
    /* JADX WARNING: Removed duplicated region for block: B:301:0x04fc  */
    /* JADX WARNING: Removed duplicated region for block: B:552:0x0a05 A[Catch:{ all -> 0x0a39, Exception -> 0x0a3d }] */
    /* JADX WARNING: Removed duplicated region for block: B:553:0x0a06 A[Catch:{ all -> 0x0a39, Exception -> 0x0a3d }] */
    /* JADX WARNING: Removed duplicated region for block: B:556:0x0a11 A[SYNTHETIC, Splitter:B:556:0x0a11] */
    /* JADX WARNING: Removed duplicated region for block: B:630:0x0a86 A[EDGE_INSN: B:630:0x0a86->B:600:0x0a86 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:631:0x0a6e A[EDGE_INSN: B:631:0x0a6e->B:589:0x0a6e ?: BREAK  
EDGE_INSN: B:631:0x0a6e->B:589:0x0a6e ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:638:0x040d A[EDGE_INSN: B:638:0x040d->B:256:0x040d ?: BREAK  
EDGE_INSN: B:638:0x040d->B:256:0x040d ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:659:0x04f2 A[EDGE_INSN: B:659:0x04f2->B:298:0x04f2 ?: BREAK  
EDGE_INSN: B:659:0x04f2->B:298:0x04f2 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0184  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0188  */
    /* JADX WARNING: Unknown variable types count: 61 */
    public void run() {
        Exception exc;
        ? r8;
        Hashtable hashtable;
        ? r5;
        ? array;
        int i;
        ? r19;
        ? r18;
        ? r12;
        ? r82;
        ? r52;
        ? r192;
        Enumeration keys;
        Enumeration keys2;
        DnsRecordText dnsRecordText;
        ? r182;
        DnsRecordService dnsRecordService;
        DnsRecordText dnsRecordText2;
        Vector vector;
        int i2;
        Hashtable hashtable2;
        DnsRecordService dnsRecordService2;
        Vector vector2;
        Enumeration enumeration;
        ? r183;
        ? r184;
        Exception exc2;
        ? r185;
        ? r186;
        ? r187;
        ? r188;
        ? r189;
        ? r1810;
        boolean z;
        String str;
        Hashtable<String, String> hashtable3;
        String str2;
        String str3;
        Printer printer;
        String clearPrinterModelName;
        int i3;
        byte[] bArr;
        String str4;
        String str5;
        Throwable th;
        ? r193;
        ? r1811;
        ? r6;
        Message message = new Message();
        int i4 = 1;
        message.what = 1;
        char c = 0;
        message.arg1 = 0;
        this.status.sendMessage(message);
        synchronized (this.destroyed) {
            th = 0;
            try {
                Vector activeNetworkInterfaces = App.getActiveNetworkInterfaces();
                if (activeNetworkInterfaces == null || activeNetworkInterfaces.size() != 0) {
                    SocketThread socketThread = new SocketThread(th, th);
                    socketThread.start();
                    this.sockets.add(socketThread);
                    if (activeNetworkInterfaces != null) {
                        for (int i5 = 0; i5 < activeNetworkInterfaces.size(); i5++) {
                            NetworkInterfaceData networkInterfaceData = (NetworkInterfaceData) activeNetworkInterfaces.get(i5);
                            if (networkInterfaceData.is_multicast) {
                                if (networkInterfaceData.ipv4_addresses != null) {
                                    for (int i6 = 0; i6 < networkInterfaceData.ipv4_addresses.size(); i6++) {
                                        try {
                                            SocketThread socketThread2 = new SocketThread((InetAddress) networkInterfaceData.ipv4_addresses.get(i6), networkInterfaceData.iface);
                                            socketThread2.start();
                                            this.sockets.add(socketThread2);
                                        } catch (Exception e) {
                                            Exception exc3 = e;
                                            exc3.printStackTrace();
                                            StringBuilder sb = new StringBuilder();
                                            sb.append("ip: ");
                                            sb.append(networkInterfaceData.ipv4_addresses.get(i6));
                                            sb.append(" iface: ");
                                            sb.append(networkInterfaceData.iface);
                                            App.reportThrowable(exc3, sb.toString());
                                        }
                                    }
                                }
                                if (networkInterfaceData.ipv6_linklocal_address != null) {
                                    try {
                                        SocketThread socketThread3 = new SocketThread(networkInterfaceData.ipv6_linklocal_address, networkInterfaceData.iface);
                                        socketThread3.start();
                                        this.sockets.add(socketThread3);
                                    } catch (Exception e2) {
                                        Exception exc4 = e2;
                                        exc4.printStackTrace();
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append("ip: ");
                                        sb2.append(networkInterfaceData.ipv6_linklocal_address);
                                        sb2.append(" iface: ");
                                        sb2.append(networkInterfaceData.iface);
                                        App.reportThrowable(exc4, sb2.toString());
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Message message2 = new Message();
                    message2.what = 4;
                    message2.arg1 = 0;
                    this.status.sendMessage(message2);
                    return;
                }
            } catch (Exception th2) {
                exc.printStackTrace();
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Internal Error: ");
                sb3.append(exc.getMessage());
                ? sb4 = sb3.toString();
                App.reportThrowable(exc);
                r8 = sb4;
            } finally {
                while (true) {
                    exc = th2;
                }
            }
        }
        printer.title = r3;
        if (clearPrinterModelName != null) {
            clearPrinterModelName = "";
        }
        printer.model = clearPrinterModelName;
        printer.location = str;
        printer.capabilities = hashtable3;
        synchronized (this.printers) {
            this.printers.add(printer);
        }
        Message message3 = new Message();
        message3.what = 2;
        message3.arg1 = 0;
        this.status.sendMessage(message3);
        if (this.rq_pid != null && this.rq_pid.equals(printer.id)) {
            destroy();
            r183 = r1810;
        }
        i2++;
        r2 = r183;
        keys2 = enumeration;
        vector = vector2;
        dnsRecordService = dnsRecordService2;
        hashtable = hashtable2;
        dnsRecordText2 = dnsRecordText;
        while (true) {
            if (i < r12.length) {
                break;
            }
            synchronized (this.destroyed) {
                try {
                    if (this.destroyed[c]) {
                    }
                } catch (Throwable th3) {
                    while (true) {
                        throw th3;
                    }
                }
            }
            i++;
            r52 = r6;
            r12 = r1811;
            r82 = r193;
            i4 = 1;
            c = 0;
            r19 = r193;
            r18 = r1811;
        }
        ? r62 = r52;
        r192 = r82;
        keys = r2.keys();
        while (true) {
            if (keys.hasMoreElements()) {
                break;
            }
            synchronized (this.destroyed) {
                try {
                    if (this.destroyed[0]) {
                    }
                } catch (Throwable th4) {
                    while (true) {
                        throw th4;
                    }
                }
            }
        }
        keys2 = hashtable.keys();
        r2 = r2;
        while (true) {
            if (keys2.hasMoreElements()) {
                break;
            }
            synchronized (this.destroyed) {
                try {
                    if (this.destroyed[0]) {
                    }
                } finally {
                    while (true) {
                        Throwable th5 = th;
                    }
                }
            }
            r2 = r2;
        }
        r182 = r2;
        r2 = r182;
        r8 = r192;
        hashtable = hashtable;
        i4 = 1;
        c = 0;
        r5 = 0;
        hashtable2 = hashtable;
        dnsRecordText = dnsRecordText2;
        r183 = r1810;
        i2++;
        r2 = r183;
        keys2 = enumeration;
        vector = vector2;
        dnsRecordService = dnsRecordService2;
        hashtable = hashtable2;
        dnsRecordText2 = dnsRecordText;
        if (r8 == 0) {
            ? hashtable4 = new Hashtable();
            hashtable = new Hashtable();
            Hashtable hashtable5 = new Hashtable();
            Hashtable hashtable6 = new Hashtable();
            HashSet hashSet = new HashSet();
            this.sender.start();
            r5 = th2;
            r2 = hashtable4;
            while (true) {
                synchronized (this.destroyed) {
                    try {
                        if (this.destroyed[c]) {
                            r8 = r8;
                            break;
                        }
                        while (true) {
                            synchronized (this.packets) {
                                try {
                                    if (this.packets.size() != 0) {
                                        break;
                                    }
                                    int i7 = 0;
                                    for (int i8 = 0; i8 < this.sockets.size(); i8++) {
                                        if (((SocketThread) this.sockets.get(i8)).isAlive()) {
                                            i7++;
                                        }
                                    }
                                    if (i7 != this.sockets.size()) {
                                        if (i7 <= 0) {
                                            break;
                                        }
                                        Thread.yield();
                                    } else {
                                        try {
                                            this.packets.wait();
                                            break;
                                        } catch (InterruptedException unused) {
                                        }
                                    }
                                } catch (Throwable th6) {
                                    while (true) {
                                        throw th6;
                                    }
                                }
                            }
                        }
                        array = this.packets.toArray();
                        this.packets.clear();
                        if (array.length != 0) {
                            r8 = r8;
                            break;
                        }
                        i = 0;
                        r82 = r8;
                        r52 = r5;
                        r12 = array;
                        r19 = r192;
                        r18 = r182;
                        while (true) {
                            if (i < r12.length) {
                            }
                            i++;
                            r52 = r6;
                            r12 = r1811;
                            r82 = r193;
                            i4 = 1;
                            c = 0;
                            r19 = r193;
                            r18 = r1811;
                        }
                        ? r622 = r52;
                        r192 = r82;
                        keys = r2.keys();
                        while (true) {
                            if (keys.hasMoreElements()) {
                            }
                        }
                        keys2 = hashtable.keys();
                        r2 = r2;
                        while (true) {
                            if (keys2.hasMoreElements()) {
                            }
                            r2 = r2;
                        }
                        r182 = r2;
                        r2 = r182;
                        r8 = r192;
                        hashtable = hashtable;
                        i4 = 1;
                        c = 0;
                        r5 = 0;
                    } catch (Throwable th7) {
                        while (true) {
                            throw th7;
                        }
                    }
                }
            }
        }
        ? r194 = r8;
        synchronized (this.destroyed) {
            try {
                this.destroyed[0] = true;
            } catch (Throwable th8) {
                while (true) {
                    throw th8;
                }
            }
        }
        if (r194 != 0) {
            Message message4 = new Message();
            message4.what = 3;
            message4.arg1 = 0;
            Bundle bundle = new Bundle();
            bundle.putString("message", r194);
            message4.setData(bundle);
            this.status.sendMessage(message4);
        } else {
            Message message5 = new Message();
            message5.what = 4;
            message5.arg1 = 0;
            this.status.sendMessage(message5);
        }
        return;
        while (i2 < vector.size()) {
            try {
                String name = dnsRecordService.getName();
                String server = dnsRecordService.getServer();
                int port = dnsRecordService.getPort();
                InetAddress inetAddress = (InetAddress) vector.get(i2);
                String hostAddress = inetAddress.getHostAddress();
                try {
                    enumeration = keys2;
                    if (inetAddress.getAddress().length != 4) {
                        try {
                            StringBuilder sb5 = new StringBuilder();
                            sb5.append("[");
                            sb5.append(hostAddress);
                            sb5.append("]");
                            hostAddress = sb5.toString();
                        } catch (Exception e3) {
                            exc2 = e3;
                            vector2 = vector;
                            dnsRecordService2 = dnsRecordService;
                            hashtable2 = hashtable;
                            dnsRecordText = dnsRecordText2;
                            r184 = r1810;
                            exc2.printStackTrace();
                            App.reportThrowable(exc2);
                            r183 = r184;
                            i2++;
                            r2 = r183;
                            keys2 = enumeration;
                            vector = vector2;
                            dnsRecordService = dnsRecordService2;
                            hashtable = hashtable2;
                            dnsRecordText2 = dnsRecordText;
                        }
                    }
                    int i9 = 0;
                    while (true) {
                        try {
                            if (i9 >= this.printers.size()) {
                                vector2 = vector;
                                dnsRecordService2 = dnsRecordService;
                                z = false;
                                break;
                            }
                            try {
                                if (((Printer) this.printers.get(i9)).direct_address.indexOf(hostAddress) > 0) {
                                    if (name.equals(((Printer) this.printers.get(i9)).id)) {
                                        vector2 = vector;
                                        dnsRecordService2 = dnsRecordService;
                                        break;
                                    } else if (name.endsWith("_printershare._tcp.local.")) {
                                        vector2 = vector;
                                        try {
                                            if (((Printer) this.printers.get(i9)).id.endsWith("_printershare._tcp.local.")) {
                                                dnsRecordService2 = dnsRecordService;
                                                try {
                                                    if (name.equals(((Printer) this.printers.get(i9)).id.substring(((Printer) this.printers.get(i9)).id.indexOf("@") + 1))) {
                                                        break;
                                                    }
                                                    i9++;
                                                    vector = vector2;
                                                    dnsRecordService = dnsRecordService2;
                                                } catch (Exception e4) {
                                                    e = e4;
                                                }
                                            }
                                            dnsRecordService2 = dnsRecordService;
                                            i9++;
                                            vector = vector2;
                                            dnsRecordService = dnsRecordService2;
                                        } catch (Exception e5) {
                                            e = e5;
                                            dnsRecordService2 = dnsRecordService;
                                            exc2 = e;
                                            hashtable2 = hashtable;
                                            dnsRecordText = dnsRecordText2;
                                            r184 = r1810;
                                            exc2.printStackTrace();
                                            App.reportThrowable(exc2);
                                            r183 = r184;
                                            i2++;
                                            r2 = r183;
                                            keys2 = enumeration;
                                            vector = vector2;
                                            dnsRecordService = dnsRecordService2;
                                            hashtable = hashtable2;
                                            dnsRecordText2 = dnsRecordText;
                                        }
                                    }
                                }
                                vector2 = vector;
                                dnsRecordService2 = dnsRecordService;
                                i9++;
                                vector = vector2;
                                dnsRecordService = dnsRecordService2;
                            } catch (Exception e6) {
                                e = e6;
                                vector2 = vector;
                                dnsRecordService2 = dnsRecordService;
                                exc2 = e;
                                hashtable2 = hashtable;
                                dnsRecordText = dnsRecordText2;
                                r184 = r1810;
                                exc2.printStackTrace();
                                App.reportThrowable(exc2);
                                r183 = r184;
                                i2++;
                                r2 = r183;
                                keys2 = enumeration;
                                vector = vector2;
                                dnsRecordService = dnsRecordService2;
                                hashtable = hashtable2;
                                dnsRecordText2 = dnsRecordText;
                            }
                        } catch (Exception e7) {
                            e = e7;
                            r188 = r1810;
                            vector2 = vector;
                            dnsRecordService2 = dnsRecordService;
                            r187 = r188;
                            hashtable2 = hashtable;
                            r186 = r187;
                            dnsRecordText = dnsRecordText2;
                            r185 = r186;
                            exc2 = e;
                            r184 = r185;
                            exc2.printStackTrace();
                            App.reportThrowable(exc2);
                            r183 = r184;
                            i2++;
                            r2 = r183;
                            keys2 = enumeration;
                            vector = vector2;
                            dnsRecordService = dnsRecordService2;
                            hashtable = hashtable2;
                            dnsRecordText2 = dnsRecordText;
                        }
                    }
                    z = true;
                    if (!z) {
                        try {
                            int indexOf = server.indexOf(".");
                            if (indexOf > 0) {
                                server = server.substring(0, indexOf);
                            }
                            if (name.endsWith("_printershare._tcp.local.")) {
                                try {
                                    if (inetAddress.getAddress().length == 4) {
                                        if (port == 25654) {
                                            port = 13924;
                                        }
                                        StringBuilder sb6 = new StringBuilder();
                                        sb6.append("http://");
                                        sb6.append(hostAddress);
                                        sb6.append(":");
                                        sb6.append(port);
                                        sb6.append("/printers");
                                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb6.toString()).openConnection();
                                        httpURLConnection.setConnectTimeout(3000);
                                        httpURLConnection.setReadTimeout(3000);
                                        httpURLConnection.setDoInput(true);
                                        httpURLConnection.setDoOutput(false);
                                        httpURLConnection.setUseCaches(false);
                                        httpURLConnection.setRequestMethod("GET");
                                        httpURLConnection.setRequestProperty("Connection", "close");
                                        if (httpURLConnection.getResponseCode() == 200) {
                                            Element firstElement = XmlUtil.getFirstElement(XmlUtil.getDocument(httpURLConnection.getInputStream()).getDocumentElement(), "printers");
                                            if (this.printers != null) {
                                                NodeList elementsByTagName = firstElement.getElementsByTagName("printer");
                                                int length = elementsByTagName.getLength();
                                                int i10 = 0;
                                                while (i10 < length) {
                                                    Element element = (Element) elementsByTagName.item(i10);
                                                    NodeList nodeList = elementsByTagName;
                                                    Printer printer2 = new Printer();
                                                    printer2.readFromXml(element);
                                                    StringBuilder sb7 = new StringBuilder();
                                                    th = length;
                                                    sb7.append(printer2.id);
                                                    sb7.append("@");
                                                    sb7.append(name);
                                                    printer2.id = sb7.toString();
                                                    StringBuilder sb8 = new StringBuilder();
                                                    sb8.append("ptp://");
                                                    sb8.append(hostAddress);
                                                    sb8.append(":");
                                                    sb8.append(port);
                                                    printer2.direct_address = sb8.toString();
                                                    printer2.owner = new User();
                                                    printer2.owner.name = server;
                                                    synchronized (this.printers) {
                                                        this.printers.add(printer2);
                                                    }
                                                    Message message6 = new Message();
                                                    message6.what = 2;
                                                    message6.arg1 = 0;
                                                    this.status.sendMessage(message6);
                                                    if (this.rq_pid != null && this.rq_pid.equals(printer2.id)) {
                                                        destroy();
                                                    }
                                                    i10++;
                                                    elementsByTagName = nodeList;
                                                }
                                            }
                                        }
                                    }
                                } catch (Exception th9) {
                                    th.printStackTrace();
                                    App.reportThrowable(th);
                                } finally {
                                    while (true) {
                                        th = th9;
                                    }
                                }
                            } else {
                                String str6 = "";
                                str = "";
                                String str7 = "";
                                String str8 = "";
                                hashtable3 = new Hashtable<>();
                                String str9 = str6;
                                byte[] text = dnsRecordText2.getText();
                                if (text != null) {
                                    String str10 = str;
                                    String str11 = str7;
                                    int i11 = 0;
                                    while (true) {
                                        if (i11 >= text.length) {
                                            hashtable2 = hashtable;
                                            break;
                                        }
                                        int i12 = i11 + 1;
                                        byte b = text[i11] & Constants.UNKNOWN;
                                        hashtable2 = hashtable;
                                        try {
                                            if (i12 >= text.length) {
                                                break;
                                            }
                                            byte b2 = b;
                                            if (i12 + b > text.length) {
                                                try {
                                                    i3 = text.length - i12;
                                                } catch (Exception e8) {
                                                    exc2 = e8;
                                                    dnsRecordText = dnsRecordText2;
                                                    r184 = r1810;
                                                    exc2.printStackTrace();
                                                    App.reportThrowable(exc2);
                                                    r183 = r184;
                                                    i2++;
                                                    r2 = r183;
                                                    keys2 = enumeration;
                                                    vector = vector2;
                                                    dnsRecordService = dnsRecordService2;
                                                    hashtable = hashtable2;
                                                    dnsRecordText2 = dnsRecordText;
                                                }
                                            } else {
                                                i3 = b2;
                                            }
                                            dnsRecordText = dnsRecordText2;
                                            try {
                                                String str12 = new String(text, i12, i3, "UTF-8");
                                                int indexOf2 = str12.indexOf("=");
                                                if (indexOf2 < 0) {
                                                    bArr = text;
                                                    str4 = str12;
                                                } else {
                                                    bArr = text;
                                                    str4 = str12.substring(0, indexOf2);
                                                }
                                                if (indexOf2 < 0) {
                                                    str5 = "";
                                                } else {
                                                    str5 = str12.substring(indexOf2 + 1);
                                                }
                                                if ("rp".equals(str4)) {
                                                    str8 = str5.trim();
                                                } else if ("ty".equals(str4)) {
                                                    str9 = str5.trim();
                                                } else if ("note".equals(str4)) {
                                                    str10 = str5.trim();
                                                } else if ("product".equals(str4)) {
                                                    str11 = str5.trim();
                                                }
                                                hashtable3.put(str4, str5);
                                                i11 = i3 + i12;
                                                hashtable = hashtable2;
                                                dnsRecordText2 = dnsRecordText;
                                                text = bArr;
                                            } catch (Exception e9) {
                                                e = e9;
                                                r185 = r1810;
                                            } catch (Throwable th10) {
                                                while (true) {
                                                }
                                                throw th10;
                                            }
                                        } catch (Exception e10) {
                                            e = e10;
                                            r186 = r1810;
                                            dnsRecordText = dnsRecordText2;
                                            r185 = r186;
                                            exc2 = e;
                                            r184 = r185;
                                            exc2.printStackTrace();
                                            App.reportThrowable(exc2);
                                            r183 = r184;
                                            i2++;
                                            r2 = r183;
                                            keys2 = enumeration;
                                            vector = vector2;
                                            dnsRecordService = dnsRecordService2;
                                            hashtable = hashtable2;
                                            dnsRecordText2 = dnsRecordText;
                                        }
                                    }
                                    dnsRecordText = dnsRecordText2;
                                    str2 = str8;
                                    str = str10;
                                    str7 = str11;
                                } else {
                                    hashtable2 = hashtable;
                                    dnsRecordText = dnsRecordText2;
                                    str2 = str8;
                                }
                                String lowerCase = str7.toLowerCase();
                                if (lowerCase.indexOf("gpl") >= 0 || lowerCase.indexOf("cups") >= 0 || lowerCase.indexOf("generic") >= 0 || lowerCase.indexOf("gutenprint") >= 0 || lowerCase.indexOf("foomatic") >= 0 || lowerCase.indexOf("ghostscript") >= 0) {
                                    str7 = "";
                                }
                                if (!str2.startsWith("/")) {
                                    StringBuilder sb9 = new StringBuilder();
                                    sb9.append("/");
                                    sb9.append(str2);
                                    str2 = sb9.toString();
                                }
                                if (name.indexOf("._ipps") > 0) {
                                    if (port == 0) {
                                        port = 631;
                                    }
                                    StringBuilder sb10 = new StringBuilder();
                                    sb10.append("ipps://");
                                    sb10.append(hostAddress);
                                    sb10.append(":");
                                    sb10.append(port);
                                    sb10.append(str2);
                                    str3 = sb10.toString();
                                } else if (name.indexOf("._ipp") > 0) {
                                    if (port == 0) {
                                        port = 631;
                                    }
                                    StringBuilder sb11 = new StringBuilder();
                                    sb11.append("ipp://");
                                    sb11.append(hostAddress);
                                    sb11.append(":");
                                    sb11.append(port);
                                    sb11.append(str2);
                                    str3 = sb11.toString();
                                } else if (name.indexOf("._pdl") > 0) {
                                    if (port == 0) {
                                        port = 9100;
                                    }
                                    StringBuilder sb12 = new StringBuilder();
                                    sb12.append("pdl://");
                                    sb12.append(hostAddress);
                                    sb12.append(":");
                                    sb12.append(port);
                                    str3 = sb12.toString();
                                } else if (name.indexOf("._printer") > 0) {
                                    if (port == 0) {
                                        port = 515;
                                    }
                                    StringBuilder sb13 = new StringBuilder();
                                    sb13.append("lpd://");
                                    sb13.append(hostAddress);
                                    sb13.append(":");
                                    sb13.append(port);
                                    sb13.append(str2);
                                    str3 = sb13.toString();
                                } else if (name.indexOf("._canon-bjnp1") > 0) {
                                    StringBuilder sb14 = new StringBuilder();
                                    sb14.append("bjnp://");
                                    sb14.append(hostAddress);
                                    sb14.append(":");
                                    sb14.append(port);
                                    str3 = sb14.toString();
                                } else {
                                    r183 = r1810;
                                    i2++;
                                    r2 = r183;
                                    keys2 = enumeration;
                                    vector = vector2;
                                    dnsRecordService = dnsRecordService2;
                                    hashtable = hashtable2;
                                    dnsRecordText2 = dnsRecordText;
                                }
                                printer = new Printer();
                                printer.owner = new User();
                                printer.id = name;
                                printer.direct_address = str3;
                                int indexOf3 = name.indexOf("._ipp");
                                if (indexOf3 < 0) {
                                    indexOf3 = name.indexOf("._pdl");
                                }
                                if (indexOf3 < 0) {
                                    indexOf3 = name.indexOf("._printer");
                                }
                                if (indexOf3 < 0) {
                                    indexOf3 = name.indexOf("._canon-bjnp1");
                                }
                                if (indexOf3 < 0) {
                                    r183 = r1810;
                                } else {
                                    String trim = name.substring(0, indexOf3).trim();
                                    int indexOf4 = trim.indexOf("@");
                                    if (indexOf4 > 0) {
                                        str9 = trim.substring(0, indexOf4).trim();
                                        trim = trim.substring(indexOf4 + 1).trim();
                                        printer.owner.name = trim;
                                    } else {
                                        String str13 = (String) hashtable3.get("inetname");
                                        if (str13 == null) {
                                            printer.owner.name = server;
                                        } else {
                                            printer.owner.name = str13;
                                        }
                                    }
                                    String str14 = str9;
                                    if ("".equals(str14)) {
                                        str14 = str7;
                                    }
                                    if (!"".equals(str14)) {
                                        trim = str14;
                                    }
                                    String clearPrinterModelName2 = App.clearPrinterModelName(trim);
                                    if ("".equals(str7) || clearPrinterModelName2.endsWith(str7)) {
                                        str7 = clearPrinterModelName2;
                                    }
                                    clearPrinterModelName = App.clearPrinterModelName(str7);
                                    String str15 = (String) hashtable3.get("usb_CMD");
                                    if (str15 != null && str15.startsWith("MFG:")) {
                                        try {
                                            int indexOf5 = str15.indexOf("CMD:");
                                            int indexOf6 = str15.indexOf(";", indexOf5 + 1);
                                            if (indexOf6 < 0) {
                                                indexOf6 = str15.length();
                                            }
                                            if (indexOf5 > 0) {
                                                hashtable3.put("usb_CMD", str15.substring(indexOf5 + 4, indexOf6));
                                            }
                                        } catch (Exception e11) {
                                            Exception exc5 = e11;
                                            exc5.printStackTrace();
                                            App.reportThrowable(exc5);
                                        }
                                    }
                                    printer.title = clearPrinterModelName2;
                                    if (clearPrinterModelName != null) {
                                    }
                                    printer.model = clearPrinterModelName;
                                    printer.location = str;
                                    printer.capabilities = hashtable3;
                                    synchronized (this.printers) {
                                    }
                                    Message message32 = new Message();
                                    message32.what = 2;
                                    message32.arg1 = 0;
                                    this.status.sendMessage(message32);
                                    destroy();
                                    r183 = r1810;
                                }
                                i2++;
                                r2 = r183;
                                keys2 = enumeration;
                                vector = vector2;
                                dnsRecordService = dnsRecordService2;
                                hashtable = hashtable2;
                                dnsRecordText2 = dnsRecordText;
                            }
                        } catch (Exception e12) {
                            e = e12;
                            r187 = r1810;
                            hashtable2 = hashtable;
                            r186 = r187;
                            dnsRecordText = dnsRecordText2;
                            r185 = r186;
                            exc2 = e;
                            r184 = r185;
                            exc2.printStackTrace();
                            App.reportThrowable(exc2);
                            r183 = r184;
                            i2++;
                            r2 = r183;
                            keys2 = enumeration;
                            vector = vector2;
                            dnsRecordService = dnsRecordService2;
                            hashtable = hashtable2;
                            dnsRecordText2 = dnsRecordText;
                        }
                    }
                    hashtable2 = hashtable;
                    dnsRecordText = dnsRecordText2;
                    r183 = r1810;
                } catch (Exception e13) {
                    e = e13;
                    r189 = r1810;
                    enumeration = keys2;
                    r188 = r189;
                    vector2 = vector;
                    dnsRecordService2 = dnsRecordService;
                    r187 = r188;
                    hashtable2 = hashtable;
                    r186 = r187;
                    dnsRecordText = dnsRecordText2;
                    r185 = r186;
                    exc2 = e;
                    r184 = r185;
                    exc2.printStackTrace();
                    App.reportThrowable(exc2);
                    r183 = r184;
                    i2++;
                    r2 = r183;
                    keys2 = enumeration;
                    vector = vector2;
                    dnsRecordService = dnsRecordService2;
                    hashtable = hashtable2;
                    dnsRecordText2 = dnsRecordText;
                }
            } catch (Exception e14) {
                e = e14;
                r189 = r2;
                enumeration = keys2;
                r188 = r189;
                vector2 = vector;
                dnsRecordService2 = dnsRecordService;
                r187 = r188;
                hashtable2 = hashtable;
                r186 = r187;
                dnsRecordText = dnsRecordText2;
                r185 = r186;
                exc2 = e;
                r184 = r185;
                exc2.printStackTrace();
                App.reportThrowable(exc2);
                r183 = r184;
                i2++;
                r2 = r183;
                keys2 = enumeration;
                vector = vector2;
                dnsRecordService = dnsRecordService2;
                hashtable = hashtable2;
                dnsRecordText2 = dnsRecordText;
            }
            i2++;
            r2 = r183;
            keys2 = enumeration;
            vector = vector2;
            dnsRecordService = dnsRecordService2;
            hashtable = hashtable2;
            dnsRecordText2 = dnsRecordText;
        }
        r2 = r2;
        r2 = r2;
        array = this.packets.toArray();
        this.packets.clear();
        if (array.length != 0) {
        }
    }
}
