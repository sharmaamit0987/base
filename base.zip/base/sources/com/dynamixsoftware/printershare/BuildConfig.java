package com.dynamixsoftware.printershare;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.dynamixsoftware.printershare";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "printershareGoogle";
    public static final String FLAVOR_base = "printershare";
    public static final String FLAVOR_store = "google";
    public static final int VERSION_CODE = 410;
    public static final String VERSION_NAME = "11.30.0";
}
